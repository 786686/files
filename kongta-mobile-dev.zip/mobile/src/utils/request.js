import axios from "axios";
import { Toast } from "vant";
import store from "@/store";
import qs from "qs";

/**
 * 自定义Axios实例
 */
const Axios = axios.create({
  baseURL: process.env.VUE_APP_URL,
  timeout: 30000,
  withCredentials: true,
  headers: { "Content-Type": "application/x-www-form-urlencoded;charset=utf-8" }
});

// 添加请求拦截器
Axios.interceptors.request.use(
  config => {
    if (localStorage.accessToken) {
      config.headers.accessToken = localStorage.accessToken;
    }
    return config;
  },
  error => {
    console.log(error);
    return Promise.reject("网络出错");
  }
);

// 添加响应拦截器
Axios.interceptors.response.use(
  function(response) {
    // 对响应数据做点什么
    const { code, msg } = response.data;
    if (code !== 200 && code !== 0) {
      Toast.fail(msg);
    }
    // 登录失效
    if (code === 401) {
      store.dispatch("GET_WX_REDIRECT");
    }
    return response.data;
  },
  function(error) {
    // 对响应错误做点什么，比如400、401、402等等
    if (error && error.response) {
      console.log(error.response);
    }
    return Promise.reject(error);
  }
);

// 定义对外Get、Post、File请求
export default {
  get(url, param = {}, headers = {}) {
    return Axios.get(url, {
      params: param,
      headers
    });
  },
  post(url, param = null, headers = {}) {
    return Axios.post(url, qs.stringify(param), {
      headers
    });
  },
  put(url, param = null, headers = {}) {
    return Axios.put(url, param, {
      headers
    });
  },
  file(url, param = null, headers = {}) {
    return Axios.post(url, param, {
      headers: Object.assign(
        {
          "Content-Type": "multipart/form-data"
        },
        headers
      )
    });
  },
  delete(url, param = null, headers = {}) {
    return Axios.delete(url, {
      param,
      headers: Object.assign(
        {
          "Content-Type": "multipart/form-data"
        },
        headers
      )
    });
  }
};
