import Vue from "vue";
import Router from "vue-router";
import Home from "@/views/Home/Home.vue";
import store from "@/store";

Vue.use(Router);

const router = new Router({
  routes: [
    {
      path: "/",
      name: "home",
      component: Home
    },
    {
      path: "/record",
      name: "record",
      component: () =>
        import(/* webpackChunkName: "record" */ "@/views/Record/Record.vue")
    },
    {
      path: "/my",
      name: "my",
      component: () => import(/* webpackChunkName: "my" */ "@/views/My/My.vue")
    },
    {
      path: "/RepairSearch",
      name: "RepairSearch",
      component: () =>
        import(
          /* webpackChunkName: "record" */ "@/views/RepairSearch/RepairSearch.vue"
        )
    },
    {
      path: "/InsureSearch",
      name: "RepairSearch",
      component: () =>
        import(
          /* webpackChunkName: "record" */ "@/views/InsureSearch/InsureSearch.vue"
        )
    },
    {
      path: "/RepairDetail",
      name: "RepairDetail",
      component: () =>
        import(
          /* webpackChunkName: "record" */ "@/views/RepairDetail/RepairDetail.vue"
        )
    },
    {
      path: "/InsureDetail",
      name: "InsureDetail",
      component: () =>
        import(
          /* webpackChunkName: "record" */ "@/views/InsureDetail/InsureDetail.vue"
        )
    },
    {
      path: "/OrderDetail",
      name: "OrderDetail",
      component: () =>
        import(
          /* webpackChunkName: "record" */ "@/views/OrderDetail/OrderDetail.vue"
        )
    },
    {
      path: "/BindPhone",
      name: "BindPhone",
      component: () =>
        import(/* webpackChunkName: "my" */ "@/views/BindPhone/BindPhone.vue")
    },
    {
      path: "/ChangePhone",
      name: "ChangePhone",
      component: () =>
        import(
          /* webpackChunkName: "my" */ "@/views/ChangePhone/ChangePhone.vue"
        )
    },
    {
      path: "/Recharge",
      name: "Recharge",
      component: () =>
        import(/* webpackChunkName: "my" */ "@/views/Recharge/Recharge.vue")
    },
    {
      path: "/PayMent",
      name: "PayMent",
      component: () =>
        import(/* webpackChunkName: "my" */ "@/views/PayMent/PayMent.vue")
    }
  ]
});
router.beforeEach(async (to, from, next) => {
  await store.dispatch("JUDGE_ROUTER_DIRECTION", to.path);
  next();
});
export default router;
