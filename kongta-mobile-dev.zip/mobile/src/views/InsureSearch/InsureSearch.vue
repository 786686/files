<template>
  <div class="repair-search">
    <swiper :bannerList="bannerList"></swiper>
    <div class="wirte-info">
      <p class="tips">温馨提示：资料填写越完整，查询成功率越高哦</p>
      <div class="info-box">
        <van-cell-group :border="false">
          <van-field
            v-model="vin"
            clearable
            label="车架号"
            placeholder="请输入车架号"
          >
            <!-- <i slot="button" class="iconfont iconxiangji" @click="getCode"></i> -->
          </van-field>
          <van-field
            v-model="band"
            label="品牌选择"
            placeholder="请选择品牌"
            @click="bandSelectVisiable = true"
            readonly
          />
          <van-field
            v-model="engineNumber"
            label="发动机号"
            placeholder="请输入完整发动机号"
          />
          <van-field style="display: none" />
          <!-- 占位 -->
        </van-cell-group>
      </div>
      <div class="agreement-choose">
        <van-checkbox
          v-model="checked"
          checked-color="#f88706"
          icon-size="12"
          shape="square"
        ></van-checkbox>
        <p class="checked-text">
          我已阅读且同意
          <span class="agreement">《维保出险VIN查询服务协议》</span>
        </p>
      </div>
      <div class="btn-groud">
        <van-button plain type="primary" @click="toDetail"
          >查看样例报告</van-button
        >
        <van-button
          plain
          type="primary"
          :class="{ 'now-check': !isEnough }"
          @click="toPayment"
          >立即查询</van-button
        >
      </div>
    </div>
    <div class="record-box">
      <record-list
        :recordList="recordList"
        :type="1"
        @loadList="getOrderList"
        :finished="finished"
        :loading="loading"
      ></record-list>
    </div>
    <van-action-sheet
      v-model="bandSelectVisiable"
      :round="false"
      name="brandName"
      :actions="bandList"
      @select="onSelect"
    />
  </div>
</template>
<script>
import swiper from "@/components/swiper";
import recordList from "@/components/recordList";
import Order from "@/api/order";
import { Toast } from "vant";
import { mapState } from "vuex";
export default {
  name: "RepairSearch",
  components: { swiper, recordList },
  data() {
    return {
      vin: "",
      brand: "",
      engineNumber: "",
      checked: false,
      pageNum: 1,
      pageSize: 10,
      finished: false,
      loading: false,
      recordList: [],
      isEnough: false,
      bandList: [],
      bandSelectVisiable: false,
      band: "",
      price: ""
    };
  },
  computed: {
    ...mapState(["bannerList", "userId"])
  },
  created() {
    this.getBandList();
  },
  methods: {
    // 获取品牌列表
    async getBandList() {
      const { data, code } = await Order.getBandList();
      if (code === 200) {
        this.bandList = data.map(item => {
          return {
            brandId: item.brandId,
            name: item.brandName,
            cxAddPrices: item.cxAddPrices,
            cxPrices: item.cxPrices,
            delStatus: item.delStatus,
            wbAddPrices: item.wbAddPrices,
            wbPrices: item.wbPrices
          };
        });
      }
    },
    // 跳转支付
    toPayment() {
      this.getCXPrices(0);
    },
    // 获取出险记录价格
    async getCXPrices() {
      await this.verificationFn();
      const params = { vin: this.vin, id: this.userId };
      const { data, code } = await Order.getCXPrices(params);
      if (code === 200) {
        const query = {
          type: 2,
          vin: this.vin,
          price: data.price,
          red_money: data.red_mony,
          band: this.band,
          engineNumber: this.engineNumber
        };
        this.$router.push({ path: "/payMent", query });
      }
    },
    // 校验
    verificationFn() {
      return new Promise(resolve => {
        if (!this.vin) return Toast("请输入车架号");
        if (!this.checked) return Toast("请查看服务协议");
        resolve();
      });
    },
    // 获取记录列表
    async getOrderList() {
      this.loading = true;
      this.finished = false;
      const params = {
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        type: this.orderType,
        content: this.content,
        id: this.userId,
        type: 2
      };
      const { data, code } = await Order.orderList(params);
      data ? (this.loading = false) : "";
      if (code === 200) {
        this.recordList = [...this.recordList, ...data.list];
        this.pageNum++;
        if (this.recordList.length >= data.Total) {
          this.finished = true;
        }
      }
    },
    toDetail() {
      this.$router.push("/InsureDetail");
    },
    getCode() {
      Toast(`哈哈`);
    },
    //  选择品牌
    onSelect(item) {
      this.band = item.name;
      this.bandSelectVisiable = false;
    }
  }
};
</script>
<style lang="scss" scoped>
.repair-search {
  background-color: #f2f2f2;
  .wirte-info {
    padding: 20px 28px 46px;
    background-color: #fff;
    .iconxiangji {
      font-size: 50px;
    }
    .tips {
      font-size: 22px;
      color: #f88706;
      padding-bottom: 20px;
    }
    .info-box {
      .van-cell {
        line-height: 90px;
        font-size: 30px;
        font-weight: 500;
        color: #333;
        .band {
          >>> .van-cell__value {
            color: red;
          }
        }
        &:first-of-type {
          /deep/.van-field__label {
            position: relative;
            width: 190px;
            &::after {
              content: "*";
              color: #f88706;
            }
          }
        }
        /deep/.van-field__label {
          width: 190px;
        }
        /deep/ .van-field__right-icon .van-icon {
          font-size: 40px;
        }
        /deep/ .van-field__control {
          line-height: 40px;
          height: 90px;
        }
      }
    }
    .agreement-choose {
      padding: 38px 0;
      font-size: 22px;
      display: flex;
      .checked-text {
        margin-left: 10px;
        vertical-align: sub;
      }
      .van-checkbox {
        margin-top: -1px;
      }
      .agreement {
        color: #f88706;
      }
    }
    .btn-groud {
      display: flex;
      justify-content: center;
      /deep/ .van-button--normal {
        width: 280px;
        height: 90px;
        margin: 0 33px;
        border-radius: 10px;
        border: 1px solid #f88706;
        color: #f88706;
        font-size: 30px;
        font-weight: 500;
      }
      .now-check {
        border: 1px solid #f2f2f2;
        background: #f2f2f2;
        font-weight: bold;
        color: #999;
      }
    }
  }
  .record-box {
    padding-top: 20px;
  }
  .van-action-sheet {
    max-height: 60% !important;
  }
}
</style>
