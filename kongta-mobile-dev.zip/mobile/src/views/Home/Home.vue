<template>
  <div class="home">
    <swiper :bannerList="bannerList"></swiper>
    <div class="nav">
      <div class="title-box">
        <img src="@/assets/image/bug-car-title.png" alt="" />
        <span class="title">买车必查</span>
        <span class="title-desc">全方位剖析车辆信息，了解车况</span>
      </div>
      <div class="nav-item-box">
        <div class="nav-item" @click="toSearch(1)">
          <div class="nav-item-left">
            <img src="@/assets/image/track-record.png" alt="" />
          </div>
          <div class="nav-item-right">
            <h3>查维修记录</h3>
            <p>查维修保养记录, 轻松判断问题车</p>
          </div>
        </div>
        <div class="nav-item" @click="toSearch(2)">
          <div class="nav-item-left">
            <img src="@/assets/image/insurance.png" alt="" />
          </div>
          <div class="nav-item-right">
            <h3>查出险理赔</h3>
            <p>全国范围内理赔记录, 一键轻松查询</p>
          </div>
        </div>
      </div>
    </div>
    <div class="record-list">
      <div class="record-list-title">
        <img src="@/assets/image/search-icon.png" alt="" />
        <h2>最近查询</h2>
      </div>
      <recordList :recordList="recordList"></recordList>
    </div>
    <div class="record-more">
      <span @click="toRecord">查询更多记录<van-icon name="arrow"/></span>
    </div>
  </div>
</template>
<script>
import swiper from "@/components/swiper";
import recordList from "@/components/recordList";
import Order from "@/api/order";
import { mapState } from "vuex";
import { Toast } from "vant";
export default {
  name: "home",
  components: {
    swiper,
    recordList
  },
  data() {
    return {
      recordList: []
    };
  },
  computed: {
    ...mapState(["bannerList", "userInfo"])
  },
  created() {
    this.getRecordList();
  },
  methods: {
    // 最近记录列表
    async getRecordList() {
      if (!this.$store.state.userId) return false;
      const params = {
        pageNum: 1,
        pageSize: 10,
        id: this.$store.state.userId
      };
      const { data, code } = await Order.orderList(params);
      if (code === 200) {
        this.recordList = data.list;
      }
    },
    toSearch(type) {
      const path = type === 1 ? `/RepairSearch` : `InsureSearch`;
      this.$router.push(path);
    },
    toRecord() {
      this.$router.push("/Record");
    }
  }
};
</script>
<style lang="scss" scoped>
.home {
  width: 100%;
  .nav {
    padding: 40px 30px 50px;
    .title-box {
      display: flex;
      line-height: 32px;
      img {
        width: 35px;
        height: 32px;
        display: block;
      }
      .title {
        font-size: 30px;
        padding: 0 16px;
        font-weight: bold;
      }
      .title-desc {
        font-size: 22px;
        color: #999;
        line-height: 40px;
      }
    }
    .nav-item-box {
      width: 100%;
      padding-top: 36px;
      .nav-item {
        display: flex;
        border-radius: 20px;
        box-shadow: 0 9px 20px 1px hsla(0, 0%, 67%, 0.33);
        padding: 30px 17px;
        margin-bottom: 35px;
        &:last-child {
          margin-bottom: 0;
        }
        .nav-item-left {
          padding-right: 22px;
          img {
            width: 86px;
            height: 86px;
            display: block;
          }
        }
        .nav-item-right {
          h3 {
            color: #f88706;
            font-size: 32px;
            font-weight: bold;
            padding: 12px 0 10px;
          }
          p {
            font-size: 22px;
            color: #999;
          }
        }
      }
    }
  }
  .record-list {
    padding: 0 32px 0 46px;
    .record-list-title {
      display: flex;
      img {
        width: 33px;
        height: 33px;
        display: block;
      }
      h2 {
        padding-left: 16px;
        font-size: 30px;
        font-weight: bold;
      }
    }
  }
  /deep/.van-list__loading {
    display: none;
  }
  .record-more {
    padding: 40px 0 30px;
    color: #666666;
    font-size: 26px;
    font-weight: 500;
    text-align: center;
    span {
      .van-icon-arrow:before {
        vertical-align: -3px;
      }
    }
  }
}
</style>
