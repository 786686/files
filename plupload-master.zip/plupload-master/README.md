# plupload

## 简单说明
    这个demo是根据阿里云文件(图片，视频)上传到oss改为vue引用

## 注意修改的地方
    src/components/Plupload.vue中 
    accessid 
    accesskey
    host 
    换成自己阿里云对应的值

## 初始化
```
npm install
```

### 开发环境运行
```
npm run serve
```

### 生产环境运行
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```
