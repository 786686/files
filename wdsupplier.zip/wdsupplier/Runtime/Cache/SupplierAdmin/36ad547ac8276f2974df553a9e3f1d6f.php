<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN" style="min-width: 1131px;">
<head>
    <meta charset="utf-8">
    <title>供应商管理后台</title>
    <meta name="robots" content="noindex,nofollow"/>
    <link rel="stylesheet" type="text/css" href="/Public/admin/layui/css/layui.css">
    <link rel="stylesheet" type="text/css" href="/Public/css/style.css">
    <link href="/Public/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <script src="/Public/js/jquery-1.11.3.min.js"></script>
    <script src="/Public/admin/layui/layui.js"></script>
    <script src="/Public/js/admin.js"></script>
    <script src="/Public/js/common.js"></script>
    <script src="/Public/js/layer/layer.js"></script>
    <script>
        function storeCombing() {
            var url = "<?php echo U('SupplierAdmin/StoreCombing/storeCombing');?>";
            var data = {}
            $.post(url, data, function (r) {
                if (r.error == 1) {
                    layer.msg(r.errmsg);
                    return false;
                } else {
                    layer.msg(r.errmsg);
                    return true;
                }
            });
        }

    </script>
    <style>
        .pr {
            position: relative;
        }

        .bread {
            position: absolute;
            top: 62px;
            left: 0;
            width: 100%;
            height: 40px;
            line-height: 40px;
            padding-left: 210px;
            box-sizing: border-box;
        }

        .bread p {
            text-align: center;
        }

        .bread p.on {
            text-align: left;
        }

        .bread i {
            color: #333;
            font-size: 12px;
        }
    </style>
</head>

<body>
<div class="layui-layout layui-layout-admin">
    <div class="layui-header pr">
        <ul class="layui-nav" lay-filter="">
            <li class="layui-nav-item logo">
                <a href="">
                    <img src="/Public/admin/images/LOGO.png">
                    <span>创课网店供应商后台管理中心(<?php echo ($store_name_all); ?>)</span>
                </a>
            </li>
            <li class="layui-nav-item logo">
                <a onclick="storeCombing()">
                    <div style="cursor:pointer;color:#2e9bef;">梳理网店</div>
                </a>
            </li>
            <li class="layui-nav-item set">
                <a href="<?php echo U('SupplierAdmin/Logout/logout');?>">
                    <div><i class="layui-icon">&#xe64d;</i></div>
                    <div>退出</div>
                </a>
            </li>
            <li class="layui-nav-item out">
                <a href="<?php echo U('SupplierAdmin/StoreAdmin/index');?>">
                    <div><i class="layui-icon">&#xe614;</i></div>
                    <div>修改密码</div>
                </a>
            </li>
            <li class="layui-nav-item out">
                <a href="<?php echo U('SupplierAdmin/StoreAdmin/goods_audit');?>">
                    <div><i class="layui-icon">&#xe645;</i>&nbsp;&nbsp;
                        <?php if($audit_all > 0): ?><span style="color:#f00;"><?php echo ($audit_all); ?></span>
                            <?php else: ?>
                            <?php echo ($audit_all); endif; ?>
                    </div>
                    <div>商品审核通知</div>
                </a>
            </li>
        </ul>
        <!-- 面包屑 -->
        <div class="bread">
            <?php echo ($bread_menu); ?>
        </div>
    </div>

<style>
    .layui-side.layui-bg-black {
        background-color: #FFFFFF;
    }

    .layui-layout-admin .layui-side.silde-auto {
        overflow-x: inherit;
        z-index: 9999;
        top: 62px;
    }

    /* .pr{ position: relative; }
    .bread{ position: absolute; top:0;right:-810px;width:800px; height: 42px;line-height: 45px;}
    .bread i{ color:#333;font-size: 12px; } */
</style>
<div class="layui-side silde-auto">
    <div class="layui-side-scroll header_menu_div" id="header_menu">

        <ul>
            <?php if(is_array($sidebarmenu)): foreach($sidebarmenu as $key=>$vo): ?><li>
                    <a href="<?php if( !$vo['_child']): echo ($vo["url"]); ?>
                    <?php else: ?>
                    javascript:void(0);<?php endif; ?>" class="menu_li
                    <?php if($vo['selected'] == true): ?>active<?php endif; ?>
                    <?php if(!$vo['_child']): ?>is_only<?php endif; ?>
                    "><?php echo ($vo["title"]); ?></a>

                    <ul class="next_menu_ul"
                    <?php if($vo['selected'] == true): ?>style="display:block"<?php endif; ?>
                    >

                    <?php if(is_array($vo['_child'])): foreach($vo['_child'] as $k=>$v): ?><li><a href="<?php echo ($v["url"]); ?>" class="<?php if( $v['selected'] == true): ?>active<?php endif; ?>">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($v["title"]); ?>
                    <i class="layui-icon">&#xe602;</i> </a></li><?php endforeach; endif; ?>

        </ul>
        </li><?php endforeach; endif; ?>
        </ul>

    </div>
</div>


<!--左侧菜单//-->

<!-- mainCon -->
<div class="layui-body">
    <table class="layui-table">
        <thead>
        <tr>
            <th colspan="99" style="text-align: left; padding: 10px 20px;">您的信息</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th style="width:180px;">用户名：</th>
            <td><?php echo (session('store_username')); ?></td>
            <th style="width:180px;">注册时间：</th>
            <td><?php echo (session('store_add_time')); ?></td>
        </tr>
        <tr>
            <th>真实姓名：</th>
            <td><?php echo (session('store_realname')); ?></td>
            <th>上次登录：</th>
            <td colspan="3">
                上次登录时间：<?php echo (session('store_lastlogin_time')); ?><br>
                上次登录IP地址：<?php echo (session('store_lastlogin_ip')); ?>
                <button type="button" id="query_log" class="layui-btn layui-btn-xs">登录日志</button>
            </td>
        </tr>
        </tbody>
    </table>

    <table class="layui-table">
        <thead>
        <tr>
            <th colspan="99" style="text-align: left; padding: 10px 20px;">统计信息</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th style="width:150px;">会员总数：</th>
            <td><?php echo ($member_nums); ?></td>
            <th style="width:150px;">商品总数：</th>
            <td><?php echo ($goods_nums); ?></td>
        </tr>
        <tr>
            <th style="width:150px;">订单总数：</th>
            <td><?php echo ($ordernum); ?></td>
            <th style="width:150px;">总销售额(元)：</th>
            <td>￥ <?php echo ($orderamount); ?></td>
        </tr>
        </tbody>
    </table>

</div>
<!--主窗体//-->

<style>
    h5 {
        height: 35px;
        line-height: 35px;
        padding-left: 15px;
        background: #f0f0f0;
        margin: 0;
    }
</style>
<script>
    $(function () {
        $("#query_log").on('click', function () {
            // var htmlcontent = '';
            // // 请求日期  {q_time : 2020-01-19}
            // // $.get('/StoreAdmin/Index/loginList',{p:1}, function (res) {
            // 	console.log(res)
            //     layer.open({
            //         type: 1,
            //         skin: 'layui-layer-rim', //加上边框
            //         area: ['1220px', '90%'], //宽高
            //         content: res
            //     });
            // // })

            var url = "<?php echo U('SupplierAdmin/Index/loginList');?>";
            layer.open({
                type: 2,
                title: '登录日志',
                shadeClose: true,
                shade: 0.8,
                area: ['1000px', '90%'],
                content: url
            });

        })
    })
</script>
<div class="layui-footer" style="line-height: 44px;text-align: right;padding-right: 20px; color: #CCC;">
    Powered by 万讯科技
</div>
</div>
</body>
</html>