<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta name="robots" content="noindex,nofollow" />
	<title>供应商管理后台</title>
	<link rel="stylesheet" href="/Public/css/bootstrap-3.3.5/css/bootstrap.min.css" />
	<style>
	#warp{width:300px;margin:0 auto;margin-top:150px;}
	.error,#ajaxErrmsg{color:#f00}
	#loginForm{margin-top:10px;}
	</style>
</head>
<body>

<div id="warp">
	<h1 style="text-align:center;">商家找回密码</h1>
	<form id="loginForm" class="form-horizontal" method="post" action="<?php echo U('StoreAdmin/ForgotPwd/checkCode');?>">
		<div class="form-group">
			<label for="sa_mobile"
				   class="usernameLebel col-sm-3 control-label">手机号</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" name="sa_mobile"
					   id="sa_mobile" placeholder="手机号">
				<button type="button" id="authCodeBtn">验证码</button>
			</div>
		</div>
		<div class="form-group">
			<label for="code"
				   class="passwordLabel col-sm-3 control-label">验证码</label>
			<div class="col-sm-9">
				<input type="text" class="form-control" name="code"
					   id="code" placeholder="验证码">
			</div>
		</div>
		
		<button type="submit" class="btn btn-info col-xs-12" >下一步</button>
	</form>
</div>

<script src="/Public/js/jquery-1.11.3.min.js"></script>
<script src="/Public/js/layer/layer.js"></script>
<script src="/Public/js/validate/jquery.validate.min.js"></script>
<script src="/Public/js/validate/messages_zh.js"></script>
<script>
$(function(){
	$('#authCodeBtn').click(function (event) {
		var sa_mobile = $(" #sa_mobile ").val();
		var url = "<?php echo U('SupplierAdmin/ForgotPwd/send');?>";
		var data = {"sa_mobile":sa_mobile};
		$.post(url,data,function(r){
			if (r.error == 1){
				layer.msg(r.errmsg);
				return false;
			} else {
				layer.msg(r.errmsg);
				$('#authCodeBtn').html('已发送').attr('disabled', true);
				return true;
			}
		});
	});
	
	$("#loginForm").validate({
        rules: {
        	oldpwd: {
                required: true,
            },
            newpwd: {
                required: true,
            },
        },
        messages: {
			oldpwd: {
                required: "请输入原密码！",
            },
			newpwd: {
                required: "请输入新密码！",
            },
        }
        
    });
	
});
</script>
</body>
</html>