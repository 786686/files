<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8"/>
    <meta name="robots" content="noindex,nofollow"/>
    <title>创课供应商管理后台</title>
    <link rel="stylesheet" href="/Public/css/bootstrap-3.3.5/css/bootstrap.min.css"/>
    <style>
        #warp {
            width: 360px;
            margin: 0 auto;
            margin-top: 150px;
        }

        .error, #ajaxErrmsg {
            color: #f00
        }

        #loginForm {
            margin-top: 10px;
        }

        .version {
            font-family: '苹方';
            font-size: 18px;
            font-weight: 500;
            color: #e0dfdf;
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<div id="warp">
    <h1 style="text-align:center;">创课供应商管理后台</h1>
    <div class="version">V3.0.0</div>
    <form id="loginForm" class="form-horizontal">
        <div class="form-group">
            <label for="username" class="usernameLebel col-sm-3 control-label">用户名</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" name="username" id="username" placeholder="用户名">
            </div>
        </div>
        <div class="form-group">
            <label for="password" class="passwordLabel col-sm-3 control-label">密码</label>
            <div class="col-sm-9">
                <input type="password" class="form-control" name="password" id="password" placeholder="密码">
            </div>
        </div>
        <div class="form-group">
            <label for="secode" class="secodeLabel col-sm-3 control-label">验证码</label>
            <div class="col-sm-9">
                <input type="text" class="form-control" name="secode" id="secode" placeholder="验证码" AUTOCOMPLETE="OFF">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-12">
                <img id="verify_img" src="<?php echo U('SupplierAdmin/Login/verify');?>" style="width: 100%;" alt="验证码"
                     title="看不清？点击刷新验证码." onclick="this.src='<?php echo U('SupplierAdmin/Login/verify');?>?'+Math.random()"/>
            </div>
        </div>

        <div class="btn btn-info col-xs-12" id="subBtn">登录</div>
        <a href="<?php echo U('SupplierAdmin/ForgotPwd/firstStep');?>" style="display: inline-block;margin-top: 10px;">忘记密码？</a>
    </form>
</div>

<script src="/Public/js/jquery-1.11.3.min.js"></script>
<script src="/Public/js/layer/layer.js"></script>
<script src="/Public/js/validate/jquery.validate.min.js"></script>
<script src="/Public/js/validate/messages_zh.js"></script>
<script>
    $(function () {

        function validform() {
            return $("#loginForm").validate({
                rules: {
                    username: {
                        required: true,
                    },
                    password: {
                        required: true,
                    },
                    secode: {
                        required: true,
                    },
                },
                messages: {
                    username: {
                        required: "请输入用户名！",
                    },
                    password: {
                        required: "请输入密码！",
                    },
                    secode: {
                        required: "请输入验证码！",
                    },
                }
            });
        }

        function login() {
            var url = "<?php echo U('SupplierAdmin/Login/checkin');?>";
            $.post(url, $('#loginForm').serialize(), function (r) {
                if (r.error == 1) {
                    layer.msg(r.errmsg);
                    $("#verify_img").attr("src", "<?php echo U('SupplierAdmin/Login/verify');?>?" + Math.random());
                    return false;
                } else {
                    window.location.href = "<?php echo U('SupplierAdmin/Index/index');?>";
                }
            });
        }

//注册表单验证
        $(validform());
//点击表单提交按钮触发单击事件，进行表单验证，验证通过发起ajax请求，验证不通过在表单里提示
        $("#subBtn").click(function () {
            if (validform().form()) {
                login()
            } else {
            }
        })
//绑定回车事件
        document.onkeydown = function (event) {
            var e = event || window.event || arguments.callee.caller.arguments[0];
            if (e && e.keyCode == 13) { // enter 键
                console.log(validform())
                if (validform().form()) {
                    login()
                }
            }
        };


        validform();


    });
</script>
</body>
</html>