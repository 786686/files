<?php
/**
 * 初始化控制器
 */

namespace SupplierAdmin\Controller;

use Common\Lib\Traits\Helper;
use Think\Controller;

class InitController extends Controller
{
    use Helper;

    protected $ossClient;

    // 初始化
    protected function _initialize()
    {
        if (defined('UID')) return;
        define('UID', is_login());

        if (!UID) {
            $this->redirect('SupplierAdmin/Login/index');
        }
        //第一次登陆强制修改密码
        $sa_password_set = M('SupplierAdmin')->where(['sa_id' => UID])->getField('sa_password_set', false);
        if ($sa_password_set == 0) {
            $this->redirect('SupplierAdmin/SupplierAdmin/index');
        }

        $thisUrl = U(MODULE_NAME . '/' . CONTROLLER_NAME . '/' . ACTION_NAME);

        // 面包屑
        $this->assignStoreBread(MODULE_NAME . '/' . CONTROLLER_NAME . '/' . ACTION_NAME);

        // 权限判断
        if (!check_permission($thisUrl)) {
            $this->error('403:无权访问');
        }

        if (!IS_AJAX) {
            // 导航菜单处理
            $menu = get_menu();
            $sidebarmenu = [];

            if (!empty($menu)) {

                foreach ($menu as $k => $v) {
                    //仅管理员显示
                    if ($v['is_super_admin'] == 1) {
                        if (session('admin_id') != C('ADMIN_ID')) {
                            continue;
                        }
                    }

                    //显示的菜单
                    if ($v['is_show'] == 1) {

                        //权限判断
                        $actionUrl = U($v['action']);
                        if (!check_permission($actionUrl)) {
                            continue;
                        }

                        $sidebarmenu[$v['menu_id']]['title'] = $v['title'];
                        $sidebarmenu[$v['menu_id']]['url'] = $actionUrl;
                        $sidebarmenu[$v['menu_id']]['selected'] = 0;
                        $sidebarmenu[$v['menu_id']]['pid'] = $v['parent_menu_id'];

                        //高亮显示
                        if ($sidebarmenu[$v['menu_id']]['url'] == $thisUrl) {

                            $sidebarmenu[$v['menu_id']]['selected'] = 1;

                        }
                    }
                    if (!empty($v['_child'])) {
                        foreach ($v['_child'] as $kk => $vv) {

                            //显示的菜单
                            if ($vv['is_show'] == 1) {
                                //仅管理员显示
                                if (isset($vv['is_admin']) && $vv['is_admin'] == 1) {
                                    if (session('admin_id') != C('ADMIN_ID')) {
                                        continue;
                                    }
                                }
                                //仅开发者显示

                                //权限判断
                                $actionUrl = U($vv['action']);
                                if (!check_permission($actionUrl)) {
                                    continue;
                                }

                                $sidebarmenu[$v['menu_id']]['_child'][$vv['menu_id']]['title'] = $vv['title'];

                                $sidebarmenu[$v['menu_id']]['_child'][$vv['menu_id']]['url'] = $actionUrl;

                                $sidebarmenu[$v['menu_id']]['_child'][$vv['menu_id']]['selected'] = 0;

                                $sidebarmenu[$v['menu_id']]['_child'][$vv['menu_id']]['pid'] = $vv['parent_menu_id'];

                                //高亮显示
                                if ($sidebarmenu[$v['menu_id']]['_child'][$vv['menu_id']]['url'] == $thisUrl) {

                                    $sidebarmenu[$v['menu_id']]['_child'][$vv['menu_id']]['selected'] = 1;

                                    $sidebarmenu[$v['menu_id']]['selected'] = 1;

                                }

                            } else {

                                // 访问隐藏的菜单，保持顶部菜单高亮
                                if (U($vv['action']) == $thisUrl) {

                                    $sidebarmenu[$v['menu_id']]['selected'] = 1;

                                    // $sidebarmenu[$v['menu_id']]['_child']['selected'] = 1;

                                }
                            }
                        }
                    }
                }

            }

            $this->assign('sidebarmenu', $sidebarmenu);
        }

    }

    // 分页配置返回分页类
    protected function setPageHander($count, $getRows = 15)
    {
        if (!$count || !is_numeric($count)) {
            return false;
        }
        $Page = new \Think\Page($count, $getRows);
        // 分页配置设置
        $Page->lastSuffix = false;
        $Page->setConfig('prev', '上一页');
        $Page->setConfig('next', '下一页');
        $Page->setConfig('first', '首页');
        $Page->setConfig('last', '末页');

        return $Page;
    }

    // 空操作
    public function _empty()
    {
        header("location: /404.html");
    }


    protected function assignStoreBread($currentUrl = '')
    {
        $desc = '';
        if (empty($currentUrl)) {
            return '';
        }
        $desc .= $this->getBreadMenu($currentUrl);

        $this->assign('bread_menu', $desc);
    }

    private function getBreadMenu($currentUrl)
    {
        $menus = C('BROWER_BREAD');
        $info = self::getInfoByMca($currentUrl, $menus);
        if (empty($info)) {
            return '';
        }

        $title = '创课供应商后台';
        if ($info['pid'] == 0) {
            return '<p>' . $title . breadTitleDesc($info['title']) . '</p>';
        }

        $parentInfo = self::getInfoById($info['pid'], $menus);
        if (!$parentInfo) {
            return '<p>' . $title . $info['title'] . '</p>';
        }
        return '<p class="on"><a href="' . U(trim($parentInfo['mca'], '/')) . '">' . $title . breadTitleDesc($parentInfo['title']) . '</a> >' . $info['title'] . '</p>';
    }

    private function getInfoByMca($currentUrl, $menus)
    {
        $info = [];
        foreach ($menus as $menu) {
            if ($menu['mca'] == $currentUrl) {
                $info = $menu;
                break;
            }
        }
        return $info;
    }

    private function getInfoById($id, $menus)
    {
        $info = [];
        if (isset($menus[$id])) $info = $menus[$id];
        return $info;
    }
}
