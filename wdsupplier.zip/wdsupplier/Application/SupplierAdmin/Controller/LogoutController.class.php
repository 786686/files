<?php
/**
 * 后台用户注销控制器
 */

namespace SupplierAdmin\Controller;

use Think\Controller;

class LogoutController extends Controller
{

    // 登出
    public function logout()
    {
        if (session('sa_id') === null) {
            if (IS_AJAX) {
                $this->ajaxReturn(['error' => 0, 'errmsg' => '操作成功', 'url' => U('SupplierAdmin/Login/index')]);
            }

            $this->redirect('SupplierAdmin/Login/index');
        }

        admin_log('退出登录', 10);
        $app_admin_token = session('app_admin_token');
        M('AdminToken')->where([
            'app_admin_token' => $app_admin_token,
        ])->setField('app_admin_token', '');
        //删除session
        session('store_logined', null);
        session('sa_id', null);
        session('store_username', null);
        session('store_realname', null);
        session('store_status', null);
        session('store_add_time', null);
        session('store_lastlogin_time', null);
        session('store_lastlogin_ip', null);
        session('sa_store_id', null);
        session('app_admin_token', null);

        // 销毁session
//		session('[destroy]');

        if (IS_AJAX) {
            $this->ajaxReturn(['error' => 0, 'errmsg' => '操作成功', 'url' => U('SupplierAdmin/Login/index')]);
        }

        $this->redirect('SupplierAdmin/Login/index');
    }

    // 空操作
    public function _empty()
    {
        $this->redirect('SupplierAdmin/Logout/logout');
    }

}