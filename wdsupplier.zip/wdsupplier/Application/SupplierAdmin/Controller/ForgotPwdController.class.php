<?php
/**
 * 供应商后台个人中心忘记密码
 */

namespace SupplierAdmin\Controller;

use Think\Controller;

class ForgotPwdController extends InitController
{

    public function _initialize()
    {

    }

    /**
     *desc: 忘记密码
     *user: xieyingting
     *time: 2020/5/29
     */
    public function index()
    {
        $this->display();
    }

}