<?php
/**
 * Created by PhpStorm.
 * User: xieyingting
 * Date: 2020/5/29
 * Time: 11:43
 */

namespace SupplierAdmin\Controller;

use Think\Controller;

class RegisterController extends Controller
{
    public function _initialize()
    {

    }

    /**
     *desc: 商家入驻注册页
     *user: xieyingting
     *time: 2020/5/29
     */
    public function index(){

        $this->display();
    }

}