<?php
/**
 * 供应商后台个人中心相关操作
 */

namespace SupplierAdmin\Controller;

class SupplierAdminController extends InitController
{

    public function _initialize()
    {
        define('UID', is_login());
        if (!UID) {
            $this->redirect('SupplierAdmin/Login/index');
        }
    }

}