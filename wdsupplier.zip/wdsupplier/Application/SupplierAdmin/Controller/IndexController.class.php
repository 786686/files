<?php

namespace SupplierAdmin\Controller;

class IndexController extends InitController
{

    public function index()
    {
        $this->display('Index/index');
    }


}