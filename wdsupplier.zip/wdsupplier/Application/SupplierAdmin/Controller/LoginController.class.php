<?php
/**
 * 登录验证控制器
 */

namespace SupplierAdmin\Controller;

use Common\Lib\Defined\ErrorMsg;
use Common\Lib\Traits\Helper;
use Common\Service\AppToken as AppTokenService;
use Common\Validate\LoginValidate;
use SupplierAdmin\Model\SupplierAdminModel;
use Think\Controller;

class LoginController extends Controller
{
    use Helper;

    protected function _initialize()
    {


    }

    // 登录页
    public function index()
    {
        //如果已经登录
        if (session('?store_logined') && session('store_logined') === true && session('?sa_id') && session('sa_id')) {
            $this->redirect('SupplierAdmin/Index/index');
        }
        $this->display('Login/index');
    }

    /**
     *  登录验证
     */
    public function checkin()
    {

        $validate = new LoginValidate();

        $params = [
            'username' => I('username', '', 'strip_tags,trim'),
            'password' => I('password', '', 'strip_tags,trim'),
            'secode' => I('secode', '', 'strip_tags,trim'),
        ];

        if (!$validate->goCheck($params)) {
            $this->errorOutput(ErrorMsg::ERR_PARAM, $validate->getError());
        }

        // 验证码校验
        if (!$this->check_verify($params['secode'])) {
            $this->errorOutput(ErrorMsg::ERR_PARAM, '验证码不正确');
        }

        $adminModel = new SupplierAdminModel();
        $userInfo = $adminModel->getUserInfoByName($params['username']);

        if (empty($userInfo)) {
            $this->ajaxReturn(['error' => 1, 'errmsg' => '用户名或密码不正确', 'field' => '']);
        }

        // 密码校验
        if (md5($params['password'] . $userInfo['sa_salt']) != $userInfo['sa_password']) {
            $this->ajaxReturn(['error' => 1, 'errmsg' => '用户名或密码不正确', 'field' => '']);
        }

        // 是否被禁用
        if ($userInfo['sa_status'] == 0) {
            $this->ajaxReturn(['error' => 1, 'errmsg' => '您的账号已被锁定，无权登录，请联系超级管理员', 'field' => '']);
        }

        // 已标记删除
        if ($userInfo['sa_status'] == -1) {
            $this->ajaxReturn(['error' => 1, 'errmsg' => '账号不存在或已被删除', 'field' => '']);
        }

        // 记录SESSION
        session('store_logined', true);
        session('sa_id', $userInfo['sa_id']);
        session('store_username', $userInfo['sa_username']);
        // 存入电话号码 -- 用于关联平台的操作
        session('sa_mobile', $userInfo['sa_mobile']);
        session('store_realname', $userInfo['sa_realname']);
        session('store_status', $userInfo['sa_status']);
        session('sa_store_id', $userInfo['sa_store_id']);
        session('store_add_time', date('Y-m-d H:i:s', $userInfo['sa_addtime']));
        session('store_lastlogin_time', date('Y-m-d H:i:s', $userInfo['sa_lastlogin_time']));
        session('store_lastlogin_ip', long2ip($userInfo['sa_lastlogin_ip']));

        //生成对应token，请求接口使用
        $appToken = new AppTokenService();
        $token = $appToken->getToken("store_admin_" . $userInfo['sa_id'], $userInfo['sa_store_id']);
        session('app_admin_token', $token);

        $adminModel->upLastloginInfo();

        admin_log('登录供应商后台系统', 1);

        $this->ajaxReturn(['error' => 0, 'errmsg' => '登录成功', 'field' => '', 'sa_id' => $userInfo['sa_id']]);
    }

    // 生成验证码
    public function verify()
    {
        $config = [
            'imageW' => 290,
            'seKey' => 'secode',
            'length' => 4,
            'fontSize' => 30,
        ];
        $Verify = new \Think\Verify($config);
        $Verify->codeSet = '0123456789';
        $Verify->entry();
    }

    // 校验验证码
    protected function check_verify($code, $id = '')
    {
        $config = [
            'imageW' => 280,
            'seKey' => 'secode',
        ];
        $verify = new \Think\Verify($config);
        return $verify->check($code, $id);
    }

    // 空操作
    public function _empty()
    {
        $this->redirect('SupplierAdmin/Login/index');
    }

}
