<?php
return array(
    'PASSWORD'=>array('88888888'),

	// 面包屑
	'BROWER_BREAD' => [
		# 会员
		## 关注会员列表
		1 => ['mca' => 'StoreAdmin/Member/lists', 'title' => '关注会员列表', 'pid'=> 0],

		# 网店商品管理
		## 网店商品列表列表
		6 => ['mca' => 'StoreAdmin/StoreGoods/lists', 'title' => '网店商品列表', 'pid'=> 0],
		8 => ['mca' => 'StoreAdmin/StoreGoods/edit', 'title' => '编辑网店信息', 'pid'=> 6],

		## 本网店商品列表
		11 => ['mca' => 'StoreAdmin/StoreGoods/goods_lists', 'title' => '本网店商品列表', 'pid'=> 0],
		12 => ['mca' => 'StoreAdmin/StoreGoods/add', 'title' => '添加网店商品', 'pid'=> 11],
		13 => ['mca' => 'StoreAdmin/StoreGoods/goods_edit', 'title' => '修改网店商品', 'pid'=> 11],

		## 网店公告
		16 => ['mca' => 'StoreAdmin/Announcement/lists', 'title' => '公告列表', 'pid'=> 0],
		17 => ['mca' => 'StoreAdmin/Announcement/add', 'title' => '添加公告', 'pid'=> 16],
		18 => ['mca' => 'StoreAdmin/Announcement/edit', 'title' => '修改公告', 'pid'=> 16],

		# 订单
		## 已结算订单
		21 => ['mca' => 'StoreAdmin/Order/transferAsk', 'title' => '已结算订单', 'pid'=> 0],

		## 订单列表
		26 => ['mca' => 'StoreAdmin/Order/lists', 'title' => '订单列表', 'pid'=> 0],

		## 维权订单
		31 => ['mca' => 'StoreAdmin/RightsOrder/lists', 'title' => '维权订单', 'pid'=> 0],

		# 分类
		## 分类列表
		36 => ['mca' => 'StoreAdmin/GoodsClass/lists', 'title' => '分类列表', 'pid'=> 0],
		37 => ['mca' => 'StoreAdmin/GoodsClass/add', 'title' => '添加分类', 'pid'=> 36],
		38 => ['mca' => 'StoreAdmin/GoodsClass/edit', 'title' => '修改分类', 'pid'=> 36],

		## 网店分类筛选
		41 => ['mca' => 'StoreAdmin/StoreClassFilter/right', 'title' => '网店分类筛选', 'pid'=> 0],

		# 供应商
		## 供应商列表
		46 => ['mca' => 'StoreAdmin/Supplier/lists', 'title' => '供应商列表', 'pid'=> 0],
		47 => ['mca' => 'StoreAdmin/Supplier/add', 'title' => '添加供应商', 'pid'=> 46],
		48 => ['mca' => 'StoreAdmin/Supplier/edit', 'title' => '修改网店', 'pid'=> 46],

		# 财务管理
		## 结账收益明细信息
		51 => ['mca' => 'StoreAdmin/Settlement/index', 'title' => '结账收益明细列表', 'pid'=> 0],
		52 => ['mca' => 'StoreAdmin/Settlement/orders', 'title' => '销售订单明细表', 'pid'=> 51],
		53 => ['mca' => 'StoreAdmin/Settlement/cash', 'title' => '已提现明细', 'pid'=> 51],
		54 => ['mca' => 'StoreAdmin/Settlement/nocash', 'title' => '未提现明细', 'pid'=> 51],

        ## 预约口罩订单
        55 => ['mca' => 'StoreAdmin/PlatformOrder/lists', 'title' => '口罩预售订单', 'pid'=> 0],
	],
);