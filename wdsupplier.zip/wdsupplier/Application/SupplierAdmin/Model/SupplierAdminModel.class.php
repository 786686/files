<?php
/**
 * 后台用户模型
 */

namespace SupplierAdmin\Model;

use Think\Model;

class SupplierAdminModel extends Model
{

    /**
     * 通过用户名获取用户信息
     * @param string $username 用户名
     * @return bool/array
     */
    public function getUserInfoByName($username)
    {
        if (empty($username) || !is_string($username)) {
            return false;
        }
        return $this->where(['sa_username' => $username])->find();
    }


    public function checkUserInfo(){

    }

    /**
     * 通过用户ID获取用户信息
     * @param int $uid 用户ID
     * @return bool/array
     */
    public function getUserInfoById($uid)
    {
        if (empty($uid)) {
            return false;
        }
        return $this->where(['sa_id' => $uid])->find();
    }

    /**
     * 更新用户最后登录时间
     * @return void
     */
    public function upLastloginInfo()
    {
        $uid = session('sa_id');
        if (!$uid) {
            return false;
        }
        $data['sa_lastlogin_time'] = NOW_TIME;
        $data['sa_lastlogin_ip'] = ip2long(get_client_ip());
        $this->where(['sa_id' => $uid])->save($data);
    }

    /**
     * 统计用户数量
     * @param array $where 查询条件
     * @return int
     */
    public function getUserNum($where = [])
    {
        if ($where && is_array($where)) {
            $this->where($where);
        }
        return $this->count();
    }

    /**
     * 检测用户名是否可用
     * @param string $username 用户名
     * @param array $where 条件
     * @return bool true可用,false不可用
     */
    public function checkUsername($username, $where = [])
    {
        if (empty($username) || !is_string($username)) {
            return false;
        }
        $where ['sa_username'] = $username;
        if ($this->where($where)->count()) {
            return false;
        }
        return true;
    }


    /**
     * 标记删除用户
     * @param int $uid
     * @return bool
     */
    public function delUser($uid)
    {
        if (!$uid || !is_numeric($uid)) {
            return false;
        }
        if ($this->where(['sa_id' => $uid])->save(['sa_status' => -1]) !== false) {
            return true;
        }
        return false;
    }

    /**
     * 获取用户状态
     * @param int $uid
     * @return mixed
     */
    public function getUserStatus($uid)
    {
        if (!$uid || !is_numeric($uid)) {
            return false;
        }
        return $this->where(['sa_id' => $uid])->getField('sa_status');
    }

    /**
     * 更改用户状态
     * @param int $uid 用户ID
     * @param int $status 状态
     * @return bool
     */
    public function changeStatus($status, $uid)
    {
        if (!$uid) {
            return false;
        }
        if ($this->where(['sa_id' => $uid])->save(['sa_status' => $status]) !== false) {
            return true;
        }
        return false;
    }

    /**
     * @param $where
     * @param $data
     * @return bool
     * 修改商家信息
     * 2019-5-10
     */
    public function updateStoreAdmin($where, $data)
    {
        return $this->where($where)->save($data);
    }

    /**
     * @param $where
     * @param $data
     * @return bool
     * 密码重置操作
     */
    public function upStoreAdminPwd($where, $data)
    {
        $sa_salt = $this->where($where)->getField('sa_salt', false);
        $passwd = md5($data['sa_password'] . $sa_salt);
        $this->where($where)->save([
            'sa_password' => $passwd,
        ]);
        M('vcode')->where(['id' => $data['id']])->save
        (['status' => 1]);
        return true;
    }
}
