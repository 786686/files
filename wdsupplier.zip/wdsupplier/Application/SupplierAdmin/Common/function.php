<?php
/**
 * 检测用户是否登录
 * @return integer 0-未登录，大于0-当前登录用户ID
 */
function is_login(){
    if (!session('?store_logined') || session('store_logined') !== true ||
        !session('?sa_id') || !session('sa_id')) {
        return 0;
    }
    return session('sa_id');
}

/**
 * 检测当前用户是否为管理员
 * @return boolean true-管理员，false-非管理员
 */
function is_administrator($uid = null){
    $uid = is_null($uid) ? is_login() : $uid;
    return $uid && (intval($uid) === C('ADMIN_ID'));
}

/**
 * 获取启用中的权限列表
 * @return array $right 权限列表数组
 */
function get_permission(){
    static $right = array();
    if (empty($right)) {
        $tmp = M('Privilege')->where(array('priv_status'=>1))->order('priv_sort desc,priv_id asc')->select();
        if (!empty($tmp)) {
            foreach ($tmp as $k=>$v) {
                $right[$v['priv_group']][$v['priv_id']] = $v;
            }
        }
    }
    return $right;
}

/**
 * 权限校验
 * @param string $actionUrl 操作的控制器方法链接
 * @return bool 有权限返回true,无权限返回false
 */
function check_permission($actionUrl) {
    static $allow_views_url = array();
    if (!UID) {
        return false;
    }

    if (IS_ROOT) {
        return true;
    }

    // 配置上允许访问的链接
    if (!$allow_views_url) {
        $allow_views_url = C('ALLOW_VIEWS_URL');
        if ($allow_views_url) {
            foreach ($allow_views_url as $k=>$v) {
                $allow_views_url[$k] = U($v);
            }
        }
    }
    // 全局配置允许访问
    if (in_array($actionUrl, $allow_views_url)) {
        return true;
    }

    // 权限判断
    $role_right = session('role_right');

    if (empty($role_right)) {
        return false;
    }
    if (in_array($actionUrl, $role_right)) {
        return true;
    }
    return false;
}

/**
 * 管理员日志
 * @param $log_value
 * @param int $log_type
 */
function admin_log($log_value,$log_type=0)
{
    if (empty($log_value)) {
        return ;
    }
    if (!is_string($log_value)) {
        return ;
    }
    $data['admin_id'] = session('sa_id');
    $data['admin_username'] = session('store_username');
    $data['createtime'] = time();
    $data['log_value'] = $log_value;
    $data['log_ip'] = get_client_ip();
    $data['log_type'] = $log_type;
    M('supplier_admin_log')->add($data);
}

function getSystemYearArr(){
    $year_arr = array('2015'=>'2015','2016'=>'2016','2017'=>'2017','2018'=>'2018','2019'=>'2019','2020'=>'2020',
//        '2021'=>'2021','2022'=>'2022','2023'=>'2023','2024'=>'2024','2025'=>'2025','2026'=>'2026','2027'=>'2027',
//        '2028'=>'2028','2029'=>'2029', '2030'=>'2030',
        );
    return $year_arr;
}
function getMonthLastDay($year, $month){
    $t = mktime(0, 0, 0, $month + 1, 1, $year);
    $t = $t - 60 * 60 * 24;
    return $t;
}
function getSystemMonthArr(){
    $month_arr = array('1'=>'01','2'=>'02','3'=>'03','4'=>'04','5'=>'05','6'=>'06','7'=>'07','8'=>'08','9'=>'09','10'=>'10','11'=>'11','12'=>'12');
    return $month_arr;
}
function getSystemWeekArr(){
    $week_arr = array('1'=>'周一','2'=>'周二','3'=>'周三','4'=>'周四','5'=>'周五','6'=>'周六','7'=>'周日');
    return $week_arr;
}
function getMonthWeekArr($current_year, $current_month){
    $firstday = strtotime($current_year.'-'.$current_month.'-01');
    $firstweekday = (7 - date('N',$firstday) +1);
    $starttime = $firstday-3600*24*(7-$firstweekday);
    $lastday = strtotime($current_year.'-'.$current_month.'-01'." +1 month -1 day");
    $lastweekday = date('N',$lastday);
    $endtime = $lastday-3600*24*$lastweekday;
    $step = 3600*24*7;
    $week_arr = array();
    for ($i=$starttime; $i<$endtime; $i= $i+3600*24*7){
        $week_arr[] = array('key'=>date('Y-m-d',$i).'|'.date('Y-m-d',$i+3600*24*6), 'val'=>date('Y-m-d',$i).'~'.date('Y-m-d',$i+3600*24*6));
    }
    return $week_arr;
}
function getWeek_SdateAndEdate($current_time){
    $current_time = strtotime(date('Y-m-d',$current_time));
    $return_arr['sdate'] = date('Y-m-d', $current_time-86400*(date('N',$current_time) - 1));
    $return_arr['edate'] = date('Y-m-d', $current_time+86400*(7- date('N',$current_time)));
    return $return_arr;
}
function getTb($updata, $currentdata){
    if($updata != 0){
        $ytoyrate = round(($currentdata - $updata)/$updata*100, 2).'%';
    } else {
        $ytoyrate = '-';
    }
    return $ytoyrate;
}
function getHb($updata, $currentdata){
    if($updata != 0){
        $mtomrate = round(($currentdata - $updata)/$updata*100, 2).'%';
    } else {
        $mtomrate = '-';
    }
    return $mtomrate;
}
function getStarttimeAndEndtime($search_arr){
    if($search_arr['search_type'] == 'day'){
        $stime = $search_arr['day']['search_time'];//今天0点
        $etime = $search_arr['day']['search_time'] + 86400 - 1;//今天24点
    }
    if($search_arr['search_type'] == 'day3'){
        $stime = $search_arr['day']['search_time'] - 86400 * 2;//3天前0点
        $etime = $search_arr['day']['search_time'] + 86400 - 1;//今天24点
    }
    if($search_arr['search_type'] == 'day7'){
        $stime = $search_arr['day']['search_time'] - 86400 * 6;//7天前0点
        $etime = $search_arr['day']['search_time'] + 86400 - 1;//今天24点
    }
    if($search_arr['search_type'] == 'week'){
        $current_weekarr = explode('|', $search_arr['week']['current_week']);
        $stime = strtotime($current_weekarr[0]);
        $etime = strtotime($current_weekarr[1])+86400-1;
    }
    if($search_arr['search_type'] == 'month'){
        $stime = strtotime($search_arr['month']['current_year'].'-'.$search_arr['month']['current_month']."-01 0 month");
        $etime = getMonthLastDay($search_arr['month']['current_year'],$search_arr['month']['current_month'])+86400-1;
    }
    if($search_arr['search_type'] == 'year'){
        $stime = strtotime($search_arr['year']['current_year']."-01-01");
        $etime = strtotime($search_arr['year']['current_year']."-12-31")+86400-1;
    }
    return array($stime,$etime);
}
function getStatData_Column2D($stat_arr){
    $stat_arr['tooltip']['trigger'] = 'axis';
    $stat_arr['tooltip']['axisPointer']['type'] = 'shadow';
//    {b0}： <br />{a0}: {c0}
//    $stat_arr['tooltip']['formatter'] = "function(params){return '{b0}:'+params[0].data.name+'<br>{a0}:'+params[0].data.value}";
    $stat_arr['grid']['left'] = '3%';
    $stat_arr['grid']['right'] = '4%';
    $stat_arr['grid']['bottom'] = '3%';
    $stat_arr['grid']['containLabel'] = true;
    is_string($stat_arr['title'])?$stat_arr['title'] = array('text'=>$stat_arr['title']):'';

    $stat_arr['yAxis']['type'] = 'value';

    $color = array('#7a96a4','#cba952','#667b16','#a26642','#349898','#c04f51','#5c315e','#445a2b',
                    '#adae50','#14638a','#b56367','#a399bb','#070dfa','#47ff07','#f809b7');


    foreach ($stat_arr['series']['data'] as $data_k=>$data_v){
        $stat_arr['series']['data'][$data_k] = array(
            'name'=>$data_v['name'],
            'value'=>$data_v['value'],
//            'label'=>array(),
            'itemStyle'=>array('normal'=>array('color'=>$color[$data_k])),
        );
    }

    //print_r($stat_arr); die;
    return json_encode($stat_arr);
}
function getStatData_LineLabels($stat_arr){
    $stat_arr['tooltip']['trigger'] = 'axis';
    $stat_arr['grid']['left'] = '3%';
    $stat_arr['grid']['right'] = '4%';
    $stat_arr['grid']['bottom'] = '3%';
    $stat_arr['grid']['containLabel'] = true;

    return json_encode($stat_arr);
}

function getSign($data=array()){
    $appSecret = 'LSK3kzm5sA2vUSWSFUpokBjNgQ1I0sy4gFRR1Qelbap';
    // 过滤签名（为空或sign字段或上传文件不参与签名）
    foreach($data as $key=>$value){
        if ($key == 'sign' ||  $key == 'picContent' || $key=="goods" || $key=="goodsJson")  unset($data[$key]);
    }
    //数组键值自然排序
    ksort($data);
    reset($data);
    //拼装签名字符
    $sign_str='';
    foreach($data as $key=>$value){
        $sign_str.=$key.$value;
    }
    $sign=md5($appSecret.$sign_str.$appSecret);
    return $sign;

}

function send_post($url, $post_data) {

    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    return $result;
}
