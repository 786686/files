<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/10/25
 * Time: 15:15
 */

namespace Common\Lib\Defined;

/**
 * 错误码定义
 * Class ErrorCode
 * @package Common\Lib\Defined
 * @see Application/Api/Model/CodeModel.class.php
 * @comment 本文件暂未启用 - 待整理完成
 * @author fanzhaogui
 * @date 2019-10-25
 */
class ErrorCode
{
    /**
     * 可以按照-定义的值-数字排行
     */
    const SUCCESS = 1;

    const PLEASE_ENTER_A_NICKNAME_WITHIN_10_CHARACTERS = -1001;
    const PLEASE_ENTER_A_VALID_PHONE_NUMBER = -1002;
    const PLEASE_ENTER_A_PASSWORD_FOR_THE_6_16_BIT = -1003;
    const PLEASE_ENTER_A_6_DIGIT_VERIFICATION_CODE = -1004;
    const CELL_PHONE_NUMBER_HAS_BEEN_REGISTERED = -1005;
    const CELL_PHONE_VERIFICATION_CODE_IS_NOT_CORRECT = -1006;
    const ONLY_10_TIMES_A_DAY_TO_GET_THE_VERIFICATION_CODE = -1007;
    const OPERATION_IS_TOO_FREQUENT_PLEASE_1_MINUTES_AFTER_THE_OPERATION = -1008;
    const ERROR_INCORRECT_USERNAME_OR_PASSWORD = -1009;
    const NO_MORE_DATA = -1012;
    const LACK_OF_NECESSARY_PARAMETERS = -1013;
    const CONTENT_CAN_NOT_BE_EMPTY = -1013;
    const REGION_ID_IS_NOT_VALID = -1014;
    const ZONE_ID_DOES_NOT_EXIST = -1015;
    const OPERATION_OBJECT_IS_NOT_VALID = -1016;
    const VERIFY_THAT_THE_CODE_HAS_EXPIRED_PLEASE_RE_OBTAIN = -1017;
    const TOKEN_NOT_VALID = -1018;
    const ACCESS_OBJECT_IS_NOT_VALID = -1021;
    const SCHOOL_NOT_ADD = -1029;

    // 1100
    const NOT_AUTHORIZED = -1100;
    const PHONE_NUMBER_HAS_NOT_BEEN_REGISTERED = -1109;
    const THE_OPERATION_IS_TOO_FREQUENT_PLEASE_GET_1_MINUTES_LATER = -1010;

    // 1200
    const ONLY_ONCE_A_DAY_TO_SUBMIT_A_PROPOSAL = -1201;
    const PROPOSED_CONTENT_CAN_NOT_BE_EMPTY = -1202;
    const VERIFICATION_CODE_TIMEOUT_PLEASE_RE_OBTAIN = -1203;

    // 2000
    const ADDRESS_ID_IS_NOT_VALID = -2001;
    const STORE_ID_IS_NOT_LEGITIMATE = -2002;
    const PLEASE_SET_THE_SHIPPING_COST = -2003;
    const IMAGE_VERIFICATION_CODE_ERROR = -2004;
    const NO_PAYMENT_PASSWORD_SET = -2005;
    const OLD_PAYMENT_PASSWORD_ERROR = -2006;
    const PLEASE_ENTER_A_NEW_PASSWORD_FOR_6_DIGITS = -2007;
    const TYPE_PARAMETER_IS_NOT_VALID = -2008;
    const RECHARGE_AMOUNT_IS_NOT_LEGITIMATE = -2009;
    const PAY_PASSWORD_ERROR = -2010;
    const INSUFFICIENT_BALANCE_OF_PAYMENT_FAILURE = -2011;
    const ACTIVITY_DATE_OUT = -2012;
    const DISTRIBUTION_RANGE_IS_NOT_WITH_IN_THE_AREA = -2013;
    const IMG_CODE_NON_EXIT = -2013;
    const IMG_CODE_IS_USE = -2014;
    const IMG_CODE_OVER = -2015;
    const PHONE_NUMBER_TO_BIND = -2016;
    const PLEASE_ENTER_THE_OLD_LOGIN_PASSWORD = -2017;
    const PLEASE_ENTER_THE_NEW_LOGIN_PASSWORD = -2018;
    const TWO_DIFFERENT_PASSWORDS = -2021;
    const GOODS_PARAMETERS_WROANG = -2020;
    const ORIGINAL_PASSWORD_ERROR = -2020;
    const WROANG_PARAMETERS = -2019;
    const GOODS_SPEC_ID_ERROR = -2021;
    const WECHAT_IS_NOT_BINDING = -2022;
    const SHOPPING_TYPE_ERROR = -2022;
    const QQ_IS_NOT_BINDING = -2023;
    const GOODS_STOCK_NUM_NOT_ENOUGH = -2023;
    const GOODS_BATCH_NUMBER_ERROR = -2024;
    const PLEASE_SELECT_THE_UNIT = -2025;
    const PLEASE_ENTER_THE_NAME_OF_THE_INSTITUTE = -2026;
    const PLEASE_ENTER_YOUR_MAJOR = -2027;
    const PLEASE_SELECT_THE_TYPE_OF_POSITION = -2028;
    const PLEASE_ENTER_YOUR_REAL_NAME = -2029;
    const PLEASE_ENTER_YOUR_STUDENT_ID_NUMBER = -2030;
    const CART_DATA_ERROR = -2031;
    const MISSING_STORE_PARAMETERS = -2032;
    const STORE_PARAMETER_ERROR = -2033;
    const PAYMENT_ERROR = -2034;
    const MESSAGE_NUMBER_SHOULD_NOT_BE_GREATER_THAN_300 = -2035;
    const PLEASE_ENTER_A_PHONE_NUMBER = -2036;
    const PHONE_NUMBER_IS_NOT_VALID = -2037;
    const PLEASE_SELECT_THE_DELIVERY_ADDRESS = -2038;
    const DELIVERY_ADDRESS_ERROR = -2039;
    const FAILED_TO_GET_THE_SHIPPING_ADDRESS = -2040;
    const PLEASE_SET_THE_DEFAULT_SHIPPING_TEMPLATE = -2041;
    const WRONG_QUANTITY_OF_GOODS = -2042;
    const PURCHASE_COMMODITY_ERROR = -2043;
    const PRODUCT_INVENTORY_SHORTAGE = -2044;
    const FAILED_TO_GENERATE_ORDER = -2045;
    const WRONG_DELIVERY_TIME = -2046;
    const GOODS_BATCH_NOT_SET = -2047;
    const GOODS_SPEC_VALUE_ERROR = -2048;
    const MERCHANDISE_ATTRIBUTION_STORE_DATA_ERROR = -2049;
    const COMPANY_ID_ERROR = -2050;
    const DATA_NOT_EXISTS = -2051;


    // 3000
    const SYSTEM_ERROR = -3000;

    // 5000
    const OTHER_ERROR = -5000;

    // 10000
    const TODAY_TWICE_FULL = -10000;

    /**
     * 错误信息
     */
    static $msg = array(

        self::SUCCESS                                                        => '请求成功',//成功
        self::NOT_AUTHORIZED                                                 => '未授权登录!',
        self::SYSTEM_ERROR                                                   => '系统错误!',
        self::OTHER_ERROR                                                    => '其他错误!',
        self::LACK_OF_NECESSARY_PARAMETERS                                   => '缺少必要参数!',
        self::WROANG_PARAMETERS                                              => '参数不合法!',
        self::OPERATION_OBJECT_IS_NOT_VALID                                  => '操作对象不合法',
        self::CONTENT_CAN_NOT_BE_EMPTY                                       => '内容不能为空',
        self::REGION_ID_IS_NOT_VALID                                         => '区域id不合法!',
        self::PLEASE_ENTER_A_VALID_PHONE_NUMBER                              => '请输入合法的手机号!',
        self::NO_MORE_DATA                                                   => '无更多数据!',
        self::ACCESS_OBJECT_IS_NOT_VALID                                     => '访问对象不合法!',
        self::PROPOSED_CONTENT_CAN_NOT_BE_EMPTY                              => '建议内容不能为空!',
        self::ONLY_ONCE_A_DAY_TO_SUBMIT_A_PROPOSAL                           => '每天只能提交一次建议!',
        self::ZONE_ID_DOES_NOT_EXIST                                         => '区域id不存在!',
        self::PLEASE_ENTER_A_6_DIGIT_VERIFICATION_CODE                       => '请输入6位数验证码!',
        self::CELL_PHONE_VERIFICATION_CODE_IS_NOT_CORRECT                    => '手机验证码不正确!',
        self::PLEASE_ENTER_A_NICKNAME_WITHIN_10_CHARACTERS                   => '请输入10个字符内的昵称!',
        self::PLEASE_ENTER_A_PASSWORD_FOR_THE_6_16_BIT                       => '请输入6-16位的密码！',
        self::CELL_PHONE_NUMBER_HAS_BEEN_REGISTERED                          => '手机号已被注册!',
        self::VERIFY_THAT_THE_CODE_HAS_EXPIRED_PLEASE_RE_OBTAIN              => '验证码已过期，请重新获取！',
        self::ONLY_10_TIMES_A_DAY_TO_GET_THE_VERIFICATION_CODE               => '每天只能获取10次验证码！',
        self::OPERATION_IS_TOO_FREQUENT_PLEASE_1_MINUTES_AFTER_THE_OPERATION => '操作过于频繁，请1分钟后再操作！',
        self::ERROR_INCORRECT_USERNAME_OR_PASSWORD                           => '用户名或密码错误!',
        self::PHONE_NUMBER_HAS_NOT_BEEN_REGISTERED                           => '手机号还未被注册!',
        self::THE_OPERATION_IS_TOO_FREQUENT_PLEASE_GET_1_MINUTES_LATER       => '操作太频繁，请1分钟后再获取！',
        self::VERIFICATION_CODE_TIMEOUT_PLEASE_RE_OBTAIN                     => '验证码超时，请重新获取！',
        self::ADDRESS_ID_IS_NOT_VALID                                        => '地址id不合法!',
        self::STORE_ID_IS_NOT_LEGITIMATE                                     => '网店id不合法!',
        self::PLEASE_SET_THE_SHIPPING_COST                                   => '请先到后台设置默认运费模板',
        self::IMAGE_VERIFICATION_CODE_ERROR                                  => '图片验证码错误',
        self::NO_PAYMENT_PASSWORD_SET                                        => '未设置支付密码',
        self::OLD_PAYMENT_PASSWORD_ERROR                                     => '旧支付密码错误',
        self::PLEASE_ENTER_A_NEW_PASSWORD_FOR_6_DIGITS                       => '请输入6位纯数字新密码',
        self::TYPE_PARAMETER_IS_NOT_VALID                                    => '类型参数不合法',
        self::RECHARGE_AMOUNT_IS_NOT_LEGITIMATE                              => '充值金额不合法',
        self::PAY_PASSWORD_ERROR                                             => '支付密码错误',
        self::INSUFFICIENT_BALANCE_OF_PAYMENT_FAILURE                        => '余额不足，支付失败',
        self::ACTIVITY_DATE_OUT                                              => '活动暂未开启，敬请期待',
        self::DISTRIBUTION_RANGE_IS_NOT_WITH_IN_THE_AREA                     => '该区域不支持配送',
        self::IMG_CODE_NON_EXIT                                              => '图片验证码不存在',
        self::IMG_CODE_IS_USE                                                => '图片验证码已使用',
        self::IMG_CODE_OVER                                                  => '图片验证码已过期',
        self::GOODS_PARAMETERS_WROANG                                        => '商品参数不合法',
        self::GOODS_SPEC_ID_ERROR                                            => '商品规格关系不合法',
        self::SHOPPING_TYPE_ERROR                                            => '购物行为参数错误',
        self::GOODS_STOCK_NUM_NOT_ENOUGH                                     => '商品库存不足',
        self::GOODS_BATCH_NUMBER_ERROR                                       => '企业采购数量出错',
        self::PHONE_NUMBER_TO_BIND                                           => '电话号码已被绑定',
        self::PLEASE_ENTER_THE_OLD_LOGIN_PASSWORD                            => '请输入旧登录密码',
        self::PLEASE_ENTER_THE_NEW_LOGIN_PASSWORD                            => '请输入新登录密码',
        self::TWO_DIFFERENT_PASSWORDS                                        => '两次密码不一致',
        self::ORIGINAL_PASSWORD_ERROR                                        => '原密码错误',
        self::WECHAT_IS_NOT_BINDING                                          => '微信尚未绑定',
        self::QQ_IS_NOT_BINDING                                              => 'QQ尚未绑定',
        self::PLEASE_SELECT_THE_UNIT                                         => '请选择所属单位',
        self::PLEASE_ENTER_THE_NAME_OF_THE_INSTITUTE                         => '请输入所属学院名称',
        self::PLEASE_ENTER_YOUR_MAJOR                                        => '请输入你的专业',
        self::PLEASE_SELECT_THE_TYPE_OF_POSITION                             => '请选择职位类型',
        self::PLEASE_ENTER_YOUR_REAL_NAME                                    => '请输入您的真实姓名',
        self::PLEASE_ENTER_YOUR_STUDENT_ID_NUMBER                            => '请输入您的学号或工号',
        self::CART_DATA_ERROR                                                => '购物车数据异常',
        self::MISSING_STORE_PARAMETERS                                       => '缺少商店参数',
        self::STORE_PARAMETER_ERROR                                          => '商店参数错误',
        self::PAYMENT_ERROR                                                  => '支付方式错误',
        self::MESSAGE_NUMBER_SHOULD_NOT_BE_GREATER_THAN_300                  => '留言字数不能大于300',
        self::PLEASE_ENTER_A_PHONE_NUMBER                                    => '请输入联系电话',
        self::PHONE_NUMBER_IS_NOT_VALID                                      => '联系电话非有效手机号码',
        self::PLEASE_SELECT_THE_DELIVERY_ADDRESS                             => '请选择配送地址',
        self::DELIVERY_ADDRESS_ERROR                                         => '配送地址错误',
        self::FAILED_TO_GET_THE_SHIPPING_ADDRESS                             => '获取送货地址位置失败,请尝试更新地址信息',
        self::PLEASE_SET_THE_DEFAULT_SHIPPING_TEMPLATE                       => '请先到后台设置默认运费模板',
        self::WRONG_QUANTITY_OF_GOODS                                        => '商品数量错误',
        self::PURCHASE_COMMODITY_ERROR                                       => '购买商品错误',
        self::PRODUCT_INVENTORY_SHORTAGE                                     => '商品状态错误或库存不足',
        self::FAILED_TO_GENERATE_ORDER                                       => '生成订单失败',
        self::WRONG_DELIVERY_TIME                                            => '请输入合法的预配送时间',
        self::GOODS_BATCH_NOT_SET                                            => '商品不允许企业采购',
        self::GOODS_SPEC_VALUE_ERROR                                         => '商品规格值错误',
        self::MERCHANDISE_ATTRIBUTION_STORE_DATA_ERROR                       => '商品归属网店数据错误',
        self::COMPANY_ID_ERROR                                               => '企业id错误',
        self::DATA_NOT_EXISTS                                                => 'id对应数据不存在',
        self::TOKEN_NOT_VALID                                                => 'token值不存在或不合法',
        self::SCHOOL_NOT_ADD                                                 => '新增学校失败',
        self::TODAY_TWICE_FULL                                               => '提现次数已满',
    );

}
