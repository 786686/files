<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/10/25
 * Time: 15:17
 */

namespace Common\Lib\Defined;


class ErrorMsg extends ErrorCode
{
    // 注意: 因为前端是强类型语言，此处所有的状态码都返回字符串

    const OK = '0';  //处理成功
    const SUCCESS = 1;

    const NOT_FOUND = '404';
    /*** 关于系统底层错误代码  小于100 ***/
    const ERR_SYTEM = '-1'; //系统错误
    const ERR_PARAM = '-2'; //参数错误
    const ERR_EMPTY_RESULT = '-3'; //请求接口无返回
    const ERR_INVALID_PARAMETER = '-4'; //请求参数错误
    const ERR_CHECK_SIGN = '-5'; //签名验证错误
    const ERR_NO_PARAMETERS = '-6'; //参数缺失
    const ERR_SERVICE_NOT_FOUND = '-7'; //方法未找到
    const ERR_VER_NOTEXISTS = '-8'; //版本号错误
    const ERR_DB_ERROR = '-9'; //数据库操作错误
    const ERR_UPLOAD = '-10'; //上传失败
    const ERR_NOT_LOGIN = '-11'; //没有登录
    const ERR_NOT_SERVICENAME = '-12'; //没有服务别名
    const ERR_SYTEM_BUSY = '-13'; //系统繁忙
    const ERR_ACCESS = '-15';//access错误
    const ERR_USER_ACCESS = '-16';//user_access错误
    const ERR_VISIT_ERROR = '-17';//频繁请求受限
    const ERR_VISIT_IP = '-18';//频繁请求受限(IP受限)
    const ERR_VISIT_DEVICE = '-19';//频繁请求受限(设备受限)
    const ERR_VISIT_BLACK = '-20';//黑名单受限(请求异常)
    const ERR_EXPIRE_TIME = '-21';//超时(请求异常)
    const ERR_VISIT_WAY_ERROR = '-22';//访问限制(请求异常)
    const ERR_STATUS = '-23';//状态错误
    const NOT_AUTHORIZED = '-1100'; // 未授权

    const TOKEN_NOT_VALID = '-24';
    /***********会员业务**********************/
    const USER_EXT_ERR = '0201'; //会员不存在


    const USER_SENDINTEGRAL_ERR = '0214'; //送积分出错
    const USER_NOTENOUGH_ERR = '0215'; //积分不够
    const USER_GETINTEGRAL_ERR = '0216'; //获取积分失败
    const USER_GETAPPOINTMENT_ERR = '0217'; //获取用户赴约次数失败

    /*************验证码********************/
    const SMSCODE_ERR = '0222'; //验证码错误
    const TOOMUCH_ERR = '0221'; //太多短信验证

    /***********约战业务**********************/
    const PROMISE_ADD_ERR = '0401'; //插入应约失败
    const PROMISE_UPD_ERR = '0402'; //更新应约状态失败
    const ACTICITY_ADD_ERR = '0403'; //插入活动信息失败
    const ACTICITY_EXT_ERR = '0404'; //活动信息不存在
    const PROMISE_COUNT_ERR = '0405'; //正在应约活动数不能超过2
    const PROMISE_ADDTIME_ERR = '0406'; //不能应约两个相同时间的活动

    /***********评论业务**********************/
    const COMMENT_ADD_ERR = '0501'; //添加评论出错
    const COMMENT_EXT_ERR = '0502'; //评论不存在
    const COMMENT_UPD_ERR = '0503'; //评论状态更新出错

    /***********其它业务**********************/
    const FEEDBACK_ADD_ERR = '0901'; //反馈出错
    const MOBILE_NO_ERR = '0902'; //号码格式出错
    const MOBILE_EXT_ERR = '0903'; //号码存在
    const VERIFI_EXT_ERR = '0904'; //发送出错
    const FAV_ADD_ERR = '0911'; //添加收藏失败
    const FAV_DEL_ERR = '0912'; //删除收藏失败
    /***********其它业务**********************/

    /**************储值卡*******************/
    const DEBIT_CARD_NOT_EXIST = '1501'; //储值卡密码有误
    const DEBIT_CARD_BINDED = '1502'; //您已改储值卡充值过一次
    const DEBIT_CARD_BINDED_BYOTHER = '1503'; //该储值卡已被使用
    const DEBIT_CARD_UNABLE = '1504'; //该储值卡已失效
    const DEBIT_CARD_EXPIRE = '1505'; //该储值卡已过期
    const DEBIT_CARD_NOT_USE = '1506'; //该储值卡尚未开放使用
    const DEBIT_CARD_BIND_MAX = '1507'; // 达到储值卡批次最大绑定限制数

    /******* 约练  *******/
    const COACH_NOT_EXIST = '1703'; //教练不存在
    const ALREADY_COMMENT_COACH = '1704'; // 已经评价过教练了
    const COMMENT_COACH_FAILED = '1705'; // 评价教练失败
    const COMFIRM_COACH_FAILED = '1706'; // 确认预约服务失败
    const COMFIRM_COACH_HAS = '1707'; // 已确认服务
    const TIME_ALREADY_BESPEAK = '1708'; // 该时间段已经被预定了
    const NOT_SET_BESPEAK_TIME = '1709'; // 教练未设置当前预定时间
    const BESPEAK_TIME_GONE = '1710'; // 已经过了预约时间
    const COACH_ORDER_NOT_EXIST = '1711'; // 订单不存在
    const CANCEL_BESPEAK_TIME_GONE = '1712'; // 已经过了取消预约的时间
    const CANCEL_BESPEAK_FAILED = '1713'; // 取消约练失败
    const CAN_NOT_CANCEL_COACH_ORDER = '1714'; // 该订单不能进行取消
    const CAN_NOT_COMMENT_COACH_ORDER = '1715'; // 该订单不能进行评价
    const CANCEL_PAY_OK_ORDER_FAILED = '1716';  // 取消约练订单

    /****** 上传图片  ******/
    const UPLOAD_IMAGE_TYPE_ERROR = '1902'; // 上传图片类型错误
    const UPLOAD_IMAGE_FAILED = '1903'; // 上传图片失败
    const DELETE_IMAGE_FAILED = '1904'; // 删除图片失败


    /****** 非法访问 *******/
    const ACT_REFRESH_RESTRICTED = '2200'; //访问频繁


    /******** 微信小程序 *********/
    const WX_USER_LOGIN_FAILED = '3000'; // 登录失败
    const WX_USER_LOGINED = '3002';//用户已登录
    const WX_USER_NOT_LOGIN = '3001'; // 用户未登录
    const WX_USER_UNBIND = '3010'; //用户未绑定
    const WX_USER_UNBIND_FAILED = '3011'; //用户绑定失败

    const INSERT_ORDER_FAILED = '3050'; // 下单失败


    // 订单相关错误码
    const ADD_ORDER_TIME_ERROR = '4001';
    const ADD_ORDER_PEOPLE_NUM_ERROR = '4002';
    const ADD_ORDER_ROOM_UNAVAILABLE = '4003';
    const ADD_ORDER_GOODS_INFO_ERROR = '4004';
    const ADD_ORDER_GOODS_TIME_ERROR = '4005';
    const ADD_ORDER_COUPON_ERROR = '4006';
    const ADD_ORDER_PACKAGE_ERROR = '4007';
    const ADD_ORDER_NAME_ERROR = '4008';
    const DELETE_ORDER_ERROR = '4009';
    const ADD_ORDER_ERROR = '4010';

    // 支付相关错误码
    const PAY_ORDER_PARAMS_ERROR = '5001';
    const PAY_ORDER_ORDER_ERROR = '5002';
    const REPAY_ORDER_ORDER_ERROR = '5011';// 预定发起支付，未完成，超时自动取消，再次点支付
    const REFUND_QUERY_NOT_FINISH = '5003';
    const PAY_SUCCESS_WITH_INTEGRAL = '5100';//积分/余额支付成功
    const PAY_INTEGRAL_ERROR = '5004';//积分不可用
    const PAY_REQUEST_ERROR = '5005';//支付请求失败
    const PAY_FREE = '5010';//免支付
    /*** 获取app客户端相关 ***/
    const GET_CLIENT_CONFIG_ERROR = '7000';        //获取相关key值失败

    const PHONE_NOT_EXIST = '1401'; //号码不存在
    const HAS_GET_RED_PACK = '1402'; //已领取红包
    const GET_RED_OVER_FLOW = '1403'; //红包已领完
    // 已领取过当前红包
    const CURRENT_COUPON_EXISTED = '1404';

    const ERR_OTHER = '9001'; // 其他错误
    const ERR_UNKNOWN = '9002'; // 未知错误

    /********** 邀请　**********/
    const INVITE_BINDED = '1002'; //已被绑定
    const ERR_BINDED_HIMSELF = '1003'; //不能跟自己绑定
    const ERR_BINDED_NOT_NEW_USER = '1004'; //非新用户
    const CARD_BINDED_BYOTHER = '1005'; //会员卡已被他人绑定
    const CARD_PHONE_NOEXIST = '1006'; //会员卡没有预留手机
    const CARD_PHONE_ERROR = '1007'; //会员卡没有预留手机

    const NOT_RESPONSE  = 3001;

    // 请求方式错误
    const QUERY_METHOD_ERR = 30001;

    // 微信相关
    const ILLEGALAESKEY = '-41001'; // encodingAesKey 非法
    const ILLEGALIV = '-41002'; // IV 非法
    const ILLEGALBUFFER = '-41003'; // aes 解密失败
    const DECODEBASE64ERROR = '-41004'; // base64解密失败
    //提醒相关
    const NOTICE_READ_ERROR = '6001';//设置已读通知失败

    const DOYEN_ERROR_JOIN = '7001';//达人加入错误
    const DOYEN_ERROR_INVITE = '7002';//邀请错误
    const DOYEN_ERROR_HOME = '7003';//达人中心错误
    const DOYEN_ERROR_CODE = '7004';//邀请码错误
    const DOYEN_ERROR_RELATION_BUILD = '7100';//关系已绑定
    const DOYEN_ERROR_WITHDRAW = '7005';//提现错误

    const RECHARGE_ACTIVITY_PRIZE = '8001';//活动已兑奖


    /**
     * 错误代码与消息的对应数组
     *
     * @var array
     */
    static $msg = array(
        self::OK                    => '处理成功',
        self::SUCCESS               => '请求成功',//成功
        self::ERR_SYTEM             => '系统错误',
        self::ERR_PARAM             => '参数错误',
        self::ERR_EMPTY_RESULT      => '请求接口无返回',
        self::ERR_INVALID_PARAMETER => '请求参数错误',
        self::ERR_CHECK_SIGN        => '签名错误',
        self::ERR_NO_PARAMETERS     => '参数缺失',
        self::ERR_SERVICE_NOT_FOUND => '方法未找到',
        self::ERR_VER_NOTEXISTS     => '版本号错误',
        self::ERR_DB_ERROR          => '数据库操作错误',
        self::ERR_UPLOAD            => '上传失败',
        self::ERR_NOT_LOGIN         => '没有登录',
        self::ERR_NOT_SERVICENAME   => '没有服务别名',
        self::ERR_SYTEM_BUSY        => '系统繁忙',
        self::TOKEN_NOT_VALID       => 'TOKEN失效或已过期',

        self::COACH_NOT_EXIST             => '教练不存在',
        self::ALREADY_COMMENT_COACH       => '已经评价过教练了',
        self::COMMENT_COACH_FAILED        => '评价教练失败',
        self::COMFIRM_COACH_FAILED        => '确认预约服务失败',
        self::COMFIRM_COACH_HAS           => '已确认服务',
        self::TIME_ALREADY_BESPEAK        => '该时间段已经被预定了',
        self::NOT_SET_BESPEAK_TIME        => '教练未设置当前预定时间',
        self::BESPEAK_TIME_GONE           => '已经过了预约时间',
        self::COACH_ORDER_NOT_EXIST       => '订单不存在',
        self::CANCEL_BESPEAK_TIME_GONE    => '已经过了取消预约的时间',
        self::CANCEL_BESPEAK_FAILED       => '取消约练失败',
        self::CAN_NOT_CANCEL_COACH_ORDER  => '该订单不能进行取消',
        self::CAN_NOT_COMMENT_COACH_ORDER => '该订单不能进行评价',
        self::CANCEL_PAY_OK_ORDER_FAILED  => '取消订单失败',

        /******* 上传图片  *******/
        self::UPLOAD_IMAGE_TYPE_ERROR     => '上传图片类型错误',
        self::UPLOAD_IMAGE_FAILED         => '上传图片失败',
        self::DELETE_IMAGE_FAILED         => '删除图片失败',
        self::ERR_UNKNOWN                 => '未知错误',

        /******* 储值卡 *******/
        self::DEBIT_CARD_NOT_EXIST        => '密码错误，充值失败',
        self::DEBIT_CARD_BINDED           => '您已用该储值卡充值过一次',
        self::DEBIT_CARD_BINDED_BYOTHER   => '该储值卡已被使用',
        self::DEBIT_CARD_UNABLE           => '该储值卡已失效',
        self::DEBIT_CARD_EXPIRE           => '该储值卡超过使用期限',
        self::DEBIT_CARD_NOT_USE          => '该储值卡尚未开放使用',
        self::USER_EXT_ERR                => '会员不存在',

        /*** 通用错误 ***/
        self::NOT_AUTHORIZED              => '未授权登录!',
        self::NOT_RESPONSE                => '查询无响应，稍后再试',
        self::QUERY_METHOD_ERR            => '非法请求',
    );


    /**
     * 返回错误代码的描述信息
     *
     * @param int $code 错误代码
     * @param string $otherErrMsg 其他错误时的错误描述
     * @return string 错误代码的描述信息
     */
    public static function getMsg($code, $otherErrMsg = '')
    {
        if ($code == self::ERR_UNKNOWN) {
            return $otherErrMsg;
        }

        if (isset(self::$msg[$code])) {
            return self::$msg[$code];
        }

        return $otherErrMsg;
    }
}