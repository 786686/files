<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/10/29
 * Time: 11:06
 */

namespace Common\Lib\Defined;

/**
 * 商城的 - 常量定义 - 统一到此处，方便管理
 * Class MallDefined
 *
 * @author fanzhaogui
 * @date 2019-10-29
 * @package Common\Lib\Defined
 */
class MallDefined
{
    /*** 首页数据 ***/
    /**
     * 菜篮子
     * @var string
     */
    const CAI_LAN_ZI_TITLE = '菜篮子';
    /**
     * 菜篮子对应的PID
     * @var integer
     */
    const CAI_LAN_ZI_PID = 3;
    /**
     * 建材网
     * @var string
     */
    const JIAN_CAI_WANG_TITLE = '建材网';
    /**
     * 建材网对应的PID
     * @var integer
     */
    const JIAN_CAI_WANG_PID = 7;
    /**
     * @var string 首页缓存数据，缓存键
     */
    const HOME_DATA_CACHE_KEY = 'home_date:total';
    /**
     * @var string 首页菜单，缓存键
     */
    const HOME_DATA_MENUS_CACHE_KEY = 'home_data:menus';
    /**
     * 默认为app类型
     * @var int
     */
    const PLAT_TYPE_FOR_APP = 2;
    /**
     * 默认为PC、WAP端
     * @var string
     */
    const DEVICE_OF_DEFAULT = '1';
    /**
     * 微信
     * @var string
     */
    const DEVICE_FOR_WECHAT = '5';
    /**
     * IOS
     * @var string
     */
    const DEVICE_FOR_IOS = '4';
    /**
     * Android
     * @var string
     */
    const DEVICE_FOR_ANDROID = '3';
    /**
     * 网店默认电话号码
     * @var string
     */
    const STORE_DEFAULT_PHONE = '4009300277';
    /**
     * 分享的标题
     * @var string
     */
    const MALL_SHARE_TITLE = '七子商城发现了好商品哦';
    /**
     * 商品名称的后缀
     * @var string
     */
    const GOODS_NAME_SUFFIX = '--七子商城';
    /**
     * token的失效时间：秒(s)
     * @var int
     */
    const TOKEN_EXPIRE_TIMESTAMP = 7200;
    /**
     * 商品审核通过的消息
     * @var string
     */
    const AUDIT_PASSED_MESSAGE = "你好，您提交的商品“%s”，id为“%d”审核通过。";
    /**
     * 商品添加审核不通过的状态值
     * @var int
     */
    const GOODS_ADD_AUDIT_NOT_PASSED_STATUS = 24;
    /**
     * 商品添加|修改 操作 待审核
     * @var int
     */
    const GOODS_ADD_OR_EDIT_AUDIT_STATUS = 20;
    /**
     * 商品审核不通过的消息
     * @var string
     */
    const AUDIT_NOT_PASSED_MESSAGE = "你好，您提交的商品“%s”，id为“%d”审核不通过。原因是：";
    /**
     * 创客-系统消息system_message的msg_type的值为30时，是商品审核
     * @var int
     */
    const SYSTEM_MSG_GOOD_AUDIT = 30;

    /**
     * 支付类型 - 余额支付
     * @var int
     */
    const PAY_TYPE_BALANCE = 1;

    /**
     * 支付类型 - 微信支付
     * @var int
     */
    const PAY_TYPE_WECHAT = 2;

    /**
     * 支付类型 - 支付宝支付
     * @var
     */
    const PAY_TYPE_ALIPAY = 3;
}