<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/1/6
 * Time: 15:36
 */

namespace Common\Lib\Defined;


class Transfer
{
    /**
     * @var int 单次提现的最大金额 1万元
     */
    const SIMPLE_WITHDRAW_AMOUNT = 10000;

    /**
     * @var int 批量提现的总计金额 10万元
     */
    const TOTAL_BATCH_WITHDRAW_AMOUNT = 100000;

    const PER_DAY_LIMIT_TRANSFER_TIMES = 30;


    /*ali*/
    /**
     * @var float 支付宝提现，最低金额 0.1元
     */
    const ALI_MIN_AMOUNT = 0.1;

    /*wechat*/

    /**
     * @var float 微信体现，最低金额 1元
     */
    const WECHAT_MIN_AMOUNT = 1;
}