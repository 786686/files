<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/10/23
 * Time: 16:21
 */

namespace Common\Lib;


use OSS\OssClient;

class OssClientFactory
{

    private static $instance = NULL;

    /**
     * @var OssClient
     */
    protected $ossClient = null;

    /**
     * @var string
     */
    protected $bucket = '';

    /**
     * @var int 默认过期时间 一天
     */
    protected $expires = 86400;

    /**
     * 防止使用 new 创建多个实例
     *
     * Db2 constructor.
     */
    private function __construct()
    {
        $this->bucket = C('aliyun.bucket');
        $this->accessKeyId = C('aliyun.accessKeyId');
        $this->accessKeySecret = C('aliyun.accessKeySecret');
        $this->oss_endpoint = C('aliyun.oss_endpoint');
        $this->ossClient = new OssClient($this->accessKeyId, $this->accessKeySecret, $this->oss_endpoint);
    }

    /**
     * 防止 clone 多个实例
     */
    private function __clone()
    {
    }

    /**
     * 防止反序列化
     */
    private function __wakeup()
    {
    }

    /**
     * getInstace - 对外的接口，返回对象
     * @author: fanzhaogui
     * @date 2020-03-05
     * @return object
     */
    public static function getInstance()
    {
        if (self::$instance == NULL) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 本地图片生成oss, 一个具有一定有效期的图片地址
     *
     * @param string $localImgUrl
     */
    public function getExpireOssImgLink($localImgUrl)
    {
        // todo 是否需要判断是本地路径
        return $this->ossClient->signUrl($this->bucket, $localImgUrl, $this->expires);
    }


    /**
     * 设置过期时间
     * @param int $time
     *
     * @return $this
     */
    public function setExpire($time = 3600)
    {
        $this->expires = $time;
        return $this;
    }

}