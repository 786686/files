<?php
/**
 * Class Chuangke
 * @author wj
 * 2019-7-11
 */
namespace Common\Lib\Chuangke;
class Chuangke
{
    public $chuangke = "";
    public $postUri = '/Mobile/Api/getPostData';
    public $v = '3.0';
    /**
     * 定义单例模式的变量
     * @var null
     */
    private static $_instance = null;

    public static function getInstance() {
        if(empty(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    private function __construct() {

    }

    /**
     * @param $studentWxsn
     * @param $type
     * @return mixed
     * 梳理网店
     */
    public function getCombingShop($studentWxsn, $type, $form_time) {
        $data = [
            'v' => $this->v,
            'timestamp'   => $form_time,
            'studentWxsn' => $studentWxsn,
            'month'        => date("Y-m"),
            'type'         => $type,
            'createTime'   => $form_time,
            'updateTime'   => $form_time,
            'method'       => 'StudentCurriculum.getCombingShop',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $studentWxsn
     * @return mixed
     * 商品梳理记录
     */
    public function shopToCombingGoods($studentWxsn, $form_time) {
        $data = [
            'v' => $this->v,
            'student_wxsn' => $studentWxsn,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToCombingGoods',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $studentWxsn
     * @param $form_time
     * @param $service_count
     * @return mixed
     * 客服任务
     */
    public function shopToCombingCustomerService ($studentWxsn, $form_time, $service_count) {
        $data = [
            'v' => $this->v,
            'student_wxsn' => $studentWxsn,
            'service_count' => $service_count,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToCombingCustomerService',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $student_id
     * @param $student_wxsn
     * @param $form_time
     * @return mixed
     * 签到任务
     */
    public function shopToCombingSignIn ($student_id, $student_wxsn, $form_time){
        $data = [
            'v' => $this->v,
            'student_id' => $student_id,
            'student_wxsn' => $student_wxsn,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToCombingSignIn',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $student_wxsn
     * @param $form_time
     * @param $member_id
     * @param $member_nickname
     * @return mixed
     * 关注学生信息
     */
    public function studentCurriculumCustomer($student_wxsn, $form_time, $member_id, $member_nickname, $follow_student_id) {
        $data = [
            'v' => $this->v,
            'follow_student_id' => $follow_student_id,
            'member_id' => $member_id,
            'member_name' => $member_nickname,
            'student_wxsn' => $student_wxsn,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.customer',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $student_wxsn
     * @param $form_time
     * @return mixed
     * 客流量
     */
    public function shopToCombingPageView ($student_wxsn, $form_time) {
        $data = [
            'v' => $this->v,
            'student_wxsn' => $student_wxsn,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToCombingPageView',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $student_wxsn
     * @param $form_time
     * @param $amount
     * @param $profits
     * @return mixed
     * 成交信息推送
     */
    public function shopToCombingOrderDone ($student_wxsn, $form_time, $amount, $profits) {
        $data = [
            'v' => $this->v,
            'student_wxsn' => $student_wxsn,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToCombingOrderDone',
            'amount' => $amount,
            'profits' => $profits,
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);
//print_r($result);exit;
        return $result;
    }

    /**
     * @param $student_wxsn
     * @param $memberInfo
     * @param $form_time
     * @return mixed
     * 回访信息
     */
    public function shopToCampusCustomerAccess ($student_wxsn, $memberInfo,$form_time) {
        $data = [
            'v' => $this->v,
            'student_wxsn' => $student_wxsn,
            'access_members' => $memberInfo,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToCampusCustomerAccess',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    /**
     * @param $student_wxsn
     * @param $type
     * @param $number
     * @param $form_time
     * @return mixed
     * 商城数据统计存储
     */
    public function shopToShopDataSummary ($student_wxsn, $type, $number, $form_time) {
        $data = [
            'v' => $this->v,
            'student_wxsn' => $student_wxsn,
            'type' => $type,
            'number' => $number,
            'create_time' => $form_time,
            'method' => 'StudentCurriculum.shopToShopDataSummary',
        ];
        $postUrl = C('wxkj.url').$this->postUri;
        $result = json_decode($this->send_post($postUrl,$data), true);

        return $result;
    }

    public function send_post($url, $post_data) {

        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);

        return $result;
    }
}