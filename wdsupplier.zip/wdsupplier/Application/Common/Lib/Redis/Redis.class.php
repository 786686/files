<?php
/**
 * Class redis
 * @author wj
 * 2019-6-28
 */

namespace Common\Lib\Redis;

class Redis
{
    public $redis = "";
    /**
     * 定义单例模式的变量
     * @var null
     */
    private static $_instance = null;

    public static function getInstance()
    {
        if (empty(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct()
    {
        if ( !extension_loaded('redis') ) {
            E(L('_NOT_SUPPORT_').':redis');
        }

        $this->redis = new \Redis();
        $options = array (
            'host'          => C('SESSION_REDIS_HOST') ? C('SESSION_REDIS_HOST') : '127.0.0.1',
            'port'          => C('SESSION_REDIS_PORT') ? C('SESSION_REDIS_PORT') : 6379,
            'timeout'       => C('SESSION_CACHE_TIME') ? C('SESSION_CACHE_TIME') : false,
            'persistent'    => C('SESSION_PERSISTENT') ? C('SESSION_PERSISTENT') : false,
            'auth'			=> C('SESSION_REDIS_AUTH') ? C('SESSION_REDIS_AUTH') : false,
        );
        $func        = $options['persistent'] ? 'pconnect' : 'connect';
        $result      = $this->redis->$func($options['host'], $options['port'], $options['timeout']);
        $this->redis->auth($options['auth']);
        // $this->redis->select(C('redis.dbindex'));
        if ($result === false) {
            throw new \Exception('redis connect error');
        }
    }

    /**
     * set
     * @param $key
     * @param $value
     * @param int $time
     * @return bool|string
     */
    public function set($key, $value, $time = 0)
    {
        if (!$key) {
            return '';
        }

        if (is_array($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE);
        }

        // 2019-10-25 fanzhaogui
        if (intval($time) < 1) {
            // return $this->redis->set($key, $value);
            // 给与默认时间 - 任何缓存都需要设置过期时间
            $time = 1200;
        }

        return $this->redis->setex($key, $time, $value);
    }

    /**
     * get
     * @param $key
     * @return bool|string
     */
    public function get($key)
    {
        if (!$key) {
            return '';
        }

        return $this->redis->get($key);
    }

    /**
     * @param $key
     * @return array
     */
    public function sMembers($key)
    {
        return $this->redis->sMembers($key);
    }

	/**
	 * maylee
	 * @return int
	 */
    public function del($key){
    	return $this->redis->del($key);
    }

    /**
     * @param $name
     * @param $arguments
     * @return array
     */
    public function __call($name, $arguments)
    {
        //echo $name.PHP_EOL;
        //print_r($arguments);
        if (count($arguments) != 2) {
            return '';
        }
        $this->redis->$name($arguments[0], $arguments[1]);
    }

    /**
     * @method 从队列左边入一个或多个队列（左进）
     * @author maylee
     * @param $key
     * @param  string $val 参数说明
     * @return
     */
	public function lPush($key, $value)
	{
		return $this->redis->lPush($key, $value);
	}

	/**
	 * @method 移除并返回存于 key 的 list 的最后一个元素。（右出）
	 * @author maylee方法名
	 * @param $key
	 * @return
	 */
	public function rpop($key){
    	return $this->redis->rPop($key);
	}

	/**
	 * @method 移除并返回存于 key 的 list 的最后一个元素。（左出）
	 * @author maylee方法名
	 * @param $key
	 * @return
	 */
	public function lpop($key){
    	return $this->redis->lPop($key);
	}

    public function incr($key)
    {
        return $this->redis->incr($key);
    }

    public function decr($key)
    {
        return $this->redis->decr($key);
    }

    public function delete($key)
    {
        return $this->redis->delete($key);
    }

    public function incrBy($key, $rows)
    {
        return $this->redis->incrBy($key, $rows);
    }
}