<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/10/25
 * Time: 15:53
 */

namespace Common\Lib\Traits;


use Common\Lib\Defined\ErrorMsg;
use Common\Util\ProviderRsa;

/**
 * Trait Helper 辅助工具
 * @package Common\Lib\Traits
 */
trait Helper
{
    public function renderJSON($res)
    {
        header('Content-type: application/json');
        if (empty($res)) {
            $res = $this->initRes();
        }
        $jsonString = json_encode($res);
        echo $jsonString;
        exit;
    }


    /**
     * 错误时json输出
     *
     * @param int $code 错误代码
     * @param string $msg 错误信息
     * @return string
     */
    public function errorOutput($code, $msg = '')
    {
        $res       = $this->initRes();
        $res->code = $code;
        if ($msg) {
            $res->msg = $msg;
        } else {
            $res->msg = ErrorMsg::getMsg($code);
        }
        $this->error = true;
        $this->renderJSON($res);
    }

    /**
     * 成功时的返回
     *
     * @param mixed $data 返回的数据
     * @return string
     */
    public function successOutput($data = array(), $msg = '', $code = 1)
    {
        $res = $this->initRes();
        if (is_string($msg) && trim($msg)) {
            $res->msg = $msg;
        }
        if (!empty($data)) { //注意： 不为空时不进行覆盖 data字段，因为data字段是对象类型
            $res->data = $data;
        }
        if ($code != ErrorMsg::SUCCESS) {
            $res->code = $code;
        }
        $this->renderJSON($res);
    }


    /**
     * initRes 初始化返回的结果
     * @author: fanzhaogui
     * @date 2019-10-25
     * @param bool $isObject
     * @return \stdClass
     */
    public function initRes($isObject = true)
    {
        $res        = new \stdClass();
        $res->code  = ErrorMsg::SUCCESS;
        $res->msg   = 'success';
        $res->param = I();
        if ($isObject) {
            $res->data = new \stdClass();
        } else {
            $res->data = array();
        }

        return $res;
    }


    /**
     * 请求创客
     * @author: fanzhaogui
     * @date 2019-11-05
     * @param $url
     * @param array $params
     * @return json|string
     */
    public function requestChuangke(array $params, $url = '')
    {
        if (empty($url)) {
            $url = C("ck_conf.url");
        }

        $rsa                    = new ProviderRsa();
        $requestParam["method"] = $params['method'] ?? C("ck_conf.store_data_method");
        // 公共参数
        $requestParam["v"]           = C("ck_conf.v");
        $requestParam["timestamp"]   = date('Y-m-d H:i:s');
        $requestParam["format"]      = "json";
        $requestParam["sign_method"] = "md5";

        // 公钥加密参数
        $paramsStr                    = json_encode($params);
        $rsaEncStr                    = $rsa->publicKeyEncode($paramsStr);
        $requestParam["requst_param"] = $rsaEncStr;

        // 签名
        $appSecret              = C('ck_conf.App_Secret');
        $requestParam['appKey'] = C('ck_conf.App_Key');
        $requestParam['sign']   = $this->getChuangkeSign($requestParam, $appSecret);
        log2File(array_merge($params, ['url' => $url]), 'chuangke');

        $result = curl_post($url, $requestParam);
        log2File(json_decode($result, true), 'api_reuslt_chuangke');
        return $result;
    }

    /**
     * 获取创客的签名
     * @author: fanzhaogui
     * @date 2019-11-05
     */
    public function getChuangkeSign(array $data, $appSecret)
    {
        // 过滤签名（为空或sign字段或上传文件不参与签名）
        foreach ($data as $key => $value) {
            if (in_array($key, ['sign'])) {
                unset($data[$key]);
            }
        }
        //数组键值自然排序
        ksort($data);
        reset($data);

        //拼装签名字符
        $prestr = '';
        foreach ($data as $k => $v) {
            $prestr .= $k . $v;
        }
        $mysign = '';

        switch (strtoupper(trim($data['sign_method']))) {
            case "MD5" :
                $mysign = md5($appSecret . $prestr . $appSecret);
                break;
        }
        return strtolower($mysign);
    }

    /**
     * 获取创客API的请求URI
     * @author: fanzhaogui
     * @date 2019-11-06
     * @return mixed
     */
    public function getChuangkeBaseApiUri()
    {
        return C("ck_conf.base_api_url");
    }
}