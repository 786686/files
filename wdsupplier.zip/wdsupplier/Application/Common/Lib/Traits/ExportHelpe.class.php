<?php
/**
 * User: Andy
 * Date: 2020/2/19
 * Time: 15:31
 */

namespace Common\Lib\Traits;


use Think\Exception;

trait ExportHelpe
{

	/**
	 * @author  建强 2020年1月10日 10:26:55
	 * @method  根据每行获取适当的行对应的字体大小
	 *
	 * @param   int $row
	 *
	 * @return  int
	 */
	public function getFontSizeByRow($row = 1)
	{
		switch ($row) {
			case 1:
				return 20;
				break;
			case 2 :
				return 11;
				break;
			default:
				return 10;
				break;
		}
	}

	/**
	 * @method  设置字体
	 * @author 建强 2020年1月10日 10:43:04
	 *
	 * @return string
	 */
	public function getFontName()
	{
		return '宋体';
	}

	/**
	 * @method 设置第二行导出excel
	 * @param string $a2
	 */
	public function getA2Time($A2 = '')
	{

		if (empty($A2)) {
			$A2 = '导出数据时间 ：' . date('Y-m-d H:i:s');
		}

		return $A2;
	}


	/**
	 * @author  建强 2020年1月10日 10:43:59
	 * @method  获取样式 应用数组
	 *
	 * @return array
	 */
	public function getStyleArrayByRow($row = 1)
	{

		$style = [
			'font'      => [
				'name' => $this->getFontName(),
				'size' => $this->getFontSizeByRow($row),
			],
			'alignment' => [
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
				// 水平居中
				'vertical'   => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				// 垂直居中
				'wrapText'   => true,
				// 自动换行

			],
			//通用配置所有边框细线
			'borders'   => [
				'allBorders' => [
					'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
				],
			],
		];

		return $style;
	}


	/**
	 * @method 获取row 行高
	 * @author 建强 2020年1月10日 10:17:08
	 *
	 * @return int 单位 pt
	 */
	public function getRowHeight($row = 1)
	{

		switch ($row) {
			case 1:
				return 25.5;
				break;
			case 2 :
			case 3 :
				return 20;
				break;
			default:
				return 18;
				break;
		}

	}

	/**
	 * 第一栏 和 第二栏的内容处理
	 *
	 * @param object $sheet
	 * @param array $columArr
	 * @param string $title
	 *
	 * @return mixed
	 */
	public function renderHeaderAndTitle($sheet, $columArr, $title = '')
	{
		$len = count($columArr);

		//渲染主体 第一 第二行
		for ($rowNum = 1; $rowNum <= 2; $rowNum++) {
			// 获取填充内容
			$title = ($rowNum == 1) ? $title : $this->getA2Time();
			$sheet->mergeCells('A' . $rowNum . ':' . $columArr[$len - 1] . $rowNum);
			$sheet->setCellValue('A' . $rowNum, $title);
			$sheet->getStyle('A' . $rowNum)
				->applyFromArray($this->getStyleArrayByRow($rowNum));
			// 行高
			$sheet->getRowDimension($rowNum)
				->setRowHeight($this->getRowHeight($rowNum));
		}

		return $sheet;
	}

	/**
	 * 获取横向坐标
	 *
	 * @param array $headerTitle
	 * @param int $rowNum
	 *
	 * @return array
	 */
	public function getRowIndexKey(array $headerTitle)
	{
		$key         = $startKey = ord("A");  //A--65
		$key2        = ord("@"); //@--64
		$Z_key       = ord("Z");
		$columArrKey = [];

		// 头部标题 -- 从第三行开始

		foreach ($headerTitle as $kh => $vh) {
			if ($key > $Z_key) {
				$key2  += 1;
				$key   = $startKey;
				$colum = chr($key2) . chr($key);//超过26个字母时才会启用
			}
			else {
				if ($key2 >= $startKey) {
					$colum = chr($key2) . chr($key);//超过26个字母时才会启用
				}
				else {
					$colum = chr($key);
				}
			}
			$columArrKey[] = $colum;
			$key++;
		}

		return $columArrKey;
	}

    /**
     * 当导出的数据为空是，提示
     *
     * @author: fanzhaogui
     */
	public function exportDataEmpty()
	{
		echo "<script>layer.alert('数据为空！')</script>";
		exit();
	}


    /**
     * 获取不同版本的信息
     *
     * @author: fanzhaogui
     * @param int|string $ver
     * @return array| Exception
     */
	public function getVersionOption($ver = 2007)
    {
        // 版本差异信息
        $version_opt = [
            '2007' => [
                'mime'       => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'ext'        => '.xlsx',
                'write_type' => 'Xlsx',
            ],
            '2003' => ['mime'       => 'application/vnd.ms-excel',
                       'ext'        => '.xls',
                       'write_type' => 'Xls',
            ],
            'pdf'  => ['mime'       => 'application/pdf',
                       'ext'        => '.pdf',
                       'write_type' => 'PDF',
            ],
            'ods'  => ['mime'       => 'application/vnd.oasis.opendocument.spreadsheet',
                       'ext'        => '.ods',
                       'write_type' => 'OpenDocument',
            ],
        ];
        if (!isset($version_opt[$ver])) {
            throw new Exception('版本信息不存在');
        }
        return $version_opt[$ver];
    }

    /**
     * 获取Content-Type的信息
     *
     * @author: fanzhaogui
     * @date xxx
     * @param int|string $ver
     * @return string
     */
    public function getVersionContentType($ver = 2007)
    {
        $option = $this->getVersionOption($ver);
        return $option['mime'];
    }

    /**
     * 获取导出文件的文件后缀
     *
     * @author: fanzhaogui
     * @param int|string $ver
     * @return string
     */
    public function getVersionFileExt($ver = 2007)
    {
        $option = $this->getVersionOption($ver);
        return $option['ext'];
    }


    /**
     * @method 获取colom 列宽
     * @author 建强 2020年1月10日 10:17:08
     * @param  int $width
     *
     * @return int 单位 pt
     */
    public function getColomWidth($width = 0)
    {
        return $width > 0 ? $width : 15;
    }
}