<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/12/19
 * Time: 17:52
 */

namespace Common\Lib\Traits;

use Admin\Model\OrderModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;


trait OrderExportHelper
{
	use ExportHelpe;

    /**
     * @var array 导出订单的标题
     */
    public $titleHeader = [
        // 1-10
        array('title' => '序号', 'colWidth' => 10),
        array('title' => '订单编号', 'colWidth' => 10),
        array('title' => '订单号', 'colWidth' => 30),
        array('title' => '支付订单号', 'colWidth' => 25),
        array('title' => '交易单号', 'colWidth' => 40),
        array('title' => '商品ID', 'colWidth' => 30),
        array('title' => '商品名称', 'colWidth' => 30),
        array('title' => '商品副标题', 'colWidth' => 30),
        array('title' => '商品分类', 'colWidth' => 30),
        array('title' => '致富中心', 'colWidth' => 30),
		// 11-20
        array('title' => '所属网店', 'colWidth' => 20),
        array('title' => '商品规格', 'colWidth' => 20),
        array('title' => '供应商', 'colWidth' => 20),
        array('title' => '商品数量', 'colWidth' => 20),
        array('title' => '商品单价(元)', 'colWidth' => 20),
        array('title' => '商品单价(元)', 'colWidth' => 20),
        array('title' => '商品优惠单价(元)', 'colWidth' => 20),
        array('title' => '订单优惠总价(元)', 'colWidth' => 20),
        array('title' => '运费', 'colWidth' => 10),
        array('title' => '综合成本(元)', 'colWidth' => 20),
		// 21-30
        array('title' => '产品购进价(元)', 'colWidth' => 10),
		array('title' => '人工成本(元)', 'colWidth' => 10),
		array('title' => '物流成本(元)', 'colWidth' => 10),
		array('title' => '实际物流成本(元)', 'colWidth' => 10),
		array('title' => '包装成本(元)', 'colWidth' => 10),
		array('title' => '风险成本(元)', 'colWidth' => 10),
		array('title' => '仓储成本(元)', 'colWidth' => 10),
		array('title' => '水电成本(元)', 'colWidth' => 10),
		array('title' => '设备用品用具摊分成本(元)', 'colWidth' => 10),
		array('title' => '其他成本(元)', 'colWidth' => 10),
		// 31 - 40
		array('title' => '最小限购量', 'colWidth' => 10),
		array('title' => '最大限购量', 'colWidth' => 10),
		array('title' => '采购税率', 'colWidth' => 10),
		array('title' => '收货人', 'colWidth' => 10),
		array('title' => '联系电话', 'colWidth' => 10),
		array('title' => '收货地址', 'colWidth' => 10),
		array('title' => '下单时间', 'colWidth' => 10),
		array('title' => '下单人手机', 'colWidth' => 10),
		array('title' => '付款时间', 'colWidth' => 10),
		array('title' => '订单状态', 'colWidth' => 10),
        // 41-50
		'商品总价(元)', '商品订单总价(元)','订单总价(元)', '物流方式', '付款方式',
		'售后状态','实退时间','实退金额', '订单留言','卖家备注',
        array('title' => '商品总价(元)', 'colWidth' => 10),
        array('title' => '商品订单总价(元)', 'colWidth' => 10),
        array('title' => '订单总价(元)', 'colWidth' => 10),
        array('title' => '物流方式', 'colWidth' => 10),
        array('title' => '付款方式', 'colWidth' => 10),
        array('title' => '售后状态', 'colWidth' => 10),
        array('title' => '实退时间', 'colWidth' => 10),
        array('title' => '实退金额', 'colWidth' => 10),
        array('title' => '订单留言', 'colWidth' => 10),
        array('title' => '卖家备注', 'colWidth' => 10),
		// 51-60
		'快递单号','到货时间','商品发货地','上传时间','地区','商品品牌',
		'品牌品种','是否测试订单','是否已完结','订单完结时间','单位名称',
        array('title' => '快递单号', 'colWidth' => 20),
        array('title' => '商品发货地', 'colWidth' => 15),
        array('title' => '到货时间', 'colWidth' => 15),
        array('title' => '上传时间', 'colWidth' => 10),
        array('title' => '商品品牌', 'colWidth' => 10),
        array('title' => '品牌品种', 'colWidth' => 10),
        array('title' => '是否测试订单', 'colWidth' => 10),
        array('title' => '是否已完结', 'colWidth' => 10),
        array('title' => '订单完结时间', 'colWidth' => 10),
        array('title' => '单位名称', 'colWidth' => 10),
        // 61-67
        array('title' => '是否刷单', 'colWidth' => 10),
        array('title' => '发票类型', 'colWidth' => 10),
        array('title' => '发票抬头', 'colWidth' => 10),
        array('title' => '发票纳税号', 'colWidth' => 10),
        array('title' => '收票人手机', 'colWidth' => 10),
        array('title' => '收票人邮箱', 'colWidth' => 10),
        array('title' => '收票人内容', 'colWidth' => 10),
        // 68
    ];

    /**
     * 导致订单列表
     * @author: fanzhaogui
     * @date xxx
     * @param array $requetParams
     * @param array $where
     * @return mixed
     *
     * todo
     * 1 单元格 内容如何居中
     * 2 number过长，变成10进制的表达式
     * 3 合并单元格
     * 4 设置字体颜色
     * 5 设置背景颜色
     * 6 是否考虑导入图片的问题
     */
    public function exportOrder(array $requetParams, array $where)
    {
		// 当不存在数据的时候，直接定制
		$orderModel = M('order');
		$total      = $orderModel->count();
		if ($total == false) {
			exit();
		}

		$spreadsheet = new Spreadsheet();
		$sheet       = $spreadsheet->getActiveSheet();
		// 横向坐标 A-Z  AA-AZ
		$columArr = $this->getRowIndexKey($this->titleHeader);

		// 文件名
		$filename = 'b2c订单列表-导出订单';

		// 第一栏和第二栏的内容
		$sheet = $this->renderHeaderAndTitle($sheet, $columArr, $filename);

		// 头部标题 -- 从第三行开始
		$rowNum = 3;
		foreach ($this->titleHeader as $kh => $vh) {
			$colum = $columArr[$kh];
			$sheet->setCellValue($colum . $rowNum, $vh['title']);
			// 设置单元格宽度
			$sheet->getColumnDimension($colum)->setWidth($vh['colWidth']);
			// 如何居中的问题
			$sheet->getStyle($colum . $rowNum)->applyFromArray($this->getStyleArrayByRow($rowNum));
			// 填充背景色
			$sheet->getStyle($colum . $rowNum)
				->getFill()
				->setFillType(Fill::FILL_SOLID)
				->getStartColor()
				->setARGB(COLOR::COLOR_YELLOW);
		}

		// 内容部分，从第四行开始
        $num = 4;
        foreach ($this->handlerExportDataList($total, []) as $list) {
            foreach ($list as $k => $data) {
                // $data 是一条记录
                if ($data) {
                    $i = 0;
                    foreach ($data as $v_1) {
                        if (!isset($columArr[$i])) { // 如果超过表头长度则忽略
                            break;
                        }
                        $sheet->setCellValue($columArr[$i] . $num, $v_1 . " ");
                        $i++;
                    }
                }
                $num++;
            }
        }

        $filename = $filename . date("Y_m_d_H_i_s") . ".xlsx";
        //或者$objWriter = new PHPExcel_Writer_Excel5($objPHPExcel); 非2007格式
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=GB2312');
//        header("Pragma: public");
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $objWriter = IOFactory::createWriter($spreadsheet, 'Xlsx');
        return $objWriter->save('php://output');

    }

    /**
     * handlerExportDataList
     * @author: fanzhaogui
     * @date xxx
     * @param array $where
     * @param string $limit
     *
     * @return \Iterator yield
     */
    protected function handlerExportDataList($total, array $where, $limit = '')
    {
        $listRows   = 15;
        $totalPages = ceil($total / $listRows);
        $model      = new OrderModel();
        for ($i = 0; $i < $totalPages; $i++) {
            $limit = ($listRows * $i) . "," . $listRows;
            yield $model->limit($limit)->select();
        }
    }
}