<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/12/19
 * Time: 17:52
 */

namespace Common\Lib\Traits;

use Admin\Model\OrderModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// 导出订单商品数据
trait OrderExportHelper
{
    /**
     * @var array 导出的标题
     */
    public $titleHeader = [
        // 1-10
        array('title' => '序号', 'colWidth' => 10),
        array('title' => '订单编号', 'colWidth' => 10),
        array('title' => '订单号', 'colWidth' => 30),
        array('title' => '支付订单号', 'colWidth' => 25),
        array('title' => '交易单号', 'colWidth' => 40),
        array('title' => '商品ID', 'colWidth' => 10),
        array('title' => '商品名称', 'colWidth' => 30),
        array('title' => '商品副标题', 'colWidth' => 30),
        array('title' => '商品分类', 'colWidth' => 20),
        array('title' => '致富中心', 'colWidth' => 10),
        // 11-20
        array('title' => '所属网店', 'colWidth' => 10),
        array('title' => '商品规格', 'colWidth' => 10),
        array('title' => '商品数量', 'colWidth' => 10),
        array('title' => '商品单价(元)', 'colWidth' => 10),
        array('title' => '商品优惠单价(元)', 'colWidth' => 10),
        array('title' => '商品优惠总价(元)', 'colWidth' => 10),
        array('title' => '订单优惠总价(元)', 'colWidth' => 10),
        array('title' => '运费', 'colWidth' => 10),
        array('title' => '综合成本(元)', 'colWidth' => 10),
        array('title' => '产品购进价(元)', 'colWidth' => 10),
        // 21-30
        array('title' => '人工成本(元)', 'colWidth' => 10),
        array('title' => '物流成本(元)', 'colWidth' => 10),
        array('title' => '实际物流成本(元)', 'colWidth' => 10),
        array('title' => '包装成本(元)', 'colWidth' => 10),
        array('title' => '风险成本(元)', 'colWidth' => 12),
        array('title' => '仓储成本(元)', 'colWidth' => 15),
        array('title' => '水电成本(元)', 'colWidth' => 10),
        array('title' => '设备用品用具摊分成本(元)', 'colWidth' => 12),
        array('title' => '其他成本(元)', 'colWidth' => 10),
        array('title' => '最小限购量', 'colWidth' => 15),
        // 31 - 40
        array('title' => '最大限购量', 'colWidth' => 10),
        array('title' => '采购税率', 'colWidth' => 10),
        array('title' => '收货人', 'colWidth' => 10),
        array('title' => '联系电话', 'colWidth' => 10),
        array('title' => '收货地址', 'colWidth' => 10),
        array('title' => '下单时间', 'colWidth' => 15),
        array('title' => '下单人手机', 'colWidth' => 20),
        array('title' => '付款时间', 'colWidth' => 15),
        array('title' => '订单状态', 'colWidth' => 10),
        array('title' => '商品总价(元)', 'colWidth' => 10),
        // 41-50
        array('title' => '商品订单总价(元)', 'colWidth' => 10),
        array('title' => '订单总价(元)', 'colWidth' => 10),
        array('title' => '物流方式', 'colWidth' => 10),
        array('title' => '付款方式', 'colWidth' => 10),
        array('title' => '售后状态', 'colWidth' => 10),
        array('title' => '实退时间', 'colWidth' => 10),
        array('title' => '实退金额', 'colWidth' => 10),
        array('title' => '订单留言', 'colWidth' => 10),
        array('title' => '卖家备注', 'colWidth' => 10),
        array('title' => '快递单号', 'colWidth' => 10),
        // 51 - 60
        array('title' => '到货时间', 'colWidth' => 10),
        array('title' => '商品发货地', 'colWidth' => 10),
        array('title' => '上传时间', 'colWidth' => 10),
        array('title' => '地区', 'colWidth' => 10),
        array('title' => '商品品牌', 'colWidth' => 10),
        array('title' => '品牌品种', 'colWidth' => 10),
        array('title' => '是否测试订单', 'colWidth' => 10),
        array('title' => '是否已完结', 'colWidth' => 10),
        array('title' => '订单完结时间', 'colWidth' => 10),
        array('title' => '单位名称', 'colWidth' => 10),
        // 61~
        array('title' => '是否刷单', 'colWidth' => 10),
        array('title' => '发票类型', 'colWidth' => 10),
        array('title' => '发票抬头', 'colWidth' => 10),
        array('title' => '发票纳税号', 'colWidth' => 10),
        array('title' => '收票人手机', 'colWidth' => 10),
        array('title' => '收票人邮箱', 'colWidth' => 10),
        array('title' => '收票人内容', 'colWidth' => 10),
    ];

    /**
     * 导致订单商品
     * @author: fanzhaogui
     * @date xxx
     * @param array $requetParams
     * @param array $where
     * @return mixed
     */
    public function exportOrder(array $requetParams, array $where)
    {
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        // 1 店铺的所有有效订单
        $key      = ord("A");  //A--65
        $key2     = ord("@"); //@--64
        $columArr = [];

        // 居中样式
        $styleArray = [
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                'vertical'   => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
            ],
        ];

        // 头部标题 -- 第三行
        $rowNum = 3;
        foreach ($this->titleHeader as $kh => $vh) {
            if ($key > ord("Z")) {
                $key2  += 1;
                $key   = ord("A");
                $colum = chr($key2) . chr($key);//超过26个字母时才会启用
            } else {
                if ($key2 >= ord("A")) {
                    $colum = chr($key2) . chr($key);//超过26个字母时才会启用
                } else {
                    $colum = chr($key);
                }
            }
            $columArr[] = $colum;
            $sheet->setCellValue($colum . $rowNum, $vh['title']);
            // 设置单元格宽度
            $sheet->getColumnDimension($colum)->setWidth($vh['colWidth']);
            // 如何居中的问题
            $sheet->getStyle($colum . $rowNum)->applyFromArray($styleArray);
            $key++;
        }

        // 合并单元格 第1/2行
        $rowNum              = 1;
        $headerTitleFont     = '微软雅黑';
        $headerTitleFontSize = 17;
        $sheet->mergeCells('A' . $rowNum . ':' . $columArr[count($columArr) - 1] . $rowNum);
        $sheet->setCellValue('A' . $rowNum, '测试合并内容');
        $sheet->getStyle('A' . $rowNum)->applyFromArray($styleArray);
        // 行高
        $spreadsheet->getActiveSheet()->getRowDimension($rowNum)->setRowHeight(50);

        // 字体
        $spreadsheet->getActiveSheet()->getStyle('A' . $rowNum)->getFont()->setBold(true)->setName($headerTitleFont)
            ->setSize($headerTitleFontSize);
        // 设置颜色
        $spreadsheet->getActiveSheet()->getStyle('A' . $rowNum)->getFill()
            ->setFillType(Fill::FILL_SOLID)
            ->getStartColor()->setARGB(COLOR::COLOR_YELLOW);


        $rowNum = 2;
        $sheet->mergeCells('A' . $rowNum . ':' . $columArr[count($columArr) - 1] . $rowNum);
        $sheet->setCellValue('A' . $rowNum, '测试合并内容');
        $sheet->getStyle('A' . $rowNum)->applyFromArray($styleArray);
        // 字体
        $spreadsheet->getActiveSheet()->getStyle('A' . $rowNum)->getFont()->setBold(true)->setName($headerTitleFont)
            ->setSize($headerTitleFontSize);


//        $spreadsheet->getActiveSheet()->getStyle('F1:Q1')->getFill()
//            ->setFillType(Fill::FILL_SOLID)
//            ->getStartColor()->setARGB(COLOR::COLOR_RED);
//        $spreadsheet->getActiveSheet()->getStyle('A2:Q2')->getFill()
//            ->setFillType(Fill::FILL_SOLID)
//            ->getStartColor()->setARGB(COLOR::COLOR_YELLOW);

        $orderModel = M('order');
        $total      = $orderModel->count();
        if ($total == false) {
            exit();
        }
        $num = 4;
        foreach ($this->handlerExportDataList($total, []) as $list) {
            foreach ($list as $k => $data) {
                // $data 是一条记录
                if ($data) {
                    $i = 0;
                    foreach ($data as $v_1) {
                        if (!isset($columArr[$i])) { // 如果超过表头长度则忽略
                            break;
                        }
                        $sheet->setCellValue($columArr[$i] . $num, $v_1 . " ");
                        $i++;
                    }
                }
                $num++;
            }
        }

        $filename = "订单商品列表-" . date("Y_m_d_H_i_s") . ".xlsx";
        //或者$objWriter = new PHPExcel_Writer_Excel5($objPHPExcel); 非2007格式
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=GB2312');
        header("Pragma: public");
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $objWriter = IOFactory::createWriter($spreadsheet, 'Xlsx');
        return $objWriter->save('php://output');

    }

    /**
     * handlerExportDataList
     * @author: fanzhaogui
     * @date xxx
     * @param array $where
     * @param string $limit
     *
     * @return \Iterator yield
     */
    protected function handlerExportDataList($total, array $where, $limit = '')
    {
        $listRows   = 15;
        $totalPages = ceil($total / $listRows);
        $model      = new OrderModel();
        for ($i = 0; $i < $totalPages; $i++) {
            $limit = ($listRows * $i) . "," . $listRows;
            yield $model->limit($limit)->select();
        }
    }
}