<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/12/19
 * Time: 17:52
 */

namespace Common\Lib\Traits;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;

/**
 * 1 商品导出
 * 2 商品成本导出
 *
 * Trait GoodsExportHelper
 *
 * @package Common\Lib\Traits
 */
trait GoodsExportHelper
{

	use ExportHelpe;

	/**
	 * @var array 导出标题
	 */
	public $titleHeader = [
		// 1-10
		['title' => '商品ID', 'colWidth' => 10],
		['title' => '商品名称', 'colWidth' => 10],
		['title' => '条形码', 'colWidth' => 30],
		['title' => '所属门店', 'colWidth' => 25],
		['title' => '商品规格', 'colWidth' => 40],
		['title' => '零售价', 'colWidth' => 30],
		['title' => '计量单位', 'colWidth' => 30],
		['title' => '销量', 'colWidth' => 20],
		['title' => '库存', 'colWidth' => 10],
		['title' => '商品分类', 'colWidth' => 10],
		// 11-20
		['title' => '上传时间', 'colWidth' => 10],
		['title' => '商品参数', 'colWidth' => 10],
		['title' => '商品溯源', 'colWidth' => 10],
		['title' => '供应商', 'colWidth' => 10],
		['title' => '商品品牌', 'colWidth' => 10],
		['title' => '品牌品种', 'colWidth' => 10],
		['title' => '商品副标题', 'colWidth' => 10],
		['title' => '排序', 'colWidth' => 10],
		['title' => '地区', 'colWidth' => 10],
		['title' => '商品市场价', 'colWidth' => 10],
		// 21-30
		['title' => '商品成本价', 'colWidth' => 10],
		['title' => '库存报警值', 'colWidth' => 10],
		['title' => '商品货号', 'colWidth' => 10],
		['title' => '商品重量', 'colWidth' => 10],
		['title' => '商品产地', 'colWidth' => 12],
		['title' => '商品发货地', 'colWidth' => 15],
		['title' => '自定义销量', 'colWidth' => 10],
		['title' => '状态', 'colWidth' => 12],
		['title' => '是否扶贫商品', 'colWidth' => 10],
		['title' => '是否热销', 'colWidth' => 15],
		// 31 - 40
		['title' => '是否自营', 'colWidth' => 10],
		['title' => '模块展示', 'colWidth' => 10],
		['title' => '是否包邮', 'colWidth' => 10],
		['title' => '是否企业采购商品', 'colWidth' => 10],
		['title' => '是否万讯商城商品', 'colWidth' => 10],
		['title' => '是否福利商品', 'colWidth' => 15],
		['title' => '是否本门店商品', 'colWidth' => 20],
		['title' => '所属一级分类模块', 'colWidth' => 15],
		['title' => '所属二级分类模块', 'colWidth' => 10],
		['title' => '商品分类层级', 'colWidth' => 10],
		// 41
		['title' => '一级分类ID', 'colWidth' => 10],
		['title' => '二级分类ID', 'colWidth' => 10],
		// 42
	];


	/**
	 * 导致列表
	 *
	 * @author: fanzhaogui
	 * @date xxx
	 *
	 * @param array $requetParams
	 * @param array $where
	 *
	 * @return mixed
	 */
	public function exportGoodsData(array $where, $order, $total)
	{
		// 当不存在数据的时候，直接定制
		if ($total == false) {
			$this->exportDataEmpty();
			return ;
		}

		$spreadsheet = new Spreadsheet();
		$sheet       = $spreadsheet->getActiveSheet();
		// 横向坐标 A-Z  AA-AZ
		$columArr = $this->getRowIndexKey($this->titleHeader);

		// 文件名
		$filename = '商品列表-导出商品';

		// 第一栏和第二栏的内容
		$sheet = $this->renderHeaderAndTitle($sheet, $columArr, $filename);

		// 头部标题 -- 从第三行开始
		$rowNum = 3;
		foreach ($this->titleHeader as $kh => $vh) {
			$colum = $columArr[$kh];
			$sheet->setCellValue($colum . $rowNum, $vh['title']);
			// 设置单元格宽度
			// $sheet->getColumnDimension($colum)->setWidth($vh['colWidth']);
			$sheet->getColumnDimension($colum)->setWidth($this->getColomWidth());
			// 如何居中的问题
			$sheet->getStyle($colum . $rowNum)->applyFromArray($this->getStyleArrayByRow($rowNum));
			// 填充背景色
			$sheet->getStyle($colum . $rowNum)
				->getFill()
				->setFillType(Fill::FILL_SOLID)
				->getStartColor()
				->setARGB(COLOR::COLOR_YELLOW);
		}

		// 内容部分，从第四行开始
		$num = 4;
		foreach ($this->getExportData($where, $order, $total) as $list) {
			foreach ($list as $k => $data) {
				// $data 是一条记录
				if ($data) {
					$i = 0;
					// 样式
					// $sheet->getStyle($columArr[$i] . $num)->applyFromArray($this->getStyleArrayByRow($num));
					// 行高
					$sheet->getRowDimension($num)->setRowHeight($this->getRowHeight($num));
					foreach ($data as $v_1) {
						if (!isset($columArr[$i])) { // 如果超过表头长度则忽略
							break;
						}
                        // 如何居中的问题
                        $sheet->getStyle($columArr[$i] . $num)->applyFromArray($this->getStyleArrayByRow($num));
						$sheet->setCellValue($columArr[$i] . $num, $v_1 . " ");
						$i++;
					}
				}
				$num++;
			}
		}

		$exportFilename = $filename . "-" . date("Y_m_d_H_i_s") . ".xlsx";
		//或者$objWriter = new PHPExcel_Writer_Excel5($objPHPExcel); 非2007格式
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=GB2312');
		header("Pragma: public");
		header('Content-Disposition: attachment;filename="' . $exportFilename . '"');
		header('Cache-Control: max-age=0');
		$objWriter = IOFactory::createWriter($spreadsheet, 'Xlsx');

		return $objWriter->save('php://output');

	}


	/**
	 * @var array 导出标题 -- 商品成本
	 */
	public $title = [
		// 1-10
		['title' => '商品ID', 'colWidth' => 10],
		['title' => '商品名称', 'colWidth' => 10],
		['title' => '商品副标题', 'colWidth' => 30],
		['title' => '商品分类', 'colWidth' => 25],
		['title' => '致富中心', 'colWidth' => 40],
		['title' => '所属网店', 'colWidth' => 30],
		['title' => '商品规格', 'colWidth' => 30],
		['title' => '零售价', 'colWidth' => 20],
		['title' => '计量单位', 'colWidth' => 10],
		['title' => '综合成本(元)', 'colWidth' => 10],
		// 11-20
		['title' => '产品购进价(元)', 'colWidth' => 10],
		['title' => '人工成本(元)', 'colWidth' => 10],
		['title' => '物流成本(元)', 'colWidth' => 10],
		['title' => '包装成本(元)', 'colWidth' => 10],
		['title' => '风险成本(元)', 'colWidth' => 10],
		['title' => '仓储成本(元)', 'colWidth' => 10],
		['title' => '水电成本(元)', 'colWidth' => 10],
		['title' => '设备用品用具摊分成本(元)', 'colWidth' => 10],
		['title' => '其他(元)', 'colWidth' => 10],
		['title' => '最小限购量', 'colWidth' => 10],
		// 21-30
		['title' => '最大限购量', 'colWidth' => 10],
		['title' => '采购税率', 'colWidth' => 10],
		['title' => '采购方式', 'colWidth' => 10],
		['title' => '销量', 'colWidth' => 10],
		['title' => '库存', 'colWidth' => 12],
		['title' => '上传时间', 'colWidth' => 15],
		['title' => '商品参数', 'colWidth' => 10],
		['title' => '商品溯源', 'colWidth' => 12],
		['title' => '供应商', 'colWidth' => 10],
		['title' => '商品品牌', 'colWidth' => 15],
		// 31 - 40
		['title' => '品牌品种', 'colWidth' => 10],
		['title' => '商品市场价', 'colWidth' => 10],
		['title' => '商品成本价', 'colWidth' => 10],
		['title' => '库存报警值', 'colWidth' => 10],
		['title' => '商品货号', 'colWidth' => 10],
		['title' => '商品重量', 'colWidth' => 15],
		['title' => '商品产地', 'colWidth' => 20],
		['title' => '商品发货地', 'colWidth' => 15],
		['title' => '自定义销量', 'colWidth' => 10],
		['title' => '是否上架', 'colWidth' => 10],
		// 41 - 50
		['title' => '是否扶贫商品', 'colWidth' => 10],
		['title' => '是否热销', 'colWidth' => 10],
		['title' => '是否推荐', 'colWidth' => 10],
		['title' => '是否自营', 'colWidth' => 10],
		['title' => '模块展示', 'colWidth' => 10],
		['title' => '是否显示销量', 'colWidth' => 15],
		['title' => '是否包邮', 'colWidth' => 20],
		['title' => '地区', 'colWidth' => 15],
		['title' => '排序', 'colWidth' => 10],
		['title' => '是否企业采购商品', 'colWidth' => 10],
		// 51-58
		['title' => '是否万讯商城商品', 'colWidth' => 10],
		['title' => '是否福利商品', 'colWidth' => 10],
		['title' => '是否本网店商品', 'colWidth' => 10],
		['title' => '所属一级分类模块', 'colWidth' => 10],
		['title' => '所属二级分类模块', 'colWidth' => 10],
		['title' => '商品分类层级', 'colWidth' => 10],
		['title' => '一级分类ID', 'colWidth' => 10],
		['title' => '二级分类ID', 'colWidth' => 10],
		// 58
	];


	/**
	 * 导致列表
	 *
	 * @author: fanzhaogui
	 * @date xxx
	 *
	 * @param array $requetParams
	 * @param array $where
	 *
	 * @return mixed
	 */
	public function exportGoodsCostData(array $where, $order, $total)
	{
		if ($total == false) {
			exit();
		}

		$spreadsheet = new Spreadsheet();
		$sheet       = $spreadsheet->getActiveSheet();
		// 横向坐标 A-Z  AA-AZ
		$columArr = $this->getRowIndexKey($this->title);

		// 文件名
		$filename = '商品列表-导出商品成本';

		// 第一栏和第二栏的内容
		$sheet = $this->renderHeaderAndTitle($sheet, $columArr, $filename);

		// 头部标题 -- 从第三行开始
		$rowNum = 3;
		foreach ($this->title as $kh => $vh) {
			$colum = $columArr[$kh];
			$sheet->setCellValue($colum . $rowNum, $vh['title']);
			// 设置单元格宽度
			//$sheet->getColumnDimension($colum)->setWidth($vh['colWidth']);
            $sheet->getColumnDimension($colum)->setWidth($this->getColomWidth());
			// 如何居中的问题
			$sheet->getStyle($colum . $rowNum)->applyFromArray($this->getStyleArrayByRow($rowNum));
			// 填充背景色
			$sheet->getStyle($colum . $rowNum)
				->getFill()
				->setFillType(Fill::FILL_SOLID)
				->getStartColor()
				->setARGB(COLOR::COLOR_YELLOW);
		}

		// 内容部分，从第四行开始
		$num = 4;
		foreach ($this->getExportDataOfGoodsCost($where, $order, $total) as $list) {
			foreach ($list as $k => $data) {
				// $data 是一条记录
				if ($data) {
					$i = 0;
					foreach ($data as $v_1) {
						if (!isset($columArr[$i])) { // 如果超过表头长度则忽略
							break;
						}
                        $sheet->getStyle($columArr[$i] . $num)->applyFromArray($this->getStyleArrayByRow($num));
						// 行高
						$sheet->getRowDimension($num)->setRowHeight($this->getRowHeight($num));
						$sheet->setCellValue($columArr[$i] . $num, $v_1 . " ");
						$i++;
					}
				}
				$num++;
			}
		}

		$exportFilename = $filename . "-" . date("Y_m_d_H_i_s") . ".xlsx";
		//或者$objWriter = new PHPExcel_Writer_Excel5($objPHPExcel); 非2007格式
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=GB2312');
		header("Pragma: public");
		header('Content-Disposition: attachment;filename="' . $exportFilename . '"');
		header('Cache-Control: max-age=0');
		$objWriter = IOFactory::createWriter($spreadsheet, 'Xlsx');

		return $objWriter->save('php://output');

	}

}