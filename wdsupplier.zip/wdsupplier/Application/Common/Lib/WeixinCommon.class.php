<?php
/**
 * 微信通用功能类
 * User: kela.xie
 * Date: 2016/12/20
 * Time: 15:22
 */

namespace Common\Lib;


class WeixinCommon
{
     static $instance;     //实例化对象

     protected $error;      //错误信息集合 数组type类型 token create_menu del_menu .....

     protected $token;      //开发者验证令牌

     protected $app_id;     //应用ID

     protected $secret;     //应用密钥

     protected $mch_id;     //商户ID

     protected $pay_secret;     //商户秘钥

     protected $expires_in;     //seccess_token有效时间

     protected $access_token;     //seccess_token

     //事件接收回复数据的对象或者函数，比如利用对象的关注方法或者函数返回值拿到需要回复的数据，数组是对象模式，字符则是函数
     protected static $reply_data_call;
      //事件接收数据的对象或者函数，比如利用对象的关注方法或者函数返回值拿到需要回复的数据，数组是对象模式，字符则是函数
     protected static $accept_data_call;

    public function __construct($config=[])
    {
        if(!empty($config)){
            !empty($config['TOKEN']) && $this->token = $config['TOKEN'];
            !empty($config['APP_ID']) && $this->app_id = $config['APP_ID'];
            !empty($config['SECRET']) && $this->secret = $config['SECRET'];
            !empty($config['MCH_ID']) && $this->mch_id = $config['MCH_ID'];
            !empty($config['PAY_SECRET']) && $this->pay_secret = $config['PAY_SECRET'];
        }

    }

    public static function instance($config)
    {
        if(is_object(self::$instance))
        {
            return self::$instance;
        }

        return self::$instance = new static($config);
    }

    protected static function getApiPaths($type=false)
    {
        $api_path = [
            //获取token的api地址
            'TOKEN_PATH'        => 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s',
            'GET_MENU_PATH'     => 'https://api.weixin.qq.com/cgi-bin/menu/get?access_token=%s',        //获取微信菜单地址
            'CREATE_MENU_PATH'  => 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token=%s',     //创建微信菜单地址
            'DEL_MENU_PATH'     => 'https://api.weixin.qq.com/cgi-bin/menu/delete?access_token=%s',     //删除微信菜单地址
            //微信授权地址
            'WEIXIN_AUTH_PATH'     => 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=STATE#wechat_redirect',
             //获取微信授权的token地址
            'WEIXIN_AUTH_TOKEN_PATH'     => 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code ',
            //发送消息模板地址
            'SEND_MESSAGE_TEMPLATE'=>'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=%s',
            //获取jsapi_ticket
            'JSAPI_TICKET_PATH'=>'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=%s&type=jsapi',
        ];

        return $type===false? $api_path : $api_path[$type];
    }

    public function getToken($token='')
    {
        !empty($token) &&  $this->token = $token;

        return $this;
    }

    public function getAppId($app_id='')
    {
        !empty($app_id) &&  $this->app_id = $app_id;

        return $this;
    }

    public function getSecret($secret='')
    {
        !empty($secret) &&  $this->secret = $secret;

        return $this;
    }

    public function getMchId($mch_id='')
    {
        !empty($mch_id) &&  $this->mch_id = $mch_id;

        return $this;
    }

    public function getPaySecret($pay_secret='')
    {
        !empty($pay_secret) &&  $this->pay_secret = $pay_secret;

        return $this;
    }

    /**
     * 获取access_token
     */
    public function getAccessToken()
    {
        if(!empty($this->access_token) && $this->expires_in>time())
        {
            return $this;
        }

        $this->access_token = S('access_token');
        if(!empty($this->access_token)){
            return $this;
        }

        $toekn_url = sprintf(self::getApiPaths('TOKEN_PATH'), $this->app_id, $this->secret);
        //var_dump($toekn_url);
        $res = self::curlApi($toekn_url);
        if($res['access_token'])
        {
            $this->expires_in = time()+$res['expires_in'];
            $this->access_token = $res['access_token'];
            S('access_token',$res['access_token'],$res['expires_in']);
            return  $this;
        }
        $this->setError('token','get_access_token_fail');

        throw new \Exception('get_access_token_fail');

    }

    /**
     * 获取查询微信菜单
     */
    public function getWeixinMenu()
    {
        $this->getAccessToken();

        $url = sprintf(self::getApiPaths('GET_MENU_PATH'), $this->access_token);

        return $res = self::curlApi($url);
    }

    /**
     * 创建微信菜单
     */
    public function createWeixinMenu($param)
    {
        $this->getAccessToken();

        $url = sprintf(self::getApiPaths('CREATE_MENU_PATH'), $this->access_token);

        $res = self::curlApi($url,$param,true);
        if($res['errcode']>0)
        {
            $this->setError('create_menu','errcode:'.$res['errcode'].',errmsg:'.$res['errmsg']);

            return false;
        }
        $this->setError('create_menu', false);

        return $res;
    }

    /**
     * 删除微信菜单
     * @return bool|mixed
     * @throws \Exception
     */
    public function delWeixinMenu()
    {

        $this->getAccessToken();

        $url = sprintf(self::getApiPaths('DEL_MENU_PATH'), $this->access_token);

        $res = self::curlApi($url);
        if($res['errcode']>0)
        {
            $this->setError('del_menu','errcode:'.$res['errcode'].',errmsg:'.$res['errmsg']);

            return false;
        }
        $this->setError('del_menu', false);

        return $res;
    }

    /**
     * 开通微信开发者和接收微信回复信息
     */
    public function replyMessage($param)
    {
        $is_success = $this->checkSignature($param);
        if(isset($param['echostr']) && $is_success===true){
           exit($param['echostr']);
        }

        $postStr = file_get_contents("php://input");
        empty($postStr) && $postStr = $GLOBALS['HTTP_RAW_POST_DATA'];
        $postStr = self::xml_parser_arr($postStr,LIBXML_NOCDATA);
        if($postStr){
            switch($postStr['Event']){
                case 'subscribe':
                    if($postStr['Ticket']){
                        //带参数的二维码

                    }
                    //关注公众号
                    self::subscribe($postStr);
                    break;
                case 'unsubscribe':        //取消关注

                    break;
                case 'SCAN': //带参数二维码

                    break;
                case 'VIEW':    //菜单点击链接
                    break;
                case 'CLICK':    //菜单点击key
                    break;
                case 'LOCATION':  //上报地理位置事件
                    break;
                case 'TEMPLATESENDJOBFINISH':
                    self::templateMessageReply();
                    break;
            }


        }
    }

    /**
     * 获取微信授权地址包括跳转地址
     * @$param array
     * @$param['auth_type'] 授权类型默认选择基本授权
     * @$param['redirect_url'] 授权之后跳转地址
     */
    public function weiAuth($param)
    {
        $auth_type = in_array($param['auth_type'],array('snsapi_base','snsapi_userinfo')) ? $param['auth_type'] : 'snsapi_base';
        $redirect_url = base64_decode($param('redirect_url'));
        return  sprintf(self::getApiPaths('WEIXIN_AUTH_PATH'), $this->app_id, urlencode($redirect_url), $auth_type);
    }

    /**
     * 微信访问的获取openid
     */
    public function getOpenId($code)
    {
        $getTokenUrl = sprintf(self::getApiPaths('WEIXIN_AUTH_TOKEN_PATH'),$this->app_id,$this->secret,$code);

        $data = self::curlApi($getTokenUrl);
        if(empty($data['access_token']) || empty($data['openid'])){
            $this->setError('get_openid','errcode:'.$data['errcode'].',errmsg:'.$data['errmsg']);

            return false;
        }

        $this->setError('get_openid', false);

        return $data;
    }


    /**
     * 关注回复信息
     * @$param 事件接收参数
     * @$replyInfo type 回复类型 1文本 2图片 3后期再加 4.。
     */
    protected static function subscribe($param)
    {
        //利用回调方式获得需要回复的数据和回复类型
        $call = self::$reply_data_call;
        is_array($call) && list($object,$method) = $call;
        if(is_object($object)){
            $replyInfo = call_user_func_array($call,['subscribe']);
        }elseif(function_exists($call)){
            $replyInfo = call_user_func_array($call,['subscribe']);
        }else{
            //这里可以灵活修改默认值
            $replyInfo = [
                'type'=>1,
                'text'=>'HELLO WORLD',
            ];
        }

        $xmlArr = [];
        $replyXML= '';
        if(!empty($replyInfo)){
            $xmlArr['ToUserName'] = $param['FromUserName'];
            $xmlArr['FromUserName'] = $param['ToUserName'];
            $xmlArr['CreateTime'] = time();
            if($replyInfo['type']==1){  //文本回复
                $xmlArr['MsgType'] = 'text';
                $xmlArr['Content'] = $replyInfo['text'];
            }elseif($replyInfo['type']==2){     //图片回复
                $xmlArr['MsgType'] = 'image';
                $xmlArr['Image']['MediaId'] = $replyInfo['text'];
            }
            $replyXML = self::array_to_xml($xmlArr,'xml');
        }

        exit($replyXML);
    }

    /**
     * 微信验证
     * @return bool
     */
    protected function checkSignature($param)
    {
        $signature = $param["signature"];
        $timestamp = $param["timestamp"];
        $nonce = $param["nonce"];

        $token = $this->token;
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );

        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }


    /**
     * 消息模板推送
     * @$param array 发送参数
     */
    public function sendMessageTemplate($param)
    {
        if(is_array($param)){
            $param = json_encode($param);
        }

        $this->getAccessToken();

        $url = sprintf(self::getApiPaths('SEND_MESSAGE_TEMPLATE'),$this->access_token);
        $res = self::curlApi($url, $param, true);
        if($res['errcode']>0)
        {
            $this->setError('send_message_tamplate','errcode:'.$res['errcode'].',errmsg:'.$res['errmsg']);

            return false;
        }
        $this->setError('send_message_tamplate', false);

        return $res;

    }

    /**
     * 模板消息接收结果
     * @$param array
     *  ToUserName	公众号微信号
        FromUserName	接收模板消息的用户的openid
        CreateTime	创建时间
        MsgType	消息类型是事件
        Event	事件为模板消息发送结束
        MsgID	消息id
        Status	发送状态为成功
     */
    protected static function templateMessageReply($param)
    {
        $call = self::$accept_data_call;
        is_array($call) && list($object,$method) = $call;
        if(is_object($object)){
             call_user_func_array($call,['templateMessageReply',$param]);
        }elseif(function_exists($call)){
             call_user_func_array($call,['templateMessageReply',$param]);
        }else{
            if($param['Status']==='success'){
                //这里做推送成功之后逻辑业务处理

            }else{
                //这里做推送失败之后逻辑业务处理

            }
        }

        return 'success';
    }

    /**
     * 获取失败信息
     */
    public function getError($type='')
    {
        if($type){
            return $this->error[$type];
        }

        return $this->error;
    }

    /**
     * 设置失败信息
     */
    public function setError($type, $message)
    {
        if($message===false){
            unset($this->error[$type]);
        }
        $this->error[$type] = $message;
    }

    /**
     * 简单行的curl操作
     */
    protected static function curlApi($url,$param=array(),$is_post=false)
    {
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_HEADER,false);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        $queryString = is_array($param) ? http_build_query($param) : $param;
        if($is_post==true){
            curl_setopt($ch,CURLOPT_POST,true);
        }
        curl_setopt($ch,CURLOPT_POSTFIELDS,$queryString);

        $res = curl_exec($ch);
        $error = curl_error($ch);
        $errno = curl_errno($ch);
        if(!empty($error)){
           throw new \Exception('curl_error:'.$error.',curl_errno:'.$errno);
        }

        curl_close($ch);

        $data= json_decode($res, true);
        if($data==false){
            return $res;
        }
        return $data;

    }

    /**
     * xml解析为数组
     * @$str
     * @$option
     */
    protected static function xml_parser_arr($str, $option=LIBXML_COMPACT)
    {
        $xml_parser = xml_parser_create();
        if(!xml_parse($xml_parser,$str,true)){
            xml_parser_free($xml_parser);
            return false;
        }else {
            return (json_decode(json_encode(simplexml_load_string($str,'SimpleXMLElement',$option)),true));
        }
    }

    /**
     * 数组转换为xml
     */
    protected static function array_to_xml($arr, $root = 'root', $dom=0, $item=0)
    {
        //初始化dom xml
        if (empty($dom)){
            $dom = new DOMDocument("1.0",'UTF-8');
        }
        //初始化第一层节点
        if(empty($item)){
            if(is_array($root)){
                $rootNode = $root['node'];
                $item = $dom->createElement($rootNode);
                foreach($root['attr'] as $attrKey=>$attrValue){
                    //创建属性
                    $domAttribute = $dom->createAttribute($attrKey);
                    //赋属性值
                    $domAttribute->value=$attrValue;
                    //放在该节点上
                    $item->appendChild($domAttribute);
                }
            }else{
                $item = $dom->createElement($root);
            }
            $dom->appendChild($item) ;
        }

        //循环回调多层数据
        foreach ($arr as $key=>$val){
            if(is_numeric($key) && is_array($val)){
                self::array_to_xml($val, $root, $dom, $item);
                continue;
            }
            $itemx = $dom->createElement(is_string($key) ? $key : "item");
            $item->appendChild($itemx);

            if (!is_array($val)){
                $text = $dom->createTextNode(self::xml_escape($val));
                $itemx->appendChild($text);
            } else {
                self::array_to_xml($val, $root, $dom, $itemx);
            }
        }
        return $dom->saveXML();
    }

    /**
     * xml特殊字符转义
     * @param $val
     * @return mixed
     */
    protected static function xml_escape($val)
    {
        return str_replace(array('&','<','>','"','\''),array('&amp;','&lt;','&gt;','&quot;','&apos;') ,$val);
    }

    /**
     * 获取jsapi_ticket
     */
    public function getJsApiTicket()
    {
        $jsapi_ticket = S('jsapi_ticket');
        if($jsapi_ticket){
            return $jsapi_ticket;
        }
        $this->getAccessToken();
        $url = sprintf(self::getApiPaths('JSAPI_TICKET_PATH'),$this->access_token);
        $res = self::curlApi($url);
        if(!empty($res['ticket'])){
            S('jsapi_ticket',$res['ticket'],$res['expires_in']);
            return  $res['ticket'];
        }
        $this->setError('token','get_jsapi_ticket_fail');

        throw new \Exception('get_jsapi_ticket_fail');
    }
}