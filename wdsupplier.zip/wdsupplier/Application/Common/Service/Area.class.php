<?php

namespace Common\Service;
class Area
{
    //逆地理编码
    public static function getAddressVal($lng, $lat)
    {
        $url = 'http://api.map.baidu.com/geocoder/v2/?location=' . $lat . ',' . $lng;
        $url .= '&output=json&extensions_town=true&pois=0&ak=zbQrD4cA5Yz7X7Pjmt3IpYcpovH2oqZs';
        $result = file_get_contents($url);
        $data = json_decode($result, true);
        return $data;
    }
}