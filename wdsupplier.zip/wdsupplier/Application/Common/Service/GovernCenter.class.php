<?php

namespace Common\Service;
class GovernCenter
{
    //获取所有公司ID
    public static function getAllCompanyID()
    {
        $result = M('CompanyAuth')->where(['status' => 1])->order('create_time asc')->getField('id', true);
        return empty($result) ? [] : $result;
    }

    //获取所有公司信息
    public function getAllCompany()
    {
        return M('CompanyAuth')->field('id,parent_company_id,member_id')->where(['status' => 1])->select();
    }

    //根据公司ID获取公司信息
    public static function getCompanyInfoByID($id)
    {
        $default_logo = C('WEBSITE_URL') . '/' . 'Public/Mobile/images/default_avatar_color.png';    //默认logo
        $default_bg = C('WEBSITE_URL') . '/' . 'Public/Mobile/images/grzxbj@2x.png';   //默认背景图
        $where['id'] = $id;
        $where['status'] = 1;   //审核状态为已通过
        $info = M('CompanyAuth')
            ->field('id,company_name,member_id,company_person,province_id,city_id,bg_img,logo_img')
            ->where($where)
            ->find();
        $info['bg_img'] = empty($info['bg_img']) ? $default_bg : C('WEBSITE_URL') . '/' . $info['bg_img'];
        $info['logo_img'] = empty($info['logo_img']) ? $default_logo : C('WEBSITE_URL') . '/' . $info['logo_img'];
        return $info;
    }

    //根据会员ID获取企业认证信息
    public static function getInfoByMemberID($memberID)
    {
        $default_logo = C('WEBSITE_URL') . '/' . 'Public/Mobile/images/default_avatar_color.png';    //默认logo
        $default_bg = C('WEBSITE_URL') . '/' . 'Public/Mobile/images/fpyjbj@2x.png';   //默认背景图
        $where['member_id'] = $memberID;
        $where['status'] = 1;   //审核状态为已通过
        $info = M('CompanyAuth')
            ->field('id,company_name,member_id,company_person,province_id,city_id,bg_img,logo_img')
            ->where($where)
            ->find();
        $info['bg_img'] = empty($info['bg_img']) ? $default_bg : C('WEBSITE_URL') . '/' . $info['bg_img'];
        $info['logo_img'] = empty($info['logo_img']) ? $default_logo : C('WEBSITE_URL') . '/' . $info['logo_img'];
        return $info;
    }

    //获取公司扶贫金额统计信息（用于查询排名的，如果业绩一样，则按照加入平台时间来进行排序）
    public static function getCompanyStatistical($company_id = '')
    {
        $where = [];
        if ($company_id) {
            $where['company_id'] = $company_id;
        }
        $field = 'company_id,sum(make_member_money) as make_member_money';
        $has_info = M('GovernCenter')
            ->alias('gc')
            ->field($field)
            ->join('left join __COMPANY_AUTH__ ca on ca.id = gc.company_id')
            ->where($where)
            ->group('company_id')
            ->order('make_member_money desc,ca.create_time asc')
            ->select();
        return $has_info;
    }

    //获取公司扶贫金额统计信息（用于查询排名的，如果业绩一样，则按照加入平台时间来进行排序）
    public static function getStoreStatistical($store_id, $start_time, $end_time)
    {
        $where = self::getTimeWhere($start_time, $end_time);
        if (!is_array($store_id)) {
            $store_id = [$store_id];
        }
        $where['store_id'] = ['in', $store_id];
        $field = 'store_id,sum(make_member_money) as make_member_money';
        $has_info = M('GovernCenter')
            ->alias('gc')
            ->field($field)
            ->where($where)
            ->group('store_id')
            ->order('make_member_money desc')
            ->select();
        return $has_info;
    }

    private static function getTimeWhere($start_time, $end_time)
    {
        if ($start_time && $end_time) {
            $where['create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($start_time) {
            $where['create_time'] = array('egt', strtotime($start_time));
        } elseif ($end_time) {
            $where['create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        } else {
            $where = [];
        }
        return $where;
    }

    /** 以公司为纬度统计扶贫业绩
     * @param $company_id
     * @param $start_time
     * @param $end_time
     * @return mixed
     * num扶贫订单数量，all_money扶贫业绩数
     */
    public static function getBriefInfo($company_id, $start_time, $end_time)
    {
        $where = self::getTimeWhere($start_time, $end_time);
        $where['company_id'] = $company_id;
        $field = 'count(company_id) as make_order_num,sum(make_member_money) as make_member_money';
        return M('GovernCenter')->field($field)->where($where)->group('company_id')->select();
    }

    /** 以超市为纬度统计扶贫业绩
     * @param $store_id
     * @param $start_time
     * @param $end_time
     * @return mixed
     * num扶贫订单数量，all_money扶贫业绩数
     */
    public static function getBriefInfoByStore($store_id, $start_time = '', $end_time = '', $company_id = '')
    {
        $where = self::getTimeWhere($start_time, $end_time);
        if(!is_array($store_id)){
            $store_id = [$store_id];
        }
        if($company_id){
            $where['company_id'] = $company_id;
        }
        $where['store_id'] = ['in', $store_id];
        $field = 'store_id,count(order_id) as make_order_num,count(distinct company_id) as poverty_company';
        $field .= ',count(distinct buyer_id) as make_member_num,sum(make_member_money) as make_member_money';
        return M('GovernCenter')->field($field)->where($where)->order('make_member_money desc')->group('store_id')->select();
    }

    /** 以超市分组
     * @param $company_id
     * @param $start_time
     * @param $end_time
     * @return mixed
     * num扶贫订单数量，all_money扶贫业绩数
     */
    public static function getStoreCompany($company_id, $start_time, $end_time, $limit)
    {
        if ($start_time && $end_time) {
            $where['gc.create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($start_time) {
            $where['gc.create_time'] = array('egt', strtotime($start_time));
        } elseif ($end_time) {
            $where['gc.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['gc.company_id'] = ['in', $company_id];
        $field = 'gc.store_id,gc.company_id,count(*) as make_order_num,sum(gc.make_member_money) as make_member_money';
        $field .= ',s.store_name,ca.company_name,COUNT(DISTINCT gc.buyer_id) as make_member_num';
        return M('GovernCenter')
            ->alias('gc')
            ->field($field)
            ->join('left join __STORE__ s on gc.store_id = s.store_id')
            ->join('left join __COMPANY_AUTH__ ca on gc.company_id = ca.id')
            ->where($where)
            ->group('gc.company_id,gc.store_id')
            ->limit($limit)
            ->select();
        // return M('GovernCenter')->getLastSql();
    }

    /** 管辖单位业绩汇总
     * @param $company_id_arr
     * @param $start_time
     * @param $end_time
     * @return mixed
     * num扶贫订单数量，all_money扶贫业绩数
     */
    public static function getAllCompanyBriefInfo($company_id_arr, $start_time, $end_time, $store_id = 0)
    {
        $where = self::getTimeWhere($start_time, $end_time);
        $where['company_id'] = ['in', $company_id_arr];
        if ($store_id) {
            $where['store_id'] = $store_id;
        }
        $field = 'ifnull(count(company_id),0) as make_order_num,ifnull(sum(make_member_money),0) as make_member_money';
        return M('GovernCenter')->field($field)->where($where)->select();
    }

    //以人 为纬度获取成交人数量
    public static function getBriefGroupMember($company_id, $start_time, $end_time, $store_id = 0)
    {
        $where = self::getTimeWhere($start_time, $end_time);
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['company_id'] = ['in', $company_id];
        if ($store_id) {
            $where['store_id'] = $store_id;
        }
        return M('GovernCenter')->field('buyer_id')->where($where)->group('buyer_id')->select();
    }

    //扶贫人数统计
    public static function getMemberAuthNum($company_id, $start_time, $end_time)
    {
//        $where = self::getTimeWhere($start_time, $end_time);
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['ma.company_id'] = ['in', $company_id];
        $where['ma.status'] = 1;
        $where['m.member_state'] = 1;
        $list = M('MemberAuth')
            ->alias('ma')
            ->field('ma.member_id')
            ->join('left join __MEMBER__ m on ma.member_id = m.member_id')
            ->where($where)
            ->select();
        return array_column($list, 'member_id');
    }

    //扶贫人数统计(新)
    public static function getMemberAuthMemberIDs($company_id)
    {
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['company_id'] = ['in', $company_id];
        $member_ids = M('GovernCompanyMember')->where($where)->getField('buyer_id', true);
        return empty($member_ids) ? [] : $member_ids;
    }

    //扶贫人数统计(取出对应member_id和company_id)以当前扶贫人为纬度
    public static function getMemberAuthInfo($company_id, $limit)
    {
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['company_id'] = ['in', $company_id];
        $where['status'] = 1;
        return M('MemberAuth')
            ->field('member_id,company_id')
            ->where($where)
            ->limit($limit)
            ->select();
    }

    /**
     * @param string $company_id 存在则取出公司值的键（键值+1即排名）
     * $company_id为空时则返回全部公司排名
     * @return array
     */
    public static function getRank($company_id = '')
    {
        $data = self::getCompanyStatistical();
        $has_company = array_column($data, 'company_id');   //已经存在的排名
        $all_company = self::getAllCompanyID(); //所有公司ID,按照加入平台时间升序排序
        $diff_data = array_diff($all_company, $has_company);   //比较差值，有些公司不一定有扶贫业绩的
        $sort_data = array_values($diff_data);  //只取值
        $result_data = array_merge($has_company, $sort_data);
        if ($company_id) {
            return array_search($company_id, $result_data) + 1;
        }
        return $result_data;
    }

    //根据公司ID获取对应信息（包括排名信息）
    public static function getCompanyRankInfo($company_id)
    {
        $rank = self::getRank($company_id); //获取公司排名
        $all_company = self::getAllCompanyID(); //所有公司ID
        $data = self::getCompanyStatistical($company_id);   //取出公司扶贫信息
        $all_order_amount = $data[0]['make_member_money'];
        return [
            'all_company_num' => count($all_company),
            'all_order_amount' => $all_order_amount ? $all_order_amount : 0,
            'rank' => $rank
        ];
    }

    //获取单位业绩汇总
    public static function getCompanyOne($company_id, $start_time, $end_time)
    {
        $briefInfo = self::getBriefInfo($company_id, $start_time, $end_time);
        $member_list = self::getBriefGroupMember($company_id, $start_time, $end_time);
        $member_auth_id = self::getMemberAuthMemberIDs($company_id);
        return [
            'poverty_member_num' => count($member_auth_id),    //扶贫人数总数量
            'make_member_num' => count($member_list),   //成交人数总数量
            'make_order_num' => empty($briefInfo[0]['make_order_num']) ? 0 : $briefInfo[0]['make_order_num'],    //扶贫订单总数量
            'make_member_money' => empty($briefInfo[0]['make_member_money']) ? 0 : $briefInfo[0]['make_member_money'], //扶贫业绩数
        ];
    }

    //获取管辖单位业绩汇总
    public function getCompanySum($company_id, $start_time, $end_time)
    {
        $company_id_list = $this->getAllChildCompanyID($company_id);
        if (empty($company_id_list)) {
            return [
                'poverty_member_num' => 0,    //扶贫人数总数量
                'make_member_num' => 0,   //成交人数总数量
                'make_order_num' => 0,    //扶贫订单总数量
                'make_member_money' => 0, //扶贫业绩数
                'is_no_level' => 0, //是否还有下级：0没有下级，1有下级
            ];
        }
        array_push($company_id_list, $company_id);
        $briefInfo = self::getAllCompanyBriefInfo($company_id_list, $start_time, $end_time);
        $member_list = self::getBriefGroupMember($company_id_list, $start_time, $end_time);
        $member_auth_id = self::getMemberAuthMemberIDs($company_id_list);
        return [
            'poverty_member_num' => count($member_auth_id),    //扶贫人数总数量
            'make_member_num' => count($member_list),   //成交人数总数量
            'make_order_num' => $briefInfo[0]['make_order_num'],    //扶贫订单总数量
            'make_member_money' => $briefInfo[0]['make_member_money'], //扶贫业绩数
            'is_no_level' => 1, //是否还有下级：0没有下级，1有下级
        ];
    }

    //单位个人业绩列表
    public static function getMemberByCompanyID($company_id, $limit)
    {
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['gc.company_id'] = ['in', $company_id];
        $field = 'gc.buyer_id,sum(gc.make_member_money) as make_member_money';
        $field .= ',m.member_avatar,ca.company_name,m.member_mobile,ma.user_name';
        $list = M('GovernCenter')
            ->alias('gc')
            ->field($field)
            ->join('left join __MEMBER__ m on m.member_id = gc.buyer_id')
            ->join('left join __MEMBER_AUTH__ ma on ma.member_id = gc.buyer_id')
            ->join('left join __COMPANY_AUTH__ ca on ca.id = gc.company_id')
            ->where($where)
            ->group('gc.company_id,gc.buyer_id')
            ->order('make_member_money desc,ma.create_time asc')
            ->limit($limit)
            ->select();
        return self::settle($list);
    }

    //单位个人业绩列表(新方法)
    public static function getGovernMemberByCompanyID($company_id, $limit)
    {
        if (!is_array($company_id)) {
            $company_id = [$company_id];
        }
        $where['gcm.company_id'] = ['in', $company_id];
        $field = 'gcm.buyer_id,gcm.make_member_money,gcm.user_name';
        $field .= ',m.member_avatar,m.member_mobile,ca.company_name';
        $list = M('GovernCompanyMember')
            ->alias('gcm')
            ->field($field)
            ->join('left join __MEMBER__ m on m.member_id = gcm.buyer_id')
            ->join('left join __COMPANY_AUTH__ ca on ca.id = gcm.company_id')
            ->where($where)
            ->order('gcm.make_member_money desc,gcm.join_time asc')
            ->limit($limit)
            ->select();
        return self::settle($list);
    }

    //根据会员ID取出对应信息(针对没有产生扶贫业绩的会员)
    public static function getMemberInfo($member_id)
    {
        if (!is_array($member_id)) {
            $member_id = [$member_id];
        }
        $where['m.member_id'] = ['in', $member_id];
        $field = 'm.member_id,0 as make_member_money';
        $field .= ',m.member_avatar,ca.company_name,m.member_mobile,ma.user_name';
        $list = M('Member')
            ->alias('m')
            ->field($field)
            ->join('left join __MEMBER_AUTH__ ma on ma.member_id = m.member_id')
            ->join('left join __COMPANY_AUTH__ ca on ca.id = ma.company_id')
            ->join('left join __GOVERN_CENTER__ gc on gc.buyer_id = m.member_id')
            ->where($where)
            ->order('ma.create_time asc')
            ->select();
        return self::settle($list);
    }

    //会员数据整理数据
    public static function settle($list)
    {
        foreach ($list as $key => $val) {
            $logo = empty($val['member_avatar']) ? 'Public/Mobile/images/default_avatar_color.png' : $val['member_avatar'];
            $list[$key]['member_avatar'] = getFullImg($logo);
            if ($val['user_name']) {
                $list[$key]['user_name'] = self::getStarName($val['user_name']);
            } else {
                if (!empty($val['member_mobile'])) {
                    if(is_mobile($val['member_mobile'])){
                        $list[$key]['user_name'] = phoneMask($val['member_mobile']);
                    }else{
                        $list[$key]['user_name'] = self::getStarName($val['member_mobile']);
                    }
                }
            }
            unset($list[$key]['member_mobile']);
        }
        return $list;
    }

    public static function getStarName($name)
    {
        $str_len = mb_strlen($name, "utf-8");
        if ($str_len >= 3) {
            $str1 = mb_substr($name, 0, 1, 'utf-8');
            $str2 = mb_substr($name, $str_len - 1, 1, 'utf-8');
            $hide_len = $str_len - 2;   //隐藏的字符数
            return $str1 . str_repeat('*', $hide_len) . $str2;
        }
        if ($str_len == 2) {
            $str1 = mb_substr($name, 0, 1, 'utf-8');
            return $str1 . str_repeat('*', 1);
        }
        return $name;
    }

    //根据公司ID获取对应信息（包括排名信息）（一开始的思路）
    public static function getCompanyRank($company_id)
    {
        $current_day = date('Y-m-d');   //当天时间
        $current_start_time = strtotime("$current_day");   //当天开始时间
        $current_end_time = strtotime("$current_day 23:59:59");   //当天结束时间
        $divide_time = $current_start_time + 6 * 60 * 60;  //当天6点

        $last_start_time = $current_start_time - 24 * 60 * 60;
        $last_end_time = $current_start_time - 1;
        if (time() > $divide_time && time() < $current_end_time) {
            $between = "between $current_start_time and $current_end_time";
        } else {
            $between = "between $last_start_time and $last_end_time";
        }
        $result = [
            'all_order_amount' => 0,
            'rank' => 0
        ];
        $model = M();
        $sql_zhu = "SELECT o.company_id,o.poverty_member_num,(@rowNum:=@rowNum+1) AS rank FROM __GOVERN_CENTER_SELF__ AS o
                ,(SELECT (@rowNum :=0) ) b ORDER BY o.poverty_member_num DESC LIMIT 10,10";
//        $sql = "SELECT company_id,poverty_member_num,rank FROM (SELECT o.company_id,o.poverty_member_num,(@rowNum:=@rowNum+1) AS rank FROM __GOVERN_CENTER_SELF__ AS o
//                ,(SELECT (@rowNum :=0) ) b WHERE o.create_time " . $between . ") AS v WHERE company_id=" . $company_id;
        $sql_zi = "SELECT company_id,poverty_member_num,rank FROM (" . $sql_zhu . ") AS v WHERE company_id=" . $company_id;
        $list = $model->query($sql_zhu);
        return $list;
        $zi_info = $model->query($sql_zi);
        return empty($list) ? $result : [
            'all_company_num' => count($list),
            'all_order_amount' => $zi_info[0]['poverty_member_num'],
            'rank' => $zi_info[0]['rank']
        ];
    }

    //递归获取公司ID
    private function _reSort($data, $parent_id = 0, $getField = 'id', $isClear = TRUE)
    {
        static $ret = array();
        if ($isClear)
            $ret = array();
        foreach ($data as $k => $v) {
            if ($v['parent_company_id'] == $parent_id) {
                $ret[] = $v[$getField];
                $this->_reSort($data, $v['id'], $getField, FALSE);
            }
        }
        return $ret;
    }

    //获取公司ID
    public function getAllChildCompanyID($company_id)
    {
        $data = $this->getAllCompany();
        return $this->_reSort($data, $company_id, 'id', TRUE);
    }

    //获取认证公司的用户ID
    public function getAllChildCompanyMemberID($company_id)
    {
        $data = $this->getAllCompany();
        return $this->_reSort($data, $company_id, 'member_id', TRUE);
    }

    //取出扶贫超市总数
    public static function getCompanyStore($member_id_arr)
    {
//        $where['member_id'] = ['in', $member_id_arr];
//        $arr = M('MemberStore')->where($where)->getField('store_id', true);
//        return $arr ? array_unique($arr) : [];
        $where['ms.member_id'] = ['in', $member_id_arr];
        $where['s.store_state'] = 1;
        $arr = M('MemberStore')
            ->alias('ms')
            ->field('s.store_id')
            ->join('left join __STORE__ s on s.store_id = ms.store_id')
            ->where($where)
            ->group('s.store_id')
            ->select();
        return $arr ? array_column($arr, 'store_id') : [];
    }

    //取出扶贫单位数量
    public static function getPovertyCompany($store_id, $member_id)
    {
        if (!is_array($member_id)) {
            $member_id = [$member_id];
        }
        $where['member_id'] = ['in', $member_id];
        $where['store_id'] = $store_id;
        $arr = M('MemberStore')->where($where)->count();
        return $arr;
    }

    //根据地区ID获取对应地区名字
    public static function getAreaNameByID($area_id)
    {
        $areaModel = M('Area');
        return $areaModel->where(['area_id' => $area_id])->getField('area_name');
    }

    //根据超市ID获取对应超市名称
    public static function getStoreNameByID($store_id)
    {
        return M('Store')->where(['store_id' => $store_id])->getField('store_name');
    }

    //获取单位业绩汇总
    public static function getCompanyOne1($company_id, $start_time, $end_time, $order = 'create_time desc')
    {
        $where['company_id'] = $company_id;
        if ($start_time && $end_time) {
            $where['create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($start_time) {
            $where['create_time'] = array('egt', strtotime($start_time));
        } elseif ($end_time) {
            $where['create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        $field = 'id,poverty_member_num,make_member_num,make_order_num,make_member_money';
        return M('GovernCenterSelf')->field($field)->where($where)->order($order)->find();
    }

    //获取管辖单位汇总
    public static function getCompanyAll($company_id, $start_time, $end_time, $order = 'create_time desc')
    {
        $where['company_id'] = $company_id;
        if ($start_time && $end_time) {
            $where['create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($start_time) {
            $where['create_time'] = array('egt', strtotime($start_time));
        } elseif ($end_time) {
            $where['create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        $field = 'id,poverty_member_num,make_member_num,make_order_num,make_member_money';
        return M('GovernCenterAll')->field($field)->where($where)->order($order)->find();
    }

    //单位个人业绩(原来)
    public static function getCompanyMarkMember($company_id, $limit)
    {
        $member_id_arr = self::getCompanyMemberID($company_id);
        if ($member_id_arr) {
            $where['buyer_id'] = ['in', $member_id_arr];
        }
        $where['o.is_profits'] = 1;
        $field = 'o.buyer_id,sum(p.all_order_amount) as all_order_amount,m.member_mobile,m.member_nickname,m.member_avatar';
        $list = M('Order')
            ->alias('o')
            ->field($field)
            ->join('left join __MEMBER__ m on o.buyer_id = m.member_id')
            ->join('left join __PROFITS__ p on o.order_id = p.order_id')
            ->where($where)
            ->group('buyer_id')
            ->limit($limit)
            ->select();
        foreach ($list as $key => $val) {
            $list[$key]['member_avatar'] = getFullImg($val['member_avatar']);
            $member_nickname = empty($val['member_nickname']) ? $val['member_mobile'] : $val['member_nickname'];
            $list[$key]['member_nickname'] = getFullImg($val['member_avatar']);
            $list[$key]['member_nickname'] = $member_nickname;
            unset($list[$key]['member_mobile']);
        }
        return $list;
    }

    //取出公司扶贫人数用户ID
    public static function getCompanyMemberID($company_id)
    {
        $where['company_id'] = $company_id;
        $where['status'] = 1;
        return M('MemberAuth')->where($where)->getField('member_id', true);
    }

    //取出下级单位列表
    public static function getChildCompany($company_id)
    {
        $model = M();
        $sql = "SELECT ca.id,ca.company_name,(SELECT count(*) FROM __MEMBER_AUTH__ as ma WHERE ma.company_id = ca.id AND status = 1) as member_num ";
        $sql .= "FROM __COMPANY_AUTH__ as ca WHERE parent_company_id = " . $company_id . " AND status = 1 ";
        $sql .= "ORDER BY member_num DESC,ca.create_time ASC";
        $list = $model->query($sql);
        //取出公司ID
//        $model = M('CompanyAuth');
//        $where['parent_company_id'] = $company_id;
//        $where['status'] = 1;
//        $list = $model->field('id,company_name')->where($where)->select();
//        foreach ($list as $key => $val) {
//            $list[$key]['member_num'] = count(self::getCompanyMemberID($val['id']));
//        }
        return $list;
    }
}