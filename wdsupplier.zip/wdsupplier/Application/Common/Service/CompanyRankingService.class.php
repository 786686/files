<?php
/**
 * Created by PhpStorm.
 * User: fengfeiwu
 * Date: 2018/9/11
 * Time: 14:02
 */

namespace Common\Service;


class CompanyRankingService
{
    //获取公司扶贫业绩在排名
    public static function getCompanyRank($company_id){
        $field = "SUM(all_order_amount) as total_order_amount,company_id";
        $list = M('profits')->field($field)->group('company_id')->order('total_order_amount desc')->select();

        foreach($list as $key=>$value){
            if($value['company_id']==$company_id){
                $rank = $key+1;
            }
        }
        return $rank;
    }

}