<?php

namespace Common\Service;
class Push
{
    /*极光推送*/

    const base_url = "http://www.wx7z.com/Mobile/";

    /** 注册成功后发送
     * @param $registration_id -用户设备ID
     */
    public static function registerSuccess($registration_id)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲，欢迎成为创课网店会员，目前充值都有1元=100积分奖励哦，".
        "每天签到还可获得10积分；欢迎选购，更多优惠在等着您~";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=4";
        push(0, $registration_id, $data);
    }

    /** 拉新活动发送
     * @param $registration_id -用户设备ID
     */
    public static function raxin($registration_id)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲，欢迎成为创课网店会员，分享您的推广码邀请好友成功注册，".
        "完成的每一笔订单您都可以获得消费积分奖励哦~赶快分享尽情坐享收益吧~";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = self::base_url . "SecLevelSale/index";
        push(0, $registration_id, $data);
    }

    /** 活动充值
     * @param $registration_id -用户设备ID
     * @param $money1 -充值的金额
     * @param $money2 -赠送的扶贫金额
     * @param $point1 -赠送的积分
     */
    public static function activityRecharge($registration_id, $money1 = 200, $money2 = 200, $point1 = 20000)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲，您已成功充值" . $money1 . "元，为感谢您对扶贫事业的支持，
        创课网店送您" . $money2 . "元助力扶贫金再赠" . $point1 . "积分，马上打开查看吧~";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=4";
        push(0, $registration_id, $data);
    }

    /** 活动充值
     * @param $registration_id -用户设备ID
     * @param $money1 -充值的金额
     * @param $point1 -赠送的积分
     */
    public static function commonRecharge($registration_id, $money1, $point1, $lilv)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲，您已成功充值" . $money1 . "元，为感谢您的支持，创课网店送您" . $point1 . "积分，
        积分每天以" . $lilv . "%左右分享到积分券账户，积分券可转为现金使用哦~";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=4";
        push(0, $registration_id, $data);
    }

    /** 注册满一个月未充值过的会员
     * @param $registration_id -用户设备ID
     */
    public static function noRecharge($registration_id)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲爱滴，凡在创课网店充值享1元=100的积分奖励，多充多送，马上充值消费吧~~~";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = self::base_url . "Account/integral_recharge";
        push(0, $registration_id, $data);
    }

    /** 积分到账
     * @param $registration_id -用户设备ID
     * @param $point1 -赠送的积分
     */
    public static function integralGiveAway($registration_id, $point1)
    {
        $data['title'] = "创课网店";
        $data['content'] = "奖励您的积分已到账" . $point1 . "分，请查收。感谢您对创课网店的支持";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=4";
        push(0, $registration_id, $data);
    }

    /** 好评感谢
     * @param $registration_id -用户设备ID
     * @param $reciver_name -收货人姓名
     */
    public static function niceComment($registration_id, $reciver_name)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲爱的" . $reciver_name . "，谢谢您给我们的好评，您的评价是我们提高更好服务的动力。".
        "也希望亲把我们商城推荐给朋友噢";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=0";
        push(0, $registration_id, $data);
    }

    /** 中差评关怀
     * @param $registration_id -用户设备ID
     * @param $reciver_name -收货人姓名
     */
    public static function secondaryComment($registration_id, $reciver_name)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲爱的" . $reciver_name . "，很抱歉没能让您有一次愉快的购物经历。为了给您提供更优质的服务，
        客户经理将会回访您，听取您的宝贵建议。";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=0";
        push(0, $registration_id, $data);
    }

    /** 未评价提醒
     * @param $registration_id -用户设备ID
     * @param $reciver_name -收货人姓名
     */
    public static function noComment($registration_id, $reciver_name)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲爱的" . $reciver_name . "，希望这次购物您能满意，您满意是我们的动力，别忘了给好评哦";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=3";
        push(0, $registration_id, $data);
    }

    /** 后台充值预付款到账
     * @param $registration_id -用户设备ID
     */
    public static function adPayMent($registration_id, $money)
    {
        $data['title'] = "创课网店";
        $data['content'] = "您的预付款账户充值到账" . $money . "元，请查收。感谢您对扶贫事业的支持。";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=0";
        push(0, $registration_id, $data);
    }

    /** 后台充值预付款到账
     * @param $registration_id -用户设备ID
     */
    public static function rechargeActivity($registration_id, $money)
    {
        $data['title'] = "创课网店";
        $data['content'] = "每到这个时候我都会想起您~您的助力消费扶贫金已到账" . $money . "元，满15元即可选购福利专区商品哦 ~ ";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=0";
        push(0, $registration_id, $data);
    }

    /** 商品信息提醒(商家信息发送)
     * @param $registration_id -用户设备ID
     */
    public static function shopMsg($registration_id)
    {
        $data['title'] = "创课网店";
        $data['content'] = "【创课网店】亲爱的合伙人，如商品信息有变动更新（包括库存、商品价格、新产品上架等），记得及时与我们联系哦，请致电4009300277 ";
        $data['content_type'] = 4;
        $data['content_id'] = 0;
        $data['content_url'] = "wx7z://tabIndex?index=0";
        push(0, $registration_id, $data);
    }
}