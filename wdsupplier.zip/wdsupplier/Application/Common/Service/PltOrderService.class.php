<?php
namespace Common\Service;
use Common\Lib\Redis\Redis;
use Common\Model\OrderModel;
use Common\Model\OptionModel;

/**
 * @author 宋建强 2020年2月29日 17:08:24 
 * @desc   运费计算
 */
class PltOrderService
{
    
    const   APIRATE    = 'api_member_id:' ;    //api限频
    const   MSAK_GOOD  = 'msk_good_id:';       
    const   BUY_DAY_IN = 'buy_day_in:' ;       //间隔时间
    
    
    const	ORDER_EXITS = 'APP_ORDER_EXSIT:';  //判断30min 
    /**
     * @method 获取用户账号
     * @author 建强 2020年2月29日
     * 
     * @return array
     */
    public static function getUserAccount(){

         $member_id = I('member_id',0,'intval');
         $data      = [ 'type' => self::getPayType()];
         
         $res = M('member_balance')->where(['uid'=>$member_id])->find();
         $res['recharge_balance'] = bcadd($res['recharge_balance'] ?? '0.00', 0, 2);
         $data['user_money'] = $res['recharge_balance'];
         
         return $data;       
    }
    
    
    /**
     * @method 检查订单是否存在
     * @author 如果存在 则不能继续生产
     *
     * @return array
     */
    public function checkOrderhas(){
        
        $where =[
            'order_state' => 10,
            'add_time'    => ['gt',time()-(30*60)],
            'buyer_id'    => I('member_id'),
        ];
        
        $count =M('platform_order')->where($where)->count();
        if($count>=5) return ['code'=>40003,'msg'=>'最多只能存在5个待支付订单哦，请赶快去支付吧！'];
        
        return ['code'=>200,'msg'=>''];
        
    }
    
    /**
     * @method 检测登录信息是否正确
     * @param  number $member_id
     * @param  string $token
     * @return boolean
     */
    public function checkLogin(){
        
        $member_id = I('member_id',0,'intval');
        $token     = I('token','','trim,addslashes');
        
        if (empty($member_id) || empty($token)) {
            return ['code'=>-10001,'msg'=>'用户信息参数为空'];
        }
        
        $where = ['token'=>$token,'member_id'=>$member_id];
        $check = M('token')->where($where)->find();
        
        if (empty($check))  return ['code'=>-10001,'msg'=>'用户登录信息失效'];
        return ['code'=>200 ,'msg'=>''];
    }
    
    /**
     * @method 频繁请求 检验今天是否已经买了
     * @author 宋建强 2020年2月29日
     * @return bool
     */
    public function checkApiRata($type = ''){
        $key = self::APIRATE.I('member_id');
        $res = Redis::getInstance()->get($key);
        if($res) return true;
  
             
         //通过
         return false; 
    }
    
    /**
     * @method 频繁请求 检验今天是否已经买了
     * @author 宋建强 2020年2月29日
     * @return bool
     */
    public function checkBuyDay($set = 0){
        //是否已买
        $buy_key  = self::BUY_DAY_IN.I('member_id');

        //设置缓存
        if($set ==1){
            $itemModel =new OptionModel();
            $day  = $itemModel->getItem('presell_limit_repay');
            $time  =$day*3600*25;
            
            return Redis::getInstance()->set($buy_key,1,$time);
        }
        
        
        $bool     = Redis::getInstance()->get($buy_key);
        
        if($bool) return true;  //当天已购买
        
        //通过
        return false;
    }
    
    
    /**
     * @method 频繁请求 支付时候 余额支付订单
     * @author 宋建强 2020年2月29日
     * @return bool
     */
    public function checkApiRataPay($pay = 'pay' ,$set =0){
        $key = self::APIRATE.$pay.I('member_id');
        if($set== 1){
            return Redis::getInstance()->set($key,1,5);
        }
        
        $res = Redis::getInstance()->get($key);
        if($res) return true;
        
        //通过
        return false;
    }
    
    /**
     * @method 频繁请求 检验今天是否已经买了
     * @author 宋建强 2020年2月29日
     * @return bool
     */
    public function checkPayPass(){
        $pass = I('pass','','trim');
        $member_id = I('member_id',0,'intval');
        if(empty($pass)){
            return ['code'=>40000, 'msg'=>'支付密码不能为空'];
        }
        
        $res = M('member')->where(['member_id'=>$member_id])->find();
        if(empty($res['member_paywd'])){
            return ['code'=>10001, 'msg'=>'支付密码没有设置'];
        }
         
        if (md5($pass) != $res['member_paywd'] ) {
            return ['code'=>40001, 'msg'=>'支付密码错误！'];
        }
        return ['code'=>200, 'msg'=>''];
    }
    
    
    /**
     * @method  埋点 设置操作缓存 频率
     * @author 建强 2020年2月29日 
     * 
     * @return  void
     */
    public function  setUserOpKey(){
        $key = self::APIRATE.I('member_id');
        Redis::getInstance()->set($key,1,6);
    }
    
    /**
     * @method 订单验证基本参数 
     * @author 建强 2020年2月29日 
     * @return  array  code=>.msg=> 
     */
    public function checkParams(){ 
        
        $params = I('post.');
        
        $fee    = I('fee','floatval ');
        $price  = I('price','floatval ');
        $money  = I('money','floatval ');
        $good_id= I('goods_id','floatval ');
        
        //收货地址
        $area_p= I('area_p_id',0,'intval');
        $area_c= I('area_c_id',0,'intval');
        $area_d= I('area_d_id',0,'intval');
        
        //支付方式
        $pay_type  =  I('pay_type',0,'intval');
        $goods_num =  I('goods_num',0,'intval');
       
        if(empty($goods_num)){
            return ['code'=>40000, 'msg'=>'请填写购买数量'];
        }
        
        if(!isset($params['realname']) || empty($params['realname'])) {
            return ['code'=>40000, 'msg'=>'请填写您的真姓名'];
        }
        
        if(!isset($params['tel']) || !is_mobile($params['tel'])) {
            return ['code'=>40001, 'msg'=>'请填写手机号码或格式错误'];
        }
        
        if(!isset($params['relationship']) || empty($params['relationship'])) {
            return ['code'=>40002, 'msg'=>'请选择店主关系'];
        }
        
        
        if(empty($area_p) || empty($area_c) || empty($area_d)){
            return ['code'=>40005, 'msg'=>'请选择收货地址'];
        }
        
        if(mb_strlen($params['express_address'], 'UTF8') > 128) {
            return ['code'=>40006, 'msg'=>'详细地址过长'];
        }
        
        if($good_id < 0){
            return ['code'=>40007, 'msg'=>'商品id不存在'];
        }
        
        if($fee< 0){
            return ['code'=>40007, 'msg'=>'运费价格不正确'];
        }
        
        if( $price<= 0 ){
            return ['code'=>40009, 'msg'=>'价格参数不正确'];
        }
        
       
        if(!empty($params['order_message']) && mb_strlen($params['order_message'],'UTF8')>30){
            return  ['code'=>40012, 'msg'=>'订单备注信息最多30个字符'];
        }
        
        if( $money<= 0 ){
            return ['code'=>40010, 'msg'=>'总价参数不正确'];
        }
        
        if(!in_array($pay_type, self::getPayType('key'))){
            return ['code'=>40011, 'msg'=>'支付方式不存在'];
        }
        
        $buy_limit_num = (new OptionModel())->getItem('buy_limit_num');
        if($goods_num > $buy_limit_num){
            return ['code'=>40122, 'msg'=>'单笔最大购买数量'.$buy_limit_num.'盒'];
        }
        
        
        //计算总价
        $good_money = $price* $goods_num; 
        //判断合计是费用 
        $total = bcadd($good_money, $fee,2);  
        if($total != $money){
            return ['code'=>40013, 'msg'=>'金额计算不相等'];
        }
        
        //通过
        return  ['code'=>200, 'msg'=>''];
    }
    
    /**
     * @method  获取支付方式 
     */
    public static function getPayType($type = 'all'){
        
        $arr = [
            1=>'账户余额',
            2=>'微信',
            3=>'支付宝',
        ];
       
        if($type == 'key'){
            return  array_keys($arr);
        }
       return $arr;
    }
    
    
    /**
     * @method 检验运费是否正
     * 
     */
    public function checkFeeGoods(){
        $area_c_id = I('area_c_id',0,'intval');
        $post_fee  = I('fee','floatval');
        
        $ser   = new AppointService();
        $goods = $ser->getCacheAppointGoodsInfo();
        $fee   = AppointService::getExpressfeeById($goods['transport_id']);

        $expree_fee = 0; 
        foreach($fee as $val){
            if(is_array($val) && $val['area']){
                $area = explode(',', $val['area']);
                if(!in_array($area_c_id, $area)) continue;
                $expree_fee = $val['sub_first_price'];
                break;
            }
        }

        if($expree_fee != $post_fee){
            return  ['code'=>40009, 'msg'=>'运费计算错误 ，金额有误'];
        }
        
        
        //成功
        return  ['code'=>200, 'msg'=>''];
     }
    
     
     /**
      * @method 计算库存是否足够   判断商品库存是否足够 
      * @author 建强 2020年2月29日  
      * 
      * @return bool
      */
     public function checkGoodNumber(){
         
         $good_id   = I('goods_id',0,'intval');
         $goods_num = I('goods_num',0,'intval');
       
         $key = self::MSAK_GOOD.$good_id;
         $ret = Redis::getInstance()->get($key);
         if($ret >= $goods_num ){
             return  ['code'=>200, 'msg'=>''];
         }
                    
         $res = M('goods')->where(['goods_id'=>$good_id])->find();
         if(empty($res['goods_storage']) || $res['goods_storage']<$goods_num){
             return  ['code'=>50009, 'msg'=>'抱歉，商品已卖完，请明天早点来'];
         }
         
         Redis::getInstance()->set($key,$res['goods_storage'],23*2600);
         return  ['code'=>200, 'msg'=>''];
     }
     
     
     
     /**
      * @method 计算库存是否足够   判断商品库存是否足够
      * @author 建强 2020年2月29日
      * @param $order_num int  下单数量  
      * @return bool
      */
     public function checkGoodNumberForUp($order_num = 0){
         
         $good_id   = I('goods_id',0,'intval');
         $goods_num = I('goods_num',0,'intval');
         
         
         if($order_num == $goods_num){
             //没有数量变化 
             return   ['code'=>200, 'msg'=>''];
         }
         
         $key      = self::MSAK_GOOD.$good_id;
         $storage  = Redis::getInstance()->get($key);
         $inc_num  = $goods_num - $order_num;
         
         
         if($inc_num<0){
             //减少购买数量 
             C('order_goods_num',$inc_num);
             return ['code'=>200, 'msg'=>''];
         }
         
         //增加购买数量  
         if($storage >= $inc_num ){
             C('order_goods_num',$inc_num);
             return ['code'=>200, 'msg'=>''];
         }
        
         $res = M('goods')->where(['goods_id'=>$good_id])->find();
         if(empty($res['goods_storage']) || $res['goods_storage']<$goods_num){
             return  ['code'=>50009, 'msg'=>'抱歉，商品已卖完，请明天早点来'];
         }
         
         //记录变化量
         C('order_goods_num',$inc_num);
         
         Redis::getInstance()->set($key,$res['goods_storage'],23*2600);
         return  ['code'=>200, 'msg'=>''];
     }
     
     /**
      * @method  使用余额支付订单 
      * @author  建强  2020年2月29日 
      * 
      * @return  array 
      */
     public function creatOrder(){
         //订单数量
         $goods_num = I('goods_num');
         
         $data  = self::getOrderData();
         $where = ['goods_id'=>I('goods_id')];
         
         M()->startTrans();
         $ret   = [];
         $id    = M('platform_order')->add($data);
         $ret[] = M('goods')->where($where)->lock(true)->setDec('goods_storage',$goods_num);
        
         
         $ret[] =$id ;

         if(in_array(false, $ret)){
             M()->rollback();
             return  ['code'=>30022,'msg'=>'下单失败'];
         }
         
         //扣减库存
         M()->commit();
         $good_key =  self::MSAK_GOOD.I('goods_id');
         Redis::getInstance()->decrBy($good_key,$goods_num);
         
         return  ['code'=>200,'msg'=>'','data'=>['id'=>$id,'type'=>9]];
     }
     
     
     /**
      * @method 修改订单信息
      * @author 建强 2020年3月30日 12:34:24
      * @return array  
      */
     public function editOrder(){
         
         //本次修改订单 数量是否发送变化 
         $chg_good_num= C('order_goods_num');
         
         
         $data  = self::getEditOrderData();
         $where_order  = ['id'=>I('id',0,'intval')];
         $where        = ['goods_id'=>I('goods_id')];
         
         $good_key =  self::MSAK_GOOD.I('goods_id');
         
         M()->startTrans();
         $ret   = [];
         $ret[] = M('platform_order')->where($where_order)->save($data);
        
         //继续减少
         if($chg_good_num >0){
             
             Redis::getInstance()->redis->decrBy($good_key,$chg_good_num);
             $ret[] = M('goods')->where($where)->setDec('goods_storage',$chg_good_num);
         }
         
         //加回来
         if($chg_good_num<0){
             $chg_good_num = abs($chg_good_num);
             
             Redis::getInstance()->redis->incrBy($good_key,$chg_good_num);
             $ret[] = M('goods')->where($where)->setInc('goods_storage',$chg_good_num);
         }
         
         
         if(in_array(false, $ret)){
             M()->rollback();
             return  ['code'=>30022,'msg'=>'订单修改失败'];
         }
         
         M()->commit();
         return  ['code'=>200,'msg'=>''];
     }
     /**
      * @method 组装数据
      * @author 建强 2020年2月29日 23:50:55
      * 
      * @return array 
      */
    public static function  getOrderData(){
         $member_id = I('member_id');
         $goods_amount = bcadd(I('price','floatval'), 0, 2);
         $order_amount = bcadd(I('money','floatval'), 0, 2);
         $shipping_fee = bcadd(I('fee','floatval'), 0, 2);
         return [
             'order_sn'    => OrderModel::makeOrderSN($member_id),
             'pay_sn'      => OrderModel::makePaySN($member_id),
             'store_name' => I('store_name','','trim'),
             'store_id'   => I('store_id'),
             'buyer_id'   => I('member_id',0,'intval'),
             'buyer_name' => I('realname','','trim'),
             'buyer_phone'=> I('tel','','trim'),
             'add_time'   => NOW_TIME,
             'goods_id'   => I('goods_id',0,'intval'),
             'payment_code'=> I('pay_type'),
             'goods_amount'=> $goods_amount,
             'order_amount'=> $order_amount,
             'shipping_fee'=> $shipping_fee,
             'reciver_name'=> I('realname','','trim'),
             'reciver_info'=> '口罩',
             
             'goods_nums'  => I('goods_num',0,'intval'),
             'order_message'       => I('order_message','','trim,strip_tags'),
             'reciver_province_id' => I('area_p_id'),
             'reciver_city_id'     => I('area_c_id'),
             'reciver_area_id'     => I('area_d_id'),
             
             'reciver_address'     => I('express_address'),
             'relationship'        => I('relationship'),
             'reciver_mobile'      => I('tel'),
            
         ];
    }
    
    
    /**
     * @method 组装数据   编辑订单
     * @author 建强 2020年2月29日 23:50:55
     *
     * @return array
     */
    public static function  getEditOrderData(){
        $goods_amount = bcadd(I('price','floatval'), 0, 2);
        $order_amount = bcadd(I('money','floatval'), 0, 2);
        $shipping_fee = bcadd(I('fee','floatval'), 0, 2);
        return [
            'buyer_name'  => I('realname','','trim'),
            'buyer_phone' => I('tel','','trim'),
            'payment_code'=> I('pay_type'),
            'goods_amount'=> $goods_amount,
            'order_amount'=> $order_amount,
            'shipping_fee'=> $shipping_fee,
            'reciver_name'=> I('realname','','trim'),
            'reciver_info'=> '口罩',
            
            'goods_nums'  => I('goods_num',0,'intval'),
            'add_time'=>NOW_TIME,  //防止字段更新不成功 
            
            'order_message'       => I('order_message','','trim,strip_tags'),
            'reciver_province_id' => I('area_p_id'),
            'reciver_city_id'     => I('area_c_id'),
            'reciver_area_id'     => I('area_d_id'),
            
            'reciver_address'     => I('express_address'),
            'relationship'        => I('relationship'),
            'reciver_mobile'      => I('tel'),
            
        ];
    }
    
    /**
     * @method 频繁请求 检验今天是否已经买了
     * @author 宋建强 2020年2月29日
     * @return bool
     */
    public static function unfreeze()
    {
        $buy_key  = self::BUY_DAY_IN.I('member_id');

        Redis::getInstance()->redis->delete($buy_key);
    }



    /**
     * 处理订单取消
     *
     * @author fanzhaogui
     * @date 2020.03.06
     *
     * @param int $member_id
     * @param int $goods_id
     * @param int $stock
     */
    public static function dealCancelOrder($member_id, $goods_id, $purchase_qualif, $stock = 1)
    {
        // 将库存返回
        $goods_key = PltOrderService::MSAK_GOOD . $goods_id;
        Redis::getInstance()->redis->incrBy($goods_key,$stock);

        // 返回库存
        M('goods')->where(['goods_id'=>$goods_id])->setInc('goods_storage', $stock);
    }
}