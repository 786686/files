<?php
namespace Common\Service;
use Think\Controller;
include 'vendor/autoload.php';
use PFinal\Excel\Excel;

class ExcelImportService{
	protected $file = null;

	protected $tempSavePath = null;

	protected $tempFileName = null;

	protected $ext = null;

	protected $checkExt = null;

	protected $errMsg = "";


	public function __construct($file,$checkExt = [])
	{
		if ($checkExt) $this->checkExt = $checkExt;
		$this->setFile($file);
		$this->setTempSavePath();
		$this->setExt();
		$this->setTempFileName();
		$this->renameFile();
		$this->checkExt();
	}

	/**
	 * 读取Excel文件数据 (或cvs文件)
	 *
	 * 使用示例
	 *
	 * $map = array(
	 *     'id' => '编号',
	 *     'name' => '姓名',
	 *     'age' => '年龄',
	 *  );
	 * $excel = new \PHPExcel\Excel();
	 * $data = $excel->readExcelFile('./user2014-11-08.xls', $map);
	 *
	 * @param $file
	 * @param array $map
	 * @param int $titleRow 标题在第几行
	 * @param int $beginColumn 从行几列开始
	 * @param string $method 获取数据方式。 支持公式计算:calculated、格式化后返回:formatted、 默认为空:原样返回单元格数据
	 * @param string $encoding 文件编码 UTF-8、GBK等。 导入csv文件时默认为UTF-8，如果你导入的csv文件是其它编码格式例如"GBK"，请传入此参数为"GBK"
	 * @return array
	 * @throws \PHPExcel_Exception
	 * @throws \PHPExcel_Reader_Exception
	 */
	public function readExcelFile($map = array(), $titleRow = 1, $beginColumn = 1, $method = '', $encoding = null)
	{
		$list =  Excel::readExcelFile($this->tempSavePath.$this->tempFileName, $map , $titleRow , $beginColumn , $method , $encoding );
		if ($list) $list = $this->filter_array($list);
		return $list;
	}


	public function getErrMsg()
	{
		return $this->errMsg;
	}

	/**
	 * 检测后缀名
	 * @return bool
	 */
	protected function checkExt()
	{
		if (empty($this->checkExt) || in_array($this->ext,$this->checkExt)){
			return true;
		}
		$this->errMsg = "文件格式不正确";
	}

	/**
	 * 将文件移动到临时目录
	 */
	protected function renameFile()
	{
		rename($this->file['tmp_name'],$this->tempSavePath.$this->tempFileName);
	}

	/**
	 * @param $file
	 */
	protected function setFile($file)
	{
		$this->file = $file;
	}

	/**
	 *
	 */
	protected function setTempFileName()
	{
		$this->tempFileName = uniqid().".".$this->ext;
	}

	/**
	 *
	 */
	protected function setExt()
	{
		$this->ext = pathinfo($this->file['name'])['extension'];
	}

	/**
	 *
	 */
	protected function setTempSavePath()
	{
		$this->tempSavePath = C('upload_path') . '/tmp/';
		if (!$this->mkdir( $this->tempSavePath)) {
			new Exception( "目录创建失败！",-1);
		}

	}

	/**
	 * @param $savepath
	 * @return bool
	 */
	protected function mkdir($savepath)
	{
		$dir = $savepath;
		if (is_dir($dir)) {
			return true;
		}

		if (@mkdir($dir, 0777, true)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param $arr
	 * @return mixed
	 */
	protected function filter_array($arr)
	{
		foreach ($arr as $key => $value){
			$tmp_v = implode("",$value);
			if (empty($tmp_v)) unset($arr[$key]);
		}
		return $arr;
	}

	/**
	 * 删除临时文件
	 */
	public function __destruct()
	{
		// TODO: Implement __destruct() method.
		@unlink($this->tempSavePath.$this->tempFileName);
	}
}
