<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/11/1
 * Time: 9:31
 */

namespace Common\Service;

class StoreService
{
    /**
     * getByIdStoreInfo
     * @author: fanzhaogui
     * @date 2019-11-05
     * @param $storeId
     * @param string $fields
     * @return array
     */
    static public function getByIdStoreInfo($storeId, $fields = '*')
    {
        $info = M("Store")->field($fields)->find($storeId);
        return $info ?? [];
    }

    /**
     * 商家后台，获取商家的手机号码
     * @author: fanzhaogui
     * @date 2019-11-5
     * @return mixed
     */
    static public function getStoreAdminCacheMobile()
    {
        return session("sa_mobile");
    }

    /**
     * 根据网店ID获取网店列表数据
     * @author: fanzhaogui
     * @date 2019-11-06
     * @param array $storesIdArr
     * @param string $fields
     * @return array store_id为键，array为值
     */
    static public function getByIdsStoreList(array $storesIdArr, $fields = '*')
    {
        $list = [];
        if ($storesIdArr) {
            $list = M("Store")->field($fields)->where(['store_id' => ['in', $storesIdArr]])->select();
            if ($list) {
                $list = array_column($list, null, 'store_id');
            }
        }
        return $list ?? [];
    }

    /**
     * getByIdStoreInfo
     * @author: fanzhaogui
     * @date 2019-11-05
     * @param $storeId
     * @param string $fields
     * @return array
     */
    static public function getByPointStoreInfo($pointId, $fields = '*')
    {
        $info = M("Store")->field($fields)->where(['point_id' => $pointId])->find();
        return $info ?? [];
    }
}