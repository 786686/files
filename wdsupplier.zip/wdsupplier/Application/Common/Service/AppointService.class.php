<?php

namespace Common\Service;

use Common\Lib\Redis\Redis;
use OSS\OssClient;

/**
 * 快速预约信息
 * Class AppointService
 *
 * @package Common\Service
 */
class AppointService
{

    //运费模板id
    const PREFIX = 'fee_template_id:';
    
	protected $redisKey = 'appoind_goods:';

	/**
	 * 获取预约商品信息
	 *
	 * @return array|mixed
	 */
	public function getAppointGoods()
	{
	    
	    //补充运费模板ID 
	    $where  = ['goods_type' => 9, 'is_delete' => 0, 'goods_state' => 1]; 
	    $field  = 'goods_id,goods_name,goods_jingle,goods_marketprice,
                   goods_unit,goods_img,goods_type,transport_id';
	    
		$info = M('Goods')->field($field)->where($where)->find();
		if (!$info) {
			$info = [];
		}  else {
            $ossClient = new OssClient(C('aliyun.accessKeyId'), C('aliyun.accessKeySecret'), C('aliyun.oss_endpoint'));
            $info['goods_img'] = !empty($info['goods_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $info['goods_img'], 7200) : '';
        }

		$this->setCache($info);

		return $info;
	}

	/**
	 * 缓存商品信息
	 *
	 * @param $info
	 */
	public function setCache($info)
	{
		if (!isset($info['goods_id']) || empty($info['goods_id'])) {
			return;
		}
		Redis::getInstance()->set($this->redisKey, $info, 7200);
	}

	/**
	 * 获取预约商品信息
	 *
	 * @return array
	 */
	public function getCacheAppointGoodsInfo()
	{
		$info = Redis::getInstance()->get($this->redisKey);
		if (empty($info)) {
			$info = $this->getAppointGoods();
		}
		else {
			$info = json_decode($info, true);
		}

		return $info;
	}

	/**
	 * 清除缓存信息
	 */
	public function refleshAppoint()
	{
        $transport_id = I('transport_id', 5 , 'intval');
        $redis = Redis::getInstance();
        $redis->redis->delete($this->redisKey);
        // 清除 运费模板
        $redis->redis->delete(self::PREFIX.$transport_id);
	}
	
	/**
	 * @method  运费模板 资费标准
	 * @author  建强  2020年2月29日 17:10:54
	 * @return  array
	 */
	public static function getExpressfeeById($transport_id = 0){
	    $redis = Redis::getInstance();
	    $key   = self::PREFIX.$transport_id;
	    $fee   = $redis->get($key);
	    
	    if ($fee) return unserialize($fee);
	    
	    $fee = M('transport')->where(['id'=>$transport_id])->field('zoning')->find();
	    
	    if(empty($fee)) return  [];
	    $redis->set($key,$fee['zoning'], 24*3600);
	    
	    return unserialize($fee['zoning']);
	}
}