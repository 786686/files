<?php

namespace Common\Service;
class CompanyStatistics
{
    public static $field = 'o.order_id,o.order_sn,o.pay_sn,o.store_id,o.goods_amount,o.order_amount
    ,o.add_time,o.buyer_phone,o.trade_no,o.reciver_name,o.reciver_mobile,o.payment_time
    ,p.id as profits_id,p.all_order_amount as deal_amount_count,p.all_goods_amount as all_goods_amount,p.all_goods_price as goods_price
    ,p.all_profits as profits,p.king_company as king_company_amount,p.naturalness as naturalness_amount
    ,p.village as village_amount,p.wan_company as wan_company_amount,p.sale_cost as sale_cost,p.additional_cost as additional_cost,p.products_cost as products_cost
    ,p.logistics_cost as logistics_cost,p.labor_cost as labor_cost,p.packaging_cost as packaging_cost,p.risk_cost as risk_cost
    ,p.warehousing_cost as warehousing_cost,p.water_electricity_cost as water_electricity_cost, p.freight
    ,p.restaurent_cost as restaurent_cost,p.others_cost as others_cost,p.platform_promotion as platform_promotion,p.is_batch,o.company_id,o.order_state,o.voucher_status,o.payment_code
    ,o.shipping_fee';

    public static $order_goods_field = 'goods_id,goods_name,goods_price as order_goods_price,goods_num,goods_unit,goods_img,goods_pay_price,goods_spec_id';

    public static $start_time = '2017-12-01';

    //取出测试订单ID
    public static function getOrdrTest()
    {
        return M('OrderTest')->getField('order_id', true);
    }

    //根据网店id取出其下的致富站id（全部）
    public static function getAllChildStoreIDArr($store_id)
    {
        $store_id_arr1 = self::getStoreFromAdmin($store_id);
        $store_id_arr2 = self::getStoreIDFromUser($store_id);
        return array_merge($store_id_arr1, $store_id_arr2);
    }

    //根据网店id取出其下的致富站id(后台管理添加超市)
    public static function getStoreFromAdmin($store_id)
    {
        $store = M('Store')->alias('s')
            ->field('s.store_id,s.point_id,p.level')
            ->join('left join __POINT__ p on s.point_id=p.point_id')
            ->where(['s.store_id' => $store_id])
            ->find();
        if (empty($store)) {
            return [];
        }
        if ($store['point_id'] > 0 && $store['level'] == 1) {
            //表示为致富中心
            //取出他底下的致富站
            $child_point_id_arr = M('Point')
                ->where(['point_parent_id' => $store['point_id']])
                ->getField('point_id', true);
            if ($child_point_id_arr) {
                $where['point_id'] = ['in', $child_point_id_arr];
                $store_id_arr = M('Store')->where($where)->getField('store_id', true);
                //兼容客户端我要开店的情况
                return $store_id_arr ? $store_id_arr : [];
            } else {
                return [];
            }
        }
        return [];
    }

    //根据网店id取出其下的致富站id(客户端我要开店情况)
    public static function getStoreIDFromUser($store_id)
    {
        $store_arr = M('Store')->where(['store_parent_id' => $store_id])->getField('store_id', true);
        if (empty($store_arr)) {
            $store_arr = [];
        }
        return $store_arr;
    }

    public static function getOrderDetail($params = [])
    {
        $order_test_id = self::getOrdrTest();
        $where = [];
        if ($params['company_id']) {
            $where['o.company_id'] = $params['company_id'];
        }
        if ($params['company_child_ids']){
            $where['o.company_id'] = ['in',$params['company_child_ids']];
        }
        if ($params['type'] == '1') {
            $where['o.is_batch'] = ['eq',1];
        }elseif($params['type'] == '2'){
            $where['o.is_batch'] = ['eq',0];
        }else{
        }
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        $page_list = 10;    //每页10条数据
        if ($params['order_sn']) {
            $where['o.order_sn'] = ['like', '%' . $params['order_sn'] . '%'];
        }
        if ($params['reciver_name']) {
            $where['o.reciver_name'] = ['like', '%' . $params['reciver_name'] . '%'];
        }
        if ($params['reciver_mobile']) {
            $where['o.reciver_mobile'] = ['like', '%' . $params['reciver_mobile'] . '%'];
        }
        if ($params['store_id'] && $params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_id']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['o.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['buyer_phone']) {
            $where['o.buyer_phone'] = ['like', '%' . $params['buyer_phone'] . '%'];
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['o.add_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
//        if ($params['create_time_start']) {
//            if (strtotime($params['create_time_start']) < strtotime(self::$start_time)) {
//                $params['create_time_start'] = self::$start_time;
//            }
//        } else {
//            $params['create_time_start'] = self::$start_time;
//        }

//        if ($params['create_time_start'] && $params['create_time_end']) {
//            $create_time_start = $params['create_time_start'];
//            $create_time_end = $params['create_time_end'];
//            $where['p.create_time'] = array('between', [strtotime("$create_time_start"), strtotime("$create_time_end 23:59:59")]);
//        } elseif ($params['create_time_start']) {
//            $where['p.create_time'] = array('egt', strtotime($params['create_time_start']));
//        } elseif ($params['create_time_end']) {
//            $end_time = $params['create_time_end'];
//            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
//        }
        if ($params['order_state'] != '' && $params['order_state'] != 'All'){
            $where['o.order_state'] = array('EQ', $params['order_state']);
        }
        if ($params['payment_code'] != '' && $params['payment_code'] != 'All'){
            $where['o.payment_code'] = $params['payment_code'];
        }
//        if ($params['areaid_5']){
//            $where['c.village_id'] = $params['areaid_5'];
//        }elseif ($params['areaid_4']){
//            $where['c.town_id'] = $params['areaid_4'];
//        }elseif ($params['areaid_3']){
//            $where['c.area_id'] = $params['areaid_3'];
//        }elseif ($params['areaid_2']){
//            $where['c.city_id'] = $params['areaid_2'];
//        }elseif ($params['areaid_1']){
//            $where['c.province_id'] = $params['areaid_1'];
//        }
        $alllist = M('Order')
            ->alias('o')
            ->field(self::$field)
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __COMPANY_AUTH__ AS c ON o.company_id=c.id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        if ($page = $params['page']) {
            M('Order')->page($page, $page_list);
        }
        $list = M('Order')
            ->alias('o')
            ->field(self::$field)
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __COMPANY_AUTH__ AS c ON o.company_id=c.id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        foreach ($list as $k => $v) {
            $list[$k]['add_time'] = date('Y-m-d H:i:s', $v['add_time']);
            $list[$k]['payment_time'] = date('Y-m-d H:i:s', $v['payment_time']);
            $order_goods = M('OrderGoods')->field(self::$order_goods_field)->where(['order_id' => $v['order_id']])->select();
            foreach ($order_goods as $key => $val) {
                $order_goods[$key]['goods_img'] = C('WEBSITE_URL') . '/' . $val['goods_img'];
            }
            $list[$k]['order_goods'] = $order_goods;
//            $company_store_profits = M('CompanyStoreProfits')
//                ->field('store_name,is_center,percent_value')
//                ->where(['profits_id' => $v['profits_id']])
//                ->select();
//            $list[$k]['company_store_profits'] = $company_store_profits;
            //获取企业信息
            $list[$k]['company'] = M('CompanyAuth')
                ->field('id,company_name,province_id,city_id,area_id,town_id,village_id')
                ->where(['id' => $v['company_id']])
                ->find();
            $area = M('area');
            if ($list[$k]['company']){
                $address = $area->where(array('area_id'=>$list[$k]['company']['province_id']))
                        ->getField('area_name').$area->where(array('area_id'=>$list[$k]['company']['city_id']))
                        ->getField('area_name').$area->where(array('area_id'=>$list[$k]['company']['area_id']))
                        ->getField('area_name').$area->where(array('area_id'=>$list[$k]['company']['town_id']))
                        ->getField('area_name').$area->where(array('area_id'=>$list[$k]['company']['village_id']))
                        ->getField('area_name');
            }
            $list[$k]['company']['address'] = isset($address) ?$address :'';
//            if($v['is_batch'] == 0 || $params['is_batch'] == 0){
//                $list[$k]['order_goods'] = [];
//            }
        }
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($alllist),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    /** 获取订单信息
     * @param array $params
     * $params['store_id'] 网店id
     * $params['start_time'] 格式2017-6-8 开始时间
     * $params['end_time'] 格式2017-6-8 结束时间
     * @return mixed
     */
    public static function getOrderSumInfo($params = [])
    {
        $where = [];
        $order_test_id = self::getOrdrTest();
        if ($order_test_id) {
            $where['p.order_id'] = ['not in', $order_test_id];
        }
        if ($params['start_time']) {
            if (strtotime($params['start_time']) < strtotime(self::$start_time)) {
                $params['start_time'] = self::$start_time;
            }
        } else {
            $params['start_time'] = self::$start_time;
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } else if ($params['start_time']) {
            $where['p.create_time'] = array('egt', strtotime($params['start_time']));
        } else if ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }

        if ($params['company_id']) {
            if(!is_array($params['company_id'])){
                $company_id = [$params['company_id']];
            }else{
                $company_id = $params['company_id'];
            }
            $where['p.company_id'] = ['in', $company_id];
        }
        if ($params['is_batch'] != '') {
            $where['p.is_batch'] = $params['is_batch'];
        }

        $order_info = M('Profits')
            ->alias('p')
            ->field('IFNULL(COUNT(*), 0) as order_num, IFNULL(SUM(p.all_order_amount), 0) as order_amount')
            ->where($where)
            ->select();
        return $order_info[0];
    }

    //分组列表要取出的字段
    public static $group_fields = 'count(*) as deal_order_count
            , sum(p.freight) as freight, sum(p.all_order_amount) as deal_amount_count
            , sum(p.all_goods_amount) as all_goods_amount, sum(p.all_goods_price) as goods_price, sum(p.sale_cost) as sale_cost, sum(p.additional_cost) as additional_cost, sum(p.all_profits) as profits, sum(p.king_company) as king_company_amount
            , sum(p.naturalness) as naturalness_amount, sum(p.village) as village_amount, sum(p.wan_company) as wan_company_amount
            , sum(p.products_cost) as products_cost, sum(p.logistics_cost) as logistics_cost
            , sum(p.labor_cost) as labor_cost, sum(p.packaging_cost) as packaging_cost, sum(p.risk_cost) as risk_cost
            , sum(p.warehousing_cost) as warehousing_cost, sum(p.water_electricity_cost) as water_electricity_cost
            , sum(p.restaurent_cost) as restaurent_cost, sum(p.others_cost) as others_cost, sum(p.platform_promotion) as platform_promotion';

    //组合查询条件
    public static function getWhereArr($params = [])
    {
        $where = [];
        $order_test_id = self::getOrdrTest();
//        $where['p.create_time'] = ['elt', strtotime("2017-12-01")];
        if ($order_test_id) {
            $where['p.order_id'] = ['not in', $order_test_id];
        }
        if ($params['store_ids'] && $params['store_id_child']) {
            $where['p.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_ids']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_ids']);
            array_push($store_id_arr, $params['store_ids']);
            $where['p.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['p.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['start_time']) {
            if (strtotime($params['start_time']) < strtotime(self::$start_time)) {
                $params['start_time'] = self::$start_time;
            }
        } else {
            $params['start_time'] = self::$start_time;
        }

        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['p.create_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }

        if ($params['company_id']) {
            if(!is_array($params['company_id'])){
                $company_id = [$params['company_id']];
            }else{
                $company_id = $params['company_id'];
            }
            $where['p.company_id'] = ['in', $company_id];
        }
        if ($params['is_batch'] != '') {
            $where['p.is_batch'] = $params['is_batch'];
        }
        return $where;
    }

    //按日期分组
    public static function getListGroupDate($params = [])
    {
        $page_list = 10;    //每页10条数据
        $where = self::getWhereArr($params);

        $allList = M('Profits')
            ->alias('p')
            ->field('p.id')
            ->where($where)
            ->order('p.create_time desc')
            ->group('DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\')')
            ->select();
        if ($page = $params['page']) {
            M('Profits')->page($page, $page_list);
        }
        $field = self::$group_fields;
        $field .= ', DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\') as meak_time';
        $list = M('Profits')
            ->alias('p')
            ->field($field)
            ->where($where)
            ->order('p.create_time desc')
            ->group('DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\')')
            ->select();
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($allList),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    //获取昨日利润
    public static function getListYeastDay($params = [])
    {
        $list = self::getListGroupDate($params);
        if (empty($list['list'])) {
            return [
                'deal_order_count' => 0,
                'profits' => 0,
                'king_company_amount' => 0,
                'village_amount' => 0,
                'naturalness_amount' => 0,
                'wan_company_amount' => 0,
            ];
        }
        return [
            'deal_order_count' => $list['list'][0]['deal_order_count'],
            'profits' => $list['list'][0]['profits'],
            'king_company_amount' => $list['list'][0]['king_company_amount'],
            'village_amount' => $list['list'][0]['village_amount'],
            'naturalness_amount' => $list['list'][0]['naturalness_amount'],
            'wan_company_amount' => $list['list'][0]['wan_company_amount']
        ];
    }

    //获取全部利润
    public static function getAllList($params = [])
    {
        $return = [
            'deal_order_count' => 0,
            'profits' => 0,
            'king_company_amount' => 0,
            'village_amount' => 0,
            'naturalness_amount' => 0,
            'wan_company_amount' => 0,
        ];
        $list = self::getListGroupDate($params);
        if (empty($list['list'])) {
            return $return;
        }
        foreach ($list['list'] as $k => $v) {
            $return['deal_order_count'] += $v['deal_order_count'];
            $return['profits'] += $v['profits'];
            $return['king_company_amount'] += $v['king_company_amount'];
            $return['village_amount'] += $v['village_amount'];
            $return['naturalness_amount'] += $v['naturalness_amount'];
            $return['wan_company_amount'] += $v['wan_company_amount'];
        }
        return $return;
    }

    //导出订单商品列表数据
    public static function getOrderInfo($params = [])
    {
        $where = self::getWhereArr($params);
        $field = 'od.*,o.order_sn,o.*,m.order_id AS test_order_id,g.gc_id AS gc_id,g.gc_id_1 AS gc_id_1';
        $field .= ',g.gc_id_2 AS gc_id_2,g.goods_jingle,g.areaid_1,g.areaid_2,g.areaid_3,g.areaid_4';
        $field .= ',g.brand_id,g.variety_id_1,g.variety_id_2,g.goods_addtime,g.purchasing_tax_rate';
        $field .= ',o.store_id AS goods_store_id,p.create_time AS profits_time,r.refund_time';
        $lists = M('OrderGoods')
            ->alias('od')
            ->join('LEFT JOIN __ORDER__ AS o ON o.order_id = od.order_id')
            ->join('LEFT JOIN __REFUND_RETURN__ AS r ON r.order_id = o.order_id')
            ->join('LEFT JOIN __GOODS__ AS g ON g.goods_id = od.goods_id')
            ->join('LEFT JOIN __ORDER_TEST__ AS m ON m.order_id = o.order_id')
            ->join('LEFT JOIN __PROFITS__ AS p ON o.order_id = p.order_id')
            ->field($field)
            ->order('o.order_id desc')
            ->where($where)
            ->select();
        return $lists;
    }

    //按公司ID和日期进行分组
    public static function getChildListGroupDate($params = [])
    {
        $page_list = 10;    //每页10条数据
        $where = self::getWhereArr($params);
        if($company_name = $params['company_name']){
            $where['ca.company_name'] = ['like', "%$company_name%"];
        }
        if($params['province_id']){
            $where['ca.province_id'] = $params['province_id'];
        }
        if($params['city_id']){
            $where['ca.city_id'] = $params['city_id'];
        }
        if($params['area_id']){
            $where['ca.area_id'] = $params['area_id'];
        }
        if($params['town_id']){
            $where['ca.town_id'] = $params['town_id'];
        }
        if($params['village_id']){
            $where['ca.village_id'] = $params['village_id'];
        }

        $allList = M('Profits')
            ->alias('p')
            ->field('p.id')
            ->join('left join __COMPANY_AUTH__ as ca on p.company_id = ca.id')
            ->where($where)
            ->order('p.create_time desc')
            ->group('p.company_id,DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\')')
            ->select();
        if ($page = $params['page']) {
            M('Profits')->page($page, $page_list);
        }
        $field = self::$group_fields;
        $field .= ', DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\') as meak_time';
        $field .= ',p.company_id,ca.company_name,ca.company_address';
        $list = M('Profits')
            ->alias('p')
            ->field($field)
            ->join('left join __COMPANY_AUTH__ as ca on p.company_id = ca.id')
            ->where($where)
            ->order('p.create_time desc')
            ->group('p.company_id,DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\')')
            ->select();
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($allList),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    public static function getOrderDetail_all($params = [])
    {
        $order_test_id = self::getOrdrTest();
        $where = [];
        if ($params['company_id']) {
            $where['o.company_id'] = $params['company_id'];
        }
        if ($params['company_child_ids']){
            $where['o.company_id'] = ['in',$params['company_child_ids']];
        }
        if ($params['type'] == '1') {
            $where['o.is_batch'] = ['neq',0];
        }elseif($params['type'] == '2'){
            $where['o.is_batch'] = ['eq',0];
        }else{
        }
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        $page_list = 10;    //每页10条数据
        if ($params['order_sn']) {
            $where['o.order_sn'] = ['like', '%' . $params['order_sn'] . '%'];
        }
        if ($params['reciver_name']) {
            $where['o.reciver_name'] = ['like', '%' . $params['reciver_name'] . '%'];
        }
        if ($params['reciver_mobile']) {
            $where['o.reciver_mobile'] = ['like', '%' . $params['reciver_mobile'] . '%'];
        }
        if ($params['store_id'] && $params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_id']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['o.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['buyer_phone']) {
            $where['o.buyer_phone'] = ['like', '%' . $params['buyer_phone'] . '%'];
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['o.add_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
//        if ($params['create_time_start']) {
//            if (strtotime($params['create_time_start']) < strtotime(self::$start_time)) {
//                $params['create_time_start'] = self::$start_time;
//            }
//        } else {
//            $params['create_time_start'] = self::$start_time;
//        }

//        if ($params['create_time_start'] && $params['create_time_end']) {
//            $create_time_start = $params['create_time_start'];
//            $create_time_end = $params['create_time_end'];
//            $where['p.create_time'] = array('between', [strtotime("$create_time_start"), strtotime("$create_time_end 23:59:59")]);
//        } elseif ($params['create_time_start']) {
//            $where['p.create_time'] = array('egt', strtotime($params['create_time_start']));
//        } elseif ($params['create_time_end']) {
//            $end_time = $params['create_time_end'];
//            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
//        }
        if ($params['order_state'] != '' && $params['order_state'] != 'All'){
            $where['o.order_state'] = array('EQ', $params['order_state']);
        }
        if ($params['payment_code'] != '' && $params['payment_code'] != 'All'){
            $where['o.payment_code'] = $params['payment_code'];
        }
        if ($params['areaid_5']){
            $where['c.village_id'] = $params['areaid_5'];
        }elseif ($params['areaid_4']){
            $where['c.town_id'] = $params['areaid_4'];
        }elseif ($params['areaid_3']){
            $where['c.area_id'] = $params['areaid_3'];
        }elseif ($params['areaid_2']){
            $where['c.city_id'] = $params['areaid_2'];
        }elseif ($params['areaid_1']){
            $where['c.province_id'] = $params['areaid_1'];
        }
        $alllist = M('Order')
            ->alias('o')
            ->field(self::$field)
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __COMPANY_AUTH__ AS c ON o.company_id=c.id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        if (isset($params['page'])){
            if ($page = $params['page']) {
                M('Order')->page($page, $page_list);
            }
        }
        $list = M('Order')
            ->alias('o')
            ->field(self::$field)
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __COMPANY_AUTH__ AS c ON o.company_id=c.id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        foreach ($list as $k => $v) {
            $list[$k]['add_time'] = date('Y-m-d H:i:s', $v['add_time']);
            $list[$k]['payment_time'] = date('Y-m-d H:i:s', $v['payment_time']);
            $order_goods = M('OrderGoods')->field(self::$order_goods_field)->where(['order_id' => $v['order_id']])->select();
            foreach ($order_goods as $key => $val) {
                $order_goods[$key]['goods_img'] = C('WEBSITE_URL') . '/' . $val['goods_img'];
            }
            $list[$k]['order_goods'] = $order_goods;
//            $company_store_profits = M('CompanyStoreProfits')
//                ->field('store_name,is_center,percent_value')
//                ->where(['profits_id' => $v['profits_id']])
//                ->select();
//            $list[$k]['company_store_profits'] = $company_store_profits;
            //获取企业信息
            $list[$k]['company'] = M('CompanyAuth')
                ->field('id,company_name,province_id,city_id,area_id,town_id,village_id,company_address')
                ->where(['id' => $v['company_id']])
                ->find();
//            if($v['is_batch'] == 0 || $params['is_batch'] == 0){
//                $list[$k]['order_goods'] = [];
//            }
        }
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($alllist),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    // 利润分成订单详情
    public static function getProfitsOrderDetail($params = [])
    {
        $order_test_id = self::getOrdrTest();
        $where = [];
        if ($params['company_id']) {
            $where['p.company_id'] = $params['company_id'];
        }
        if ($params['is_batch'] != '') {
            $where['p.is_batch'] = $params['is_batch'];
        }
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        $page_list = 10;    //每页10条数据
        if ($params['order_sn']) {
            $where['o.order_sn'] = ['like', '%' . $params['order_sn'] . '%'];
        }
        if ($params['reciver_name']) {
            $where['o.reciver_name'] = ['like', '%' . $params['reciver_name'] . '%'];
        }
        if ($params['reciver_mobile']) {
            $where['o.reciver_mobile'] = ['like', '%' . $params['reciver_mobile'] . '%'];
        }

        if ($params['store_id'] && $params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_id']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['o.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['buyer_phone']) {
            $where['o.buyer_phone'] = ['like', '%' . $params['buyer_phone'] . '%'];
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['o.add_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        if ($params['create_time_start']) {
            if (strtotime($params['create_time_start']) < strtotime(self::$start_time)) {
                $params['create_time_start'] = self::$start_time;
            }
        } else {
            $params['create_time_start'] = self::$start_time;
        }

        if ($params['create_time_start'] && $params['create_time_end']) {
            $create_time_start = $params['create_time_start'];
            $create_time_end = $params['create_time_end'];
            $where['p.create_time'] = array('between', [strtotime("$create_time_start"), strtotime("$create_time_end 23:59:59")]);
        } elseif ($params['create_time_start']) {
            $where['p.create_time'] = array('egt', strtotime($params['create_time_start']));
        } elseif ($params['create_time_end']) {
            $end_time = $params['create_time_end'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }

        $alllist = M('Profits')
            ->alias('p')
            ->field(self::$field)
            ->join('left join __ORDER__ o on o.order_id=p.order_id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        if ($page = $params['page']) {
            M('Profits')->page($page, $page_list);
        }
        $list = M('Profits')
            ->alias('p')
            ->field(self::$field)
            ->join('left join __ORDER__ o on o.order_id=p.order_id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        foreach ($list as $k => $v) {
            $list[$k]['add_time'] = date('Y-m-d H:i:s', $v['add_time']);
            $list[$k]['payment_time'] = date('Y-m-d H:i:s', $v['payment_time']);
            $order_goods = M('OrderGoods')->field(self::$order_goods_field)->where(['order_id' => $v['order_id']])->select();
            foreach ($order_goods as $key => $val) {
                $order_goods[$key]['goods_img'] = C('WEBSITE_URL') . '/' . $val['goods_img'];
            }
            $list[$k]['order_goods'] = $order_goods;
            if($v['is_batch'] == 0){
                $list[$k]['order_goods'] = [];  //个人的订单隐藏商品信息
            }
            $company_store_profits = M('CompanyStoreProfits')
                ->field('store_name,is_center,percent_value')
                ->where(['profits_id' => $v['profits_id']])
                ->select();
            $list[$k]['company_store_profits'] = $company_store_profits;
        }
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($alllist),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

}