<?php

namespace Common\Service;
class Date
{
    //返回日期数组
    /**
     * @param $startDate-开始的时间戳
     * @return array
     */
    public static function getEnterpriseDate($startDate)
    {
        $dateLength = M('Config')->where(['name' => 'company_make_time'])->getField('value');
        $dateLength = empty($dateLength) ? 30 : $dateLength;
//        $startDate = time();
        $currentZhou = date('W', time());   //当前周
        $currentYear = date('Y', time());   //当前年份
        $currentMonth = date('n', time());  //当前月份
        $weekZh = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
        $list = [
            'current_zhou' => ['本周'],
            'next_zhou' => ['下周'],
            'current_month' => [$currentMonth . '月'],
            'next_month' => [$currentMonth + 1 . '月']
        ];
        for ($i = 0; $i < $dateLength; $i++) {
            $nt = $startDate + $i * 24 * 60 * 60;
            if ($currentZhou == date('W', $nt)) {
                $list['current_zhou'][] = date('Y-m-d', $nt);
                continue;
            }
            if ($currentZhou + 1 == date('W', $nt)) {
                $list['next_zhou'][] = date('Y-m-d', $nt);
                continue;
            }
            if ($currentYear == date('Y', $nt) && $currentMonth == date('n', $nt)) {
                $list['current_month'][] = date('Y-m-d', $nt);
            }
            if ($currentYear == date('Y', $nt) && $currentMonth + 1 == date('n', $nt)) {
                $list['next_month'][] = date('Y-m-d', $nt);
            }
        }
        return $list;
    }
}