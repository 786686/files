<?php
/**
 * 花名册服务类
 * User: yangjiyang
 * Date: 2018/8/20
 * Time: 15:38
 */

namespace Common\Service;


class PerformanceService
{
    /**
     * 导出扶贫业绩
     * @param $list
     */
    public static function exportPerformanceByList($list)
    {
        $row = [];
        foreach ($list as $key=>$value){
            $row[$key]['sn'] = $value['sn'];
            $row[$key]['id'] = $value['id'];
            $row[$key]['user_name'] = $value['user_name'];
            $row[$key]['department_name'] = $value['department_name'];
            $row[$key]['position_name'] = $value['position_name'];
            $row[$key]['mobile'] = $value['mobile'];
            $row[$key]['order_num'] = $value['order_num'];
            $row[$key]['order_amount'] = $value['order_amount'];
        }
        header('Content-Type:text/html;charset=utf-8');
        $fileName = '扶贫业绩列表-'.date('Y-m-d H:i:s',time());
        $title = array('序号', '员工id','员工姓名', '所属部门', '职位', '手机号码','扶贫订单数','扶贫业绩');
        array_unshift($row,$title);
        \Org\Util\Csv::makeCsv($fileName,$row);
    }

    /**
     * 导出下级单位列表
     * @param $list
     */
    public static function exprotChildCompanyListByList($list)
    {
        $row = [];
        foreach ($list as $key=>$value){
            $row[$key]['sn'] = $value['sn'];
            $row[$key]['id'] = $value['id'];
            $row[$key]['company_name'] = $value['company_name'];
            $row[$key]['area'] = $value['area'];
            $row[$key]['order_amount'] = $value['order_amount'];
            $row[$key]['order_profits'] = $value['order_profits'];
            $row[$key]['order_num'] = $value['order_num'];
        }
        header('Content-Type:text/html;charset=utf-8');
        $fileName = '下级单位列表-'.date('Y-m-d H:i:s',time());
        $title = array('序号', '单位id','单位名称', '所属地区', '扶贫总金额', '扶贫总利润', '成交订单总数');
        array_unshift($row,$title);
        \Org\Util\Csv::makeCsv($fileName,$row);
    }

}