<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/3/24
 * Time: 10:04
 */

namespace Common\Service;

use Common\Model\TokenModel;

/**
 * Mobile模块的token操作
 *
 * @author fanzhaogui 2020-03-24
 * @package Common\Service
 */
class MobileTokenService
{
    public static function getToken($memberId, $token = '', $type = 0)
    {
        $data = (new TokenModel())->getTokenSer($memberId,$token,$type);
        return $data ?? [];
    }

    /**
     * 用户的token检测
     * checkMemberToken
     * @author: fanzhaogui
     * @param int $memberId
     * @param string $token
     * @return array|mixed
     */
    public static function checkMemberToken($memberId, $token = '')
    {
        $data = (new TokenModel())->getTokenSer($memberId,$token);
        return $data ?? [];
    }
}