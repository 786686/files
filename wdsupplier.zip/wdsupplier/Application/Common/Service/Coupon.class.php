<?php

namespace Common\Service;
class Coupon
{
    public $total = 20225;    //红包金额上限

    //现在一个用户只能领一张优惠券，这里是特定镇安超市
    public function getCouponQual($parm = array())
    {
        if (empty($parm['member_id'])) {
            return 0;
        }
        $member_id = $parm['member_id'];
        $store_id = $parm['store_id'];
        if ($store_id != 329) return 0;//目前可抽奖超市
        if (!$this->checkTime(time()) || !$this->checkMemberAuth($member_id) || !$this->checkRegisterTime($member_id) || !$this->checkAttention($member_id)) {
            return 0;
        }
        //判断已发金额
        if ($this->getTotalMoney() >= $this->total) {
            return 0;
        }
        $addwhere['member_id'] = $member_id;
        $addwhere['store_id'] = $store_id;
        $getcount = M('coupon_get_log')->where($addwhere)->order('create_time desc')->find();
        if ($getcount && $this->checkTime($getcount['create_time'])) return 0;
        return 1;
    }

    public function checkTime($time)
    {
        $start_time = "2017-11-23 00:00:00";
        $end_time = "2017-11-24 23:59:59";
        if ($time < strtotime($start_time) || $time > strtotime($end_time)) {
            return false;    //不能抽奖
        }
        return true;
    }

    //获取已发放金额
    public function getTotalMoney()
    {
        $where['activity_type'] = 6;
        return M('Coupon')->where($where)->sum('reduce_price');
    }

    //判断是否认证了工业和信息化部第五研究所
    public function checkMemberAuth($member_id)
    {
        $where['member_id'] = $member_id;
        $where['company_id'] = 190;
        $where['status'] = 1;
        $list = M('MemberAuth')->where($where)->find();
        if ($list) {
            return true;
        }
        return false;
    }

    public function checkRegisterTime($member_id)
    {
        $list = M('Member')->where(['member_id' => $member_id])->find();
        if (empty($list)) {
            return false;
        }
        return $this->checkTime($list['member_time']);
    }
    //查看是否关注镇安超市
    public function checkAttention($member_id)
    {
        return D('Member')->checkMemberByStoreID($member_id);
    }

    /**
     *获取奖券
     */
    public function gainCoupon($data = array())
    {
        $tmp_rand = rand(0, 100);
        if ($tmp_rand < 80) {
            $tmp_price = rand(168, 268) * 0.01;
        } elseif ($tmp_rand < 95) {
            $tmp_price = rand(368, 468) * 0.01;
        } else {
            $tmp_price = rand(568, 668) * 0.01;
        }
        //判断红包剩余金额
        $total_money = $this->getTotalMoney();    //已领取红包总额
        $total_j = $this->total;    //红包上限金额
        $s_total = $total_j - $total_money;
        if ($s_total >= 4 && $s_total < 7) {
            $tmp_price = $s_total / 2;
        } elseif ($s_total < 4) {
            $tmp_price = $s_total;
        }
        $tmp_price = sprintf("%.1f", $tmp_price);
        $coupon = $this->addConpon(['member_id' => $data['member_id'], 'store_id' => $data['store_id'], 'reduce_price' => $tmp_price]);
        $this->addCouponLog(['coupon_id' => $coupon['coupon_id'], 'member_id' => $data['member_id'], 'store_id' => $data['store_id']]);
        return $coupon;
    }

    //插入优惠券记录表
    private function addConpon($params = [])
    {
        $addData['member_id'] = $params['member_id'];
        $addData['title'] = '工贸活动' . $params['reduce_price'] . '元优惠券';
        $addData['reduce_price'] = $params['reduce_price'];
        $addData['valid_price'] = '0';
        $addData['valid_store_id'] = $params['store_id'];
        $addData['source_member_id'] = '0';
        $addData['start_time'] = time();
        $addData['end_time'] = strtotime('2017-11-24 23:59:59');
        $addData['type'] = '1';
        $addData['activity_type'] = 6;
        $coupon_id = M('Coupon')->add($addData);
        $addData['coupon_id'] = $coupon_id;
        return $addData;
    }

    //插入日志
    private function addCouponLog($params = [])
    {
        $logData['coupon_id'] = $params['coupon_id'];
        $logData['member_id'] = $params['member_id'];
        $logData['source'] = 1;
        $logData['create_time'] = time();
        $logData['store_id'] = $params['store_id'];
        M('coupon_get_log')->add($logData);
    }
}