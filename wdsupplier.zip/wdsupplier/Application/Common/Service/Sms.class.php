<?php

namespace Common\Service;
class Sms
{
    /*短信发送*/

    // 不接收短信的手机号码
    private static $noSendPhone = [
        '15218361587', '15296291418', '13558480605', '13647876630', '18377125699', '18376966209',
        '18174116519', '13737928751', '18276100551', '15078763009', '18977152342', '13457803672',
        '15977107983', '13471143963', '15296428089', '18811822666', '13828692008', '13592964311',
        '13929777888', '13828687506', '13926710003', '13702869080', '13318510333', '13809764068',
        '13926701988', '18316600333', '13929773200', '15915272038', '13702862413', '18806699726',
        '13927531391', '13702868723', '15815299003', '13692507577', '13927559263', '13542339419',
        '13902541028', '13702862617', '18000000008', '18929715687', '13727840591', '13553653055',
        '13169170533', '13686766392', '13727723068', '13580065777', '13929778502', '13809762384',
        '13828674588', '13542342039', '17322937815', '13542355169', '13428164375', '18122570917',
        '15875881978', '13922033252', '18000000007', '15119696312', '13592992559', '13929726669',
        '18000000006', '13926705278', '15360781379', '18000000005', '15218376301', '13543368229',
        '18000000004', '13702868732', '13500076258', '15915262392', '13727837626', '13902510290',
        '13553692008', '13929711190', '13686736899', '13686735908', '13509926812', '13500077069',
        '13809762313', '13709648129', '13926705033', '15119620109', '13922030778', '13580022063',
        '13336553819', '13686757628', '13902541639', '18819864444', '13592985719', '13432387468',
        '13592997799', '13927551998', '13809782298', '13926715753', '13336532418', '13902540763',
        '15016608796', '13727779029', '18000000003', '13727784168', '18000000002', '18318299888',
        '13535921866', '13929725199', '13926705728', '13828698278', '13809765775', '13727822018',
        '13727832977', '13432370368', '13686779265', '15917119688', '18000000001', '13509925793',
        '18000000000', '13432367542', '13432381424', '13432992353', '13809762369', '13542335006',
        '13929718666', '13005684178', '13500075512', '13543370518', '13926727111', '13432372950',
        '13809762608', '13927531685', '13922030650', '13686750692', '13592985730', '13428189269',
        '15019362881', '13509921278', '13828695538', '13922056732', '13702862498', '13542356583',
        '13450107588', '13929704588', '13709628783', '18718820268', '13543381375', '13423596698',
        '18929705922', '18929712967', '13450112439', '15219918219', '13926711844', '13542336085',
        '15706689596', '13592990109', '13927558622', '18929722913', '13553661262', '13902542897',
        '13580010168', '13428181395', '13724853596', '17620918199', '13800000003', '13728219668',
        '13800000002', '13828637758', '13800000001', '13800000000', '13809788840', '13828637863',
        '13580068766', '15555555551', '13929771816', '13828676906', '13686785123', '13336562686',
        '13800001125', '13800001124', '13702898418', '13560118123', '13828638013', '15014379769',
        '13542326363', '13535919135', '13336552110', '13727776897', '13542323813', '13592956267',
        '13929770886', '13800001123', '15813022033', '13543398306', '13702895492', '13927566822',
        '13432330777', '13727707611', '15016666803', '18814322108', '13929797929', '13686757266',
        '15875891928', '13800001122', '13686761669', '13800001121', '13828633208', '13902517248',
        '18718533338', '13535917081', '13727821354', '13535914039', '15089621588', '17817995633',
        '13922374488', '13702899312', '13922050502', '13828632132', '13809786831', '13929797222',
        '13535915663', '13535917882', '18813371437', '13727709388', '18929780386', '13068501999',
        '15992930788', '13802794602', '13929776458', '13302511885', '18938483588', '13809788815',
        '13543395821', '13542397705', '13413301168', '13828643351', '13927571223', '13432322789',
        '13828630148', '13929790119', '13580052166', '13929786766', '13927562201', '13580055633',
        '18819872255', '13543366578', '13535913232', '13828639939', '18899893363', '13005667611',
        '13929779938', '13543396769', '15820197782', '13702861083', '13360733528', '13111111112',
        '15030121852', '13226633141', '15813363750', '13828423360', '15555555553', '13727774868',
        '15011720128', '15820264036', '13410197327', '13800001243', '13800001242', '13800001241',
        '13800001240', '13800001239', '13800001238', '13800001237', '13800001236', '13800001235',
        '15899969333', '13702316572', '13075606771', '13809786114', '13809788849', '13600390880',
        '15976543412', '13828648383', '13709623388', '13543397565', '13727707636', '13692523622',
        '13702897070', '13902548196', '13727769981', '13828632828', '13927546000', '13580060988',
        '13692688775', '13509911086', '13927571033', '13535917008', '13543386048', '13580051919',
        '18306687071', '13542380183', '13580060133', '13413319866', '13828638088', '18929729929',
        '13929798822', '13809786498', '13380800008', '13809764063', '13702866613', '13926705188',
        '13600392968', '13686786498', '13423518291', '13727770050', '13702899935', '15706683646',
        '13500074900', '13709623673', '13927563892', '13592962080', '13553682222', '13828636343',
        '13326564688', '13376683799', '13413353295', '13727700669', '13702898756', '13922037388',
        '18318681122', '13929786366', '13828635555', '13500074771', '13336552363', '13543397348',
        '13828630181', '13542391309', '13902548737', '13828645538', '13580065555', '13929716262',
        '13413352822', '13809787999', '13686763293', '13702897608', '13828698989', '13929799633',
        '13580062183', '13727796180', '13809787893', '13592959699', '13828643663', '13692551520',
        '13534866466', '13929702532', '13927547068', '13580026606', '17620011680', '13246898796',
        '13670975099', '18676512868', '18574770129', '13533258557', '18718537876', '15813455733',
        '13692691352', '13113717275', '13423523786', '18814277511', '18148992136', '13927207787',
        '13692606082', '18575736676', '15302343303', '15876124568', '13631457286', '13678983818',
        '15017770022', '15875893314', '18306655511', '13686796522', '13667222639', '13432985613',
        '13432326641', '18802519020', '13660203889', '13422254605', '13533308795', '13432018881',
        '13076874898', '13423500892', '13826059078', '13423542125', '18802511526', '13690317907',
        '13544460093', '13527797483', '18819447783', '13724882767', '18312825255', '13650734657',
        '13702551141', '13688891617', '13229667675', '13719324236', '18007574943', '13424018430',
        '15521182507', '13632455883', '13632499931', '15220019366', '13265064835', '15778417811',
        '13710279197', '13169168985', '13422222183', '18566402922', '13229926215', '13431650500',
        '18813756191', '15919686951', '18127981835', '13929715069', '13660133300', '13066374991',
        '13380014613', '18902292003', '15766359002', '18319239259', '13711541239', '13692552731',
        '13077450968', '18659193926', '13760715807', '13556160838', '18576518942', '15917467495',
        '18588507917', '18664706007', '15999979411', '18807649201', '13533754152'
    ];

    //发送短信记录
    public static function addLog($vl_name, $vl_content)
    {
        $data['vl_name'] = $vl_name;
        $data['vl_content'] = $vl_content;
        $data['vl_num'] = 1;
        $data['vl_num_total'] = 1;
        $data['send_time'] = time();
        $data['admin_id'] = 0;
        $data['vl_type'] = 0;
        M('VcodeLog')->add($data);
    }

    /** 邀请用户注册账户
     * @param $phone -目标手机号码
     * @return bool true表示发送成功；false表示发送失败
     * 短信模板内容：【创课网店】尊敬的客户，邀您成为创课网店会员，
     * 消费可享受全额积分奖励哦~详情搜索“创课网店”公众号或APP下载，马上来体验吧-回复T退订
     */
    public static function inviteRegister($phone)
    {
        $sms_sdk_template_id = 'SMS_114265020';
        $sms_free_sign_name = '创课网店';
        $vl_name = "注册推荐";
        $vl_content = "【创课网店】尊敬的客户，邀您成为创课网店会员，" .
            "消费可享受全额积分奖励哦~详情搜索“创课网店”公众号或APP下载，马上来体验吧-回复T退订";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name);
    }

    /** 注册成功后发送
     * @param $phone -目标手机号码
     * @return bool true表示发送成功；false表示发送失败
     * 短信模板内容：【创课网店】亲，欢迎成为创课网店会员，目前充值都有1元=100积分奖励哦，每天签到还可获得10积分；
     * 欢迎选购，更多优惠在等着您~-回复T退订
     */
    public static function registerSuccess($phone)
    {
        $sms_sdk_template_id = 'SMS_114150014';
        $sms_free_sign_name = '创课网店';
        $vl_name = "注册成功提示";
        $vl_content = "【创课网店】亲，欢迎成为创课网店会员，目前充值都有1元=100积分奖励哦，每天签到还可获得10积分；" .
            "欢迎选购，更多优惠在等着您~-回复T退订";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name);
    }

    /** 拉新活动发送
     * @param $phone -目标手机号码
     * @return bool true表示发送成功；false表示发送失败
     * 短信模板内容：【创课网店】亲，欢迎成为创课网店会员，分享您的推广码邀请好友成功注册，
     * 完成的每一笔订单您都可以获得消费积分奖励哦~赶快分享尽情坐享收益吧~-回复T退订
     */
    public static function raxin($phone)
    {
        $sms_sdk_template_id = 'SMS_114185022';
        $sms_free_sign_name = '创课网店';
        $vl_name = "注册跟进";
        $vl_content = "【创课网店】亲，欢迎成为创课网店会员，分享您的推广码邀请好友成功注册，" .
            "完成的每一笔订单您都可以获得消费积分奖励哦~赶快分享尽情坐享收益吧~-回复T退订";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name);
    }

    /** 活动充值
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"money1\":\"{$money1}\",\"money2\":\"{$money2}\",\"point1\":\"{$point1}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲，您已成功充值200元，为感谢您对扶贫事业的支持，
     * 创课网店送您200元助力扶贫金再赠 20000积分，马上打开查看吧~
     */
    public static function activityRecharge($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_114095022';
        $sms_sdk_template_id = 'SMS_155856816';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "充值活动成功提醒";
        $vl_content = "【创课网店】亲，您已成功充值" . $param_arr['money1'] .
            "元，为感谢您对创课网店的支持，创课网店送您" . $param_arr['money2'] . "元助力金再赠" . $param_arr['point1'] . "积分，马上打开查看吧~";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 普通充值
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"money\":\"{$money}\",\"point\":\"{$point}\",\"lilv\":\"{$lilv}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 亲，您已成功充值${money}元，为感谢您的支持，创课网店送您${point}积分，
     * 积分每天以${lilv}%左右分享到积分券账户，积分券可转为现金使用哦~
     */
    public static function commonRecharge($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_116535004';
        $sms_sdk_template_id = 'SMS_155861825';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "普通充值成功提醒";
        $vl_content = "【创课网店】亲，您已成功充值" . $param_arr['money'] . "元，为感谢您的支持，创课网店送您" . $param_arr['point'] .
            "积分，积分每天以" . $param_arr['lilv'] . "%左右分享到积分券账户，积分券可转为现金使用哦~";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 注册满一个月未充值过的会员
     * @param $phone -目标手机号码
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱滴，凡在创课网店充值享1元=100的积分奖励，多充多送，马上充值消费吧~~~-回复T退订
     */
    public static function noRecharge($phone)
    {
        $sms_sdk_template_id = 'SMS_114120019';
        $sms_free_sign_name = '创课网店';
        $vl_name = "充值提醒";
        $vl_content = "【创课网店】亲爱滴，凡在创课网店充值享1元=100的积分赠送，多充多送，马上充值消费吧~~~-回复T退订";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name);
    }

    /** 引导会员拍下订单提醒
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"member_name\":\"{$member_name}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的张三，好久不见，我们特地给你准备了新品，先到有折扣哦！~
     */
    public static function guideConsump($phone, $sms_param)
    {
        $sms_sdk_template_id = 'SMS_112625004';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "引导会员拍下订单提醒";
        $vl_content = "【创课网店】亲爱的" . $param_arr['member_name'] . "，好久不见，我们特地给你准备了新品，先到有折扣哦！~（链接商品详情页）";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 合伙人消费积分奖励
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"username\":\"{$username}\",\"username2\":\"{$username2}\",\"username3\":\"{$username3}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#账户名#，您的合伙人“（昵称）”在创课网店成功完成一笔订单，恭喜您获得**的合伙人积分奖励~
     */
    public static function partnerConsump($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_116450114';
        $sms_sdk_template_id = 'SMS_157281002';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "合伙人消费积分奖励";
        $vl_content = "【创课网店】亲爱的" . $param_arr['username'] . "，您的合伙人“（" . $param_arr['username2'] .
            "）”在创课网店成功完成一笔订单，恭喜您获得" . $param_arr['username3'] . "的合伙人积分奖励~";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 会员拍下订单未支付、催款提醒(当会员拍下订单刚好达到10分钟时)
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"username\":\"{$username}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】#收货人#主人，偶是您在创课网店领养的宝贝哦！您在待支付，还有20分钟就支付超时了~在等着您带回家~
     */
    public static function orderNoPay($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_114155021';
        $sms_sdk_template_id = 'SMS_155856828';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "会员拍下订单未支付提醒";
        $vl_content = "【创课网店】" . $param_arr['username'] . "主人，偶是您在创课网店领养的宝贝哦！您在待支付，还有20分钟就支付超时了~在等着您带回家~";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 后端指定团长订单未支付、催款提醒(当会员拍下订单刚好达到10分钟时)
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"username\":\"{$username}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】#收货人#主人，偶是您在创课网店领养的宝贝哦！您的团购订单及时支付后可成功开团哦，如48小时未支付将超时。~
     */
    public static function groupOrderNoPay($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_123900003';
        $sms_sdk_template_id = 'SMS_157275996';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "团购支付提醒";
        $vl_content = "【创课网店】" . $param_arr['username'] . "主人，偶是您在创课网店领养的宝贝哦！您的团购订单及时支付后可成功开团哦，如48小时未支付将超时。";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 会员拍下订单付款关怀
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"username\":\"{$username}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将为您播报订单状态，方便您随时了解。如有问题可以联系客服哦~
     */
    public static function orderPaySuccess($phone, $sms_param)
    {
        $array = self::$noSendPhone;
        if (in_array($phone, $array)) {
            return true;
        }
//        $sms_sdk_template_id = 'SMS_112650003';
        $sms_sdk_template_id = 'SMS_155856799';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "会员拍下订单付款关怀";
        $vl_content = "【创课网店】亲爱的" . $param_arr['username'] . "，感谢购买我们的商品！我们将为您播报订单状态，方便您随时了解。如有问题可以联系客服哦~";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 订单发货时
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"username\":\"{$username}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦
     */
    public static function orderShipping($phone, $sms_param)
    {
        $array = self::$noSendPhone;
        if (in_array($phone, $array)) {
            return true;
        }
//        $sms_sdk_template_id = 'SMS_112630006';
        $sms_sdk_template_id = 'SMS_13220006';
        $sms_free_sign_name = '万讯创课';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "顾客订单发货提醒";
        $vl_content = "【创课网店】亲爱的" . $param_arr['username'] . "，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send_old($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 商品信息提醒(商家信息发送)
     * @param $phone -目标手机号码
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦
     */
    public static function shopMsg($phone)
    {
//        $sms_sdk_template_id = 'SMS_112535004';
        $sms_sdk_template_id = 'SMS_155861856';
        $sms_free_sign_name = '创课网店';
        $vl_name = "商品信息提醒";
        $vl_content = "【创课网店】亲爱的合伙人，如商品信息有变动更新（包括库存、商品价格、新产品上架等），记得及时与我们联系哦，请致电4009300277";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name);
    }

    /** 账户认证审核通过时，旧的，已废弃
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"name\":\"{$name}\",\"password\":\"{$password}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦
     */
    public static function companyCertificationPassOld($phone, $sms_param)
    {
        $sms_sdk_template_id = 'SMS_133525039';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "政企审核-账户认证审核通过时";
        $vl_content = "欢迎成为创课网店单位会员，您提交的资料已审核通过；账号：" . $param_arr['name'] .
            ",登录密码：" . $param_arr['password'] . ",欢迎登录创课网店选购";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 账户认证审核通过时
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"name\":\"{$name}\",\"password\":\"{$password}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦
     */
    public static function companyCertificationPass($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_134440026';
        $sms_sdk_template_id = 'SMS_157280998';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "政企审核-账户认证审核通过时";
        $vl_content = "欢迎成为创课网店政企会员，您提交的资料已审核通过；账号：" . $param_arr['name'] .
            ",登录密码：" . $param_arr['password'] . ",欢迎登录创课网店采购。";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 账户认证审核不通过时
     * @param $phone -目标手机号码
     * @param $sms_param -短信模板变量（json）格式如：
     * "{\"message\":\"{$message}\"}"
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦
     */
    public static function companyCertificationNoPass($phone, $sms_param)
    {
//        $sms_sdk_template_id = 'SMS_133300049';
        $sms_sdk_template_id = 'SMS_157275995';
        $sms_free_sign_name = '创课网店';
        $param_arr = json_decode($sms_param, true);
        $vl_name = "政企审核-账户认证审核不通过时";
        $vl_content = "感谢您对创课网店的支持，您提交的资料因" . $param_arr['message'] . "原因,审核不通过，请核实后重新提交";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name, $sms_param);
    }

    /** 商品信息提醒(商家信息发送)
     * @param $phone -目标手机号码
     * @return bool true表示发送成功；false表示发送失败
     * 【创课网店】亲爱的#收货人#，感谢购买我们的商品！我们将随时播报状态，方便您随时了解。如有问题可以联系客服哦
     */
    public static function companyRegister($phone)
    {
//        $sms_sdk_template_id = 'SMS_133385042';
        $sms_sdk_template_id = 'SMS_157281001';
        $sms_free_sign_name = '创课网店';
        $vl_name = "政企审核-企业认证资料成功提交时";
        $vl_content = "【创课网店】感谢您对创课网店的支持，您的单位信息已成功提交，审核结果敬请留意短信通知";
        self::addLog($vl_name, $vl_content);
        return alidayu_sms_num_send($phone, $sms_sdk_template_id, $sms_free_sign_name);
    }
}