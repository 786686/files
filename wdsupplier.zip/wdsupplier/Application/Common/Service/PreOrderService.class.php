<?php
namespace Common\Service;
use Common\Lib\Redis\Redis;

/**
 * @author 宋建强 2020年2月29日 17:08:24 
 * @desc   运费计算
 */
class PreOrderService
{
    const GOOD_STRAGE_CAHCEH = 18000;//库存缓存时间5小时

    const OPTION_CACHE = 600; //10min
   
    const OPTION_KEY   = 'PC_OPTION_KEY_ORDER';
    /**
     * @method  获取订单配置 预购时间抢购时间
     * @author  建强   2020年3月9日 11:29:07
     * 
     * @return  array  
     */
    public  function getPreOrder(){
        
        $key_time= self::OPTION_KEY;
        $res  = Redis::getInstance()->get($key_time);
        if($res){
           return json_decode($res,true);
        }
        
        
        $where = ['option_name' => ['IN',['preorder_time','preorder_buy_time']]];
        $arr   = M('option') ->where($where)->select();
        
        $data = [];
        foreach ($arr as $val){
            $time = explode('-', $val['option_value']);
            $data[$val['option_name'].'_s_time'] = date('Y-m-d H:i:s',$time[0]);
            $data[$val['option_name'].'_e_time'] = date('Y-m-d H:i:s',$time[1]);
           
            $data[$val['option_name'].'_word'] = $val['option_desc'];
            $data[$val['option_name'].'_tt'] = $time;
            
            
            $data[$val['option_name'].'_status'] = 0;
            if($time[1]<NOW_TIME){
                //不能预约状态 不能购买都是 1 
                $data[$val['option_name'].'_status'] = 1;
            }
        }

        Redis::getInstance()->set($key_time,json_encode($data),self::OPTION_CACHE);
        return $data;
    }
    
    /**
     * @method 获取邀请人数资格 
     */   
    public function getQualification(){
        $member_id  =I('member_id',0,'intval');
       
        if(empty($member_id)){
            return [
                'full_user'   =>5,
                'invite_user' =>0,
                'unUse_num'   =>0,
                'need_user'   =>5,
                'unUser_qui'  =>0,
            ];
            
        }
        
        $where = ['member_id'=>$member_id];
        $res   = M('share_code')->where($where)->find();
       
        if(empty($res)){
            return [
                'full_user'   =>5,
                'invite_user' =>0,
                'unUse_num'   =>0,
                'need_user'   =>5,
                'unUser_qui'  =>0,
            ];
        }
        
        // 剩余资格次数  = 总次数 - 使用过的资格数*5的倍数
        $unUse   = $res['num']-$res['buy_num'];
        
        $thisQui = $unUse%5;
        return [
            'full_user'   => 5,
            'invite_user' => $thisQui,   //邀请几人
            'need_user'   => 5-$thisQui, //还需要几人
            'unUse_num'   => $unUse,     //未使用次数
            'unUser_qui'  =>floor($unUse/5),//未使用资格
        ];
    }
    
    
    /**
     * @method 是否已经预约 
     */
    public function getAppiontStatus(){
       
        //未登录状态下也可以显示 
        $data =[
            'pre_order_status'=>0
        ];
        
        $member_id = I('member_id',0,'intval');
        
        if(empty($member_id)){
            return $data;
        }
        
        $where = [
            'member_id' => $member_id,
            'log_time' =>['EGT',NOW_TIME-(5*24*3600)]  //是否在五天内
        ];
        $res       = M('appoint_time')->where($where)->find();
        if(empty($res)){
            return $data;
        }
        
        // 资格已经被购买   需要重新 预约
        if($res['status']!=1){
            return $data;
        }
        
        //已经预约  资格有效并且是五天内    
        return  ['pre_order_status'=>1];
    }
    
    
    /**
     * @method 判断库存是否足够
     * @author 建强 2020年3月9日 16:28:33
     *
     * @return array
     */
    public function checkGoodstorage(){
        
        $goods_id  = I('goods_id',0,'intval') ;
        $key  = PltOrderService::MSAK_GOOD.I('goods_id',0,'intval');
        
        $res  = Redis::getInstance()->get($key);
        
        if($res>0) return true;
        
        $where = ['goods_id'=>$goods_id];
        $res   = M('goods')->where($where)->field('goods_storage')->find();
        if(empty($res) || $res['goods_storage']<=0 ) return false;
        
        Redis::getInstance()->set($key,$res['goods_storage'],self::GOOD_STRAGE_CAHCEH);
        return true;
    }
    
    /**
    * @method 获取店铺名称
    * @return string
    */
   public static function getStoreName(){
   	   $store_id = I('store_id',0,'intval');

   	   /* $key  = 'store_name:'.$store_id;
   	   $name = Redis::getInstance()->get($key);
   	   
   	   if($name) return $name; */
   	   
   	   $where = ['store_id'=>$store_id];
   	   $name   = M('store')->where($where)->getField('store_name');
   	  
   	    if(empty($name)) return '';
   	   
   	    // Redis::getInstance()->set($key,$name,24*30*3600);*/
   	   return $name; 
   }
    
    
   /**
    * @method 扣减资格 资格类型   1.预约记录  2.抢购资格
    * @author 建强 2020年3月9日 
    * @return bool
    */
   public function cutQuickf(){
       //配置购买类型
       $buy_type = C('purchase_qualif');
       
       if(!in_array($buy_type, [1,2])) return false;
       
       $where = ['member_id' => I('member_id',0,'intval')];
       if($buy_type ==1){
           $save = ['status'=>2];  //使用资格
          return M('appoint_time')->where($where)->save($save);
       }
       
       
       return M('share_code')->where($where)->setInc('buy_num',5);
   }
   
   
   /**
    * @method 是否有资格   扣除的哪种资格 
    * @desc   动态配置的说明 资格后面入库
    * @return array 
    */
   public function checkQuickflication(){
       
       $where = [
           'member_id' => I('member_id',0,'intval'),
           'log_time' =>  ['EGT',NOW_TIME-(5*24*3600)],
           'status'   =>  1
           
       ];
       $res = M('appoint_time')->where($where)->find();
       
       //优先判断预约资格  并且在五天内
       if($res){
          C('purchase_qualif',1);
          return ['code'=>200,'msg'=>''];
       }
       //查看邀请好友是有资格 
       $arr = $this->getQualification();
       if($arr['unUse_num']>=$arr['full_user']){
           C('purchase_qualif',2);
           return ['code'=>200,'msg'=>''];
       }
       
       return ['code'=>3009,'msg'=>'您没有购买资格，立即预约下一场，或分享好友'];
   }
   
   
   /**
    * @method 没有购买成功购买 加回去
    * @author 建强 2020年3月9日
    * 
    * @return bool
    */
   public static function addQuickf($qualif = 0,$member_id =0 ){
       $where =['member_id'=>$member_id];
       if($qualif ==2){
           return M('share_code')->where($where)->setDec('buy_num',5);
       }
       
       $save = ['status'=>1];
       return  M('appoint_time')->where($where)->save($save);
       
   }
}