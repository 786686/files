<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/11/1
 * Time: 9:31
 */

namespace Common\Service;

class GoodsService
{
    /**
     * getByIdGoodsInfo 获取商品的信息
     * @author: fanzhaogui
     * @date 2019-11-05
     * @param $goodsId
     * @param string $fields
     * @return array
     */
    static public function getByIdGoodsInfo($goodsId, $fields = '*')
    {
        $info = M("Goods")->field($fields)->find($goodsId);
        return $info ?? [];
    }

    /**
     * 根据商品ID获取商品列表数据
     * @author: fanzhaogui
     * @date 2019-11-06
     * @param array $goodsIdArr
     * @param string $fields
     * @return array goods_id为键，array为值
     */
    static public function getByIdsGoodsList(array $goodsIdArr, $fields = '*')
    {
        $list = [];
        if ($goodsIdArr) {
            $list = M("Goods")->field($fields)->where(['goods_id' => ['in', $goodsIdArr]])->select();
            if ($list) {
                $list = array_column($list, null, 'goods_id');
            }
        }
        return $list ?? [];
    }
}