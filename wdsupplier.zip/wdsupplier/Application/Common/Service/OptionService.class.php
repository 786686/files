<?php

namespace Common\Service;

use Common\Model\OptionModel;

/**
 * 系统配置
 *
 * @package Common\Service
 */
class OptionService
{
    /**
     * 分佣开关状态
     *
     * @author: fanzhaogui
     * @return int
     */
    public static function getCommissionSwitchStatus()
    {
        $status = (new OptionModel())->getItem('swtich_presell_order');
        return intval($status);
    }
}