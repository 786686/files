<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/11/1
 * Time: 9:31
 */

namespace Common\Service;
use Think\Exception;

/**
 * 系统消息处理
 * Class SystemMessageLogService
 * @package Common\Service
 */
class SystemMessageLogService
{

    /**
     * getTotalMsg - 系统消息的数量
     * @author: fanzhaogui
     * @date 2019-11-01
     * @param $member_id
     * @param $type 0 系统消息， 2商品审核消息
     * @param $isRead 0 未读， 1已读消息
     */
    static function getTotalMsg($member_id, $type = 2, $isRead = 0)
    {
        if ($member_id < 1) return 0;

        $where = ['member_id' => $member_id];

        // 当类型为0的时候，统计所有的数量
        if ($type != 0) {
            $where['msg_type'] = $type;
        }

        // 默认情况下-查询未读取的消息总数
        if (!$isRead) {
            $where['is_read'] = 0;
        }
        $count = M("SystemMessageLog")->where($where)->count();
        return intval($count);
    }

    /**
     * getAuditMessage -- 获取审核消息  system_message_log
     * @author: fanzhaogui
     * @date 2019-11-01
     * @param $goodsId
     */
    static function getAuditMessage($goodsId)
    {
        return M("SystemMessageLog")->where(['goods_id' => $goodsId])->find();
    }

    /**
     * getAuditMsgList - 获取审核消息
     * @author: fanzhaogui
     * @date 2019-11-01
     * @param array $where
     * @param int $page
     * @param int $page_size
     * @return array
     */
    static function getAuditMsgList($where = [], $page = 1, $page_size = 10)
    {
        $result    = [
            'page_num'  => 1,
            'page'      => 1,
            'page_size' => $page_size,
            'count'     => 0,
            'list'      => [],
        ];

        $condition = ['msg_type' => 2];
        if (isset($where['goods_id'])) {
            $condition['goods_id'] = $where['goods_id'];
        }
        if (isset($where['member_id'])) {
            $condition['member_id'] = $where['member_id'];
        }
        if (isset($where['admin_username'])) {
            $condition['admin_username'] = $where['admin_username'];
        }
        if (isset($where['admin_id'])) {
            $condition['admin_id'] = $where['admin_id'];
        }

        $model = M("SystemMessageLog");
        $count = $model->where($condition)->count();

        if ($count != false) {
            $result['count']    = $count;
            $result['page_num'] = max(1, ceil($count / $page_size) - 1);
            $result['list']     = $model->where($condition)
                ->order('createtime desc')
                ->page($page, $page_size)
                ->select();
        }

        return $result;
    }

    /**
     * readAuditMessage - 标记信息的状态
     * @author: fanzhaogui
     * @date xxx
     * @param $messageId
     */
    static public function changeAuditMessageStatus($messageId, $isRead)
    {
        $rs = [
            'status' => 0,
            'msg' => '',
        ];
        $model = M("SystemMessageLog");
        $model->startTrans();
        try {
            $result = M("SystemMessageLog")->where([
                'message_id' => $messageId,
                'msg_type' => 2,
            ])->save(['is_read' => $isRead]);
            $model->commit();
            if (!$result) {
                throw new Exception($model->getError());
            }
            $rs['status'] = 1;
        } catch (\Exception $e) {
            $model->rollback();
            $rs['msg'] = $e->getMessage();
        }
        return $rs;
    }
}