<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/3/7
 * Time: 1:20
 */

namespace Common\Service;

use Common\Model\PlatformOrderRefundModel;
use Think\Exception;

/**
 * @author 范昭瑰 2020年3月6日
 * @desc   预约订单退款
 */
class PltOrderRefundService
{

    /**
     * 退款，失败
     */
    const FAIL_REFUND = -1;

    /**
     * 退款，进行中
     */
    const LOADING_REFUND = 1;

    /**
     * 退款状况，完成
     */
    const FISHED_REFUND = 2;

    /**
     * @var array 微信配置
     */
    protected static $config = [];


    public function __construct($pay = 0)
    {
        if ($pay == 1) {
            self::$config = C('wxpay');
        }
        else {
            if ($pay == 2) {

            }
            self::$config = C('wxpay_app');
        }
    }

    /**
     * 多条-微信退款
     *
     * @param $refundData
     *
     * @return boolean
     */
    public function wxMultRefundOrders($refundDatas)
    {
        foreach ($refundDatas as $refundData) {
            //先把退款状态改为退款中
            $this->wxRefundOrder($refundData);
        }

        return true;
    }


    /**
     * 单条 - 微信退款
     */
    public function wxRefundOrder($refundData)
    {
        log2File('== START WX == ', 'refund_platform_order');
        log2File($refundData, 'refund_platform_order');
        //引入微信类库
        vendor('Weixin.WxPayPubHelper');
        //获取微信支付配置
        $wxConfig = self::getWeipayConfig();
        //输入需退款的订单号
        if (is_null($refundData["pay_sn"]) || is_null($refundData["refund_amount"])) {
            return false;
        }
        else {
            //开始组装请求数据
            $out_trade_no  = $refundData["pay_sn"];
            $order_amount  = bcmul($refundData['order_amount'], 100, 0);
            $refund_fee    = bcmul($refundData["refund_amount"], 100, 0);   //退款单位为分 整数
            $out_refund_no = $refundData['refund_sn'];
            //使用退款接口
            $refund = new \Refund_pub($wxConfig);
            //设置必填参数
            //appid已填,商户无需重复填写
            //mch_id已填,商户无需重复填写
            //noncestr已填,商户无需重复填写
            //sign已填,商户无需重复填写
            $refund->setParameter("out_trade_no", $out_trade_no);//商户订单号
            $refund->setParameter("out_refund_no", $out_refund_no);//商户退款单号
            $refund->setParameter("total_fee", $order_amount);//总金额
            $refund->setParameter("refund_fee", $refund_fee);//退款金额
            $refund->setParameter("op_user_id", $wxConfig['MCHID']);//操作员，默认为商户号
            //非必填参数，商户可根据实际情况选填
            //$refund->setParameter("sub_mch_id","XX");     //子商户号
            //$refund->setParameter("device_info","XX");    //设备号
            //$refund->setParameter("transaction_id","XX"); //微信订单号
            $request = $refund->getParameter();    //获得请求参数

            $refundData['refund_reload_time'] = NOW_TIME;
            try {
                //调用结果
                $respond = $refund->getResult();
                //商户根据实际情况设置相应的处理流程,此处仅作举例

                $refundData['refund_request_param']  = json_encode($request);
                $refundData['refund_response_param'] = json_encode($respond);


                log2File('== RESULT == ', 'refund_platform_order');
                log2File($respond, 'refund_platform_order');

                if ($respond['return_code'] == 'SUCCESS' && $respond['result_code'] == 'SUCCESS') {
                    $refundData['refund_reload_status'] = self::FISHED_REFUND;
                    $refundData['refund_respose_info']  = '退款成功';
                }
                else {
                    $refundData['refund_reload_status'] = self::FAIL_REFUND;
                    $refundData['refund_respose_info']  = $respond['err_code_des'];
                    log2File('err:' . $respond['err_code_des'] ?? '', 'refund_platform_order');
                    return false;
                }

                (new PlatformOrderRefundModel())->save($refundData);
            } catch (\Exception $e) {
                $refundData['refund_request_param'] = json_encode($request);
                $refundData['refund_reload_status'] = self::FAIL_REFUND;
                $refundData['refund_respose_info']  = $e->getMessage();
                (new PlatformOrderRefundModel())->save($refundData);
                log2File('err:' . $e->getMessage(), 'refund_platform_order');
                return false;
            }

            return true;
        }
    }

    /**
     * 获取微信配置
     *
     * @return array
     */
    protected function getWeipayConfig()
    {
        return [
            'APPID'        => self::$config['appid'],
            'MCHID'        => self::$config['mchid'],
            'KEY'          => self::$config['partnerkey'],
            'SSLCERT_PATH' => self::$config['sslcert_path'],
            'SSLKEY_PATH'  => self::$config['sslkey_path'],
        ];
    }


    /**
     * 支付宝退款
     *
     * @param array $refundDatas 退款信息
     */
    public function alipayMultRefundNoPwd($refundDatas)
    {

        foreach ($refundDatas as $refundData) {
            $this->alipayRefundNoPwd($refundData);
        }
    }


    /**
     * 单个 - 无密退款
     *
     * @param $refundData
     *
     * @return bool
     */
    public function alipayRefundNoPwd($refundData)
    {
        log2File('== START ALI == ', 'refund_platform_order');
        log2File($refundData, 'refund_platform_order');

        Vendor('alipay-sdk-PHP.aop.AopClient');
        Vendor('alipay-sdk-PHP.aop.SignData');
        Vendor('alipay-sdk-PHP.aop.request.AlipayTradeRefundRequest');

        //先把退款状态改为退款中
        $refundData['refund_reload_status'] = self::LOADING_REFUND;

        //构造要请求的参数数组，无需改动
        $aop                     = new \AopClient ();
        $aop->appId              = trim(C('alipay.appid'));
        $aop->rsaPrivateKey      = C('alipay.private_key');
        $aop->alipayrsaPublicKey = C('alipay.alipay_public_key');
        $aop->signType           = strtoupper('RSA2');
        $aop->postCharset        = strtolower('utf-8');
        $aop->format             = 'json';
        $request                 = new \AlipayTradeRefundRequest ();

        $param = [
            'out_trade_no'       => $refundData['pay_sn'],
            'refund_amount'  => $refundData['refund_amount'],
            'refund_reason'  => '库存不足退款',
            'out_request_no' => $refundData['refund_sn'],
        ];


        $refundData['update_time'] = NOW_TIME;

        try {
            $request->setBizContent(json_encode($param));
            $result = $aop->execute($request);

            $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
            $resultCode   = $result->$responseNode->code;

            //保存退款结果
            $refundData['refund_request_param']  = json_encode($aop->requestParam, 256);
            $refundData['refund_response_param'] = json_encode($result->$responseNode, 256);
            $refundData['refund_reload_time']    = NOW_TIME;
            log2File('== RESULT == ', 'refund_platform_order');
            log2File($refundData['refund_request_param'], 'refund_platform_order');
            log2File($refundData['refund_response_param'], 'refund_platform_order');

            if (!empty($resultCode) && $resultCode == 10000) {
                $refundData['refund_reload_status'] = self::FISHED_REFUND;
                $refundData['refund_respose_info']  = '退款成功';
            }
            else {
                $refundData['refund_reload_status'] = self::FAIL_REFUND;
                $refundData['refund_respose_info']  = $result->$responseNode->sub_msg;
                return false;
            }

            (new PlatformOrderRefundModel())->save($refundData);
        } catch (\Exception $e) {
            $response = $aop->responseParam->alipay_trade_refund_response;

            $refundData['refund_request_param']  = json_encode($aop->requestParam);
            $refundData['refund_response_param'] = json_encode($aop->responseParam);
            $refundData['refund_reload_status']  = self::FAIL_REFUND;
            if ($response->sub_msg) {
                $refundData['refund_respose_info'] = $response->sub_msg;
                log2File('err:' . $response->sub_msg, 'refund_platform_order');
            }
            else {
                $refundData['refund_respose_info'] = $e->getMessage();
            }
            log2File('err:' . $e->getMessage(), 'refund_platform_order');
            (new PlatformOrderRefundModel())->save($refundData);
            return false;
        }

        return true;
    }


    /**
     * 退款到余额
     *
     * @param array $refundInfo 退款信息
     */
    public function balanceRefundOrder($refundInfo)
    {
        log2File('== START BALANCE ==', 'refund_platform_order');
        log2File($refundInfo, 'refund_platform_order');
        try {
            // sx_member_balance
            // sx_member_account_log
            $model = M('member_balance');
            $balance = $model
                ->where(['uid' => $refundInfo['buyer_id']])
                ->find();
            if (!$balance) {
                $res = $model->add([
                    'uid'              => $refundInfo['buyer_id'],
                    'recharge_balance' => $refundInfo['refund_amount'],
                ]);

                if(!$res) throw new Exception($model->getLastSql());
            } else  {
                $balance['recharge_balance'] = bcadd($refundInfo['refund_amount'], $balance['recharge_balance'], 3);
                $res = $model
                    ->where(['uid' => $refundInfo['buyer_id']])
                    ->save(['recharge_balance' => $balance['recharge_balance']]);
                if(!$res) throw new Exception($model->getLastSql());
            }
            // 账户日志表
            $accountData                 = [];
            $accountData['uid']          = $refundInfo['buyer_id'];
            $accountData['account_type'] = 3; //账户日志类型 3：退款
            $accountData['change_money'] = $refundInfo['refund_amount']; //收支
            $accountData['balance']      = $balance['recharge_balance']; //余额
            $accountData['order_sn']     = $refundInfo['order_sn']; //订单编号
            $accountData['pay_sn']       = 'plat_order';
            $accountData['order_id']     = $refundInfo['order_id'];
            $accountData['type_name']    = '退款';
            $accountData['remark']       = '商品售空退款';
            $accountData['createtime']   = NOW_TIME;

            // 写入一条记录
            M('member_account_log')->data($accountData)->add();
            $refundInfo['refund_reload_status'] = self::FISHED_REFUND;
            $refundInfo['refund_respose_info']  = '库存不足退款';
            $refundInfo['update_time']          = NOW_TIME;
            (new PlatformOrderRefundModel())->where(['refund_id' => $refundInfo['refund_id']])->save($refundInfo);
            return true;

        } catch (\Throwable $e) {
            $refundInfo['refund_reload_status'] = self::FAIL_REFUND;
            $refundInfo['update_time']          = NOW_TIME;
            log2File('err:' . $e->getMessage(), 'refund_platform_order');
            (new PlatformOrderRefundModel())->where(['refund_id' => $refundInfo['refund_id']])->save($refundInfo);

            return false;
        }
    }
}