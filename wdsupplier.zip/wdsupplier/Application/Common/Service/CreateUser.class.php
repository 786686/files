<?php

namespace Common\Service;

use Common\Service\Sms as SmsService;

class CreateUser
{
    //随机生成账户名称
    public static function generate($length = 6)
    {
        $ranChar = random($length);
        $timestamp = $_SERVER['REQUEST_TIME_FLOAT'];
        return substr(md5($ranChar . $timestamp), 0, $length);
    }

    //插入会员表
    public static function createMember($name, $email, $phone)
    {
//        $username = self::generate(6);
        vendor('pinyin.src.Pinyin');
        vendor('pinyin.src.DictLoaderInterface');
        vendor('pinyin.src.FileDictLoader');
        $pinyin = new \Overtrue\Pinyin\Pinyin();
        $username = $pinyin->abbr($name);
        $checkCompany = self::checkCompanyUser($username);
        if ($checkCompany['code'] != 0) {
            return [
                'status' => 0,
                'msg' => $checkCompany['msg'],
                'data' => []
            ];
        } else {
            if ($checkCompany['data']['isRgister'] == false) {
                preg_match_all('/\d+/', $checkCompany['data']['mobile'], $pregData);
                $last_num = end($pregData[0]);
                $num = intval($last_num) + 1;
                $username = $username . $num;
            }
        }
        if(strlen($username) > 64){
            return [
                'status' => 0,
                'msg' => "公司名字太长，生成账户字符超过限制",
                'data' => []
            ];
        }
        $passwd = '123456';
        $checkInfo = self::checkMember($username, $passwd);
        if ($checkInfo['code'] != 0) {
            return [
                'status' => 0,
                'msg' => $checkInfo['msg'],
                'data' => []
            ];
        }
        $model = M('Member');
        $salt = createApiToken(6);
        $pass = create_password($salt, $passwd);
        $data['member_mobile'] = $username;
        $data['member_pass'] = $pass;
        $data['member_pass_salt'] = $salt;
        $data['member_time'] = time();
        $data['member_reg_ip'] = get_client_ip();
        $data['member_type'] = 1;
        $data['member_from'] = 1;
        $data['is_company_user'] = 1;
        $id = $model->add($data);
        $title = '认证企业成功';
        $content = '欢迎成为创课网店政企会员，您提交的资料已审核通过；账号：' . $username . '登录密码：' . $passwd . '，欢迎登录创课网店采购';
        self::successSendEmail($email, $title, $content);
        self::successSendSms($phone, $username, $passwd);
        return [
            'status' => 1,
            'msg' => 'success',
            'data' => [
                'member_id' => $id
            ]
        ];
    }

    //进行发送短信和邮件通知
    public static function successSendEmail($email, $title, $content)
    {
        // =======验证万讯服务平台===========
        $url = '/Mobile/Api/getPostData';
        $data = [
            'method' => 'NewCenter.emailSend',
            'email' => $email,
            'title' => $title,
            'content' => $content
        ];
        $result = postCurl($url, $data, 2);
        $result = json_decode($result, 1);
        // =======验证万讯服务平台===========
    }

    //通过认证发送短信
    public static function successSendSms($phone, $name, $password)
    {
        $sms_param = "{\"name\":\"{$name}\",\"password\":\"{$password}\"}";
        $result = SmsService::companyCertificationPass($phone, $sms_param);
    }

    //不通过认证发送短信
    public static function errorSendSms($phone, $message)
    {
        $sms_param = "{\"message\":\"{$message}\"}";
        $result = SmsService::companyCertificationNoPass($phone, $sms_param);
    }

    public static function checkCompanyUser($username)
    {
        $url = '/Mobile/Api/getPostData';
        $data = [
            'mobile' => $username,
            'method' => 'NewCenter.checkCompanyUser',
        ];
        $result = postCurl($url, $data, 2);
        $result = json_decode($result, 1);
        return $result;
    }

    //先进行会员中心注册
    public static function checkMember($username, $passwd)
    {
        $url = '/Mobile/Api/getPostData';
        $data = [
            'mobile' => $username,
            'passwd' => $passwd,
            'type' => 0,
            'method' => 'NewCenter.loginRegisterCheck',
        ];
        $result = postCurl($url, $data, 2);
        $result = json_decode($result, 1);
        return $result;
    }
}