<?php

namespace Common\Service;
class AppToken
{
    private $token_salt = 'token';

    /**
     * @param $store_id 网店ID，总后台可以存为0
     * @return string
     */
    public function getToken($mark_name, $mark_id)
    {
        $admin_token_model = M('SupplierToken');
        $info = $admin_token_model
            ->where([
                'mark_name' => $mark_name,
                'mark_id' => $mark_id
            ])
            ->find();

        $token = $this->generateToken();//退出的时候已经清空了，所以登录需要从新生成
        if ($info) {
            $admin_token_model
                ->where(['id' => $info['id']])
                ->save([
                    'app_admin_token' => $token,
                    'update_time' => time()
                ]);
        } else {
            $admin_token_model->add([
                'mark_name' => $mark_name,
                'mark_id' => $mark_id,
                'app_admin_token' => $token,
                'update_time' => time()
            ]);
        }
        return $token;
    }

    public function getCompanyToken($mark_id)
    {
        $admin_token_model = M('CompanyToken');
        $info = $admin_token_model
            ->where([
                'member_id' => $mark_id
            ])
            ->find();
        if (empty($info) || $info['update_time'] + 7200 < time()){
            $token = $this->generateToken();
        }else{
            $token = $info['app_company_token'];
        }
        if ($info) {
            $admin_token_model
                ->where(['id' => $info['id']])
                ->save([
                    'app_company_token' => $token,
                    'update_time' => time()
                ]);
        } else {
            $admin_token_model->add([
                'member_id' => $mark_id,
                'app_company_token' => $token,
                'update_time' => time()
            ]);
        }
        return $token;
    }

    // 生成令牌
    public function generateToken()
    {
        $randChar = random(32);
        return md5($randChar . $this->token_salt);
    }
}