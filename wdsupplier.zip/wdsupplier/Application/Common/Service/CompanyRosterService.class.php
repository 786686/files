<?php
/**
 * 花名册服务类
 * User: yangjiyang
 * Date: 2018/8/20
 * Time: 15:38
 */

namespace Common\Service;


class CompanyRosterService
{
    /**
     * 导出企业化名单
     * @param $list
     */
    public static function exportCompanyRosterMemberByList($list)
    {
        $row = [];
        foreach ($list as $key=>$value){
            $row[$key]['sn'] = $value['sn'];
            $row[$key]['user_name'] = $value['user_name'];
            $row[$key]['mobile'] = $value['mobile'];
            $row[$key]['department_name'] = $value['department_name'];
            $row[$key]['position_name'] = $value['position_name'];
            $row[$key]['sex'] = $value['sex'];
            $row[$key]['is_reg'] = $value['is_reg'];
            $row[$key]['is_auth'] = $value['is_auth'];
            $row[$key]['export_time'] = $value['export_time'];
            $row[$key]['member_time'] = $value['member_time'];
            $row[$key]['auth_time'] = $value['auth_time'];
        }
        header('Content-Type:text/html;charset=utf-8');
        $fileName = '单位花名单人员列表-'.date('Y-m-d H:i:s',time());
        //应赠送预付款金额是指创业账户返还累计的金额
        $title = array('序号', '员工姓名', '员工手机号', '所属部门', '职务', '性别', '是否已注册','是否已认证', '导入时间','注册时间','认证时间');
        array_unshift($row,$title);
        \Org\Util\Csv::makeCsv($fileName,$row);
    }

    /**
     * 导出下级单位列表
     * @param $list
     */
    public static function exprotChildCompanyListByList($list)
    {
        $row = [];
        foreach ($list as $key=>$value){
            $row[$key]['sn'] = $value['sn'];
            $row[$key]['company_id'] = $value['company_id'];
            $row[$key]['company_name'] = $value['company_name'];
            $row[$key]['company_address'] = $value['company_address'];
            $row[$key]['total_member'] = $value['total_member'];
            $row[$key]['total_reg'] = $value['total_reg'];
            $row[$key]['total_auth'] = $value['total_auth'];
        }
        header('Content-Type:text/html;charset=utf-8');
        $fileName = '下级单位列表-'.date('Y-m-d H:i:s',time());
        //应赠送预付款金额是指创业账户返还累计的金额
        $title = array('序号', '单位id','单位名称', '所属地区', '总人数', '已经注册人数', '已认证人数');
        array_unshift($row,$title);
        \Org\Util\Csv::makeCsv($fileName,$row);
    }

}