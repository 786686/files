<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/4/23
 * Time: 15:03
 */

namespace Common\Service;


use OSS\OssClient;

class AdvertisingImgServer
{
    /**
     * 广告位置 1- 预约区 2-珍选区 3-优选区 4-热销区 5-预约列表顶部
     *
     * @param $ossclient OssClient 云存储对象
     * @author: fanzhaogui
     * @return array
     */
    public static function getIndexAdList($ossclient)
    {
        $fields = 'ad_url,ad_img,ad_position,ad_title';
        $tmplist = M('advertising_img')
            ->field($fields)
            ->where([
                'ad_state' => 1,
                'ad_app' => 2,
                '_string' => 'ad_position > 0 AND ad_position < 7',
            ])
            ->order('ad_sort')
            ->select();

        if (empty($tmplist)) return [];

        $advList = array();
        foreach ($tmplist as $k => &$v) {
            $v['ad_img'] = $ossclient->signUrl(C('aliyun.bucket'), $v['ad_img'], 3600);
            switch ($v['ad_position']) {
                case '1':
                    $advList['yyq'][] = $v;
                    break;
                case '3':
                    $advList['yxq'] = $v;
                    break;
                case '2':
                    $advList['zxq'] = $v;
                    break;
                case '4':
                    $advList['rxq'][] = $v;
                    break;
                case '5':
                    $advList['yylbq'] = $v;
                    break;
                case '6':
                    $advList['tyzq'] = $v;
                    break;
            }
        }
        return $advList;
    }
}