<?php
/**
 * Created by PhpStorm.
 * User: yangjiyang
 * Date: 2018/12/21
 * Time: 17:57
 */

namespace common\Service;

import("Org.Util.PHPExcel");
import("Org.Util.PHPExcel.Reader.Excel2007");
class ExportExcelService
{

    protected $excel = null;

    protected $objActSheet = null;

    protected $letter = [];

    protected $_row = 1;

    protected $css = "";

    protected $head = "";

    protected $valueMap = [];

    protected $tableHead = [];

    public function __construct($tableHead = [],$title = "")
    {
        //set_time_limit(300);
        //引入phpexcel核心文件，不是tp，你也可以用include（‘文件路径’）来引入
        $this->initPhpExcel();
        //或者excel5，用户输出.xls，不过貌似有bug，生成的excel有点问题，底部是空白，不过不影响查看。
        //import("Org.Util.PHPExcel.Reader.Excel5");

        //设置sheet的name
        $this->setSheetName();
        if ($tableHead){
            $this->tableHead = $tableHead;
            //根据有生成的excel多少列，$letter长度要大于等于这个值
            $this->initLetter($tableHead);
            $this->setTableTitle($title);
            $this->setTableHead($tableHead);
        }
    }

    protected function initPhpExcel()
    {
        //new一个PHPExcel类，或者说创建一个excel，tp中“\”不能掉
        $this->excel = new \PHPExcel();
//        if (is_null($savefile)) {
//            $savefile = time();
//        }else{
//            //防止中文命名，下载时ie9及其他情况下的文件名称乱码
//            iconv('UTF-8', 'GB2312', $savefile);
//        }
        //ini_set("memory_limit", "1024M"); // 设置php可使用内存
        $cacheMethod = \PHPExcel_CachedObjectStorageFactory::cache_in_memory_gzip;
        if (!\PHPExcel_Settings::setCacheStorageMethod($cacheMethod)) {
            die($cacheMethod . " 缓存方法不可用" . EOL);
        }
        //设置excel属性
        $this->objActSheet = $this->excel->getActiveSheet();
        //设置当前的sheet
        $this->excel->setActiveSheetIndex(0);
    }


    public function setValueMap($map)
    {
        $this->valueMap = $map;
    }

    /**
     * 设置边框
     * @param string $pCellCoordinate
     * @param array $styleArray
     * @throws \PHPExcel_Exception
     */
    public function setBorderThin($pCellCoordinate = 'A1',$styleArray = [])
    {
        if (empty($styleArray)){
            $styleArray = array(
                'borders' => array(
                    'allborders' => array(
                        //'style' => PHPExcel_Style_Border::BORDER_THICK,//边框是粗的
                        'style' => \PHPExcel_Style_Border::BORDER_THIN,//细边框
                        //'color' => array('argb' => 'FFFF0000'),
                    ),
                ),
            );
        }
        $this->objActSheet->getStyle($pCellCoordinate)->applyFromArray($styleArray);
    }

    /**
     * @param $fileHeader
     */
    protected function initLetter($head)
    {
        $letter = [];
        for ($i = 0; $i < count($head); $i++) {
            $y = ($i / 26);
            if ($y >= 1) {
                $y = intval($y);
                array_push($letter,chr($y+64).chr($i-$y*26 + 65));
            } else {
                array_push($letter,chr($i+65));
            }
        }
        $this->letter = $letter;
    }


    public function setSheetName($sheetName = "Sheet1")
    {
        //设置sheet的name
        $this->objActSheet->setTitle($sheetName);
    }

    /**
     * 设置表格标题
     * @param $title
     */
    public function setTableTitle($title)
    {
        //设置表格的标题
        $titleArr = is_array($title) ? $title : [$title];
        foreach ($titleArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $this->objActSheet->setCellValue($this->letter[0].$this->_row,$value);
            //设置表头字体样式
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getFont()->setSize(17);
            //设置表头字体是否加粗
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $this->objActSheet->getStyle($this->letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $this->excel->setActiveSheetIndex(0)->getStyle($this->letter[0])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $this->excel->getActiveSheet()->mergeCells($this->letter[0].$this->_row.":".end($this->letter).$this->_row);
            $this->_row+=1;
        }
    }


    public function setTableHead($tableHead)
    {
        //设置表头
        for($i = 0;$i < count($tableHead);$i++) {
//            if ($this->letter[$i] == 'F' && strpos($tableHead[$i],'商品') !==false){
//                $this->objActSheet->getColumnDimension($this->letter[$i])->setAutoSize(false);
//                $objActSheet->getColumnDimension("$letter[$i]")->setWidth(25);
//            }elseif(($i >= 14 && $i <= 32) || ($i >= 40 && $i <= 42) || ($i >= 46 && $i <= 51)){
//                $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(false);
//                $objActSheet->getColumnDimension("$letter[$i]")->setWidth(9);
//            }else{
//                //单元宽度自适应,1.8.1版本phpexcel中文支持勉强可以，自适应后单独设置宽度无效
//                $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(true);
//            }
            $this->objActSheet->getColumnDimension($this->letter[$i])->setWidth(strlen($tableHead[$i]));
//            if ($fileheader[$i] == '快递单号'){
//                $objActSheet->getStyle("$letter[$i]")->getNumberFormat()
//                    ->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
//            }
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $this->objActSheet->setCellValue($this->letter[$i].$this->_row,$tableHead[$i]);
            //设置表头字体样式
            $this->objActSheet->getStyle($this->letter[$i].$this->_row)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $this->objActSheet->getStyle($this->letter[$i].$this->_row)->getFont()->setSize(12);
            //设置表头字体是否加粗
            //$objActSheet->getStyle("$letter[$i]1")->getFont()->setBold(true);
            //设置表头文字垂直居中
            $this->objActSheet->getStyle($this->letter[$i].$this->_row)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $this->objActSheet->getStyle($this->letter[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $this->excel->setActiveSheetIndex(0)->getStyle($this->letter[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置边框
            $this->setBorderThin($this->letter[$i].$this->_row);
        }
        $this->_row += 1;
    }


//    protected function setFormatText($coordinate = 'A')
//    {
//        if (is_array($coordinate)){
//
//        }else{
//
//        }
//        $this->objActSheet->getStyle("$letter[$i]")->getNumberFormat()
//            ->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
//    }


    public function setRowValue($rows,$map = [])
    {
        if ($map) $this->setValueMap($map);
        $dataCount = count($rows);
        for ($i = $this->_row;$i < $dataCount + $this->_row;$i++) {

            if ($map){
                $this->_setMapRowValue($rows,$map,$i);
            }else{
                $this->_setRowValue($rows,$i);
            }
            //设置单元格高度，暂时没有找到统一设置高度方法
            if ($i)
                $this->objActSheet->getRowDimension($i)->setRowHeight(15);
        }
        $this->_row += $dataCount;
    }

    /**
     * @param $rows
     * @param array $map
     * @param array $childMap
     * @throws \PHPExcel_Exception
     */
    public function setRowValueAndChild($rows,$map = [],$childMap = [])
    {
        if ($map || $childMap) $this->setValueMap(array_merge($map,$childMap));
//        $dataCount = count(array_column($rows,'list'),true);
        $i = $this->_row;
        $totao_number = 0;
        foreach ($rows as $key=>$v){
            $j = 0;
            foreach ($map as $value){
                $this->objActSheet->setCellValue($this->letter[$j].$i,$v[$value]);
                $mergeRow = count($v['companyList']);
                if ($mergeRow > 1){
                    $this->objActSheet->mergeCells($this->letter[$j].$i.":".$this->letter[$j].($i + $mergeRow -1));
                }
                $this->setBorderThin($this->letter[$j].$i.":".$this->letter[$j].($i + $mergeRow -1));
                $j++;
            }
            foreach ($v['companyList'] as $vv){
                $jj = $j;
                foreach ($childMap as $value){
                    $this->objActSheet->setCellValue($this->letter[$jj].$i,$vv[$value]);
                    $this->setBorderThin($this->letter[$jj].$i);
//                    $this->setBorderThin($this->letter[$j].$i);
                    $jj++;
                }

                $i++;
            }
            $totao_number += count($v['companyList']);
            //设置单元格高度，暂时没有找到统一设置高度方法
            if ($i)
                $this->objActSheet->getRowDimension($i)->setRowHeight(15);
        }
        $this->_row += $totao_number;
    }

    /**
     * @param $rows
     * @param $map
     * @param $i
     */
    protected function _setMapRowValue($rows,$map,$i)
    {
        $j = 0;
        foreach ($map as $value){
            $this->objActSheet->setCellValue($this->letter[$j].$i,$rows[$i - ($this->_row)][$value]);
            $this->setBorderThin($this->letter[$j].$i);
            $j++;
        }
    }

    /**
     * @param $rows
     * @param $i
     */
    protected function _setRowValue($rows,$i)
    {
        $j = 0;
        foreach ($rows[$i - ($this->_row)] as $key => $value) {
            //不是图片时将数据加入到excel，这里数据库存的图片字段是img
                $this->objActSheet->setCellValue($this->letter[$j].$i,$value);
                $j++;
        }
    }

    /**
     * @param $description
     * @throws \PHPExcel_Exception
     */
    public function setFooterDescription($description)
    {
        //设置表格的页尾说明
        $footerArr = is_array($description) ? $description : [$description];
        foreach ($footerArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $this->objActSheet->setCellValue($this->letter[0].$this->_row,$value);
            //设置表头字体样式;
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getFont()->setSize(17);
            //设置表头字体是否加粗
//            $this->objActSheet->getStyle($this->letter[0].$titleNumber)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $this->objActSheet->getStyle($this->letter[0].$this->_row)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            //设置文字上下居中
            $this->objActSheet->getStyle($this->letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);

            $this->excel->getActiveSheet()->mergeCells($this->letter[0].$this->_row.":".end($letter).$this->_row);

            $this->setBorderThin($this->letter[0].$this->_row.":".end($letter).$this->_row);
            //行高
            $valueStrArr = explode("\r\n",$value);
            $this->objActSheet->getRowDimension($this->_row)->setRowHeight(count($valueStrArr) * 12.5);
            $this->_row+=1;
        }
    }

    /**
     * @param string $fileName
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function output($fileName = "")
    {
        if (is_null($fileName)) {
            $fileName = time();
        }else{
            //防止中文命名，下载时ie9及其他情况下的文件名称乱码
            iconv('UTF-8', 'GB2312', $fileName);
        }
        header('Content-Type: application/vnd.ms-excel');
//        下载的excel文件名称，为Excel5，后缀为xls，不过影响似乎不大
        header('Content-Disposition: attachment;filename="' . $fileName . '.xlsx"');
        header('Cache-Control: max-age=0');
        header("Content-Encoding:UTF-8");
        // 用户下载excel
        $objWriter = \PHPExcel_IOFactory::createWriter($this->excel, 'Excel2007');
        $temp_file = tempnam(sys_get_temp_dir(), 'Excel2007');
        $objWriter->save($temp_file);
        $temp_file_size = filesize($temp_file);
        header("Content-Length:{$temp_file_size}");
        $objWriter->save('php://output');
        exit();
    }

    /**
     *
     * 通过value map  定位行  设置求和
     * @param $map  array value值求和的坐标
     * @param int $start 起始的行数
     * @param int $end  结束的行数
     */
    public function setCellRowSumByMap($map,$start = 0,$end = "")
    {
        $map = array_intersect($this->valueMap,$map);
        if ($map){
            if ($end === "") $end = $this->_row -1;
            foreach ($map as $key=>$value){
                $cell = $this->letter[$key].$this->_row;
                $start_cell =  $this->letter[$key].$start;
                $end_cell = $this->letter[$key].$end;
                $this->setCellSum($cell,$start_cell,$end_cell);
            }
            $this->setBorderThin($this->letter[0].$this->_row.":".end($this->letter).$this->_row);
        }
    }

    /**
     * ______________
     * |_序号_|_省份_|
     * |____合_计____|
     *
     * 通过value map 定位行 合并单元格并复制
     * @param $value
     * @param string $start_map
     * @param string $end_map
     * @param bool $isBorderThin 是否设置边框
     * @throws \PHPExcel_Exception
     */
    public function cellRowMergeAndValueByMap($value,$start_map = "",$end_map = "",$isBorderThin = false)
    {
        if ($start_map){
            $start = $this->letter[array_search($start_map,$this->valueMap)];
        }else{
            $start = $this->letter[0];
        }
        if ($end_map){
            $end = $this->letter[array_search($end_map,$this->valueMap)];
        }else{
            $end = end($letter);
        }
        $this->cellRowMergeAndValue($value,$start,$end);
        if ($isBorderThin){
            $this->setBorderThin($start.$this->_row.":".$end.$this->_row);
        }
    }

    /**
     * 合并单元格并赋值
     * @param $value
     * @param $start
     * @param $end
     */
    public function cellRowMergeAndValue($value,$start,$end)
    {
        $this->objActSheet->setCellValue($start.$this->_row,$value);
        $this->objActSheet->mergeCells($start.$this->_row.":".$end.$this->_row);
    }

    /**
     * 求和
     * @param $cell
     * @param $start
     * @param $end
     */
    public function setCellSum($cell,$start,$end)
    {
        $this->objActSheet->setCellValue($cell, '=SUM(' . $start . ':' . $end .')');
    }

    /**
     * 设置求百分比
     * @param $cell
     * @param $x
     * @param $y
     */
    public function setCellFormatPercentage($cell,$x,$y)
    {
//        $this->objActSheet->setCellValue($cell, '=(' . $x . '/' . $y .')');
        $this->objActSheet->setCellValue($cell, "=IF(AND({$x}<>0,{$y}<>0),{$x}/{$y},0)");
        $this->objActSheet->getStyle($cell)->getNumberFormat()->setFormatCode(\PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
    }

    /**
     * 通过map 定位 某行百分比
     * @param $map string 数据写入的单元格 map_key
     * @param $x_map  string 除数单元格 map_key
     * @param $y_map string 被除数的单元格 map_key
     */
    public function setCellFormatPercentageMap($map,$x_map,$y_map)
    {
        $map_key = array_search($map,$this->valueMap);
        if ($map_key){
            $cell = $this->letter[$map_key].$this->_row;
            $x_cell = $this->letter[array_search($x_map,$this->valueMap)].$this->_row;
            $y_cell = $this->letter[array_search($y_map,$this->valueMap)].$this->_row;
            $this->setCellFormatPercentage($cell,$x_cell,$y_cell);
        }
    }

    /**
     * 通过列 设置宽度
     * @param $column
     * @param $withd
     */
    public function setCellWith($column,$width)
    {
        $this->objActSheet->getColumnDimension($this->letter[$column])->setWidth($width);
    }

    /**
     * 通过表头设置宽度
     * @param $filed
     * @param $width
     */
    public function setCellWithByHeadField($filed,$width)
    {
        $key = array_search($filed,$this->tableHead);
        if (null !== $key){
            $this->objActSheet->getColumnDimension($this->letter[$key])->setWidth($width);
        }
    }



}