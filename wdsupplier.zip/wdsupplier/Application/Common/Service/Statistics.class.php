<?php

namespace Common\Service;
use Common\Model\AreaModel;

class Statistics
{
    public static $field = 'o.order_id,o.order_sn,o.pay_sn,o.store_id,o.goods_amount,o.order_amount
    ,o.add_time,o.shipping_fee as freight,o.buyer_phone,o.trade_no,o.reciver_name,o.reciver_mobile,o.payment_time,o.company_id
    ,p.id as profits_id,p.all_order_amount as deal_amount_count,p.all_goods_amount as all_goods_amount,p.all_goods_price as goods_price
    ,p.all_profits as profits,p.king_company as king_company_amount,p.naturalness as naturalness_amount
    ,p.village as village_amount,p.wan_company as wan_company_amount,p.sale_cost as sale_cost,p.additional_cost as additional_cost,p.products_cost as products_cost
    ,p.logistics_cost as logistics_cost,p.labor_cost as labor_cost,p.packaging_cost as packaging_cost,p.risk_cost as risk_cost
    ,p.warehousing_cost as warehousing_cost,p.water_electricity_cost as water_electricity_cost
    ,p.restaurent_cost as restaurent_cost,p.others_cost as others_cost,p.platform_promotion as platform_promotion';

    public static $order_goods_field = 'goods_id,goods_name,goods_price as order_goods_price,goods_num,goods_unit,goods_img,goods_pay_price,goods_spec_id';

    public static $start_time = '2017-12-01';

    //取出测试订单ID
    public static function getOrdrTest()
    {
        return M('OrderTest')->getField('order_id', true);
    }

    public static function getOrderDetail($params = [])
    {
        $order_test_id = self::getOrdrTest();
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        $page_list = 10;    //每页10条数据
        if ($params['company_id']) {
            $where['o.company_id'] = ['eq',$params['company_id']];
        }else{
            if($params['areaid_5']){
                $company = M('company_auth')->where(array('village_id'=>$params['areaid_5'],'status'=>1))->field('id')->select();
            }elseif($params['areaid_4']){
                $company = M('company_auth')->where(array('town_id'=>$params['areaid_4'],'status'=>1))->field('id')->select();
            }elseif($params['areaid_3']){
                $company = M('company_auth')->where(array('area_id'=>$params['areaid_3'],'status'=>1))->field('id')->select();
            }elseif($params['areaid_2']){
                $company = M('company_auth')->where(array('city_id'=>$params['areaid_2'],'status'=>1))->field('id')->select();
            }elseif($params['areaid_1']){
                $company = M('company_auth')->where(array('province_id'=>$params['areaid_1'],'status'=>1))->field('id')->select();
            }else{
                $company = '';
            }
            //通过地区筛选返回的企业为空则直接返回空数据
            if ($company === []){
                return [
                    'list' => [],
                    'page_info' => [
                        'all_count' => 0,
                        'page_list' => $page_list,
                        'current_page' => 0
                    ]
                ];
            }
        }
        if($params['areaid_5'] || $params['areaid_4'] || $params['areaid_3'] || $params['areaid_2'] || $params['areaid_1']) {
            if ($company) {
                $company = array_column($company, 'id');
                $where['o.company_id'] = ['in', $company];
            } else {
                if($params['company_id']){

                }else {
                    $where['o.company_id'] = ['in', ''];
                }
            }
        }
//        p($company);
        if ($params['company_name']) {
            $where['o.order_sn'] = ['like', '%' . $params['company_name'] . '%'];
        }
        if ($params['order_sn']) {
            $where['o.order_sn'] = ['like', '%' . $params['order_sn'] . '%'];
        }
        if ($params['reciver_name']) {
            $where['o.reciver_name'] = ['like', '%' . $params['reciver_name'] . '%'];
        }
        if ($params['reciver_mobile']) {
            $where['o.reciver_mobile'] = ['like', '%' . $params['reciver_mobile'] . '%'];
        }

        if ($params['store_id'] && $params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_id']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['o.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['buyer_phone']) {
            $where['o.buyer_phone'] = ['like', '%' . $params['buyer_phone'] . '%'];
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['o.add_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        if ($params['create_time_start']) {
            if (strtotime($params['create_time_start']) < strtotime(self::$start_time)) {
                $params['create_time_start'] = self::$start_time;
            }
        } else {
            $params['create_time_start'] = self::$start_time;
        }

        if ($params['create_time_start'] && $params['create_time_end']) {
            $create_time_start = $params['create_time_start'];
            $create_time_end = $params['create_time_end'];
            $where['p.create_time'] = array('between', [strtotime("$create_time_start"), strtotime("$create_time_end 23:59:59")]);
        } elseif ($params['create_time_start']) {
            $where['p.create_time'] = array('egt', strtotime($params['create_time_start']));
        } elseif ($params['create_time_end']) {
            $end_time = $params['create_time_end'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }

        $where['o.is_profits'] = 1;   //已经计算利润的订单

        $alllist = M('Order')
            ->field(self::$field)
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        if ($page = $params['page']) {
            M('Order')->page($page, $page_list);
        }
        $list = M('Order')
            ->field(self::$field)
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();
        foreach ($list as $k => $v) {
            $list[$k]['add_time'] = date('Y-m-d H:i:s', $v['add_time']);
            if($v['payment_time'] == 0){
                $list[$k]['payment_time'] = '';
            }else {
                $list[$k]['payment_time'] = date('Y-m-d H:i:s', $v['payment_time']);
            }
            $order_goods = M('OrderGoods')->field(self::$order_goods_field)->where(['order_id' => $v['order_id']])->select();
            foreach ($order_goods as $key => $val) {
                $order_goods[$key]['goods_img'] = C('WEBSITE_URL') . '/' . $val['goods_img'];
            }
            $list[$k]['order_goods'] = $order_goods;
            if($v['company_id'] == 0){
                $list[$k]['company_name'] = '';
            }else {
                $list[$k]['company_name'] = M('company_auth')->where(array('id' => $v['company_id']))->getField('company_name');
            }
        }
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($alllist),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    //平台会员总数量
    public static function memberCount()
    {
        return M('Member')->where(array('member_state' => array('neq', -1)))->count();
    }

    //取出公司会员ID
    public static function getCompanyMember()
    {
        $member_ids = M('CompanyAuth')->where(['status' => 1])->getField('member_id', true);
        return $member_ids;
    }

    //取出平台有关注行为的会员数量
    public static function getMemberStore($params = [])
    {
        $where = [];
        if ($params['store_id']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['store_id'] = array('in', $store_id_arr);
        }
        $company_member_ids = self::getCompanyMember();
        if ($company_member_ids) {
            $where['member_id'] = ['not in', $company_member_ids];
        }
        $list = M('MemberStore')->field('member_id')->where($where)->group('member_id')->select();
        return count($list);
    }

    //取出关注公司会员数量
    public static function getCompanyMemberIDs($store_id)
    {
        $company_member_ids = self::getCompanyMember();
        if ($company_member_ids) {
            $where['member_id'] = ['in', $company_member_ids];
        }
        if ($store_id) {
            $store_id_arr = self::getAllChildStoreIDArr($store_id);
            array_push($store_id_arr, $store_id);
            $where['store_id'] = ['in', $store_id_arr];
        }
        $list = M('MemberStore')->field('member_id')->where($where)->group('member_id')->select();
        return count($list);
    }

    //根据网店id取出其下的致富站信息（列表信息用于搜索）
    public static function getChildStoreList($store_id)
    {
        $store_id_arr = self::getAllChildStoreIDArr($store_id);
        if (empty($store_id_arr)) {
            return [];
        }
        $where['store_id'] = ['in', $store_id_arr];
        $list = M('Store')->field('store_id,store_name')
            ->where($where)
            ->select();
        return $list;
    }

    //根据网店id取出其下的致富站id（全部）
    public static function getAllChildStoreIDArr($store_id)
    {
        $store_id_arr1 = self::getStoreFromAdmin($store_id);
        $store_id_arr2 = self::getStoreIDFromUser($store_id);
        return array_merge($store_id_arr1, $store_id_arr2);
    }

    //取出所有一级超市（即致富中心）
    public static function getFirstStore()
    {
        $list = M('Store')->alias('s')
            ->field('s.store_id,s.store_name')
            ->join('left join __POINT__ p on s.point_id=p.point_id')
            ->where(['p.level' => 1])
            ->select();
        return $list;
    }

    //根据网店id取出其下的致富站id(后台管理添加超市)
    public static function getStoreFromAdmin($store_id)
    {
        $store = M('Store')->alias('s')
            ->field('s.store_id,s.point_id,p.level')
            ->join('left join __POINT__ p on s.point_id=p.point_id')
            ->where(['s.store_id' => $store_id])
            ->find();
        if (empty($store)) {
            return [];
        }
        if ($store['point_id'] > 0 && $store['level'] == 1) {
            //表示为致富中心
            //取出他底下的致富站
            $child_point_id_arr = M('Point')
                ->where(['point_parent_id' => $store['point_id']])
                ->getField('point_id', true);
            if ($child_point_id_arr) {
                $where['point_id'] = ['in', $child_point_id_arr];
                $store_id_arr = M('Store')->where($where)->getField('store_id', true);
                //兼容客户端我要开店的情况
                return $store_id_arr ? $store_id_arr : [];
            } else {
                return [];
            }
        }
        return [];
    }

    //根据网店id取出其下的致富站id(客户端我要开店情况)
    public static function getStoreIDFromUser($store_id)
    {
        $store_arr = M('Store')->where(['store_parent_id' => $store_id])->getField('store_id', true);
        if (empty($store_arr)) {
            $store_arr = [];
        }
        return $store_arr;
    }

    //根据手机号取出会员简要信息
    public static function getMemberInfo($member_mobile)
    {
        $member = D('Common/Member');
        $info = $member->field('member_id,member_avatar,member_nickname')->where(['member_mobile' => $member_mobile])->find();
        $info['member_avatar'] = C('WEBSITE_URL') . '/' . $info['member_avatar'];
        $company = $member->getCompanyInfo($info['member_id']);
        $info['bind_unit'] = $company['company_name'];
        return $info;
    }

    /** 获取订单信息
     * @param array $params
     * $params['store_id'] 网店id
     * $params['start_time'] 格式2017-6-8 开始时间
     * $params['end_time'] 格式2017-6-8 结束时间
     * @return mixed
     */
    public static function getOrderSumInfo($params = [])
    {
        $params['is_get_all_Child_store'] = true;
        $where = self::getOrderInfoWhereByParams($params);
        $order_info = M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->field('COUNT(*) as order_num, IFNULL(SUM(p.all_order_amount), 0) as order_amount')
            ->find();
        return $order_info;
    }

    /**获取网店分组订单信息
     * @param array $params
     * $params['store_id'] 网店id  为0的时候获取所有  排除订单网店是0的
     * $params['start_time'] 格式2017-6-8 开始时间
     * $params['end_time'] 格式2017-6-8 结束时间
     *  @return mixed
     */
    public static function getGroupStoreOrderSumInfo($params = [],$Page)
    {
        $where = self::getProfitAllotWhereByParams($params);
        if (empty($params['store_id'])){
            $where['p.store_id'] = ['gt',0];
        }
        $refundReturnQuery = self::getRefundReturnQuery();
        $order_info = M('Order')
            ->alias('o')
            ->join('join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __STORE__ s on s.store_id=p.store_id')
            ->join('left join __POINT__ po on s.point_id=po.point_id')
            ->join("LEFT JOIN {$refundReturnQuery} rr ON rr.order_id = o.order_id")
            ->where($where)
            ->field('IFNULL(SUM(o.order_amount) - IFNULL(SUM(rr.refund_amount),0), 0) as order_amount,IFNULL(SUM(p.sale_cost), 0)+IFNULL(SUM(p.freight), 0) as sale_cost,IFNULL(SUM(p.all_profits), 0) as all_profits,p.store_id,s.store_name,po.point_name,min(p.create_time) as min_time,MAX(p.create_time) as max_time')
            ->group('s.store_id')
            ->order('min_time asc')
            ->limit($Page->firstRow.','.$Page->listRows)
            ->select();
        return $order_info;
    }

    /**
     * @return mixed
     */
    public static function getRefundReturnQuery()
    {
        return M('RefundReturn')->where(['seller_state' => 2,'refund_state' => 3])->field('SUM(refund_amount) as refund_amount,order_id')->group('order_id')->buildSql();
    }

    /**获取网店分组订单统计总数
     * @param array $params
     * $params['store_id'] 网店id  为0的时候获取所有  排除订单网店是0的
     * $params['start_time'] 格式2017-6-8 开始时间
     * $params['end_time'] 格式2017-6-8 结束时间
     *  @return mixed
     */
    public static function getGroupStoreOrderSumCount($params = [])
    {
        $where = self::getProfitAllotWhereByParams($params);
        if (empty($params['store_id'])){
            $where['p.store_id'] = ['gt',0];
        }
        $orderCount = M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __STORE__ s on s.store_id=p.store_id')
            ->join('left join __POINT__ po on s.point_id=po.point_id')
            ->where($where)
            ->group('s.store_id')
            ->field('p.order_id')
            ->select();
        return count($orderCount);
    }

    /**获取日期分组订单信息
     * @param array $params
     * $params['store_id'] 网店id  为0的时候获取所有  排除订单网店是0的
     * $params['start_time'] 格式2017-6-8 开始时间
     * $params['end_time'] 格式2017-6-8 结束时间
     *  @return mixed
     */
    public static function getGroupMonthOrderSumInfo($params = [])
    {
        $where = self::getProfitAllotWhereByParams($params);
        if (empty($params['store_id'])){
            $where['p.store_id'] = ['gt',0];
        }
        $refundReturnQuery = self::getRefundReturnQuery();
        $order_info = M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __STORE__ s on s.store_id=p.store_id')
            ->join("LEFT JOIN {$refundReturnQuery} rr ON rr.order_id = o.order_id")
            ->where($where)
            ->field('IFNULL(SUM(o.order_amount) - IFNULL(SUM(rr.refund_amount),0), 0) as order_amount,IFNULL(SUM(p.sale_cost), 0)+IFNULL(SUM(p.freight), 0) as sale_cost,IFNULL(SUM(p.all_profits), 0) as all_profits,p.store_id,s.store_name,date_format(FROM_UNIXTIME(p.create_time), "%Y年%m月") as date_month,o.refund_amount')
            ->group('date_month')
            ->order('date_month ASC')
            ->select();
        return $order_info;
    }

    /**
     * 获取销售与成本明细
     * @param $params
     * @return mixed
     */
    public static function getSalesCostAnalysisDetailByParams($params)
    {
        $where = self::getProfitAllotWhereByParams($params);
        $refundReturnQuery = self::getRefundReturnQuery();
        $order_info = M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __STORE__ s on s.store_id=p.store_id')
            ->join('left join __ORDER_GOODS__ og on og.order_id=p.order_id')
            ->join("LEFT JOIN {$refundReturnQuery} rr ON rr.order_id = o.order_id")
            ->where($where)
            ->field('o.add_time,o.order_sn,s.store_name,og.goods_unit,og.goods_name,og.goods_num,(o.order_amount - IFNULL(rr.refund_amount,0)) as all_order_amount,(p.sale_cost+p.freight)as sale_cost,p.all_profits,o.refund_amount,p.create_time')
            ->group('o.order_id')
            ->order('o.add_time asc')
            ->select();
        return $order_info;
    }

    /**
     * 获取网店消费排名
     * @param $params
     * @return mixed
     */
    public static function getStoreConsumeRank($params)
    {
        $where = self::getProfitAllotWhereByParams($params);
        $order_info = M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->field('p.order_id,o.buyer_phone,count(p.order_id) as order_num,SUM(o.order_amount) as total_order_amount,o.buyer_name,MIN(p.create_time) AS min_time,MAX(p.create_time) AS max_time')
            ->group('p.buyer_id')
            ->order('min_time ASC')
            ->limit(10)
            ->select();
        return $order_info;
    }

    /**
     * @param $params
     * @return array
     */
    public static function getProfitAllotWhereByParams($params)
    {
        $where = self::getOrderInfoWhereByParams($params);
        self::setProfitAllotWhereOrderTime($where);
        $where = array_merge($where,self::getStoreWhereAreaByParams($params));
        return $where;
    }

    /**
     * 设置下单时间2018-05-01 开始
     * @param $where
     */
    public static function setProfitAllotWhereOrderTime(&$where)
    {
        $where['o.add_time'] = ['GT',strtotime('2018-4-30 23:59:59')];
    }

    /**
     * 获取网店地区条件
     * @param $params
     * @return array
     */
    public static function getStoreWhereAreaByParams($params)
    {
        $where = [];
        if ($params['town_id']){
            $where['s.town_id'] = $params['town_id'];
        }elseif ($params['county_id']){
            $where['s.district_id'] = $params['county_id'];
        }elseif ($params['city_id']){
            $where['s.city_id'] = $params['city_id'];
        }elseif ($params['province_id']){
            $where['s.province_id'] = $params['province_id'];
        }
        return $where;
    }

    /** 获取订单信息where条件
     * @param array $params
     * $params['store_id'] 网店id
     * $params['start_time'] 格式2017-6-8 开始时间
     * $params['end_time'] 格式2017-6-8 结束时间
     * $params['is_group_sotre'] false true 是否以网店分组
     * $params['is_get_all_Child_store'] false true 是否获取下级网店(致富中心和超市)
     * @return array
     */
    protected function getOrderInfoWhereByParams($params = [])
    {
        $order_test_id = self::getOrdrTest();
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        if ($params['store_id'] && $params['is_get_all_Child_store']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['o.store_id'] = ['in', $store_id_arr];
        }elseif ($params['store_id'] != 0){
            $where['o.store_id'] = $params['store_id'];
        }
        if ($params['start_time']) {
            if (strtotime($params['start_time']) < strtotime(self::$start_time)) {
                $params['start_time'] = self::$start_time;
            }
        } else {
            $params['start_time'] = self::$start_time;
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } else if ($params['start_time']) {
            $start_time = $params['start_time'];
            $where['p.create_time'] = array('egt', strtotime("$start_time"));
        } else if ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        $where['o.is_profits'] = 1; //已计算利润
        //去除未发货退款  但是在利润分配表里面有存在运费的订单;
        $where['_string'] = 'o.order_state > 0 AND sale_cost != 0';
        return $where;
    }

    //分组列表要取出的字段
    public static $group_fields = 'count(*) as deal_order_count
            , sum(o.shipping_fee) as freight, sum(p.all_order_amount) as deal_amount_count
            , sum(p.all_goods_amount) as all_goods_amount, sum(p.all_goods_price) as goods_price, sum(p.sale_cost) as sale_cost, sum(p.additional_cost) as additional_cost, sum(p.all_profits) as profits, sum(p.king_company) as king_company_amount
            , sum(p.naturalness) as naturalness_amount, sum(p.village) as village_amount, sum(p.wan_company) as wan_company_amount
            , sum(p.products_cost) as products_cost, sum(p.logistics_cost) as logistics_cost
            , sum(p.labor_cost) as labor_cost, sum(p.packaging_cost) as packaging_cost, sum(p.risk_cost) as risk_cost
            , sum(p.warehousing_cost) as warehousing_cost, sum(p.water_electricity_cost) as water_electricity_cost
            , sum(p.restaurent_cost) as restaurent_cost, sum(p.others_cost) as others_cost, sum(p.platform_promotion) as platform_promotion';

    //组合查询条件
    public static function getWhereArr($params = [])
    {
        $where = [];
        $order_test_id = self::getOrdrTest();
        $where['o.is_profits'] = 1;   //已经计算利润的订单
//        $where['p.create_time'] = ['elt', strtotime("2017-12-01")];
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        if ($params['store_ids'] && $params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_ids']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_ids']);
            array_push($store_id_arr, $params['store_ids']);
            $where['o.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['start_time']) {
            if (strtotime($params['start_time']) < strtotime(self::$start_time)) {
                $params['start_time'] = self::$start_time;
            }
        } else {
            $params['start_time'] = self::$start_time;
        }

        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['p.create_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        //下单时间
        if ($params['order_start_time'] && $params['order_end_time']) {
            $order_start_time = $params['order_start_time'];
            $order_end_time = $params['order_end_time'];
            $where['o.add_time'] = array('between', [strtotime("$order_start_time"), strtotime("$order_end_time 23:59:59")]);
        } elseif ($params['order_start_time']) {
            $where['o.add_time'] = array('egt', strtotime($params['order_start_time']));
        } elseif ($params['order_end_time']) {
            $order_end_time = $params['order_end_time'];
            $where['o.add_time'] = array('elt', strtotime("$order_end_time 23:59:59"));
        }
        return $where;
    }

    //按日期分组
    public static function getListGroupDate($params = [])
    {
        $page_list = 10;    //每页10条数据
        $where = self::getWhereArr($params);
        $allList = M('Order')
            ->field('o.buyer_phone')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->order('p.create_time desc')
            ->group('DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\')')
            ->select();
        if ($page = $params['page']) {
            M('Order')->page($page, $page_list);
        }
        $field = self::$group_fields;
        $field .= ', DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\') as meak_time';
        $list = M('Order')
            ->field($field)
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->order('p.create_time desc')
            ->group('DATE_FORMAT(FROM_UNIXTIME(p.create_time), \'%Y-%m-%d\')')
            ->select();
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($allList),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    //按手机号码分组
    public static function getListGroupMobile($params = [])
    {
        $page_list = 10;    //每页10条数据
        $where = self::getWhereArr($params);
        $allList = M('Order')
            ->field('o.buyer_phone')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->group('o.buyer_phone')
            ->select();
        if ($page = I('page')) {
            M('Order')->page($page, $page_list);
        }
        $field = self::$group_fields;
        $field .= ',o.buyer_id as member_id,o.buyer_phone as member_mobile,o.add_time';
        $list = M('Order')
            ->field($field)
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->where($where)
            ->order('o.buyer_id desc')
            ->group('o.buyer_phone')
            ->select();
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($allList),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    //获取昨日利润
    public static function getListYeastDay($params = [])
    {
        $list = self::getListGroupDate($params);
        if (empty($list['list'])) {
            return [
                'deal_order_count' => 0,
                'profits' => 0,
                'king_company_amount' => 0,
                'village_amount' => 0,
                'naturalness_amount' => 0,
                'wan_company_amount' => 0,
            ];
        }
        return [
            'deal_order_count' => $list['list'][0]['deal_order_count'],
            'profits' => $list['list'][0]['profits'],
            'king_company_amount' => $list['list'][0]['king_company_amount'],
            'village_amount' => $list['list'][0]['village_amount'],
            'naturalness_amount' => $list['list'][0]['naturalness_amount'],
            'wan_company_amount' => $list['list'][0]['wan_company_amount']
        ];
    }

    //获取全部利润
    public static function getAllList($params = [])
    {
        $return = [
            'deal_order_count' => 0,
            'profits' => 0,
            'king_company_amount' => 0,
            'village_amount' => 0,
            'naturalness_amount' => 0,
            'wan_company_amount' => 0,
        ];
        $list = self::getListGroupDate([
            'store_ids' => $params['store_id']
        ]);
        if (empty($list['list'])) {
            return $return;
        }
        foreach ($list['list'] as $k => $v) {
            $return['deal_order_count'] += $v['deal_order_count'];
            $return['profits'] += $v['profits'];
            $return['king_company_amount'] += $v['king_company_amount'];
            $return['village_amount'] += $v['village_amount'];
            $return['naturalness_amount'] += $v['naturalness_amount'];
            $return['wan_company_amount'] += $v['wan_company_amount'];
        }
        return $return;
    }


    //获取企业下级所有订单
    public static function getCompanyAllOrderList($params = [])
    {
        $order_test_id = self::getOrdrTest();
        if ($order_test_id) {
            $where['o.order_id'] = ['not in', $order_test_id];
        }
        if ( $params['company_arr'] == 0 ) {
            $where['o.buyer_id']  = M('Order')->where(['order_id'=>$params['order_id']])->getField('buyer_id');
        } else {
            $where['o.company_id'] = array('IN',$params['company_arr']);
        }


        $page_list = 10;    //每页10条数据
        if ($params['order_sn']) {
            $where['o.order_sn'] = ['like', '%' . $params['order_sn'] . '%'];
        }
        if ($params['reciver_name']) {
            $where['o.reciver_name'] = ['like', '%' . $params['reciver_name'] . '%'];
        }
        if ($params['reciver_mobile']) {
            $where['o.reciver_mobile'] = ['like', '%' . $params['reciver_mobile'] . '%'];
        }

        if ($params['store_id'] && $params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        } elseif ($params['store_id']) {
            $store_id_arr = self::getAllChildStoreIDArr($params['store_id']);
            array_push($store_id_arr, $params['store_id']);
            $where['o.store_id'] = ['in', $store_id_arr];
        } elseif ($params['store_id_child']) {
            $where['o.store_id'] = ['in', $params['store_id_child']];
        }

        if ($params['buyer_phone']) {
            $where['o.buyer_phone'] = ['like', '%' . $params['buyer_phone'] . '%'];
        }
        if ($params['start_time'] && $params['end_time']) {
            $start_time = $params['start_time'];
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
        } elseif ($params['start_time']) {
            $where['o.add_time'] = array('egt', strtotime($params['start_time']));
        } elseif ($params['end_time']) {
            $end_time = $params['end_time'];
            $where['o.add_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }
        if ($params['create_time_start']) {
            if (strtotime($params['create_time_start']) < strtotime(self::$start_time)) {
                $params['create_time_start'] = self::$start_time;
            }
        } else {
            $params['create_time_start'] = self::$start_time;
        }

        if ($params['create_time_start'] && $params['create_time_end']) {
            $create_time_start = $params['create_time_start'];
            $create_time_end = $params['create_time_end'];
            $where['p.create_time'] = array('between', [strtotime("$create_time_start"), strtotime("$create_time_end 23:59:59")]);
        } elseif ($params['create_time_start']) {
            $where['p.create_time'] = array('egt', strtotime($params['create_time_start']));
        } elseif ($params['create_time_end']) {
            $end_time = $params['create_time_end'];
            $where['p.create_time'] = array('elt', strtotime("$end_time 23:59:59"));
        }

        $where['o.is_profits'] = 1;   //已经计算利润的订单

        $alllist = M('Order')
            ->field(self::$field.',c.company_name')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __COMPANY_AUTH__ c on c.id=o.company_id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();

        if ($page = $params['page']) {
            M('Order')->page($page, $page_list);
        }
        $list = M('Order')
            ->field(self::$field.',c.company_name')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __COMPANY_AUTH__ c on o.company_id=c.id')
            ->where($where)
            ->order('o.order_id desc')
            ->select();

        foreach ($list as $k => $v) {
            $list[$k]['add_time'] = date('Y-m-d H:i:s', $v['add_time']);
            $list[$k]['payment_time'] = date('Y-m-d H:i:s', $v['payment_time']);
            $order_goods = M('OrderGoods')->field(self::$order_goods_field)->where(['order_id' => $v['order_id']])->select();
            foreach ($order_goods as $key => $val) {
                $order_goods[$key]['goods_img'] = C('WEBSITE_URL') . '/' . $val['goods_img'];
            }
            $list[$k]['order_goods'] = $order_goods;
        }
        return [
            'list' => $list,
            'page_info' => [
                'all_count' => count($alllist),
                'page_list' => $page_list,
                'current_page' => $page
            ]
        ];
    }

    /**
     * 收益分配汇总表导出
     * @param $params
     * @return bool
     */
    public static function exportProfitAllotSummaryByParams($params)
    {
        import("Org.Util.PHPExcel");
        import("Org.Util.PHPExcel.Reader.Excel2007");
        $storeIds_str = I('selecteds');
        if (empty($storeIds_str)){
            $storeIds = self::getExportProfitAllotSummaryStoreByParams($params);
        }else{
            $storeIds = explode(',',I('selecteds'));
        }
        //没有导出网店暂且返回false
        if (empty($storeIds)){
            return false;
        }
        $excel = new \PHPExcel();
        $savefile = '收益分配汇总表-'.date('Y-m-d-h-i-s');
        iconv('UTF-8', 'GB2312', $savefile);
        $objActSheet = $excel->getActiveSheet();
        $letter = array('A','B','C','D','E','F','G','H','I','J','K');
        //设置当前的sheet
        $excel->setActiveSheetIndex(0);
        //设置sheet的name
        $objActSheet->setTitle('Sheet1');
        $areaName = self::getAreaNameByRequestParams();
        if (!empty($areaName)){
            if (count($storeIds) > 1){
                $areaName .= '各致富中心';
            }else{
                $areaName .= '致富中心';
            }
        }
        $titleArr = [
            '《创课网店农村电商》',
            '收益分配汇总表',
            "项目名称：{$areaName}",
        ];
        if ($params['start_time']){
            $start_time = date('n',strtotime($params['start_time']));
        }
        if ($params['end_time']){
            $end_time = date('n',strtotime($params['end_time']));
        }
        $objActSheet->getColumnDimension('A')->setWidth(3.5);
        $objActSheet->getColumnDimension('B')->setWidth(18);
        $objActSheet->getColumnDimension('C')->setWidth(13);
        $objActSheet->getColumnDimension('D')->setWidth(10);
        $objActSheet->getColumnDimension('E')->setWidth(10);
        $objActSheet->getColumnDimension('F')->setWidth(10);
        $objActSheet->getColumnDimension('G')->setWidth(11.5);
        $objActSheet->getColumnDimension('H')->setWidth(11.5);
        $objActSheet->getColumnDimension('I')->setWidth(11.5);
        $objActSheet->getColumnDimension('J')->setWidth(11.5);
        $objActSheet->getColumnDimension('K')->setWidth(10.5);
        $titleNumber = 1;
        foreach ($titleArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $objActSheet->setCellValue("$letter[0]".$titleNumber,$value);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            if ($key== 0 || $key== 2){
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(10);
            }else{
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(15);
            }
            //设置表头字体是否加粗
//            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[0])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            if ($key == 2){
                $objActSheet->mergeCells("A3:J3");
                $objActSheet->getStyle("A3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $objActSheet->setCellValue("K3","单位：元");
                $objActSheet->getStyle("K3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }else{
                $excel->getActiveSheet()->mergeCells("$letter[0]".$titleNumber.":".end($letter).$titleNumber);
            }
            $titleNumber+=1;
        }

        $fileheader = ['序号','致富中心','期间','销售收入','销售成本','销售利润(分配金额)','村委会(经济合作联社)(20%)','经济合作社(50%)','万讯教育扶贫基金(5%)','金陶电子商务有限公司(25%)','备注'];
        //设置表头
        for($i = 0;$i < count($fileheader);$i++) {
            //设置单元格高度，暂时没有找到统一设置高度方法
            $objActSheet->getRowDimension($titleNumber)->setRowHeight(40);
            $objActSheet->getRowDimension($titleNumber + 1)->setRowHeight(50);
//            if ($i > 2){
//                $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(true);
//            }
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            if ($i < 6 || $i == 10){
                $objActSheet->mergeCells("$letter[$i]".$titleNumber.":"."$letter[$i]".($titleNumber + 1));
                $objActSheet->setCellValue("$letter[$i]".$titleNumber,$fileheader[$i]);
            }
            if ($i == 6){
                $objActSheet->mergeCells("G4:J4");
                $objActSheet->setCellValue("$letter[$i]".$titleNumber,"分配对象");
            }
            if ($i > 5 && $i < 10){
                $objActSheet->setCellValue("$letter[$i]".($titleNumber + 1),$fileheader[$i]);
                $objActSheet->getStyle("$letter[$i]".($titleNumber + 1))->getAlignment()->setWrapText(true);
            }
            //换行
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setWrapText(true);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setSize(12);
            //设置表头字体是否加粗
            //$objActSheet->getStyle("$letter[$i]1")->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $tailTotal = [];

        $i = $titleNumber+2;
        //初始化是否有导出数据;
        $export_data_status = false;
        foreach ($storeIds as $key=>$storeId){
            $params['store_id'] = $storeId;
            $row = self::getStoreProfitsGroupMonthByParams($params);
            if ($export_data_status == false && $row){
                $export_data_status = true;
            }
            $j = 0;
            $mergei = $i + count($row)-1;
            foreach ($row as $k=>$value) {
                if ($k == 0){
                    $objActSheet->mergeCells('A'.$i.":".'A'.$mergei);
                    $objActSheet->mergeCells('B'.$i.":".'B'.$mergei);
                    $objActSheet->setCellValue("A$i",$key +1);
                    $objActSheet->setCellValue("B$i",$value['store_name']);
                }
                $objActSheet->setCellValue("C$i",$value['date_month']);
                $objActSheet->setCellValue("D$i",$value['order_amount']);
                $objActSheet->setCellValue("E$i",$value['sale_cost']);
                $objActSheet->setCellValue("F$i",$value['all_profits']);
                $objActSheet->setCellValue("G$i",price_format($value['all_profits'] * 0.2));
                $objActSheet->setCellValue("H$i",price_format($value['all_profits'] * 0.5));
                $objActSheet->setCellValue("I$i",price_format($value['all_profits'] * 0.05));
                $objActSheet->setCellValue("J$i",price_format($value['all_profits'] * 0.25));
                $objActSheet->setCellValue("K$i","            ");
                //设置单元格高度，暂时没有找到统一设置高度方法
                $objActSheet->getRowDimension($i)->setRowHeight(17);
                $j++;
                $i++;
            }
            //小计
            if ($row){
                $rows_total = [
                    "order_amount" => array_sum(array_column($row,'order_amount')),
                    "sale_cost" => array_sum(array_column($row,'sale_cost')),
                    "all_profits" => array_sum(array_column($row,'all_profits')),
                    "all_profits20" => price_format(array_sum(array_column($row,'all_profits')) * 0.2),
                    "all_profits50" => price_format(array_sum(array_column($row,'all_profits')) * 0.5),
                    "all_profits5" => price_format(array_sum(array_column($row,'all_profits')) * 0.05),
                    "all_profits25" => price_format(array_sum(array_column($row,'all_profits')) * 0.25),
                ];
                $objActSheet->setCellValue("A$i",$value);
                $objActSheet->mergeCells('B'.$i.":".'C'.$i);
                if (count($row) >1 || ($start_time && $end_time && $start_time != $start_time)){
                    $tmp_start_time = $start_time ?:date_parse_from_format('Y年m月',$row[0]['date_month'])['month'];
                    $tmp_end_time = $end_time?:date_parse_from_format('Y年m月',end($row)['date_month'])['month'];
                    $objActSheet->setCellValue("B$i",$tmp_start_time.'月 ～ '.$tmp_end_time.'月小计');
                }else{
                    $objActSheet->setCellValue("B$i",date_parse_from_format('Y年m月',$row[0]['date_month'])['month'].'月小计');
                }
                //第三个单元格开始添加
                $j = 3;
                foreach ($rows_total as $k=>$value){
                    $objActSheet->setCellValue("$letter[$j]$i",$value);
                    $j ++;
                }
                $objActSheet->setCellValue("K$i",'');
                $i++;
                array_push($tailTotal,$rows_total);
            }
        }
        //没有导出数据  暂且返回false
        if ($export_data_status === false){
            return false;
        }
        //合计
        if ($tailTotal){
            $objActSheet->setCellValue("A$i",'');
            $objActSheet->mergeCells('B'.$i.":".'C'.$i);
            $objActSheet->setCellValue("B$i",'合计');
            $objActSheet->setCellValue("D$i",array_sum(array_column($tailTotal,'order_amount')));
            $objActSheet->setCellValue("E$i",array_sum(array_column($tailTotal,'sale_cost')));
            $objActSheet->setCellValue("F$i",array_sum(array_column($tailTotal,'all_profits')));
            $objActSheet->setCellValue("G$i",array_sum(array_column($tailTotal,'all_profits20')));
            $objActSheet->setCellValue("H$i",array_sum(array_column($tailTotal,'all_profits50')));
            $objActSheet->setCellValue("I$i",array_sum(array_column($tailTotal,'all_profits5')));
            $objActSheet->setCellValue("J$i",array_sum(array_column($tailTotal,'all_profits25')));
            $objActSheet->setCellValue("K$i","");
            $objActSheet->getRowDimension($i)->setRowHeight(22);
            $i ++;
        }
        //说明
        $objActSheet->mergeCells('A'.$i.":".'K'.$i);
        $footer = "说明：销售收入=商品销售总额+运费，销售成本=商品综合成本(购进价、包装成本、物流成本、仓储成本、水电成本、设备用具用品分摊成本、风险成本、其他成本)";
        $objActSheet->setCellValue("A$i",$footer);
        $objActSheet->getStyle("A$i")->getAlignment()->setWrapText(true);
        $objActSheet->getRowDimension($i)->setRowHeight(40);
        $style_array = array(
            'borders' => array(
                'allborders' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN
                )
            )
        );
        $objActSheet->getStyle('A4:K'.$i)->applyFromArray($style_array);
        header('Content-Type: application/vnd.ms-excel');
        //下载的excel文件名称，为Excel5，后缀为xls，不过影响似乎不大
        header('Content-Disposition: attachment;filename="' . $savefile . '.xlsx"');
        header('Cache-Control: max-age=0');
        // 用户下载excel
        $objWriter = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    /**
     * 收益分配按月分組
     * @param $params
     * @return mixed
     */
    public static function getStoreProfitsGroupMonthByParams($params)
    {
        $where = self::getProfitAllotWhereByParams($params);
        $order_info = M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('left join __STORE__ s on s.store_id=p.store_id')
            ->join('left join __POINT__ po on s.point_id=po.point_id')
            ->where($where)
            ->field('IFNULL(SUM(o.order_amount), 0) as order_amount,IFNULL(SUM(p.sale_cost), 0)+IFNULL(SUM(p.freight), 0) as sale_cost,IFNULL(SUM(p.all_profits), 0) as all_profits,p.store_id,s.store_name,po.point_name,date_format(FROM_UNIXTIME(p.create_time), "%Y年%m月") as date_month')
            ->group('date_month')
            ->order('date_month asc')
            ->select();
        return $order_info;
    }

    /**
     * @return string
     */
    public static function getAreaNameByRequestParams()
    {
        $province_id = I('province_id',0);
        $city_id = I('city_id',0);
        $county_id = I('county_id',0);
        $town_id = I('town_id',0);
        $data = (new AreaModel())->getList(['area_id' => ['IN',[$province_id,$city_id,$county_id,$town_id]]],'area_name','');
        return implode(array_column($data,'area_name'),'');
    }

    /**
     * @param $params
     */
    public static function getExportProfitAllotSummaryStoreByParams($params)
    {
        $where = self::getProfitAllotWhereByParams($params);
        $storeIds =M('Order')
            ->alias('o')
            ->join('left join __PROFITS__ p on o.order_id=p.order_id')
            ->join('LEFT JOIN __STORE__ s on p.store_id = s.store_id')
            ->where($where)
            ->field('DISTINCT p.store_id')
            ->order('p.create_time asc')
            ->select();
        return array_column($storeIds,'store_id');
    }

    public static function exportSalesCostAnalysisDetail($lists,$start_time,$end_time,$store_name)
    {
        import("Org.Util.PHPExcel");
        import("Org.Util.PHPExcel.Reader.Excel2007");

        $excel = new \PHPExcel();
        $savefile = '销售与成本分析明细表-'.date('Y-m-d-h-i-s');
        iconv('UTF-8', 'GB2312', $savefile);
        $objActSheet = $excel->getActiveSheet();
        $letter = array('A','B','C','D','E','F','G');
        //设置当前的sheet
        $excel->setActiveSheetIndex(0);
        //设置sheet的name
        $objActSheet->setTitle('Sheet1');

        $titleArr = [
            '《创课网店农村电商》',
            '销售与成本分析明细表',
            1
        ];

        $objActSheet->getColumnDimension('A')->setWidth(18);
        $objActSheet->getColumnDimension('B')->setWidth(19);
        $objActSheet->getColumnDimension('C')->setWidth(13);
        $objActSheet->getColumnDimension('D')->setWidth(25);
        $objActSheet->getColumnDimension('E')->setWidth(10);
        $objActSheet->getColumnDimension('F')->setWidth(10);
        $objActSheet->getColumnDimension('G')->setWidth(9);
        $titleNumber = 1;
        foreach ($titleArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $objActSheet->setCellValue("$letter[0]".$titleNumber,$value);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            if ($key== 0 || $key== 2){
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(10);
            }else{
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(15);
            }
            //设置表头字体是否加粗
//            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[0])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            if ($key == 2){
                $objActSheet->setCellValue("A3","网店名称：".$store_name);
                $objActSheet->mergeCells("B3:E3");
                $objActSheet->setCellValue("B3",'所属时间：'.$start_time.'-'.$end_time);
                $objActSheet->getStyle("A3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $objActSheet->getStyle("B3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objActSheet->mergeCells("F3:G3");
                $objActSheet->setCellValue("F3","单位：元");
                $objActSheet->getStyle("F3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }else{
                $excel->getActiveSheet()->mergeCells("$letter[0]".$titleNumber.":".end($letter).$titleNumber);
            }
            $titleNumber+=1;
        }

        $fileheader = ['下单时间','订单号','网店','商品名称','销售收入','销售成本','销售利润'];
        //设置表头
        for($i = 0;$i < count($fileheader);$i++) {
//            //设置单元格高度，暂时没有找到统一设置高度方法
//            $objActSheet->getRowDimension($titleNumber)->setRowHeight(20);
//            $objActSheet->getRowDimension($titleNumber + 1)->setRowHeight(20);
////            if ($i > 2){
///             $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(true);
////            }
//            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
//            if ($i < 6 || $i == 10){
//                $objActSheet->mergeCells("$letter[$i]".$titleNumber.":"."$letter[$i]".($titleNumber + 1));
                $objActSheet->setCellValue("$letter[$i]".$titleNumber,$fileheader[$i]);
//            }
//            if ($i == 6){
//                $objActSheet->mergeCells("G4:J4");
//                $objActSheet->setCellValue("$letter[$i]".$titleNumber,"分配对象");
//            }
//            if ($i > 5 && $i < 10){
//                $objActSheet->setCellValue("$letter[$i]".($titleNumber + 1),$fileheader[$i]);
//                $objActSheet->getStyle("$letter[$i]".($titleNumber + 1))->getAlignment()->setWrapText(true);
//            }
            //换行
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setWrapText(true);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setSize(12);
            //设置表头字体是否加粗
            //$objActSheet->getStyle("$letter[$i]1")->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $tailTotal = [];

        $i = $titleNumber+1;
        //初始化是否有导出数据;
        $dataCount = count($lists);
        $total_order_amount = 0;
        $total_profits = 0;
        $total_sale_cost = 0;
        for ($i = $titleNumber+1;$i <= $dataCount + $titleNumber;$i++) {
            $total_order_amount += $lists[$i - ($titleNumber+1)]['all_order_amount'];
            $total_profits += $lists[$i - ($titleNumber+1)]['all_profits'];
            $total_sale_cost += $lists[$i - ($titleNumber+1)]['sale_cost'];
            $objActSheet->setCellValue("A".$i,date('Y-m-d H:i:s',$lists[$i - ($titleNumber+1)]['add_time']));
            $objActSheet->setCellValue("B".$i,$lists[$i - ($titleNumber+1)]['order_sn']);
            $objActSheet->setCellValue("C".$i,$lists[$i - ($titleNumber+1)]['store_name']);
            $objActSheet->setCellValue("D".$i,$lists[$i - ($titleNumber+1)]['goods_name'].'/ 数量:'.$lists[$i - ($titleNumber+1)]['goods_num'].($lists[$i - ($titleNumber+1)]['goods_unit']?$lists[$i - ($titleNumber+1)]['goods_unit']:'件'));
            $objActSheet->setCellValue("E".$i,$lists[$i - ($titleNumber+1)]['all_order_amount']);
            $objActSheet->setCellValue("F".$i,$lists[$i - ($titleNumber+1)]['sale_cost']);
            $objActSheet->setCellValue("G".$i,$lists[$i - ($titleNumber+1)]['all_profits']);
            //设置单元格高度，暂时没有找到统一设置高度方法
            if ($i)
                $objActSheet->getRowDimension($i)->setRowHeight(15);
        }

        //合计
            $objActSheet->setCellValue("A$i",'合计');
            $objActSheet->setCellValue("E$i",$total_order_amount);
            $objActSheet->setCellValue("F$i",$total_sale_cost);
            $objActSheet->setCellValue("G$i",$total_profits);
            $objActSheet->getRowDimension($i)->setRowHeight(22);
        //说明
//        $objActSheet->mergeCells('A'.$i.":".'G'.$i);
//        $footer = "说明：销售收入=商品销售总额+运费，销售成本=商品综合成本(购进价、包装成本、物流成本、仓储成本、水电成本、设备用具用品分摊成本、风险成本、其他成本)";
//        $objActSheet->setCellValue("A$i",$footer);
//        $objActSheet->getStyle("A$i")->getAlignment()->setWrapText(true);
//        $objActSheet->getRowDimension($i)->setRowHeight(40);
        $style_array = array(
            'borders' => array(
                'allborders' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN
                )
            )
        );
//        $objActSheet->getStyle('A4:G'.$i)->applyFromArray($style_array);
        header('Content-Type: application/vnd.ms-excel');
        //下载的excel文件名称，为Excel5，后缀为xls，不过影响似乎不大
        header('Content-Disposition: attachment;filename="' . $savefile . '.xlsx"');
        header('Cache-Control: max-age=0');
        // 用户下载excel
        $objWriter = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    public function exportPrintConsumeRank($lists,$start_time,$end_time,$store_name){
        import("Org.Util.PHPExcel");
        import("Org.Util.PHPExcel.Reader.Excel2007");

        $excel = new \PHPExcel();
        $savefile = '消费排名表-'.date('Y-m-d-h-i-s');
        iconv('UTF-8', 'GB2312', $savefile);
        $objActSheet = $excel->getActiveSheet();
        $letter = array('A','B','C','D','E');
        //设置当前的sheet
        $excel->setActiveSheetIndex(0);
        //设置sheet的name
        $objActSheet->setTitle('Sheet1');

        $titleArr = [
            '《创课网店农村电商》',
            '消费排名表',
            1
        ];

        $titleNumber = 1;
        foreach ($titleArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $objActSheet->setCellValue("$letter[0]".$titleNumber,$value);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            if ($key== 0 || $key== 2){
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(10);
            }else{
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(15);
            }
            //设置表头字体是否加粗
//            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[0])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            if ($key == 2){
                $objActSheet->mergeCells("A3:B3");
                $objActSheet->setCellValue("A3","网店名称：".$store_name);
                $objActSheet->mergeCells("C3:D3");
                $objActSheet->setCellValue("C3",'所属时间：'.$start_time.'-'.$end_time);
                $objActSheet->getStyle("A3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $objActSheet->getStyle("C3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objActSheet->setCellValue("E3","单位：元");
                $objActSheet->getStyle("E3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }else{
                $excel->getActiveSheet()->mergeCells("$letter[0]".$titleNumber.":".end($letter).$titleNumber);
            }
            $titleNumber+=1;
        }

        $fileheader = ['排名','成交用户','购买次数（次）','消费总金额（元）','客户名称'];
        //设置表头
        for($i = 0;$i < count($fileheader);$i++) {
//            //设置单元格高度，暂时没有找到统一设置高度方法
//            $objActSheet->getRowDimension($titleNumber)->setRowHeight(20);
//            $objActSheet->getRowDimension($titleNumber + 1)->setRowHeight(20);
////            if ($i > 2){
//            $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(true);
////            }
//            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
//            if ($i < 6 || $i == 10){
//                $objActSheet->mergeCells("$letter[$i]".$titleNumber.":"."$letter[$i]".($titleNumber + 1));
            $objActSheet->setCellValue("$letter[$i]".$titleNumber,$fileheader[$i]);
//            }
//            if ($i == 6){
//                $objActSheet->mergeCells("G4:J4");
//                $objActSheet->setCellValue("$letter[$i]".$titleNumber,"分配对象");
//            }
//            if ($i > 5 && $i < 10){
//                $objActSheet->setCellValue("$letter[$i]".($titleNumber + 1),$fileheader[$i]);
//                $objActSheet->getStyle("$letter[$i]".($titleNumber + 1))->getAlignment()->setWrapText(true);
//            }
            //换行
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setWrapText(true);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setSize(12);
            //设置表头字体是否加粗
            //$objActSheet->getStyle("$letter[$i]1")->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $tailTotal = [];

//        $i = $titleNumber+2;
        //初始化是否有导出数据;
        $dataCount = count($lists);
        for ($i = $titleNumber+1;$i <= $dataCount + $titleNumber;$i++) {
            $objActSheet->setCellValue("A".$i,$lists[$i - ($titleNumber+1)]['sn']);
            $objActSheet->setCellValue("B".$i,$lists[$i - ($titleNumber+1)]['buyer_phone']);
            $objActSheet->setCellValue("C".$i,$lists[$i - ($titleNumber+1)]['order_num']);
            $objActSheet->setCellValue("D".$i,$lists[$i - ($titleNumber+1)]['total_order_amount']);
            $objActSheet->setCellValue("E".$i,$lists[$i - ($titleNumber+1)]['buyer_name']);
            //设置单元格高度，暂时没有找到统一设置高度方法
            if ($i)
                $objActSheet->getRowDimension($i)->setRowHeight(15);
        }
        $objActSheet->getColumnDimension('A')->setWidth(10);
        $objActSheet->getColumnDimension('B')->setWidth(18);
        $objActSheet->getColumnDimension('C')->setWidth(17);
        $objActSheet->getColumnDimension('D')->setWidth(15);
        $objActSheet->getColumnDimension('E')->setWidth(25);
        //说明
//        $objActSheet->mergeCells('A'.$i.":".'G'.$i);
//        $footer = "说明：销售收入=商品销售总额+运费，销售成本=商品综合成本(购进价、包装成本、物流成本、仓储成本、水电成本、设备用具用品分摊成本、风险成本、其他成本)";
//        $objActSheet->setCellValue("A$i",$footer);
//        $objActSheet->getStyle("A$i")->getAlignment()->setWrapText(true);
//        $objActSheet->getRowDimension($i)->setRowHeight(40);
        $style_array = array(
            'borders' => array(
                'allborders' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN
                )
            )
        );
        $i -= 1;
        $objActSheet->getStyle('A4:E'.$i)->applyFromArray($style_array);
        header('Content-Type: application/vnd.ms-excel');
        //下载的excel文件名称，为Excel5，后缀为xls，不过影响似乎不大
        header('Content-Disposition: attachment;filename="' . $savefile . '.xlsx"');
        header('Cache-Control: max-age=0');
        // 用户下载excel
        $objWriter = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    public function exportprintProfitAllotSummary($lists,$sum){
        import("Org.Util.PHPExcel");
        import("Org.Util.PHPExcel.Reader.Excel2007");

        $excel = new \PHPExcel();
        $savefile = '销售数据分析表-'.date('Y-m-d-h-i-s');
        iconv('UTF-8', 'GB2312', $savefile);
        $objActSheet = $excel->getActiveSheet();
        $letter = array('A','B','C','D','E','F');
        //设置当前的sheet
        $excel->setActiveSheetIndex(0);
        //设置sheet的name
        $objActSheet->setTitle('Sheet1');

        $titleArr = [
            '《创课网店农村电商》',
            '销售数据分析表',
            1
        ];

        $objActSheet->getColumnDimension('A')->setWidth(18);
        $objActSheet->getColumnDimension('B')->setWidth(19);
        $objActSheet->getColumnDimension('C')->setWidth(13);
        $objActSheet->getColumnDimension('D')->setWidth(15);
        $objActSheet->getColumnDimension('E')->setWidth(10);
        $objActSheet->getColumnDimension('F')->setWidth(10);
        $titleNumber = 1;
        foreach ($titleArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $objActSheet->setCellValue("$letter[0]".$titleNumber,$value);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            if ($key== 0 || $key== 2){
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(10);
            }else{
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(15);
            }
            //设置表头字体是否加粗
//            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[0])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            if ($key == 2){
                $objActSheet->mergeCells("A3:B3");
                $objActSheet->setCellValue("A3","网店名称：".$lists[0]['store_name']);

                $objActSheet->getStyle("A3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $objActSheet->mergeCells("C3:D3");
                $objActSheet->mergeCells("E3:F3");
                $objActSheet->setCellValue("E3","单位：元");
                $objActSheet->getStyle("E3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }else{
                $excel->getActiveSheet()->mergeCells("$letter[0]".$titleNumber.":".end($letter).$titleNumber);
            }
            $titleNumber+=1;
        }

        $fileheader = ['期间','致富超市','销售收入','销售成本','销售利润','销售利率'];
        //设置表头
        for($i = 0;$i < count($fileheader);$i++) {
//            //设置单元格高度，暂时没有找到统一设置高度方法
//            $objActSheet->getRowDimension($titleNumber)->setRowHeight(20);
//            $objActSheet->getRowDimension($titleNumber + 1)->setRowHeight(20);
////            if ($i > 2){
///             $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(true);
////            }
//            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
//            if ($i < 6 || $i == 10){
//                $objActSheet->mergeCells("$letter[$i]".$titleNumber.":"."$letter[$i]".($titleNumber + 1));
            $objActSheet->setCellValue("$letter[$i]".$titleNumber,$fileheader[$i]);
//            }
//            if ($i == 6){
//                $objActSheet->mergeCells("G4:J4");
//                $objActSheet->setCellValue("$letter[$i]".$titleNumber,"分配对象");
//            }
//            if ($i > 5 && $i < 10){
//                $objActSheet->setCellValue("$letter[$i]".($titleNumber + 1),$fileheader[$i]);
//                $objActSheet->getStyle("$letter[$i]".($titleNumber + 1))->getAlignment()->setWrapText(true);
//            }
            //换行
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setWrapText(true);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setSize(12);
            //设置表头字体是否加粗
            //$objActSheet->getStyle("$letter[$i]1")->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $tailTotal = [];

        $i = $titleNumber+1;
        //初始化是否有导出数据;
        $dataCount = count($lists);
        $total_order_amount = 0;
        $total_profits = 0;
        $total_sale_cost = 0;
        for ($i = $titleNumber+1;$i <= $dataCount + $titleNumber;$i++) {
            $objActSheet->setCellValue("A".$i,$lists[$i - ($titleNumber+1)]['date_month']);
            $objActSheet->setCellValue("B".$i,$lists[$i - ($titleNumber+1)]['store_name']);
            $objActSheet->setCellValue("C".$i,$lists[$i - ($titleNumber+1)]['order_income']);
            $objActSheet->setCellValue("D".$i,$lists[$i - ($titleNumber+1)]['sale_cost']);
            $objActSheet->setCellValue("E".$i,$lists[$i - ($titleNumber+1)]['all_profits']);
            $objActSheet->setCellValue("F".$i,number_format($lists[$i - ($titleNumber+1)]['profits_margin'],2).'%');
            //设置单元格高度，暂时没有找到统一设置高度方法number_format($lists[$i - ($titleNumber+1)]['profits_margin'],2)
            if ($i)
                $objActSheet->getRowDimension($i)->setRowHeight(15);
        }

        //合计
        $objActSheet->mergeCells("A$i:B$i");
        $objActSheet->setCellValue("A$i",'合计');
        $objActSheet->setCellValue("C$i",$sum['total_income']);
        $objActSheet->setCellValue("D$i",$sum['total_sale_cost']);
        $objActSheet->setCellValue("E$i",$sum['total_profits']);
        $objActSheet->setCellValue("F$i",$sum['total_profits_margin'].'%');
        $objActSheet->getRowDimension($i)->setRowHeight(22);
        //说明
//        $objActSheet->mergeCells('A'.$i.":".'G'.$i);
//        $footer = "说明：销售收入=商品销售总额+运费，销售成本=商品综合成本(购进价、包装成本、物流成本、仓储成本、水电成本、设备用具用品分摊成本、风险成本、其他成本)";
//        $objActSheet->setCellValue("A$i",$footer);
//        $objActSheet->getStyle("A$i")->getAlignment()->setWrapText(true);
//        $objActSheet->getRowDimension($i)->setRowHeight(40);
        $style_array = array(
            'borders' => array(
                'allborders' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN
                )
            )
        );
//        $objActSheet->getStyle('A4:G'.$i)->applyFromArray($style_array);
        header('Content-Type: application/vnd.ms-excel');
        //下载的excel文件名称，为Excel5，后缀为xls，不过影响似乎不大
        header('Content-Disposition: attachment;filename="' . $savefile . '.xlsx"');
        header('Cache-Control: max-age=0');
        // 用户下载excel
        $objWriter = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

    public function exportprintProfitAllot($data,$poverty_company,$start_time,$end_time){
        import("Org.Util.PHPExcel");
        import("Org.Util.PHPExcel.Reader.Excel2007");

        $excel = new \PHPExcel();
        $savefile = '收益分配表-'.date('Y-m-d-h-i-s');
        iconv('UTF-8', 'GB2312', $savefile);
        $objActSheet = $excel->getActiveSheet();
        $letter = array('A','B','C','D');
        //设置当前的sheet
        $excel->setActiveSheetIndex(0);
        //设置sheet的name
        $objActSheet->setTitle('Sheet1');

        $titleArr = [
            '《创课网店农村电商》',
            '收益分配表',
            1
        ];

        $titleNumber = 1;
        foreach ($titleArr as $key=>$value){
            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
            $objActSheet->setCellValue("$letter[0]".$titleNumber,$value);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            if ($key== 0 || $key== 2){
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(10);
            }else{
                $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setSize(15);
            }
            //设置表头字体是否加粗
//            $objActSheet->getStyle("$letter[0]".$titleNumber)->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[0]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[0])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[0])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            if ($key == 2){
                $objActSheet->setCellValue("A3","网店名称：".$data['store_name']);
                $objActSheet->mergeCells("B3:C3");
                $objActSheet->setCellValue("B3",'所属时间：'.$start_time.'-'.$end_time);
                $objActSheet->getStyle("A3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $objActSheet->getStyle("B3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $objActSheet->setCellValue("D3","单位：元");
                $objActSheet->getStyle("D3")->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            }else{
                $excel->getActiveSheet()->mergeCells("$letter[0]".$titleNumber.":".end($letter).$titleNumber);
            }
            $titleNumber+=1;
        }

        $fileheader = ['分配人','分配基数（元）','分配比例（%）','分配金额（元）'];
        //设置表头
        for($i = 0;$i < count($fileheader);$i++) {
//            //设置单元格高度，暂时没有找到统一设置高度方法
//            $objActSheet->getRowDimension($titleNumber)->setRowHeight(20);
//            $objActSheet->getRowDimension($titleNumber + 1)->setRowHeight(20);
////            if ($i > 2){
//            $objActSheet->getColumnDimension("$letter[$i]")->setAutoSize(true);
////            }
//            //设置表头值，这里的setCellValue第二个参数不能使用iconv，否则excel中显示false
//            if ($i < 6 || $i == 10){
//                $objActSheet->mergeCells("$letter[$i]".$titleNumber.":"."$letter[$i]".($titleNumber + 1));
            $objActSheet->setCellValue("$letter[$i]".$titleNumber,$fileheader[$i]);
//            }
//            if ($i == 6){
//                $objActSheet->mergeCells("G4:J4");
//                $objActSheet->setCellValue("$letter[$i]".$titleNumber,"分配对象");
//            }
//            if ($i > 5 && $i < 10){
//                $objActSheet->setCellValue("$letter[$i]".($titleNumber + 1),$fileheader[$i]);
//                $objActSheet->getStyle("$letter[$i]".($titleNumber + 1))->getAlignment()->setWrapText(true);
//            }
            //换行
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setWrapText(true);
            //设置表头字体样式
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setName('微软雅黑');
            //设置表头字体大小
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getFont()->setSize(12);
            //设置表头字体是否加粗
            //$objActSheet->getStyle("$letter[$i]1")->getFont()->setBold(true);
            //设置表头文字垂直居中
            $objActSheet->getStyle("$letter[$i]".$titleNumber)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            //设置文字上下居中
            $objActSheet->getStyle($letter[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            //设置表头外的文字垂直居中
            $excel->setActiveSheetIndex(0)->getStyle($letter[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        }
        $tailTotal = [];

        $i = $titleNumber+2;
        //初始化是否有导出数据;
        $objActSheet->setCellValue("A5",'甲方：经济合作社');
        $objActSheet->mergeCells("B5:B8");
        $objActSheet->setCellValue("B5",$data['all_profits']);
        $objActSheet->setCellValue("C5",'50%');
        $objActSheet->setCellValue("D5",$data['store_child']);
        $objActSheet->getRowDimension(5)->setRowHeight(15);
        $objActSheet->setCellValue("A6","乙方：金陶电子商务有限公司");
        $objActSheet->setCellValue("C6","25%");
        $objActSheet->setCellValue("D6",$data['king_company']);
        $objActSheet->getRowDimension(6)->setRowHeight(15);
        $objActSheet->setCellValue("A7","万讯教育扶贫基金");
        $objActSheet->setCellValue("C7","5%");
        $objActSheet->setCellValue("D7",$data['wan_company']);
        $objActSheet->getRowDimension(7)->setRowHeight(15);
        $objActSheet->setCellValue("A8",$data['point_name'].'(经济合作联社)');
        $objActSheet->setCellValue("C8","20%");
        $objActSheet->setCellValue("D8",$data['store_al_child']);
        $objActSheet->getRowDimension(8)->setRowHeight(15);
        $objActSheet->mergeCells("A9:C9");
        $objActSheet->setCellValue('A9','合计');
        $objActSheet->setCellValue('D9',$data['all_profits']);
        $objActSheet->setCellValue('D10',$data['all_profits']);
        $objActSheet->setCellValue('D11',$data['all_profits']);
        $objActSheet->getRowDimension(9)->setRowHeight(15);
        $objActSheet->getColumnDimension('A')->setWidth(20);
        $objActSheet->getColumnDimension('B')->setWidth(18);
        $objActSheet->getColumnDimension('C')->setWidth(17);
        $objActSheet->getColumnDimension('D')->setWidth(15);
        //说明
        $objActSheet->mergeCells("A10:D10");
        $beizhu = '备注：以创课网店'.$data['store_name'].'线上网店所销售的订单进行统计';
        $objActSheet->setCellValue("A10",$beizhu);
        $objActSheet->getStyle("A10")->getAlignment()->setWrapText(true);
        $objActSheet->getRowDimension(11)->setRowHeight(15);
        $objActSheet->getRowDimension(12)->setRowHeight(40);
        $objActSheet->mergeCells("A11:B11");
        $objActSheet->mergeCells("C11:D11");
        $objActSheet->setCellValue("A11","甲方：村民经济合作社");
        $objActSheet->setCellValue("C11","乙方：金陶电子商务有限公司");
        $objActSheet->mergeCells("A12:B12");
        $objActSheet->setCellValue("A12",$data['store_name']);
        $company ='扶贫单位:';

        if (!empty($poverty_company)){
            foreach ($poverty_company as $k => $value){
                $company .=  $value['company_name']."\n";
            }
        }
        $objActSheet->mergeCells("C12:D12");
        $objActSheet->setCellValue("C12",$company);
        $objActSheet->getStyle('C12')->getAlignment()->setWrapText(true);
        $objActSheet->getColumnDimension("C12")->setAutoSize(true);
        $style_array = array(
            'borders' => array(
                'allborders' => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN
                )
            )
        );
        $objActSheet->getStyle('A4:D9')->applyFromArray($style_array);
        header('Content-Type: application/vnd.ms-excel');
        //下载的excel文件名称，为Excel5，后缀为xls，不过影响似乎不大
        header('Content-Disposition: attachment;filename="' . $savefile . '.xlsx"');
        header('Cache-Control: max-age=0');
        // 用户下载excel
        $objWriter = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $objWriter->save('php://output');
        exit();
    }

}