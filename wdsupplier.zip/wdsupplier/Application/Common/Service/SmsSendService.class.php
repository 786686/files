<?php
namespace Common\Service;

use AlibabaCloud\Client\AlibabaCloud;
use AlibabaCloud\Client\Exception\ClientException;
use AlibabaCloud\Client\Exception\ServerException;
use Think\Log;

/**
 *
 * @author 建强 2019年11月8日
 * @desc   校园创客  校园创客专属短信  阿里短信发送 升级短信接口
 * @see https://help.aliyun.com/document_detail/102364.html?spm=a2c4g.11186623.2.14.13b13e2ch77uXx
 */
class SmsSendService
{
    /**
     * @desc 秘钥ID
     * @var string
     */
    CONST ACCESSKEYID   =  'LTAI4FiU8PGY3fB6u82UFGQb';
    /**
     * @desc  秘钥
     * @var   string
     */
    CONST ACCESSSECRET  =  'ORwWLFuxH6aFnZwJo1paZuFcC5YpTP';
    
    /**
     * @desc 短信签名 
     * @var  string
     */
    const SIGN_NAME    = '校园创客'  ;
    /**
     * @param string $scense
     * @param $mobile
     * @param string $code
     * 
     * @return array 
     */
    public static function sendSms($mobile,$templateParam,$type= 1){
        $batch_send = 0 ;
        $params = [
            'PhoneNumbers'   => $mobile,
            'SignName'       => self::SIGN_NAME,
            'TemplateCode'   => self::getTemplement($type),
            'TemplateParam'  => json_encode($templateParam),
        ];
        //批量发送
        if(is_array($mobile)){
            $batch_send = 1;
            $count  = count($mobile);
            $params = [
                'PhoneNumberJson'    => json_encode($mobile),
                'SignNameJson'       => json_encode(self::getSumSignArr($count)),
                'TemplateCode'       => self::getTemplement($type),
                'TemplateParamJson'  => json_encode($templateParam),
            ];
        }
        

       AlibabaCloud::accessKeyClient(self::ACCESSKEYID, self::ACCESSSECRET)
           ->regionId('cn-hangzhou')->asGlobalClient();
        return self::doSend($params,$batch_send);
    }
    
    /**
     * @method 群发需要批量模板签名匹配 
     * @param  int 长度
     * @return array 
     */
    protected  static function getSumSignArr($len= 1){
        $arr = [] ;
        for ($i = 0; $i < $len; $i++) {
            $arr[] = self::SIGN_NAME;
        }
        return $arr;
    }
    /**
     * @author 建强 2019年11月8日
     * @method 发送短信
     *
     * @return array
     */
    protected static function doSend(array $param , $batch_send = 0 ){
        try {
            $action = 'SendSms'; 
            if($batch_send == 1) $action = 'SendBatchSms';
            
            $result = AlibabaCloud::rpcRequest()->product('Dysmsapi')
                ->version('2017-05-25')->action($action)->method('POST')
                ->options(['query' => $param])->request();
            
            $ret = $result->toArray();
            
            if(empty($ret) || !is_array($ret))     return ['code'=> 70001,'msg'=>'系统繁忙,请稍后再试'];
            if(strtolower($ret['Code']) !== 'ok')  return ['code'=> 70002,'msg'=>$ret['Message']];
            
            return  ['code'=> 0,'msg'=>'success'] ;
            
        } catch (ClientException $e) {
            return  ['code'=> $e->getCode(),'msg'=>$e->getErrorMessage()];
        } catch (ServerException $e) {
            return  ['code'=> $e->getCode(),'msg'=>$e->getErrorMessage()];
        }
    }
    
    /**
     * @method  获取短信发送模板
     * @author  建强 2019年12月5日 17:43:02
     * @param   $scense int 发送场景  
     * @return  string
     */
    public static function getTemplement($scense = ''){
        
        $templement = [
            //1 =>'SMS_185212283',
            1 =>'SMS_186610283', //支持短信退订
        ];
        return array_key_exists($scense, $templement) ? $templement[$scense] : '';
    }
}