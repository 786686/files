<?php

namespace Common\Service;


class Mail
{
    /**
     * @param $to -收件人
     * @param $title -邮件标题
     * @param $content -邮件内容
     * @return array
     */
    public static function send($to, $title, $content)
    {
        vendor('smtp.phpmailer');
        $mail = new \PHPMailer();
        $mail->IsSMTP(); // 启用SMTP
        $mail->Host = "smtp.163.com"; //SMTP服务器 这里以新浪邮箱为例子
        $mail->Port = 25;  //邮件发送端口
        $mail->SMTPAuth = true;  //启用SMTP认证
        $mail->CharSet = "UTF-8"; //字符集
//        $mail->Encoding = "base64"; //编码方式
        $mail->Username = "";  //企业名字
        $mail->Password = "";  //企业邮箱密码
        $mail->Subject = $title; //邮件标题
        $mail->From = "";  //发件人地址（也就是企业邮箱）
        $mail->FromName = "创课网店";  //发件人姓名
        $mail->AddAddress($to);//添加收件人地址，昵称
        // $mail->AddAttachment("test,zip","重命名附件.zip"); // 添加附件,并重命名
        $mail->IsHTML(true); //支持html格式内容
        $mail->Body = $content; //邮件内容
        //发送
        if (!$mail->Send()) {
            return [
                'status' => 0,
                'msg' => 'error:' . $mail->ErrorInfo
            ];
        } else {
            return [
                'status' => 1,
                'msg' => 'ok'
            ];
        }
    }
}