<?php
/**
 * 微信退款服务
 * User: xiebaozhi
 * Date: 2018/5/31
 * Time: 10:12
 */

namespace Common\Service;


use Common\Model\RefundReloadModel;

class WxpayRefund
{
    protected static $config = array();

    public function __construct($pay='wap_wxpay')
    {
        if($pay=='wap_wxpay'){
            self::$config = C('wxpay');
        }elseif($pay=='app_wxpay'){
            self::$config = C('wxpay_app');
        }
    }

    /**
     * 执行退款任务
     * @param $refundData
     * @return boolean
     */
    public function refund($refundData)
    {
        foreach($refundData as $val){
            //先把退款状态改为退款中
            $saveData = array();
            $saveData['refund_reload_id'] = $val['refund_reload_id'];
            $saveData['refund_reload_status'] = RefundReloadModel::LOADING_REFUND;
            //D('Common/RefundReload')->save($saveData);

            $this->wxBack($val);
        }
        return true;
    }

    /**
     * 微信退款
     *
     */
    protected function wxBack($param){
        //引入微信类库
        vendor('Weixin.WxPayPubHelper');
        //获取微信支付配置
        $wxConfig = $this->getWeipayConfig();
        //输入需退款的订单号
        if (is_null($param["order_sn"]) || is_null($param["refund_amount"]))
        {
            return false;
        }else{
                //开始组装请求数据
                $out_trade_no = $param["order_sn"];
                $amount_order = $param['order_amount']*100;
                $refund_fee = $param["refund_amount"]*100;   //退款单位为分
                //商户退款单号，商户自定义，此处仅作举例
                $out_refund_no = $param['refund_reload_sn'];
                //使用退款接口
                $refund = new \Refund_pub($wxConfig);
                //设置必填参数
                //appid已填,商户无需重复填写
                //mch_id已填,商户无需重复填写
                //noncestr已填,商户无需重复填写
                //sign已填,商户无需重复填写
                $refund->setParameter("out_trade_no",$out_trade_no);//商户订单号
                $refund->setParameter("out_refund_no",$out_refund_no);//商户退款单号
                $refund->setParameter("total_fee",$amount_order);//总金额
                $refund->setParameter("refund_fee",$refund_fee);//退款金额
                $refund->setParameter("op_user_id",$wxConfig['MCHID']);//操作员，默认为商户号
                //非必填参数，商户可根据实际情况选填
                //$refund->setParameter("sub_mch_id","XX");     //子商户号
                //$refund->setParameter("device_info","XX");    //设备号
                //$refund->setParameter("transaction_id","XX"); //微信订单号
            $request = $refund->getParameter();	//获得请求参数
            try{
                //调用结果
                $respond = $refund->getResult();
                //商户根据实际情况设置相应的处理流程,此处仅作举例
                //var_dump($refundResult);exit;
                //$respond = serialize($refundResult);			//获得微信响应结果

                $saveData = array();
                $saveData['refund_request_param'] = json_encode($request);
                $saveData['refund_response_param'] = json_encode($respond);
                $saveData['refund_reload_time'] = date('Y-m-d H:i:s');
                $saveData['refund_reload_id'] = $param['refund_reload_id'];

                if($respond['return_code']=='SUCCESS' && $respond['result_code']=='SUCCESS'){
                    $saveData['refund_reload_status'] = RefundReloadModel::FISHED_REFUND;
                    $saveData['refund_respose_info'] = '退款成功';
                }else{
                    $saveData['refund_reload_status'] = RefundReloadModel::FAIL_REFUND;
                    $saveData['refund_respose_info'] = $respond['err_code_des'];
                }

                D('Common/RefundReload')->save($saveData);
            }catch (\Exception $e){
                //var_dump($e->getMessage());exit;
                $saveData = array();
                $saveData['refund_request_param'] = json_encode($request);
                $saveData['refund_reload_time'] = date('Y-m-d H:i:s');
                $saveData['refund_reload_id'] = $param['refund_reload_id'];
                $saveData['refund_reload_status'] = RefundReloadModel::FAIL_REFUND;
                $saveData['refund_respose_info'] = $e->getMessage();
                D('Common/RefundReload')->save($saveData);
            }

            return true;
        }
    }

    protected function getWeipayConfig()
    {
        return array(
            'APPID'=>self::$config['appid'],
            'MCHID'=>self::$config['mchid'],
            'KEY'=>self::$config['partnerkey'],
            'SSLCERT_PATH'=>self::$config['sslcert_path'],
            'SSLKEY_PATH'=>self::$config['sslkey_path'],
        );
    }


}