<?php
/**
 * 支付宝退款服务
 * User: xiebaozhi
 * Date: 2018/5/31
 * Time: 16:01
 */

namespace Common\Service;


use Common\Model\RefundReloadModel;
use mobile\Controller\AlipaySubmit;

class AlipayRefund
{
    /**
     * 有密退款，不用，留着而已
     * @param $refundData
     * @return bool
     */
    public function refund($refundData)
    {
        foreach ($refundData as $val){
            //先把退款状态改为退款中
            $saveData = array();
            $saveData['refund_reload_id'] = $val['refund_reload_id'];
            $saveData['refund_reload_status'] = RefundReloadModel::LOADING_REFUND;
            //D('Common/RefundReload')->save($saveData);

            //开始组装数据
            $nowTime = time();
            require_once(APP_PATH."Mobile/Common/alipay/alipay.config.php");
            require_once(APP_PATH."Mobile/Common/alipay/lib/alipay_submit.class.php");
            $param['service'] = 'refund_fastpay_by_platform_pwd';
            $param['partner'] = $alipay_config['partner'];
            $param['_input_charset'] = $alipay_config['input_charset'];
            $param['sign_type'] = $alipay_config['sign_type'];
            $param['notify_url'] = C('WEBSITE_URL').U('Api/RefundReload/alipayRefundNotifyUrl');
            $param['seller_email'] = C('alipay.account');
            $param['seller_user_id'] = $alipay_config['partner'];
            $param['refund_date'] = date('Y-m-d H:i:s',$nowTime);
            $param['batch_no'] = $val['refund_reload_sn'];
            $param['batch_num'] = 1;
            $param['detail_data'] = $val['pay_sn'].'^'.$val['refund_amount'].'^'.'协商退款';
            $alipaySubmit = new AlipaySubmit($alipay_config);
            $requestParam = $alipaySubmit->buildRequestPara($param);
            $url = $alipaySubmit->alipay_gateway_new.http_build_query($requestParam);

            header('location:'.$url);
        }

        return true;
    }

    /**
     * 无密退款
     * @param $refundData
     * @return bool
     */
    public function refundNoPwd($refundData)
    {
        Vendor('alipay-sdk-PHP.aop.AopClient');
        Vendor('alipay-sdk-PHP.aop.SignData');
        Vendor('alipay-sdk-PHP.aop.request.AlipayTradeRefundRequest');
        foreach ($refundData as $val) {
            //先把退款状态改为退款中
            $saveData = array();
            $saveData['refund_reload_id'] = $val['refund_reload_id'];
            $saveData['refund_reload_status'] = RefundReloadModel::LOADING_REFUND;
            //D('Common/RefundReload')->save($saveData);

            //开始组装数据
            $nowTime = time();

            //构造要请求的参数数组，无需改动
            $aop = new \AopClient ();
            $aop->appId = trim(C('alipay.appid'));
            $aop->rsaPrivateKey = C('alipay.private_key');
            $aop->alipayrsaPublicKey = C('alipay.alipay_public_key');
            $aop->signType =    strtoupper('RSA2');
            $aop->postCharset = strtolower('utf-8');
            $aop->format = 'json';
            $request = new \AlipayTradeRefundRequest ();

            $param = array(
                'trade_no' => $val['pay_sn'],
                'refund_amount' => $val['refund_amount'],
                'refund_reason' => '正常退款',
                'out_request_no' => $val['refund_reload_sn'],
            );

            try {
                $request->setBizContent(json_encode($param));
                $result = $aop->execute($request);

                $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
                $resultCode = $result->$responseNode->code;

                //保存退款结果
                $saveData = array();
                $saveData['refund_request_param'] = json_encode($aop->requestParam);
                $saveData['refund_response_param'] = json_encode($result->$responseNode);
                $saveData['refund_reload_time'] = date('Y-m-d H:i:s');
                $saveData['refund_reload_id'] = $val['refund_reload_id'];
                if (!empty($resultCode) && $resultCode == 10000) {
                    $saveData['refund_reload_status'] = RefundReloadModel::FISHED_REFUND;
                    $saveData['refund_respose_info'] = '退款成功';
                }else{
                    $saveData['refund_reload_status'] = RefundReloadModel::FAIL_REFUND;
                    $saveData['refund_respose_info'] = $result->$responseNode->sub_msg;
                }

                D('Common/RefundReload')->save($saveData);
            } catch (\Exception $e) {
                //var_dump($e->getMessage());exit;
                $response = $aop->responseParam->alipay_trade_refund_response;
                $saveData = array();
                $saveData['refund_request_param'] = json_encode($aop->requestParam);
                $saveData['refund_response_param'] = json_encode($aop->responseParam);
                $saveData['refund_reload_time'] = date('Y-m-d H:i:s');
                $saveData['refund_reload_id'] = $val['refund_reload_id'];
                $saveData['refund_reload_status'] = RefundReloadModel::FAIL_REFUND;
                if($response->sub_msg){
                    $saveData['refund_respose_info'] = $response->sub_msg;
                }else{
                    $saveData['refund_respose_info'] = $e->getMessage();
                }

                D('Common/RefundReload')->save($saveData);
            }
        }

        return true;
    }

//    /**
//     * 支付宝回调处理
//     */
//    public function alipayRefundNotifyUrl()
//    {
//        require_once(APP_PATH."Mobile/Common/alipay/alipay.config.php");
//        require_once(APP_PATH."Mobile/Common/alipay/lib/alipay_notify.class.php");
//        $requestData = I();
//        $saveData = array();
//        $saveData['refund_response_param'] = json_encode($requestData);
//        $where['refund_reload_sn'] = $requestData['refund_batch_no'];
//        $alipayNotify = new AlipayNotify($alipay_config);
//        $verify_result = $alipayNotify->verifyNotify();
//        if($verify_result===true && isset($requestData['status'])
//            && $requestData['status']==='S')
//        {
//            $saveData['refund_reload_status'] = RefundReloadModel::FISHED_REFUND;
//            $saveData['refund_respose_info'] = '退款成功';
//        }else{
//            $saveData['refund_reload_status'] = RefundReloadModel::FAIL_REFUND;
//            $saveData['refund_respose_info'] = '退款失败';
//        }
//        D('Common/RefundReloadModel')->where($where)->save($saveData);
//
//        return true;
//    }
//
//    /**
//     * 将xml转为array
//     * @param string $xml
//     * @return throws WxPayException
//     */
//    public function FromXml($xml)
//    {
//        libxml_disable_entity_loader(true);
//        return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
//    }
}