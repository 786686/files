<?php
/**
 * 退款回调通知结果服务
 * User: xiebaozhi
 * Date: 2018/5/31
 * Time: 15:21
 */

namespace Common\Service;

use Common\Model\RefundReloadModel;

Vendor('Wxpay.Wxpay#Notify');

class WxpayRefundNotify extends \WxPayNotify
{
    protected $result;
    //查询订单
    public function Queryorder($transaction_id)
    {
        Vendor('Wxpay.Wxpay#Data');
        Vendor('Wxpay.Wxpay#Api');
        Vendor('Wxpay.Wxpay#Config');
        $input = new \WxPayOrderQuery();
        $input->SetTransaction_id($transaction_id);
        $result = \WxPayApi::orderQuery($input);

        //结果记录保存
        $this->result['query'] = $result;
        $this->saveRefundReload();
        if(array_key_exists("return_code", $result)
            && array_key_exists("result_code", $result)
            && $result["return_code"] == "SUCCESS"
            && $result["result_code"] == "SUCCESS")
        {
            return true;
        }
        return false;
    }

    //重写回调处理函数
    public function NotifyProcess($data, &$msg)
    {
        $this->result['notify'] = $data;

        if(!array_key_exists("transaction_id", $data)){
            return false;
        }
        //查询订单，判断订单真实性
        if(!$this->Queryorder($data["transaction_id"])){
            return false;
        }
        return true;
    }

    protected function saveRefundReload()
    {
        $saveData = array();
        $saveData['refund_response_param'] = json_encode($this->result);
        $where['refund_reload_sn'] = $this->result['query']['out_refund_no_0'];
        if(array_key_exists("return_code", $this->result['query'])
            && array_key_exists("result_code", $this->result['query'])
            && $this->result['query']["return_code"] == "SUCCESS"
            && $this->result['query']["result_code"] == "SUCCESS")
        {
            $saveData['refund_reload_status'] = RefundReloadModel::FISHED_REFUND;
            $saveData['refund_respose_info'] = '退款成功';
        }else{
            $saveData['refund_reload_status'] = RefundReloadModel::FAIL_REFUND;
            $saveData['refund_respose_info'] = isset($this->result['query']['err_code_des']) ?
            $this->result['query']['err_code_des'] : $this->result['query']['return_msg'];
        }
        D('Common/RefundReload')->where($where)->save($saveData);
    }
}