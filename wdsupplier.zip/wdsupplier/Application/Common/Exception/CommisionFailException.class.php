<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/3/27
 * Time: 11:21
 */

namespace Common\Exception;


class CommisionFailException extends \Exception
{
    protected $message = '分佣失败';
}