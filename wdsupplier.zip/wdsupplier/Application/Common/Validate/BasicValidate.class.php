<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/11/28
 * Time: 15:40
 */

namespace Common\Validate;

use Common\Lib\Validate;

/**
 * 验证基类
 *
 * @desc 继承此类来做参数验证的操作
 *
 * @example 查看使用范列  \Mobile\Controller\AppointController::makeAppoint
 *
 * @package Common\Validate
 */
class BasicValidate extends Validate
{
    /**
     * @param $params
     * @param $scene string 场景
     * @return bool
     * @throws \Think\Exception
     */
    public function goCheck($params, $scene = '')
    {
        $result = false;

        if (count($params) == count($params, 1)) {
            if (!empty($scene)) {
                $result = $this->scene($scene)->check($params);
            } else {
                $result = $this->check($params);
            }

        } else {
            foreach ($params as $param) {
                if (!empty($scene)) {
                    $result = $this->scene($scene)->check($params);
                } else {
                    $result = $this->check($param);
                }
            }
        }

        // 当为false时，获取error，通过实例化的对象 $validate->getError();
        return $result;
    }


    /**
     * 正整数验证
     *
     * @param $value
     * @param string $rule
     * @param string $data
     * @param string $field
     *
     * @return bool
     */
    protected function isPositiveInteger($value, $rule = '', $data = '', $field = '')
    {
        if ($value && is_numeric($value) && is_int($value + 0) && ($value + 0) > 0) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 非空验证
     * @param $value
     * @param string $rule
     * @param string $data
     * @param string $field
     *
     * @return bool
     */
    protected function isNotEmpty($value, $rule = '', $data = '', $field = '')
    {
        if (!empty($value)) {
            return true;
        } else {
            return false;
        }
    }

    // 参数未 整形的 的数组, 如： [1, 2, 3]
    public function isIdArr($value, $rult = "", $date = '', $field = '')
    {

        $flat = true;
        if (is_array($value) && !empty($value)) {
            foreach ($value as $id) {
                if (!$flat) {
                    break;
                }

                if (is_numeric($id) && is_int($id + 0) && ($id + 0) > 0) {
                    continue;
                } else {
                    $flat = false;
                }
            }
        } else {
            $flat = false;
        }

        return $flat;
    }
}