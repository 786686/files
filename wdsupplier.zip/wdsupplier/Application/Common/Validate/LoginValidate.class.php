<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/5/22
 * Time: 10:34
 */

namespace Common\Validate;

class LoginValidate extends BasicValidate
{

    //验证规则
    protected $rule = [
        'username' => 'require|is_username',
        'password' => 'require',
        'secode'   => 'require'
    ];

    //描述信息
    protected $message = [
        'username.require' => '用户名不能为空',
        'password.require' => '密码不能为空',
    ];


    /**
     * 检查用户名是否符合规定（ 3-20位英文数字组成）
     *
     * @param STRING $username 要检查的用户名
     * @return 	TRUE or FALSE
     */
    function is_username($username) {
        $strlen = strlen($username);
        if (is_badword($username) || !preg_match("/^[a-zA-Z0-9_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]+$/", $username)) {
            return '用户名必须由3-20位英文或数字组成';
        } elseif ( 20 < $strlen || $strlen < 3 ) {
            return '用户名必须由3-20位英文或数字组成';
        }
        return true;
    }
}