<?php
/**
 * 花名册部门Model
 * User: yangjiyang
 * Date: 2018/8/20
 * Time: 20:29
 */

namespace Common\Model;


use Think\Model;

class CompanyRosterDepartmentModel extends Model
{
    /**
     * 获取部门id，如果不存在则添加
     * @param $departmentName
     * @param $companyId
     * @return mixed
     */
    public function getDepartmentIdByDepartmentNameAndCompanyId($departmentName,$companyId)
    {
        $departmentId = $this->where(['department_name' => $departmentName, 'company_id' => $companyId])->getField('id');
        if (empty($departmentId)){
            $departmentId = $this->addDepartmentByDepartmentNameAndCompanyId($departmentName,$companyId);
        }
        return $departmentId;
    }

    /**
     * 添加部门
     * @param $departmentName
     * @param $companyId
     * @return mixed
     */
    public function addDepartmentByDepartmentNameAndCompanyId($departmentName,$companyId)
    {
        $data = [
            'company_id' => $companyId,
            'department_name' => $departmentName,
        ];
        return $this->add($data);
    }

}