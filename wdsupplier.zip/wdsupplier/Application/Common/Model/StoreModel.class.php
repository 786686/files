<?php
/**
 * 网店模型
 * @author wuxiao 2017-3-30
 */
namespace Common\Model;
use Think\Model;
use OSS\OssClient;

class StoreModel extends Model {
    const FIELD_STORE_LIST = 'st.store_id,st.store_name,st.store_img,st.address,st.store_img,st.store_state,st.store_phone,st.store_story,st.level,st.ad_img';
	public $type=array('0'=>'优惠','1'=>'包邮');
    public $store_category=array('0'=>'食品类','1'=>'电器类');
    /*
		获取超市列表
		wuxiao
	 */
	public function getList($parm=array(), $ossClient)
	{
        if(empty($ossClient)){
            include_once(OssClient);
            $ossClient = new OssClient(C('aliyun.accessKeyId'), C('aliyun.accessKeySecret'), C('aliyun.oss_endpoint'));
        }
		$where['st.store_state'] = 1;		// Default: 正常状态
        if(!empty($parm['town_id'])){
            $deep=M('area')->where('area_id='.$parm['town_id'])->getField('area_deep');
            if($deep=='3') $where['district_id']=$parm['town_id'];
            else $where['town_id']=$parm['town_id'];
        }
        if(!empty($parm['level'])) $where['st.level']=$parm['level'];
        if(!empty($parm['keyword'])) $where['store_name|address']=array('like','%'.$parm['keyword'].'%');
        if(!empty($parm['is_spread'])) $where['is_spread']=$parm['is_spread'];
        if(!empty($parm['notin_store_id'])&&is_array($parm['notin_store_id'])&&!empty($parm['notin_store_id'])) $where['st.store_id']=array('not in',$parm['notin_store_id']);
        //如果传入父级商店id,查找子超市
        if(!empty($parm['parent_id'])){
            $point_parent_id=M('store')->where('store_id='.$parm['parent_id'])->getField('point_id');
            $store_ids=M('store')->field('st.store_id')->alias('st')->join('__POINT__ as po on st.point_id=po.point_id')->where('po.point_parent_id='.$point_parent_id)->order('store_sort asc')->select();
            if(!empty($store_ids)){
                foreach($store_ids as $store){
                    $instores[]=$store['store_id'];
                }
                $where['st.store_id']=array('in',$instores);
            }else{
                return array();
            }
        }
        $sort= empty($parm['sort']) ? 'store_sort asc'  : $parm['sort'];
        $field= empty($parm['field']) ? self::FIELD_STORE_LIST  : $parm['field'];
        $parm['page'] = $parm['page'] ?? 1;
        $parm['rows'] = $parm['rows'] ?? 10;
        $limit = sprintf('%d,%d', ($parm['page'] ? ($parm['page'] - 1) : 0) * $parm['rows'], $parm['rows']);
        //我的关注搜索
        if(isset($parm['is_follow']) && $parm['is_follow'] == 1){
	        $where['m.member_id'] = $parm['member_id'];
	        $where['m.is_follow'] = 1;
	        $storeList=$this
		        ->alias('st')
		        ->join("left join __MEMBER_STORE__ m on m.store_id = st.store_id")
		        ->where($where)
		        ->limit($limit)
		        ->field($field)
		        ->order($sort)
		        ->select();
        }else{
	        $storeList=$this->alias('st')->where($where)->limit($limit)->field($field)->order($sort)->select();
        }

        $result = [];
		//如果传入附带商品个数
        foreach ($storeList as $key => $store) {
            if($store['store_id'] == C('company_store_id')){
                //屏蔽企业超市
                unset($storeList[$key]);
                continue;
            }
            $storeList[$key]['thank_store_txt']=$store['store_name']."感谢您对扶贫事业的支持";
            $storeList[$key]['store_discount_info']=$this->getDiscountInfo($store['store_id']);
            $storeList[$key]['store_img']=$ossClient->signUrl(C('aliyun.bucket'), $store['store_img'], 3600);
            $storeList[$key]['url']=$this->getDetailUrl($store['store_id']);
            $storeList[$key]['bind_num']=M('member_store')->where(array('store_id'=>$store['store_id']))->count();
       		$storeList[$key]['goodsList']=array();
       		if(!empty($parm['goods_num'])){
                $goodsModel=D('Goods');
        		$storeList[$key]['goodsList']=$goodsModel->getList(['store_id'=>$store['store_id']],'0,'.$parm['goods_num'],$goodsModel::FIELD_GOODS_LIST,'common_desc',$ossClient);
            }
            $result[] = $storeList[$key];
        }
		return $result;
	}
    public function getDiscountInfo($store_id){
        $type = $this->type;
        $list = M('StoreDiscountInfo')->field('type,info')->where(array('store_id'=>$store_id))->order('create_time desc')->limit(2)->select();
        foreach($list as $k=>$v){
            $list[$k]['type_txt'] = $type[$v['type']];
        }
        return $list;
    }

    /**
     * @param array $where
     * @param string $field
     * @return mixed
     * 获取商品信息
     */
    public function getInfo($where = array(), $field = '*', $ossClient)
    {
        $info=$this->where($where)->field($field)->find();
        if($info['bg_img']=='') {
            $info['bg_img']='/Public/Mobile/images/default_store_bg.png';
        } else {
            $info['bg_img']=$ossClient->signUrl(C('aliyun.bucket'), $info['bg_img'], 3600);
        }
        $info['store_img']=!empty($info['store_img']) ? $ossClient->signUrl(C
        ('aliyun.bucket'),$info['store_img'], 3600): '';
        if(!empty($info['qrcode'])){
            $info['qrcode']=$ossClient->signUrl(C('aliyun.bucket'), $info['qrcode'], 3600);
        }
        $store_banner = M("store_banner")->where(array('store_id'=>$where['store_id']))->select();
        foreach($store_banner as $key=>$storeimg){
            $store_banner[$key]['banner_img']=!empty($storeimg['banner_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $storeimg['banner_img'], 3600) : '';
        }
        $info['createtime']=date('Y-m-d H:i:s', $info['createtime']);
        $store_category=$this->store_category;
        $info['store_category']=$info['store_scope'];
        $info['store_banner']=$store_banner;
        return $info;
    }


    /**
    扫码公司绑定事件
     */
    public function bindAction($parm = array())    {
        $member_id=$parm['member_id'];
        $company_member_id=$parm['company_member_id'];
        $company_id=M('company_auth')->where(array('member_id'=>$company_member_id,'status'=>1))->order('id desc')->getField('id');
        if(empty($company_id)){
            return ;
        }
        $store_list_old=M('member_store')->where(array('member_id'=>$member_id))->field('store_id')->select();//用户已绑定的网店
        $store_list_old_array=array();
        foreach($store_list_old as $key=>$value){
            $store_list_old_array[]=$value['store_id'];
        }
        $store_list_old_array=(empty($store_list_old_array))?'':$store_list_old_array;
        $store_list=M('member_store')->where(array('member_id'=>$company_member_id,'store_id'=>array('NOT IN',$store_list_old_array)))->field('store_id')->select();
        foreach($store_list as $key=>$value){
            M('member_store')->add(array('member_id'=>$member_id,'store_id'=>$value['store_id']));
        }
        $memberAuthInfo=M('member_auth')->where(array('member_id'=>$member_id,'status'=>1))->find();
        if(empty($memberAuthInfo)){
            $addData['member_id']=$member_id;
            $addData['company_id']=$company_id;
            $addData['status']=1;
            $addData['create_time']=time();
            M('member_auth')->add($addData);
        }
    }


    /**
    扫码绑定超市事件
     */
    public function bindOnlyStoreAction($parm = array())    {
        $member_id=$parm['member_id'];
        $bind_store_id=$parm['bind_store_id'];
        $addwhere=array('member_id'=>$member_id,'store_id'=>$bind_store_id);
        $ishas=M('member_store')->where($addwhere)->find();
         if(!$ishas) M('member_store')->add($addwhere);
    }



    public function getFullImg($img){
        return C('WEBSITE_URL').'/'.$img;
    }

    public function getDetailUrl($store_id){
        return C('WEBSITE_URL').'/index.php/Mobile/Store/StoreDetail/store_id/'.$store_id;
    }
    /**
     * [getStoreAnnouncement 根据超市ID获取对应超市公告]
     * @param  [type] $store_id [description]
     * @return [type]           [description]
     */
    public function getStoreAnnouncement($store_id){
        $list = M('Announcement')->field('a_id,a_comment,a_url')->where(array('store_id'=>$store_id,'is_delete'=>0,'a_visible'=>1))->select();
        foreach ($list as $key => $value) {
            $list[$key]['a_url']=getFullUrl('/Mobile/Index/headNews/id/'.$value['a_id']);
        }
        return $list;
    }
    /**
     * [getStoreSpecial 获取商店专区]
     * @param  [type] $store_id [description]
     * @return [type]           [description]
     */
    public function getStoreSpecial($store_id){
        $list = M('Special')->field('s_id,s_title,s_img,s_type')->where(array('store_id'=>$store_id,'s_state'=>1))->select();
        foreach($list as $k=>$v){
            $list[$k]['s_img']=$this->getFullImg($v['s_img']);
            if($v['s_type'] == 3){
                //团购专区
                $list[$k]['url']=C('WEBSITE_URL').U('Mobile/Store/group_purchase?s_id='.$v['s_id']);
            }
            else{
                //普通专区
                $list[$k]['url']=C('WEBSITE_URL').U('Mobile/Store/special_region?s_id='.$v['s_id']);
            }
        }
        return $list;
    }
    /**
     * [getStoreRate 根据商店获取好评率，每次评论都是五分，如果商店没有商品没有评论默认100%好评]
     * @param  [type] $store_id [description]
     * @return [type]           [description]
     */
    public function getStoreRate($store_id){
        $where['b.buy_store_id'] = $store_id;
        $where['a.comment_star'] = array('in','4,5');   //4星和5星为好评
        $stotal = M('GoodsComment')
                ->alias('a')
                ->join('left join __ORDER_GOODS__ b on a.comment_order_id=b.order_id')
                ->where($where)
                ->count();
        $count = M('GoodsComment')
                ->alias('a')
                ->join('left join __ORDER_GOODS__ b on a.comment_order_id=b.order_id')
                ->where(array('b.buy_store_id'=>$store_id))
                ->count();
        if($count>0){
            $rate = sprintf('%.2f%%',$stotal/$count*100);
        }else{
            $rate = sprintf('%.2f%%',1*100);
        }
        return $rate;
    }
    /**
     * [getStoreAndChildStore 获取商店以及商店的子类商店]
     * @return [type] [description]
     */
    public function getStoreAndChildStore($parm=array()){
        if(!empty($parm['town_id'])){
            $deep=M('area')->where('area_id='.$parm['town_id'])->getField('area_deep');
            if($deep=='3') $where['district_id']=$parm['town_id'];
            else $where['town_id']=$parm['town_id'];
        }
        if(!empty($parm['level'])) $where['level']=$parm['level'];
        if(!empty($parm['level'])) $order=$parm['order'];

        $limit = sprintf('%d,%d', ($parm['page'] ? ($parm['page'] - 1) : 0) * $parm['rows'], $parm['rows']);
        if( !empty($parm['in_store_id']) )  $where['store_id']=array('in',$parm['in_store_id']);
        if( !empty($parm['not_in_store_id']) )  $where['store_id']=array('not in',$parm['not_in_store_id']);
        $where['store_state'] = 1;      // Default: 正常状态
        //取出一级商店
        $level_1_town_data=M('point')->where(array('level'=>1))->field('point_id')->select();
        $level_1_town_ary=array();
        foreach($level_1_town_data as $key=>$value){
            $level_1_town_ary[]=$value['point_id'];
        }
        $where['point_id'] = array('in',$level_1_town_ary);
        $model = M('Store');
        $list = $model->field('store_id,store_name,ad_img,store_img,town_id,point_id')->where($where)->order('store_sort asc,store_id asc')->limit($limit)->select();
        $goodsModel=D('Goods');
        $result = [];
        foreach($list as $k=>$v){
            if($v['store_id'] == C('company_store_id')){
                //屏蔽企业超市
                unset($list[$k]);
                continue;
            }
            $list[$k]['store_img'] = $this->getFullImg($v['store_img']);
            if(empty($v['ad_img'])){
                $list[$k]['ad_img']=$list[$k]['store_img'];
            }else{
                $list[$k]['ad_img']=$this->getFullImg($v['ad_img']);
            }
            $list[$k]['url']=$this->getDetailUrl($v['store_id']);
            //获取网店商品
            if(!empty($parm['goods_num'])){
                $list[$k]['goodsList']=$goodsModel->getList(['store_id'=>$v['store_id']],'0,'.$parm['goods_num'],$goodsModel::FIELD_GOODS_LIST,$order);
            }
            $sql='SELECT store_id,store_name,store_img FROM sx_store WHERE store_state=1 AND point_id IN(SELECT point_id FROM sx_point WHERE point_parent_id="'.$v['point_id'].'")';
            $child_store = M()->query($sql);
            foreach ($child_store as $k1 => $v1) {
                $child_store[$k1]['store_img']=$this->getFullImg($v1['store_img']);
                $child_store[$k1]['url']=$this->getDetailUrl($v1['store_id']);
                //获取网店商品
                if(!empty($parm['goods_num'])){
                    $child_store[$k1]['goodsList']=$goodsModel->getList(['store_id'=>$v1['store_id']],'0,'.$parm['goods_num'],$goodsModel::FIELD_GOODS_LIST,$order);
                }
            }
            $list[$k]['child_store'] = $child_store;
            $result[] = $list[$k];
        }
        return $result;
    }
    /**
     * [getRecommendGoods 获取镇店之宝推荐商品]
     * @param  array  $parm [description]
     * @return [type]       [description]
     */
    public function getRecommendGoods($parm=array(), $ossClient){
        $where['o.store_id'] = $parm['store_id'];
        $where['o.goods_state'] = 1;  //上架商品
        $where['o.is_recommend'] = 1; //推荐商品
        $where['r.type'] = 0; //推荐商品
        $list = M('Goods')->alias('o')
            ->join('LEFT JOIN __GOODS_PRICE__ AS r ON o.goods_id = r.goods_id')
            ->field('o.goods_id,r.price as goods_price,o.goods_name,o.goods_img,o.goods_salenum')
            ->where($where)
            ->limit(6)
            ->select();
        foreach($list as $k=>$v){
            $list[$k]['url'] = C('WEBSITE_URL').'/Mobile/Store/storeGoodDetail/s/1/goods_id/'.$v['goods_id'];
            $list[$k]['goods_img'] = $ossClient->signUrl(C('aliyun.bucket'), $v['goods_img'], 3600);
        }
        return $list;
    }
    /**
     * [getStoreParent 获取商店上级网店名称，如果是第一级则返回自身名称]
     * @param  array  $parm [description]
     * @return [type]       [description]
     */
    public function getStoreParent($parm=array()){
        if($parm['store_parent_id'] == 0){
            return $parm['store_name'];
        }
        return M('Store')->where(array('store_id'=>$parm['store_parent_id']))->getField('store_name');
    }
    /**
     * [getStoreParent 获取商店上级网店名称，如果是第一级则返回自身名称,根据村委对应关系来取]
     * @param  array  $parm [description]
     * @return [type]       [description]
     */
    public function getPointParent($parm=array()){
        if($parm['point_id'] == 0){
            return $parm['store_name'];
        }else{
            if(M('point')->where(array('point_id'=>$parm['point_id']))->getField('point_parent_id') == 0){
                return $parm['store_name'];
            }else{
                $point_parent = M('point')->where(array('point_id'=>$parm['point_id']))->getField('point_parent_id');
                return M('Store')->where(array('point_id'=>$point_parent))->getField('store_name');
            }
        }
    }
    /**
     * [getSpecialGoods 获取商店专题商品]
     * @return [type] [description]
     */
    public function getSpecialGoods($parm=array()){
        $info = M('Special')->field('s_id,s_img,s_title')->where(array('s_state'=>1,'s_id'=>$parm['s_id']))->find();
        if(empty($info)){
            return array('s_img'=>'','info'=>'');
        }
        $info['s_img'] = $this->getFullImg($info['s_img']);
        $modelGoods     = D('Goods');
        $subgoods_list = M('SpecialGoods')
            ->alias('sp')
            ->join('__GOODS__ as go on sp.goods_id=go.goods_id')
            ->field('go.goods_id,go.goods_spec_id')
            ->where(array('sp.s_id'=>$info['s_id']))
            ->order('sp.sg_sort asc,go.goods_id desc')
            ->select();
        foreach ($subgoods_list as $kk => &$vv) {
            $vv=$modelGoods->getListDetail(['goods_id'=>$vv['goods_id'],'goods_spec_id'=>$vv['goods_spec_id']]);
            //商品合法性校验
            $checkState=$modelGoods->checkStateToBuyByInfo($vv);
            if($checkState['code']!=1){
                unset($subgoods_list[$kk]);
                continue;
            }
            //如果要取出团购商品时，需要把商品的团购信息取出来
            if($parm['is_group_purchase'] == 1){
                $specialInfo = M('GoodsGroupPurchase')->where(array('goods_id'=>$vv['goods_id']))->find();
                if(empty($specialInfo)){
                    unset($subgoods_list[$kk]);
                    continue;
                }
                //覆盖之前商品详情的url
                $vv['url'] = C('WEBSITE_URL').'/Mobile/Store/group_detail/goods_id/'.$vv['goods_id'].'/buy_store_id/'.$vv['store_id'];
            }
        }
        $subgoods_list=array_merge($subgoods_list);
        $info['info']= $subgoods_list;
        return $info;
    }

    /**
     * [getSpecialGroupGoods 获取超市团购专题商品（新）]
     * @return [type] [description]
     */
    public function getSpecialGroupGoods($parm=array()){
        $limit = sprintf('%d,%d', ($parm['page'] ? ($parm['page'] - 1) : 0) * $parm['rows'], $parm['rows']);
        $info = M('Special')->field('s_id,s_img,s_title')->where(array('s_state'=>1,'s_id'=>$parm['s_id']))->find();
        if(empty($info)){
            return [
                's_img' => '',
                'info' => ''
            ];
        }
        $info['s_img'] = $this->getFullImg($info['s_img']);
        $modelGoods     = D('Goods');
        $map['sp.s_id'] = $info['s_id'];
        $map['go.goods_state'] = 1;
        $subgoods_list = M('SpecialGoods')
            ->alias('sp')
            ->join('__GOODS__ as go on sp.goods_id=go.goods_id')
            ->join('__GOODS_GROUP_PURCHASE__ as ggp on ggp.goods_id=go.goods_id')
            ->field('go.goods_id,go.goods_spec_id,ggp.start_time,ggp.end_time,sp.sg_sort')
            ->where($map)
            ->order('sp.sg_sort asc,ggp.end_time desc,go.goods_id desc')
            ->limit($limit)
            ->select();
        foreach ($subgoods_list as $kk => &$vv) {
            $sg_sort = $vv['sg_sort'];
            //状态
            if($vv['start_time'] > time()){
                $status = '活动未开始';
            }
            if($vv['end_time'] < time()){
                $status = '活动已结束';
            }
            if($vv['end_time'] >= time() && $vv['start_time'] <= time()){
                $status = '去拼团';
            }
            $start_time = date('Y-m-d H:i:s', $vv['start_time']);
            $end_time = date('Y-m-d H:i:s', $vv['end_time']);
            $vv = $modelGoods->getListDetail(['goods_id'=>$vv['goods_id'],'goods_spec_id'=>$vv['goods_spec_id']]);
            //商品合法性校验
            $checkState = $modelGoods->checkStateToBuyByInfo($vv);
            if($checkState['code']!=1){
                unset($subgoods_list[$kk]);
                continue;
            }
            $vv['sg_sort'] = $sg_sort;
            $vv['start_time'] = $start_time;
            $vv['end_time'] = $end_time;
            $vv['status'] = $status;
            $vv['url'] = C('WEBSITE_URL').'/Mobile/Store/group_detail/goods_id/'.$vv['goods_id'].'/buy_store_id/'.$vv['store_id'];
        }
        $subgoods_list = array_merge($subgoods_list);
        $info['info'] = $subgoods_list;
        return $info;
    }


    /**
     *  根据网店名称获取网店相关信息
     * @param $storeName
     * @return array|bool|mixed
     */
    public function getStoreInfoByStoreName($storeName){
        if(empty($storeName)){
            return false;
        }
        $where = [];
        $where['store_name'] = $storeName;
        $result = M('store')->where($where)->find();
        return empty($result) ? [] : $result;
    }

    /**
     *  去网店系数表里面根据要求获取不一样的网店排序
     * @param $order
     * @param $limit
     * @return array
     */
    public function getStoreLists($order,$limit){
        if(empty($order) || empty($limit)){
            return false;
        }
        $storeList = M('store_coefficient')
            ->alias('sc')
            ->field('s.store_id,s.store_number,store_name,ad_img,store_img')
            ->join('left join __STORE__ s on s.store_id = sc.store_id')
            ->where(['sc.delect_time'=>['exp','is null'],'s.store_state'=>'1'])
            ->order($order)
            ->limit($limit)
            ->select();
        return empty($storeList) ? [] : $storeList;
    }


    /**
     *  根据网店编号获取对应的网店列表
     * @param $storeNumberArray
     * @return array
     */
    public function getStoreListsByStoreNumber($storeNumberArray){
        if(empty($storeNumberArray) || !is_array($storeNumberArray)){
            return false;
        }
        $storeList = [];
        foreach($storeNumberArray as $value){
            $where['store_state'] = '1';
            $where['store_number'] = $value;
            $storeList[] = M('store')
                ->field('store_id,store_number,store_name,ad_img,store_img')
                ->where($where)
                ->find();
        }

        return empty($storeList) ? [] : $storeList;

    }


    /**
     *  获取网店以及商品信息
     * @param $list
     * @return array
     */
    public function getStoreAndGoods($list,$parm, $ossClient){
        $goodsModel=D('Goods');
        $result = [];
        foreach($list as $k => $v){

            if(empty($v['ad_img'])){
                $list[$k]['ad_img'] = $list[$k]['store_img'];
            }else{
                $list[$k]['ad_img'] = $ossClient->signUrl(C('aliyun.bucket'), $v['ad_img'], 3600);
            }
            $list[$k]['store_img'] = !empty($v['store_img']) ?
            $ossClient->signUrl(C('aliyun.bucket'), $v['store_img'], 3600) : '';
            $list[$k]['url'] = $this->getDetailUrl($v['store_id']);

            //获取网店商品
            if(!empty($parm['goods_num'])){
                $list[$k]['goodsList'] = $goodsModel->getList(['store_id'=>$v['store_id']],'0,'.$parm['goods_num'],$goodsModel::FIELD_GOODS_LIST,$order = 'recommend_desc',$ossClient);
            }else{
                $list[$k]['goodsList'] = $goodsModel->getList(['store_id'=>$v['store_id']],'0,2',$goodsModel::FIELD_GOODS_LIST,$order = 'recommend_desc',$ossClient);
            }

            $result[] = $list[$k];
        }
        return $result;
    }


    /**
     * 根据手机号码获得网店详细信息
     * @param  array  $where [description]
     * @param  string $field [description]
     * @return [type]        [description]
     */
    public function getStoreInfoByMobile($mobile, $field = '*')
    {
        if(empty($mobile) || !is_mobile($mobile)){
            return false;
        }

        $where['store_phone'] = $mobile;
        $res = $this->where($where)->field($field)->find();

        return empty($res) ? [] : $res;
    }


    /**
     *  商城账号更换手机号码
     * @param $member_id
     * @param $mobile
     * @return bool
     */
    public function changeMobile($id,$mobile){

        $where['store_id'] = $id;
        $updateData = [
            'store_phone' => $mobile,
        ];

        $res = $this->where($where)->save($updateData);
        return $res ? true : false;

    }

	/**
	 *  去网店系数表里面根据要求获取不一样的网店排序
	 * @param $order
	 * @param $limit
	 * @return array
	 */
	public function getFollowStores($order,$limit, $member_id){
		if(empty($order) || empty($limit)){
			return false;
		}
		$storeList = M('store_coefficient')
			->alias('sc')
			->field('s.store_id,s.store_number,store_name,ad_img,store_img')
			->join('left join __STORE__ s on s.store_id = sc.store_id')
			->join('left join __MEMBER_STORE__ m on s.store_id = m.store_id')
			->where(['sc.delect_time'=>['exp','is null'],'s.store_state'=>'1','m.member_id'=>$member_id,'m.is_follow'=>1])
			->order($order)
			->limit($limit)
			->select();

		return empty($storeList) ? [] : $storeList;
	}


}