<?php
/**
 * 商品成本模型
 * @author wuxiao 2017-3-30
 */
namespace Common\Model;
use Think\Model;

class GoodsCostModel extends Model {


    public function getList($parm = array())
    {

        if(!empty($parm['goods_id'])) $where['goods_id']=$parm['goods_id'];
        if(!empty($parm['goods_spec_id'])) $where['goods_spec_id']=$parm['goods_spec_id'];
        $where['batch_num'] = M('goods_cost')->where($where)->max('batch_num');

        $goodsCost = M('goods_cost')->where($where)->select();

        return $goodsCost;
    }

    public function getAdd($parm = array())
    {

        if(!empty($parm['goods_id'])) $data['goods_id']=$parm['goods_id'];
        if(!empty($parm['goods_spec_id'])) $data['goods_spec_id']=$parm['goods_spec_id'];
        if(!empty($parm['type_name'])) $data['type_name']=$parm['type_name'];
        if(!empty($parm['type_cost'])) $data['type_cost']=$parm['type_cost'];
        if(!empty($parm['batch_num'])) $data['batch_num']=$parm['batch_num'];
        if(!empty($parm['remarks'])) $data['remarks']=$parm['remarks'];

//        $data['batch_num'] = M('goods_cost')->where(array('goods_id'=>$data['goods_id'],'goods_spec_id'=>$data['goods_spec_id']))->max('batch_num');
//
//        if($data['batch_num'] == ''){
//            $data['batch_num'] = '0';
//        }

//        $data['batch_num'] = $data['batch_num'] + 1;
        $data['updatetime'] = NOW_TIME;

        $goodsCost = M('goods_cost')->add($data);

    }
    //获取一个商品的毛利成本（根据时间）
    public function getGoodsCostData($goods_id,$goods_spec_id,$order_time=false){
        $batch_num=(!$order_time)?$this->where(array('goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id))->max('batch_num'):$this->where(array('goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id,'updatetime'=>array('elt',$order_time)))->order('updatetime DESC')->getField('batch_num');
        //如果存在时间筛选，且下单前没有设置，下单后有设置过，用最近的一条设置记录
        if($order_time && !$batch_num){
            $batch_num=$this->where(array('goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id))->order('updatetime ASC')->getField('batch_num');
        }
        $goods_cost=$this->where(array('goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id,'batch_num'=>$batch_num))->sum('type_cost');
        return ($goods_cost)?$goods_cost:0;
    }

}