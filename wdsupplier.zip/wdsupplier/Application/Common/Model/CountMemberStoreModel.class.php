<?php
/**
 * 商品模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class CountMemberStoreModel extends Model {
	//获取企业基础统计信息            
	public function getCompanyCount($parm = array())
	{
		//统计公司绑定的用户在公司绑定的扶贫单位订单
		$company_id=$parm['company_id'];
		$mids=$this->getbindMembers($company_id);//公司绑定的用户
		$addwhere['member_id']=array('in',$mids);
		$sids=$this->getbindStores($parm['member_id']);
		$addwhere['store_id']=array('in',$sids);
		if(empty($mids)||empty($sids)) $list=array();
		else $list=$this->where($addwhere)->select();
		$totalprice=$totalorder=0;
		$todayKey=date('Y-m-d');
		$yestodayKey=date('Y-m-d',strtotime('-1 day'));
		foreach ($list as $key => $value) {
			$totalorder+=$value['order_num'];
			$totalprice+=$value['order_price'];
			if($value['date']==$todayKey){
				 $todayOrder=$value['order_num'];
				 $todayPrice=$value['order_price'];
			}
			if($value['date']==$yestodayKey){
				 $yestodayOrder=$value['order_num'];
				 $yestodayPrice=$todayPrice=$value['order_price'];
			}
		}
		$result['totalOrder']=$totalorder;
		$result['totalPrice']=$totalprice;
		$result['todayPrice']=empty($todayPrice) ?0 : $todayPrice;
		$result['todayOrder']=empty($todayOrder) ?0 : $todayOrder;	//今日订单数量
		$result['yestodayOrder']=empty($yestodayOrder) ?0 : $yestodayOrder;	//昨日订单数量
		$result['yestodayPrice']=empty($yestodayPrice) ?0 : $yestodayPrice;	//昨日订单总额
		$addwhere2['company_id']=$parm['company_id'];
		$result['totalMemberNumber']=M('member_auth')->where($addwhere2)->count();
		$addwhere2['create_time'] =array('gt',strtotime($todayKey));
		$result['todayMemberNumber']=M('member_auth')->where($addwhere2)->count();
		return $result;
	}
	//获取企业下用户统计信息列表
	public function getCompanyMemberList($parm = array())
	{
		$mids=$this->getbindMembers($parm['company_id']);
		if(empty($mids)) return array();
		if(!empty($mids)) $addwhere['ma.member_id']=array('in',$mids);

		$sids=$this->getbindStores($parm['member_id']);
		if(!empty($sids)) $addwhere2['store_id']=array('in',$sids);
		$subQuery = M('count_member_store')->where($addwhere2)->buildSql(); 


		$addwhere['ma.status']=1;
		$list=M('member_auth')->alias('ma')->field('sum(order_num) as totalOrder,sum(cms.order_price) as totalPrice,ma.member_id,sm.member_avatar,sm.member_mobile,sm.member_nickname')
				->join('sx_member as sm on ma.member_id=sm.member_id')
				->join('left join '.$subQuery.' as cms on cms.member_id=ma.member_id')
				->where($addwhere)->group('ma.member_id')->order('cms.order_price desc')->select();
		foreach($list as $key => $value){
			$list[$key]['totalorder']=empty($value['totalorder']) ? 0 :$value['totalorder'];
			$list[$key]['totalprice']=empty($value['totalprice']) ? 0 :$value['totalprice'];
		}
		return $list;
	}
	//获取企业下订单列表
	public function getCompanyOrderList($parm = array())
	{
		$sids=$this->getbindStores($parm['member_id']);
		$addwhere['cms.store_id']=array('in',$sids);
		$list=$this->alias('cms')->field('cms.store_id,sum(cms.order_num) as totalOrder,sum(cms.order_price) as totalPrice,cms.date')
				->where($addwhere)->group('cms.date')->order('cms.date desc')->select();
		return $list;
	}

	//获取企业基础统计信息
	public function getPointCount($parm = array())
	{


		$pids=$this->getAllPoint($parm['point_id']);
		$addwhere['point_id']=array('in',$pids);
		$list=$this->where($addwhere)->select();

		$totalprice=$totalorder=$todayOrder=$todayPrice=0;
		$todayKey=date('Y-m-d');
		$yestodayKey=date('Y-m-d',strtotime('-1 day'));


		foreach ($list as $key => $value) {
			$totalorder+=$value['order_num'];
			$totalprice+=$value['order_price'];
			if($value['date']==$todayKey){
				 $todayOrder=$value['order_num'];
				 $todayPrice=$value['order_price'];
			}
			if($value['date']==$yestodayKey){
				 $yestodayOrder=$value['order_num'];
				 $yestodayPrice=$value['order_price'];
			}
		}

		$result['totalOrder']=$totalorder;
		$result['totalPrice']=$totalprice;
		$result['todayPrice']=empty($todayPrice) ?0 : $todayPrice;
		$result['todayOrder']=empty($todayOrder) ?0 : $todayOrder;
		$result['yestodayOrder']=empty($yestodayOrder) ?0 : $yestodayOrder;
		$result['yestodayPrice']=empty($yestodayPrice) ?0 : $yestodayPrice;


		$addwhere2['ss.point_id']=array('in',$pids);
		$result['totalMemberNumber']=M('member_store')->alias('ms')->join('sx_store as ss on ms.store_id =ss.store_id ')->where($addwhere2)->count();


		$addwhere2['ms.create_time'] =array('gt',strtotime($todayKey));
		$result['todayMemberNumber']=M('member_store')->alias('ms')->join('sx_store as ss on ms.store_id =ss.store_id ')->where($addwhere2)->count();
		$mids=$this->getAllPointMembers($parm['point_id']);//村委下所有的企业的member_id
		$result['totalCompanyNumber']=count($mids);
		$result['orderMemberNumber']=2;
		return $result;
	}
	//获取村委下企业列表
	public function getPointCompanyList($parm = array())
	{
		$pids=$this->getAllPoint($parm['point_id']);
		$addwhere['st.point_id']=array('in',$pids);
		$list=M('count_company_store')->alias('ccs')->field('ccs.store_id,count(ccs.order_num) as totalOrder,sum(ccs.order_price) as totalPrice,ccs.date,st.store_img,st.store_name,st.point_id,ccs.company_id')
				->join('sx_store as st on ccs.store_id=st.store_id')
				->where($addwhere)->group('ccs.store_id')->order('ccs.date desc')->select();
		foreach ($list as $key => $value) {
			$list[$key]['totalMember']=M('member_auth')->where(['status'=>1,'company_id'=>$value['company_id']])->count();
		}
		return $list;
	}
	//获取村委下订单列表
	public function getPointOrderList($parm = array())
	{
		$pids=$this->getAllPoint($parm['point_id']);
		$addwhere['cms.point_id']=array('in',$pids);
		$list=$this->alias('cms')->field('cms.store_id,count(cms.order_num) as totalOrder,sum(cms.order_price) as totalPrice,cms.date')
				->where($addwhere)->group('cms.date')->order('cms.date desc')->select();
		return $list;
	}


	//获取村委下所有的point_id  alter table sx_point add  `member_id` int(11)  NOT NULL  COMMENT '绑定的member_id';
	public function getAllPoint($point_id){
		$points=M('point')->where('point_id ='.$point_id.' or point_parent_id='.$point_id)->select();
		foreach ($points as $key => $value) {
			$point_ids[]=$value['point_id'];
		}
		return $point_ids;
	}

	//获取村委下关联公司的member_id;
	public function getAllPointMembers($point_id){
		$point_ids=$this->getAllPoint($point_id);
		$members=M('member_store')->field('ms.member_id')->alias('ms')
				->join('sx_store as ss on ms.store_id =ss.store_id ')
				->join('sx_company_auth as ca on ms.member_id =ca.member_id ')
				->where(['ss.point_id'=>['in',$point_ids],'ca.status'=>1])->group('ms.member_id')->select();
		foreach ($members as $key => $value) {
			$member_ids[]=$value['member_id'];
		}
		return $member_ids;
	}

	//获取公司绑定的用户
	public function getbindMembers($company_id){
		$members=M('member_auth')->field('member_id')->where('company_id='.$company_id)->group('member_id')->select();
		if(empty($members)) return array();
		foreach ($members as $key => $value) {
			$member_ids[]=$value['member_id'];
		}
		return $member_ids;
	}


	//获取公司绑定的网店id
	public function getbindStores($member_id){
		$stores=M('member_store')->field('store_id')->where('member_id='.$member_id)->group('store_id')->select();
		if(empty($stores)) return array();
		foreach ($stores as $key => $value) {
			$store_ids[]=$value['store_id'];
		}
		return $store_ids;
	}

}
