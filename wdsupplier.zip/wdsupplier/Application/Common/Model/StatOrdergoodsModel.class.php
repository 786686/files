<?php
namespace Common\Model;

use Think\Model;

class StatOrdergoodsModel extends Model {
    

    public function insertAll($insert_arr)
    {
        if (empty($insert_arr) || empty($insert_arr[0]) || !is_array($insert_arr)) {
            return false;
        }

        return $this->addAll($insert_arr);
    }

}