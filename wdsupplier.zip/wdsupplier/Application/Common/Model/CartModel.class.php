<?php
/**
 * 购物车模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class CartModel extends Model {

	// 处理结果关键字
	const HANDLE_STATE_CODE_SUCCESS = 'success';
	const HANDLE_STATE_CODE_FAIL    = 'fail';

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $limit [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $limit = '')
	{
		$field = 'c.cart_id,c.goods_id,c.buyer_id,c.store_id,c.goods_num,g.goods_name,g.goods_storage,g.goods_unit,g.goods_state,g.goods_img AS goods_image';
		return $this->alias('c')
			->join('__GOODS__ AS g ON g.goods_id = c.goods_id', 'LEFT')
			->where($where)
			->limit($limit)
			->field($field)
			->order('cart_id ASC')
			->select();
	}

	/**
	 * 获取列表数量
	 * @param  array  $where [description]
	 * @return [type]        [description]
	 */
	public function getCount($where = array())
	{
		return $this->where($where)->count();
	}

	/**
	 * 获取商品数量列表, ID => 数量
	 * @param  array $where 条件
	 * @return [type]        [description]
	 */
	public function getNumList($where)
	{
		return $this->alias('c')
            ->join('LEFT JOIN __GOODS__ AS g ON c.goods_id = g.goods_id')
            ->where($where)->getField('c.goods_id,c.goods_num');
	}

	/**
	 * 获取购物列表统计信息
	 * @param  array  $where [description]
	 * @return [type]        [description]
	 */
	public function getTotal($where = array())
	{
		/*
		-- SQL查询语句原型
		SELECT
			SUM((c.goods_num * g.goods_price)) AS money,
			SUM(c.goods_num) AS number,
			COUNT(c.cart_id) AS total
		FROM sx_cart AS c
		LEFT JOIN sx_goods AS g ON g.goods_id = c.goods_id
		WHERE
			c.buyer_id = 4209 AND c.store_id = 10;
		 */
		$result = $this->alias('c')
			->join('__GOODS__ AS g ON g.goods_id = c.goods_id', 'LEFT')
			->field('SUM((c.goods_num * g.goods_price)) AS money, SUM(c.goods_num) AS number, COUNT(c.cart_id) AS total')
			->where($where)
			->select();
		$data = array_shift($result);
		return array(
			'money'		=> sprintf('%.2f', $data['money']),
			'number'	=> strval($data['number']),
			'count'		=> strval($data['total'])
		);
	}

	/**
	 * 获得详细信息
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($parm = array())
	{

		if(empty($parm['cart_id'])) return array();
		$field="a.buyer_id,b.goods_name,b.goods_id,b.goods_img,a.goods_num,e.goods_spec_id,e.sp_price price,b.store_id,b.store_name";
		$where['go.goods_state']=1;
		$where['ca.cart_id']=1;
		$cartInfo=$this->field($field)->alias('ca')
		               ->join("left join __GOODS__  go on ca.goods_id=go.goods_id ")
		               ->join("left join __STORE__  st on ca.store_id=st.store_id ")
		               ->join("left join __GOODS_SPEC__  gs on ca.goods_id=gs.goods_id  AND ca.goods_spec_id=gs.goods_spec_id ")
		               ->where($where)->find();
		return $cartInfo;
	}

	/**
	 * 获取商品数量
	 * @param  integer $id    商品 ID
	 * @param  integer $buyer 用户 ID
	 * @param  integer $spec  规格 ID
	 * @return integer 		  商品数量
	 */
	public function getGoodsNum($id, $buyer, $spec = NULL)
	{
		$where = array(
			'goods_id' => $id,
			'buyer_id' => $buyer
		);
		if ($spec) {
			$where['goods_spec_id'] = $spec;
			return $this->where($where)->getField('goods_num');
		} else {
			return $this->where($where)->sum('goods_num');
		}
	}

	/**
	 * 删除购物车商品
	 * @author deason  2016-08-30
	 * @param  integer $id    商品ID
	 * @param  integer $buyer 会员ID
	 */
	public function delGoods($goodsId, $buyer ,$goods_spec_id)
	{
        $this->where(array('goods_id' => $goodsId, 'buyer_id' => $buyer ,'goods_spec_id'=>$goods_spec_id))->delete();
        return true;
    }

	/**
	 * 修改删除代码为清空购买数量
	 * @author deason 2016-08-29
	 * @param  array  $where [description]
	 * @return [type]        [description]
	 */
//	public function delete($where = array())
//	{
//		if (!empty($where)) {
//			$this->where($where);
//		}
//		if (empty($this->options['where'])) {
//			return false;
//		}
//		$result = $this->save(array('goods_num' => 0));
//		return $result === false ? false : true;
//	}

	// ------------------ 逻辑操作 ------------------ //

	public function logicAlter($goodsId, $memberId, $number = 1, $isMerge = false)
	{
		$cartInfo     = $this->where(array(
			'buyer_id' => $memberId,
			'goods_id' => $goodsId
		))->field('cart_id,goods_num')->find();
		$targetNumber = $isMerge ? $cartInfo['goods_num'] + $number : $number;
		$targetNumber = $targetNumber >= 0 ? $targetNumber : 0;
		$modelGoods   = D('Goods');
		$checkReturn  = $modelGoods->checkStateToBuy($goodsId, $targetNumber);
		// 只有数量大于0才检查商品库存及状态(递减,和删除过滤)
		if ($number > 0 && !$checkReturn['state']) {
			return array(
				'state' => false,
				'name'  => $checkReturn['data']['goods_name'],
				'code'  => $checkReturn['code'],
				'number'=> $cartInfo['goods_num'],
				'msg'   => $checkReturn['msg'],
				'data'  => $checkReturn['data']
			);
		}
		$data = array(
			'buyer_id'    => $memberId,
			'store_id'    => $checkReturn['data']['store_id'],
			'store_name'  => $checkReturn['data']['store_name'],
			'goods_id'    => $goodsId,
			'goods_name'  => $checkReturn['data']['goods_name'],
			'goods_image' => $checkReturn['data']['goods_img'],
			'goods_num'   => $targetNumber,
			'goods_price' => $checkReturn['data']['goods_price']
		);
		if ($cartInfo['cart_id']) {
			// 表中是否已存在该字段
			$result = $this->where(array('cart_id' => $cartInfo['cart_id']))->save($data);
		} else {
			$result = parent::add($data);
		}
		// 返回结果
		return array(
			'state'  => $result !== false ? true : false,
			'name'   => $checkReturn['data']['goods_name'] ?: $goodsId,
			'code'   => $result ? self::HANDLE_STATE_CODE_SUCCESS : self::HANDLE_STATE_CODE_FAIL,
			'number' => $targetNumber,
			'msg'    => $result !== false ? '修改购买数量成功' : '修改购买数量失败',
			'data'  => $checkReturn['data']
		);
	}

}
