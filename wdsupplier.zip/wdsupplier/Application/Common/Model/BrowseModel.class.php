<?php
//+------------------------------------------------------------------------------------
//|WanXunChuangKeWebsite(www.wxeepp.com)
//+------------------------------------------------------------------------------------
//|Copyright©2019GuangzhouWanxunNetworkTechnologyCo.,Ltd.Allrightsreserved.
//+------------------------------------------------------------------------------------
//|Licensed(http://www.wanxunkeji.com/LICENSE.txt)
//+------------------------------------------------------------------------------------
//|Author:GuangzhouWanxunNetworkTechnologyCo.,Ltd.—limeiling
//+------------------------------------------------------------------------------------
//|Tel:+86-020-87527067+86-181428138216E-mail:wanxun@wanxunkeji.com
//+------------------------------------------------------------------------------------
//|本“万讯创客”网站(www.wxeepp.com)版权属于广州万讯网络科技有限公司所有。
//+------------------------------------------------------------------------------------
//|作者：广州万讯网络科技有限公司研发技术部李美玲。
//+------------------------------------------------------------------------------------
//|发布时间：2019/12/31。
//+------------------------------------------------------------------------------------
//|万讯®商标和著作权所有者为广州万讯网络科技有限公司。
//+------------------------------------------------------------------------------------

namespace Common\Model;

use Think\Model;

class BrowseModel extends Model {
	public function getlist( $params ) {
		return $this->alias( 'b' )
		            ->field( $params['field'] )
		            ->join( $params['join'] )
		            ->where( $params['where'] )
		            ->order( 'browse_time desc' )
		            ->select();
	}

	public function countDay( $params ) {
		$limit = $params['limit'] ?? '';
		$data  = $this->alias( 'b' )
		              ->field( 'FROM_UNIXTIME(browse_time,"%Y-%m-%d") as daytime,count(id)' )
		              ->where( $params['where'] )
		              ->order( 'browse_time desc' )
		              ->group( 'daytime' )
		              ->limit( $limit )
		              ->select();
		return array_column( $data, 'daytime' );
	}

}