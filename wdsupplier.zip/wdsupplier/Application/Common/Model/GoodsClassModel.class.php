<?php
/**
 * 商品分类模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class GoodsClassModel extends Model {

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $field = '*', $order = 'gc_level ASC,gc_sort ASC,gc_id ASC')
	{
		return $this->where($where)->field($field)->order($order)->select();
	}

	/**
	 * 通过名字获取ID
	 * @param  string $name 分类名称
	 * @return [type]       [description]
	 */
	public function getIdByName($name)
	{
		return $this->where(array('gc_name' => $name))->getField('gc_id');
	}

	/**
	 * 格式化成树结构
	 * @param  array 	$list 	查询列表结果,必须包含 gc_id,gc_index 字段
	 * @param  boolean 	$noKey 	是否返回无键值的数组 默认:否
	 * @return array 	格式化后的树形结构多维数组
	 */
	public function formatTree($list, $noKey = false)
	{
		$data = array();
		if ($list && is_array($list)) {
			foreach ($list as $row) {
				$level = explode('-', $row['gc_index']);
				// $levelCount = count($level);
				// $data[] = array($level, $levelCount);

				if ($level[2]) {
					$row['child'] = $data[$level[1]]['child'][$level[2]]['child'][$row['gc_id']]['child'] ? $data[$level[1]]['child'][$level[2]]['child'][$row['gc_id']]['child'] : array();
					$data[$level[1]]['child'][$level[2]]['child'][$row['gc_id']] = $row;
				} elseif ($level[1]) {
					$row['child'] = $data[$level[1]]['child'][$row['gc_id']]['child'] ? $data[$level[1]]['child'][$row['gc_id']]['child'] : array();
					$data[$level[1]]['child'][$row['gc_id']] = $row;
				} else {
					$row['child'] = $data[$row['gc_id']]['child'] ? $data[$row['gc_id']]['child'] : array();
					$data[$row['gc_id']] = $row;
				}
			}
		}

		$returnData = array();
		foreach ($data as $key1 => $row1) {
			// 非有效二级过滤
			if (($row1['gc_name'] && $row1['gc_status'] == 1) || !empty($row1['child'])) {
				$child1 = array();
				if (is_array($row1['child'])) {
					// 遍历二级分类
					foreach ($row1['child'] as $key2 => $row2) {
						// 非有效二级过滤
						if ($row2['gc_name'] && $row2['gc_status'] == 1) {
							$row2['child'] = $noKey ? array_values($row2['child']) : $row2['child'];
							$noKey ? ($child1[] = $row2) : ($child1[$key2] = $row2);
						}
					}
				}
				$row1['child'] = $child1;
				$noKey ? ($returnData[] = $row1) : ($returnData[$key1] = $row1);
			}
		}
		return $returnData;
	}
    /**
     * 根据类别str，筛选后返回三级类别数组
     * 分一二三级返回
     * 如果含有下级子类id，删除上级夫类id,做精确筛选
     * 主要用于PC端商品列表页的筛选功能
     */
    function getClassLevelStr($gclass_str){
        $gclass_array=explode(',',$gclass_str);
        $gclass_1_array=$gclass_2_array=$gclass_3_array=array();
        $gclass_1_str=$gclass_2_str=$gclass_3_str='';
        //先把分类数据分级填入各级类别
        foreach($gclass_array as $key=>$value){
            $data=$this->getClassLevel($value);
            $level=$data['gc_level'];//类别等级
            $parent_id=$data['gc_parent_id'];//父类id
            switch($level){
                case 1:
                    $gclass_1_array[$value]=$parent_id;
                    break;
                case 2:
                    $gclass_2_array[$value]=$parent_id;
                    break;
                case 3:
                    $gclass_3_array[$value]=$parent_id;
                    break;
            }
        }
        //当含有下级子类时，删除父类id，为了精确查询
        foreach($gclass_3_array as $key=>$value){
            foreach($gclass_2_array as $key2=>$value2){
                if($value==$key2){
                    unset($gclass_2_array[key2]);
                }
            }
        }
        foreach($gclass_2_array as $key=>$value){
            foreach($gclass_1_array as $key2=>$value2){
                if($value==$key2){
                    unset($gclass_1_array[key2]);
                }
            }
        }
        //反转数组key和value
        $gclass_1_array_new=$gclass_2_array_new=$gclass_3_array_new=array();
        foreach($gclass_1_array as $key=>$value){
            if (!in_array($key, $gclass_1_array_new)){
                $gclass_1_array_new[]=$key;
            }
        }
        foreach($gclass_2_array as $key=>$value){
            if (!in_array($key, $gclass_2_array_new)){
                $gclass_2_array_new[]=$key;
            }
        }
        foreach($gclass_3_array as $key=>$value){
            if (!in_array($key, $gclass_3_array_new)){
                $gclass_3_array_new[]=$key;
            }
        }
        //拼装类别字符串
        $gclass_1_str=implode(",",$gclass_1_array_new);
        $gclass_2_str=implode(",",$gclass_2_array_new);
        $gclass_3_str=implode(",",$gclass_3_array_new);

        return array($gclass_1_str,$gclass_2_str,$gclass_3_str);
    }
    /**
     * 获取类别夫类等级level
     */
    function getClassLevel($gc_id){
        $data=$this->where(array('gc_id'=>$gc_id))->field('gc_level,gc_parent_id')->select();
        return $data[0];
    }


}
