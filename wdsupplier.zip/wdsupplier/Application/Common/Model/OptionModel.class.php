<?php
/**
 * 系统配置模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Common\Lib\Redis\Redis;
use Think\Model;

class OptionModel extends Model {

    const OptionRedisKey = 'option:';
    const OptionCacheTime = 172800; // 2天时间

    /** 获取单个配置项值 */
    public function getItem($optionName)
    {
        $optionRedisKey = self::OptionRedisKey . $optionName;
        $val = Redis::getInstance()->get($optionRedisKey);
        if (empty($val)) {
            $val = $this->where(array('option_name' => $optionName))->getField('option_value');
            if ($val) {
                Redis::getInstance()->set($optionRedisKey, $val, self::OptionCacheTime);
            }
        }
        return $val;
    }

	/** 获取网店配送距离(Km) */
	public function getTransportRange()
	{
		return $this->getItem('transport_range');
	}

	/** 获取网店配送距离(m) */
	public function getTransportRangeToM()
	{
		return $this->getTransportRange() * 1000;
	}

	/** 获取网店配送费用 */
	public function getTransportPrice()
	{
		return $this->getItem('transport_price');
	}

}
