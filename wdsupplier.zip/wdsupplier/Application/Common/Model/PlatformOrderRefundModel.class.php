<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/3/7
 * Time: 1:19
 */

namespace Common\Model;

use Think\Exception;
use Think\Model;

/**
 * 预付订单退款表
 */
class PlatformOrderRefundModel extends Model
{

    /**
     * 生成一条退款记录
     *
     * @param $order
     * @param $refund_ree
     * @param $refund_type
     *
     * @return array
     */
    public function preRefundData($order, $refund_fee, $refund_type = 0, $remark = '无货退款')
    {
        $data = $this->where(['order_id' => $order['id']])->find();
        if ($data) {
            $data['refund_amount'] = $refund_fee;
            $data['refund_type']   = $refund_type;
            $data['reason_info']   = $remark;

            return $data;
        }
        $data = [
            'order_id'              => $order['id'],
            'order_sn'              => $order['order_sn'],
            'pay_sn'                => $order['pay_sn'],
            'refund_sn'             => self::makeNo(),
            'store_id'              => $order['store_id'],
            'buyer_id'              => $order['buyer_id'],
            'goods_id'              => $order['goods_id'],
            'payment_code'          => $order['payment_code'],
            'refund_amount'         => $refund_fee,
            'refund_type'           => $refund_type,
            'reason_info'           => $remark,
            'refund_request_param'  => '',
            'refund_response_param' => '',
            'refund_reload_status'  => 0, // -1退款失败 0待退款 1退款中 2已退款
            'admin_id'              => session('admin_id'),
        ];
        $rs = $this->add($data);
        if (!$rs) throw new Exception($this->getLastSql());
        $data['refund_id'] = $this->getLastInsID();

        return $data;
    }



    /**
     * 生成订单号
     *
     * @return string 32位长度
     */
    public static function makeNo()
    {
        $yCode   = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
        $orderSn = $yCode[(intval(date("Y")) - 2020) % 10]
            . date('YmdHis')
            . strtoupper(dechex(date('m')))
            . date('d')
            . substr(time(), -5)
            . substr(microtime(), 2, 7)
            . sprintf('%02d', rand(0, 99));

        return $orderSn;
    }

}