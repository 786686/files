<?php
/**
 * 运费模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class TransportModel extends Model {

	const MODE_US_SEND = 1;
	const MODE_EXPRESS = 2;

	public function getList($where = array(), $limit = '', $field = '*', $order = '')
	{
		return $this->where($where)->field($field)->limit($limit)->select();
	}

	/**
	 * 通过ID(商店,收货地址)获取配送模式
	 * @author deason 2016-08-18
	 * @param  integer $store   商店ID
	 * @param  integer $address 收货地址ID
	 * @return integer			配送模式
	 */
	public function getTransportModeById($store, $address)
	{
		$storePoint   = D('StoreMap')->getCoordinateById($store);
		$addressPoint = D('MemberAddress')->getGeoPoint($address);
		return $this->getTransportModeByPoint($storePoint['baidu_lat'], $storePoint['baidu_lng'], $addressPoint['lat'], $addressPoint['lng']);
	}

	/**
	 * 通过两点百度坐标得到配送模式
	 * @author deason 2016-08-18
	 * @param  float $storeLat  商店.百度经度
	 * @param  float $storeLng  商店.百度纬度
	 * @param  float $targetLat 目标.百度经度
	 * @param  float $targetLng 目标.百度纬度
	 * @return [type]            [description]
	 */
	public function getTransportModeByPoint($storeLat, $storeLng, $targetLat, $targetLng)
	{
		// 获取配置网店配送距离(米)
		$transportRange = D('Option')->getTransportRangeToM();
		// 计算两点坐标距离(米)
		$transportDistance = getDistance($storeLat, $storeLng, $targetLat, $targetLng);
		// 如果距离超出配送距离,则为快递配送模式
		if ($transportDistance > $transportRange) {
			return self::MODE_EXPRESS;
		}
		return self::MODE_US_SEND;
	}

	/**
	 * 根据公式计算运费
	 * @author deason 2016-08-20
	 * @param  array   $param  运费参数 {first_price,first_weight,second_weight,second_price}
	 * @param  integer $weight 重量(克)
	 * @return float		   计算结果
	 */
	static public function calcFeeByFormula($param, $weight)
	{
		// 公式: 首重价格 + 续重价格 * 进一取整((重量 - 首重) / 续重)
		return $param['first_price']
			+ (
				($weight - $param['first_weight']) > 0 && $param['second_weight'] != 0
				?
				$param['second_price'] * ceil(($weight - $param['first_weight']) / $param['second_weight'])
				:
				0
			);
	}

	/**
	 * 提取模板中有效的运费参数 - 来模板详细
	 * @author deason 2016-08-20
	 * @param  array   $transportInfo 模板信息数组
	 * @param  integer $cityId        收货城市ID
	 * @return array 			 	  有效的运费参数
	 */
	static public function getValidParamByInfo($transportInfo, $cityId)
	{
		$validInfo = array(
			'first_weight'  => $transportInfo['first_weight'],
			'second_weight' => $transportInfo['second_weight'],
			'first_price'   => $transportInfo['first_price'],
			'second_price'  => $transportInfo['second_price'],
		);
		$pattern = '/(^|,)' . $cityId . '(,|$)/';	// 城市ID匹配正则
		if ($transportInfo['zoning']) {
			$zoning = unserialize($transportInfo['zoning']);
			foreach ($zoning as $row) {
				if ($row['area'] && preg_match($pattern, $row['area'])) {
					$validInfo['first_weight']  = $row['sub_first_weight'] ?: $transportInfo['first_weight'];
					$validInfo['second_weight'] = $row['sub_second_weight'] ?: $transportInfo['second_weight'];
					$validInfo['first_price']   = $row['sub_first_price'] ?: $transportInfo['first_price'];
					$validInfo['second_price']  = $row['sub_second_price'] ?: $transportInfo['second_price'];
				}
			}
		}
		return $validInfo;
	}

	public function getValidParamById($transportId, $cityId)
	{
		$transportInfo = $this->where(array('id' => $transportId))
			->find('first_weight,second_weight,first_price,second_price');
		return self::getValidParamByInfo($transportInfo, $cityId);
	}

	/**
	 * [calcTransportFee description]
	 * @author deason 2016-08-20
	 * @param  [type] $cityId [description]
	 * @param  [type] $goods  [description]
	 * @return [type]         [description]
	 */
	public function calcTransportFee($cityId, $goods)
	{
		$modelGoods    = D('Goods');
		$totalWeight   = $modelGoods->getTotalWeight($goods);					// 获取总计重量
		$transportIds  = $modelGoods->getTransportIds(array_keys($goods));		// 获得模板ID组
		// 没有模板时为默认模板
		if (empty($transportIds)) {
			$whereList = array('is_default' => 1);
		} else {
			$whereList = array('id' => array('IN', $transportIds));
		}
		$transportList = $this->getList($whereList);
		$feeList = array();		// 运费计算结果列表
		foreach ($transportList as $transportInfo) {
			// 计算运费
			// 公式: 首重价格 + 续重价格 * 进一取整((重量 - 首重) / 续重)
			$feeList[] = self::calcFeeByFormula(self::getValidParamByInfo($transportInfo ,$cityId), $totalWeight);
		}
			// printf("[MODEL] feeList: %s\n",json_encode($feeList));	// TEST
		return max($feeList);
	}

	/**
	 * 通过ID(商店,收货地址)和商品及数量计算运费
	 * @author deason 2016-08-18
	 * @param  integer $storeId   商店ID
	 * @param  integer $addressId 收货地址ID
	 * @param  array   $goods     商品ID-数量的键值对 array(ID=>NUM)
	 * @return float			  运费
	 */
	public function getTransportFee($storeId, $addressId, $goods)
	{
		$sendMode = $this->getTransportModeById($storeId, $addressId);
		$goodsTotal = D('Goods')->getTotalByList($goods);
		return $this->getTransportFeeByModeAndTotal($sendMode, $goodsTotal['weight'], $goodsTotal['amount']);
	}

	/**
	 * [getTransportFeeByModeAndTotal description]
	 * @author deason 2016-10-18
	 * @param  [type] $model  [description]
	 * @param  [type] $weight [description]
	 * @param  [type] $amount [description]
	 * @return [type]         [description]
	 */
	public function getTransportFeeByModeAndTotal($model, $weight, $amount)
	{
		$modelOption = D('Option');
		$feeTransportAmount = $modelOption->getItem('free_transport_amount');
		if ($feeTransportAmount > 0 && $amount >= $feeTransportAmount) {
			return 0;
		}
		if ($model == self::MODE_US_SEND) {
			return D('Option')->getTransportPrice();
		}
		return false;
		// TODO: 暂时屏蔽完成模板计算
		// 收货地址城市ID
		// $cityId = D('MemberAddress')->getCityId($addressId);
		// 计算快递运费
		// return $this->calcTransportFee($cityId, $goods);
	}


}
