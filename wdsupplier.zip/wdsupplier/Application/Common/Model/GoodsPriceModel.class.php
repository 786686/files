<?php
/**
 * 商品价格模型
 * @author hubert 2017-04
 */
namespace Common\Model;
use Think\Model;

class GoodsPriceModel extends Model {

    // 处理结果关键字
    const SUCCESS = 1;
    const FAIL    = 0;

    /**
     * 获取商品价格
     * array $where 搜索条件数组
     * $where['goods_spec_id']  商品规格id
     * $where['goods_id']  商品id
     * $where['type']  价格类型（0:规格价；1：企业价；）
     */
    public function getPrice($where = array()){
        //缺失关键筛选参数
        if(!isset($where['goods_spec_id']) || !isset($where['goods_id']) || !isset($where['type'])){
            return array('code'=>self::FAIL,'msg'=>'缺失关键筛选参数');
        }
        //判断goods_spec_id,goods_id是否合法
        $check=M('goods_spec')->where(array('goods_spec_id'=>$where['goods_spec_id'],'goods_id'=>$where['goods_id']))->select();
        if(empty($check)){
            return array('code'=>self::FAIL,'msg'=>'商品或商品规格不合法');
        }
        //判断价格类型是否合法
        if(!in_array($where['type'],array(0,1))){
            return array('code'=>self::FAIL,'msg'=>'价格类型不合法');
        }
        //判断价格是否已经录入
        $price=$this->where($where)->getField('price');
        if(empty($price) && $where['type'] ==0){
            return array('code'=>self::FAIL,'msg'=>'商品价格未录入');
        }
        //如果是获取企业价且企业价为空，返回规格价
        if($where['type']==1 && empty($price)){
            $where['type'] = 0;
            $price=$this->where($where)->getField('price');
            return array('code'=>self::SUCCESS,'msg'=>'','data'=>$price);
        }
        //成功
        return array('code'=>self::SUCCESS,'msg'=>'','data'=>$price);
    }
    /**
     * 设置商品价格
     * 且写入操作日志
     */
    public function setPrice($save=array()){
        //缺失关键筛选参数
        if(!isset($save['goods_spec_id']) || !isset($save['goods_id']) || !isset($save['type']) || !isset($save['price'])){
            return array('code'=>self::FAIL,'msg'=>'缺失关键参数');
        }
        //判断goods_spec_id,goods_id是否合法
        $check=M('goods_spec')->where(array('goods_spec_id'=>$save['goods_spec_id'],'goods_id'=>$save['goods_id']))->select();
        if(empty($check)){
            return array('code'=>self::FAIL,'msg'=>'商品或商品规格不合法');
        }
        //判断价格类型是否合法
        if(!in_array($save['type'],array(0,1))){
            return array('code'=>self::FAIL,'msg'=>'价格类型不合法');
        }
        $save['price']=floatval($save['price']);
        //判断通过，写入记录
        $check=$this->where(array('goods_spec_id'=>$save['goods_spec_id'],'goods_id'=>$save['goods_id'],'type'=>$save['type']))->getField('id');

        //判断通过，写入记录
        $check=$this->where(array('goods_spec_id'=>$save['goods_spec_id'],'goods_id'=>$save['goods_id'],'type'=>0))->getField('id');
        if(empty($check)){
            $this->add($save);
        }else{
            $this->where(array('id'=>$check,'type'=>$save['type']))->save(array('price'=>$save['price']));
        }
        $check2=$this->where(array('goods_spec_id'=>$save['goods_spec_id'],'goods_id'=>$save['goods_id'],'type'=>1))->getField('id');
        if(empty($check2)){
            $save['type'] = 1;
            $this->add($save);
        }else{
            //这里查询企业价格然后赋值
            $batch_price = D('GoodsBatch')->getBatchPrice(array('goods_spec_id'=>$save['goods_spec_id'],'goods_id'=>$save['goods_id']));
            $batch_price = $batch_price==0?$save['price']:$batch_price;
            $this->where(array('id'=>$check2))->save(array('price'=>$batch_price));
        }
        //写入操作日志
        M('goods_price_log')->add(array('goods_spec_id'=>$save['goods_spec_id'],'goods_id'=>$save['goods_id'],'type'=>$save['type'],'history_price'=>$save['price'],'createtime'=>time()));
        return array('code'=>self::SUCCESS,'msg'=>'操作成功');
    }


    /**
     * 获取商品所有价格
     * array $where 搜索条件数组
     * $where['goods_spec_id']  商品规格id
     * $where['goods_id']  商品id
     */
    public function getAllPrice($where = array()){
        //缺失关键筛选参数
        if(!isset($where['goods_spec_id']) || !isset($where['goods_id'])){
            return array('code'=>self::FAIL,'msg'=>'缺失关键筛选参数');
        }
        //判断goods_spec_id,goods_id是否合法
        $type = $where['type'];
        $where=array('goods_spec_id'=>$where['goods_spec_id'],'goods_id'=>$where['goods_id']);
        $check=M('goods_spec')->where($where)->select();
        if(empty($check)){
            return array('code'=>self::FAIL,'msg'=>'商品或商品规格不合法');
        }
        $priceArr=$this->field('price,type')->where($where)->select();
        $prices['common_price']=$prices['company_price']='';//普通价格和企业价格初始化

        foreach ($priceArr as $key => $value) {
            if($type == 2 ){
                if($value['type']==='1')  $prices['company_price']=$value['price'];
            }else{
                if($value['type']==='0')  $prices['common_price']=$value['price'];
                if($value['type']==='1')  $prices['company_price']=$value['price'];
            }
        }

        if($prices['company_price']=='') $prices['company_price']=$prices['common_price'];
        //成功
        return array('code'=>self::SUCCESS,'msg'=>'','data'=>$prices);
    }


}
