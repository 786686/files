<?php
/**
 * 退款队列模型
 * User: xiebaozhi
 * Date: 2018/5/30
 * Time: 11:41
 */

namespace Common\Model;


use Think\Model;

class RefundReloadModel extends Model
{
    protected $tableName = 'refund_reload';
    const REFUND_STATUS_FISHED = 3;     //售后状态完成
    const SELLER_STATE_CHECKED = 2;     //卖家同意

    const WEIXIN_WAP_PAYMENT = 1;       //微信支付wap
    const WEIXIN_APP_PAYMENT = 2;       //微信支付app
    const ALIPAY_PAYMENT = 3;       //支付宝支付

    const WAIT_REFUND = 1;          //待退款
    const LOADING_REFUND = 2;       //退款中
    const FISHED_REFUND = 3;        //已退款
    const FAIL_REFUND = 4;          //退款失败

    const YES_CHECKED = 1;      //审核通过
    const NO_CHECKED = 2;       //审核不通过

    static $payments = array(
        'alipay'=>array(
            'pay_id'=>self::ALIPAY_PAYMENT,
            'pay_name'=>'支付宝支付',
        ),
        'wxpay'=>array(
            '1'=>array(
                'pay_id'=>self::WEIXIN_WAP_PAYMENT,
                'pay_name'=>'公众号微信支付',
            ),
            '2'=>array(
                'pay_id'=>self::WEIXIN_WAP_PAYMENT,
                'pay_name'=>'公众号微信支付',
            ),
            '3'=>array(
                'pay_id'=>self::WEIXIN_APP_PAYMENT,
                'pay_name'=>'APP微信支付',
            ),
            '4'=>array(
                'pay_id'=>self::WEIXIN_APP_PAYMENT,
                'pay_name'=>'APP微信支付',
            ),

        )
    );

    public function createReload($refund_id)
    {
        if($refund_id==false) return false;

        //判断是否已存在该条退款记录
        $isExist = $this->where(array('refund_id'=>$refund_id))->count();
        if($isExist>0){
            return false;
        }
        $refundInfo = M('refund_return')->where(array('refund_id'=>$refund_id))->find();
        //必须是售后完成、同意和退款金额大于0状态
        if($refundInfo['refund_state']!=self::REFUND_STATUS_FISHED ||
            $refundInfo['seller_state']!=self::SELLER_STATE_CHECKED ||
            $refundInfo['refund_amount']==0){
            return false;
        }

        //获取订单信息
        $orderFields = array('payment_code','pay_sn','refund_state','order_amount','order_from','trade_no');
        $orderInfo = M('order')->field($orderFields)->where(array('order_id'=>$refundInfo['order_id']))->find();
        //不是支付宝和微信支付订单，不进入退款队列，只支持微信和支付宝线上退款
        if(!in_array($orderInfo['payment_code'],array('alipay','wxpay'))){
            return false;
        }else{
            if($orderInfo['payment_code']=='alipay'){
                $payName = self::$payments[$orderInfo['payment_code']]['pay_name'];
                $payId = self::$payments[$orderInfo['payment_code']]['pay_id'];
            }else{
                $payName = self::$payments[$orderInfo['payment_code']][$orderInfo['order_from']]['pay_name'];
                $payId = self::$payments[$orderInfo['payment_code']][$orderInfo['order_from']]['pay_id'];
            }

        }

        //订单的退款状态必须是退款或全部退款
        if(!in_array($orderInfo['refund_state'],array(1,2))){
            return false;
        }

	    //检测是否可以退运费
	    $shipping_fee = M('order')->where(array('order_id'=>$refundInfo['order_id']))->getField('shipping_fee');
	    $refundReturn = new RefundReturnModel();
	    $goodsIds[] = $refundInfo['goods_id'];
	    $result = $refundReturn->isRefundFee($refundInfo['order_id'],$goodsIds,2);
	    if($result===false){
		    $shipping_fee = '0.00';
	    }
	    $refundInfo['refund_amount'] +=$shipping_fee;

        $addData = array();
        $addData['refund_id'] = $refund_id;
        $addData['order_id'] = $refundInfo['order_id'];
        $addData['goods_id'] = $refundInfo['goods_id'];
        $addData['order_sn'] = $orderInfo['pay_sn'];
        $addData['buyer_id'] = $refundInfo['buyer_id'];
        $addData['store_id'] = $refundInfo['store_id'];
        $addData['order_amount'] = $orderInfo['order_amount'];
        $addData['refund_amount'] = $refundInfo['refund_amount'];
        $addData['pay_name'] = $payName;
        $addData['pay_id'] = $payId;
        $addData['pay_sn'] = $orderInfo['trade_no'] ? $orderInfo['trade_no'] : '';
        $addData['refund_reload_sn'] = $this->_generate_nonce_str($refund_id,$addData['pay_id']);
        $addData['refund_request_param'] = '';
        $addData['refund_response_param'] = '';
        $addData['refund_respose_info'] = '';

        if($this->create($addData)){
            $insertId = $this->add();
            return $insertId;
        }
        return false;
    }

    //必须保证它的唯一性
    private function _generate_nonce_str($refundId,$payId)
    {
        if($payId==self::WEIXIN_WAP_PAYMENT || $payId==self::WEIXIN_APP_PAYMENT){
            $str = date('YmdHis');
            return $str.substr(md5($str.md5($refundId)),14);
        }elseif($payId==self::ALIPAY_PAYMENT){
            return date('Ymd').str_pad($refundId,8,'0',STR_PAD_LEFT);
        }

    }

    //执行退款操作获取退款数据
    public function getRefundData()
    {
        $where = array();
        $where['refund_reload_status'] = self::WAIT_REFUND;
        $where['refund_reload_checked'] = self::YES_CHECKED;
        $listData = $this->where($where)->order('create_time asc')->limit(30)->select();
        $returnData = array('alipay'=>array(),'wap_wxpay'=>array(),'app_wxpay'=>array());
        foreach($listData as $val){
            if($val['pay_id']==self::WEIXIN_APP_PAYMENT){
                $returnData['app_wxpay'][] = $val;
            }elseif($val['pay_id']==self::WEIXIN_WAP_PAYMENT){
                $returnData['wap_wxpay'][] = $val;
            }elseif($val['pay_id']==self::ALIPAY_PAYMENT){
                $returnData['alipay'][] = $val;
            }
        }

        return $returnData;
    }
}