<?php

namespace Common\Model;

use Think\Model;

/**
 * RoleModel
 * @author Kun
 */
class RoleModel extends Model
{
    const ROLE_LIST_FIELD    = 'role_id,role_name,FROM_UNIXTIME(role_createtime) as role_createtime,role_describe,role_status,role_parent_id,role_founder,role_update_user';
    const ROLE_STRUCTURE     = 'role_id,role_name,role_parent_id';
    const ROLE_DETAILS       = 'role_id,role_name,role_describe,role_status';
    const ROLE_STATUS_DELETE = -1;
    const ROLE_PARENT        = 0;
    const PRIVILEGE_FIELD    = 'priv_id,priv_title,priv_group';
    public function checkLogin( $data = [] ,$field = 'mark_name' )
    {
        return M("AdminToken")->where([
            'mark_name'       => "admin_".$data['admin_id'],
            'app_admin_token' => $data['admin_token']
        ])->field($field)->find();
    }

    private function getAdmin( $where = [] , $field= '' )
    {
        return M("Admin")->where($where)->field($field)->find();
    }

    private function role( $data = [] ,$state = '', $where = [] )
    {
        $model = M("Role");
        if ( $state == 1 ) {//修改数据，状态，假删
            return $model->where($where)->save($data);
        } else {
            return $model->add($data);
        }
    }

    public function getLists( $field = '', $where = [] ,$limit = '' )
    {
        $model = $this
            ->field($field)
            ->where($where);
        if ( $limit ) {
            return $model->limit($limit)->order('role_createtime DESC')->select();
        }

        return $model->order('role_createtime DESC')->select();
    }

    public function countList( $where = [] )
    {
        return $this->where($where)->count();
    }


    private function getPram( $data = [] )
    {
        $return_arr = [];
        if ( $data['keyword'] ) {
            $return_arr['role_name'] = ['like',"%{$data['keyword']}%"];
        }

        if ( is_numeric($data['status']) ) {
            $return_arr['role_status'] = $data['status'];
        }

        if ( $data['start_time'] ) {
            $return_arr['role_createtime']  = ['EGT',strtotime($data['start_time'])];
        }

        if ( $data['end_time'] ) {
            $end_time = $data['end_time'];
            $return_arr['role_createtime']  = ['ELT',strtotime("$end_time 23:59:59")];
        }

        if ( $data['start_time'] && $data['end_time'] ) {
            $end_time = $data['end_time'];
            $return_arr['role_createtime'] = [
                ['EGT',strtotime($data['start_time'])],
                ['ELT',strtotime("$end_time 23:59:59")],
            ];
        }

        return $return_arr;
    }

    /**
     * 角色列表
     * @param  $data['limit'] 分页
     * @param  $data['keyword'] 关键字
     * @param  $data['status'] 状态
     * @param  $data['start_time'] 创建时间
     * @param  $data['end_time']
     * @return array 返回类型
     */
    //todo 如果没有以上任何一个筛选，就按照，上级->下级，否则就是搜索什么就出现什么
    public function lists( $data = [] )
    {
        $where = $this->getPram( $data );
        $count = count($where);
        if ( $count >= 1 || $data['export'] == 1 ) {//如果是筛选的话，不缓存直接查询
            $where = array_merge( [
                'role_status' => ['NEQ',self::ROLE_STATUS_DELETE],
            ],$where );
            return $this->getListData( $where,$data,$count);

        } else {
            $where = array_merge( [
                'role_status'    => ['NEQ',self::ROLE_STATUS_DELETE],
                'role_parent_id' => self::ROLE_PARENT
            ],$where );

        }

        $list = S('role_lists');

        if ( empty($list[$data['limit']])  ) {
            return $this->getListData( $where,$data,$count );
        }
        return $list[$data['limit']];

    }


    private function getListData( $where = [],$data = [] ,$count_where = '' )
    {
        $list  = $this->getLists( self::ROLE_LIST_FIELD, $where, ($data['export']==1)?'':$data['limit'] );

            foreach ( $list as $key => $value ) {
                $list[$key]['sn'] = $key + 1 + ($data['page'] - 1) * $data['rows'];
                $list[$key]['children'] = [];
                if ( $count_where <= 0 ) {//如果是筛选的话，者不进去
                    $children = $this->getLists(self::ROLE_LIST_FIELD,
                        [
                            'role_status' => ['NEQ', self::ROLE_STATUS_DELETE],
                            'role_parent_id' => $value['role_id']
                        ]
                    );
                    $list[$key]['children'] = $children ?: [];
                }
            }


        $list = [
            'list'  => $list,
            'count' => $this->countList( $where )
        ];

        if ( $list && $count_where <= 0 ) {//有数据才缓存,且不是筛选
            if ( empty(S('role_lists')) ) {
                S('role_lists',[$data['limit']=>$list]);
            } else {
                $merge = array_merge([$data['limit']=>$list],S('role_lists'));
                S('role_lists',$merge);
            }
        }

        return $list;
    }


    public function structure( $keyword = '' )
    {
        $where = [
            'role_status'    => ['NEQ',self::ROLE_STATUS_DELETE],
            'role_parent_id' => self::ROLE_PARENT
        ];
        if ( $keyword ) {
            $where = [
                'role_status' => ['NEQ',self::ROLE_STATUS_DELETE],
                'role_name'   => ['like',"%{$keyword}%"]
            ];
            $list = $this->getStructure( $where, $keyword );
            return array_values($list);
        }

        $list = S('role_structure');

        if ( empty($list)  ) {//没有缓存，连接数据库
            $list = $this->getStructure( $where, $keyword );
        }

        return array_values($list);
    }


    private function getStructure( $where = [] ,$keyword = '' )
    {
        $list = $this->getLists( self::ROLE_STRUCTURE,$where );
        if ( empty($keyword) ) {
            foreach ( $list as $key => $value ) {
                if ( $value['role_parent_id'] == 0 ) {
                    $list[$key]['children'] = $this->getLists( self::ROLE_STRUCTURE,
                        [
                            'role_status'    => ['NEQ',self::ROLE_STATUS_DELETE],
                            'role_parent_id' => $value['role_id']
                        ] );
                }


            }
            S('role_structure',$list);
        }

        return $list;
    }


    public function modify( $data = [] )
    {

        if ( $data['type'] == 'add' || $data['type'] == 'update' || $data['type'] == 'add_son' ) {

            return  $this->newModification( $data );

        } elseif( $data['type'] == 'del' || $data['type'] =='state' ) { //删除，修改禁用状态

            return $this->statusModify( $data );

        } elseif ( $data['type'] == 'details' ) {//查看详情

            return $this->where([
                'role_id'     => $data['id'],
                'role_status' => ['NEQ',self::ROLE_STATUS_DELETE],
            ])->field(self::ROLE_DETAILS)->find();

        }

    }


    private function statusModify( $data = [] )
    {
        $save_data['role_status'] = ($data['type']=='del')?'-1':$data['status'];

        $where = ['role_id' => $data['id']];

        if ( $data['type'] == 'del' ) {//如果是删除一级的话，一并把下级也删除
            $sel = $this->where([
                'role_parent_id' => $data['id']
            ])->field('role_id')->select();

            $arr = array_column($sel,'role_id');

            if ( $sel !== false && count($sel) >= 1 ) {
                $where['role_id'] = ['IN',implode(',',$arr).','.$data['id']];
                $data['id'] = implode(',',$arr).','.$data['id'];
            }
        } elseif ( $data['type'] == 'state' ) {
            $role_founder = $this->getAdmin( [
                'admin_id' => $data['admin_id']
            ] ,'admin_username');
            $role_createtime = time();
            $save_data['role_update_user'] = $role_founder['admin_username'].' '.date('Y-m-d H:i:s',$role_createtime);
        }

        $bool = $this->role($save_data,1,$where);
        if ( $bool !== false ) {
            if ( $data['type'] == 'del' ) {
                $msg = '删除角色';
            } elseif ( $data['type'] == 'state' ) {
                $msg = '编辑角色';
            }
            admin_log("{$msg},ID:{$data['id']}",9,$data['admin_id']);
            return true;
        }
        return false;
    }

    private function newModification( $data = [] )
    {
        $save_data['role_name']     = $data['name'];
        $save_data['role_describe'] = $data['describe'];
        $save_data['role_status']   = $data['status'];
        $role_founder = $this->getAdmin( [
            'admin_id' => $data['admin_id']
        ] ,'admin_username');
        $role_createtime = time();
        $save_data['role_update_user'] = $role_founder['admin_username'].' '.date('Y-m-d H:i:s',$role_createtime);
        if ( $data['type'] == 'add' || $data['type'] == 'add_son' ) {
            $save_data['role_founder']     = $role_founder['admin_username'];
            $save_data['role_createtime']  = $role_createtime;
            if ( $data['type'] == 'add_son' ) {
                $save_data['role_parent_id'] = $data['id'];
            }
        }

        $state = ($data['type']=='add'||$data['type']=='add_son')?0:1;
        if ( $data['type']=='add'||$data['type']=='add_son' ) {
            $bool = $this->role($save_data,$state);
            if ( $bool !== false ) {
                admin_log("新增角色,ID:{$bool}",9,$data['admin_id']);
                return true;
            }
        } else {
            $bool = $this->role($save_data,$state,[
                'role_id' => $data['id']
            ]);
            if ( $bool !== false ) {
                admin_log("编辑角色,ID:{$data['id']}",9,$data['admin_id']);
                return true;
            }
            return false;
        }

    }


    public function privilege( $data = [] )
    {
        if ( $data['type'] == 'lists' ) {
            return $this->privilegeLists( $data['id'] );
        } elseif ( $data['type'] == 'add' ) {
            $role_founder = $this->getAdmin( [
                'admin_id' => $data['admin_id']
            ] ,'admin_username');
            $role_createtime = time();
            $bool = $this->where(['role_id'=>$data['id']])->save([
                'role_privilege'   => $data['privilege_arr'],
                'role_update_user' => $role_founder['admin_username'].' '.date('Y-m-d H:i:s',$role_createtime)
            ]);
            if ( $bool !== false ) {
                S('role_lists',null);
                admin_log("角色授权,角色ID:{$data['id']}，授权：{$data['privilege_arr']}",9,$data['admin_id']);
                return true;
            }
            return false;
        }
    }

    private function privilegeSel ( $where = [] ,$field = self::PRIVILEGE_FIELD )
    {
        return M('Privilege')->where($where)->order('priv_sort desc,priv_id asc')->field($field)->select();
    }

    private function privilegeLists( $id = '' )
    {
        static $right_all = array();
        static $right_has = array();
        if (empty($right_all)) {
            $tmp_all = $this->privilegeSel( [
                'priv_status'=>1
            ] );
        }

        $role_privilege = $this->where(['role_id'=>$id])->getField('role_privilege');

        if ( empty($right_has) && $role_privilege ) {
            $tmp_has = $this->privilegeSel( [
                'priv_status'=> 1,
                'priv_id'    => ['IN',$role_privilege]
            ] );

        }


        if (!empty($tmp_has)) {
            foreach ($tmp_has as $key => $val ) {
                $right_has[$val['priv_group']][$val['priv_id']] = $val;
            }
        }

        if (!empty($tmp_all)) {
            $arr = explode(',',$role_privilege);
            foreach ($tmp_all as $k=>$v) {
                $right_all[$v['priv_group']][$v['priv_id']] = $v;
                $right_all[$v['priv_group']][$v['priv_id']]['status'] = 0;
                if ( in_array($v['priv_id'],$arr) ) {
                    $right_all[$v['priv_group']][$v['priv_id']]['status'] = 1;
                }
            }
        }

        return [
            'right_all' => $right_all,
            'right_has' => $right_has
        ];
    }

    /**
     * 导出角色列表
     * @param array $list
     * @param array $params
     */
    public static function exportRoleListAndParams($list,$params)
    {
        ini_set("max_execution_time", 0);//修改最大执行时间
        ini_set("memory_limit", -1); //修改此次的最大运行内存
        $fileName = '角色管理列表-'.date('Y-m-d H:i:s',time());
        $row = array();
        foreach ($list['list'] as $key => $value) {
            $row[$key]['sn']               = $key + 1;
            $row[$key]['role_founder']     = $value['role_founder'];
            $row[$key]['role_name']        = $value['role_name'] . "\t";
            $row[$key]['role_createtime']  = $value['role_createtime'] . "\t";
            $row[$key]['role_update_user'] = $value['role_update_user'] . "\t";
            if ( $value['role_status'] == 0 ) {
                $role_status = '禁用';
            } elseif ( $value['role_status'] == 1 ) {
                $role_status = '启用';
            }
            $row[$key]['role_status']     = $role_status . "\t";
            $row[$key]['role_describe']   = $value['role_describe'] . "\t";
        }
        $title = array('序号','创建人', '角色名称', '创建时间','上一次更新操作','状态','角色描述');
        $tableTitle = ['角色管理列表'];

        exportExcel($row,$fileName,$title,'Sheet1',$tableTitle);
    }
}
