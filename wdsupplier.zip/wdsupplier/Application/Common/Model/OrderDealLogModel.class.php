<?php
/**
 * 订单处理日志模型
 * @author 
 */
namespace Common\Model;
use Think\Model;
class OrderDealLogModel extends Model {
	/**
	 * [addDealLog 用户下单完成后平均分配订单给客服处理]
	 */
	public function addDealLog($pay_sn){
        try {
            //根据订单支付单号取出订单主键ID
            $orderModel = M('Order');
            $order_id = $orderModel->where(array('pay_sn'=>$pay_sn))->getField('order_id');
            //设置订单表的处理状态为1
            $orderModel->where(array('pay_sn'=>$pay_sn))->setField('deal_state', 1);
            $role_id = 17;
            // 取出处理订单日志表中的管理员IDgroup
            $assign_id = M('OrderDealLog')
                ->where(array('role_id'=>$role_id,'is_done'=>0))
                ->group('assign_id')->getField('assign_id', true);

            $assign_ids = empty($assign_id)?array():$assign_id;
            //角色为客服的全部管理员ID
            $all_admin = M('Admin')->where(array('role_id'=>$role_id,'admin_status'=>1))->getField('admin_id', true);
            $result = array_diff($all_admin,$assign_ids);
            if(empty($result)){
                if (empty($all_admin)) {
                    log2File('无客服角色！', 'pay_error');
                    return 0;
                }
                //如果为空则表示每个客服都已经有处理过订单
                //那就取出处理订单最少的客服ID
                $aiwhere['role_id'] = $role_id;
                $aiwhere['is_done'] = 0;
                $aiwhere['assign_id'] = array('in', $all_admin);

                $admin_info = $this->field('assign_id,count(assign_id) as sum_num')->where($aiwhere)->group('assign_id')->order('sum_num')->limit(1)->select();
                $assign_id = $admin_info[0]['assign_id'];
            }else{
                $assign_id = current($result);
            }

            $data['order_id'] = $order_id;
            $data['role_id'] = $role_id;	//分配的角色ID
            $data['assign_id'] = $assign_id;	//分配的管理员ID
            $data['start_state'] = 1;	//设置订单处理状态为客服审核
            $data['update_state'] = 1;
            $data['message'] = "用户下单完成自动推送给客服审核";
            $data['create_time'] = time();
            $id = $this->add($data);
            if (!$id) {
                throw new \Exception('err: ' . $this->getError() . "\r\n" . "sql" . $this->getLastSql());
            }
        } catch (\Exception $e) {
            log2File($e->getMessage(), 'pay_error');
            return 0;
        }

	}
	/**
	 * [confirmAddDealLog 用户签收后把订单处理状态改为正常处理完成]
	 * @param  [type] $order_id [description]
	 * @return [type]           [description]
	 */
	public function confirmAddDealLog($order_id){
		M('OrderDealLog')->where(array('order_id'=>$order_id))->setField('is_done', 1);
		//设置订单表的处理状态为7
		M('Order')->where(array('order_id'=>$order_id))->setField('deal_state', 7);
		$data['order_id'] = $order_id;
		$data['role_id'] = 0;	//分配的角色ID
		$data['assign_id'] = 0;	//分配的管理员ID
		$data['update_state'] = 7;	//状态变为正常处理完成
		$data['is_done'] = 1;
		$data['message'] = "用户确认收货后自动把订单处理状态变为已完成";
		$data['create_time'] = time();
		$this->add($data);
	}
	/**
	 * [addReadDealLog 仓管把订单推送给财务后，也要提示给处理这个订单的客服，给客服只读的日志即可]
	 */
	public function addReadDealLog($parm=array()){
		$info = $this->field('assign_id')->where(array('order_id'=>$parm['order_id'],'role_id'=>3))->order('create_time desc')->find();
		$data['order_id'] = $parm['order_id'];
		$data['role_id'] = 3;	//分配的角色ID
		$data['assign_id'] = $info['assign_id'];	//分配的管理员ID
		$data['update_state'] = $parm['update_state'];
		$data['is_done'] = 1;
		$data['message'] = "仓管处理完成后，自动把消息推送给处理这个订单的客服号";
		$data['create_time'] = time();
		$data['is_read'] = 0;	//表示未读
		$this->add($data);
	}
}
