<?php
/**
 * 致富超市商品模型
 * @author deason 2016-07
 */

namespace Common\Model;

use Think\Model;

class CouponModel extends Model
{
    const FIELD_LIST = '';
    //参加红包活动的超市，0表示我们的平台
    public $store_list = array(0);
    public $start_time = "2017-8-11 19:00:00";    //活动开始时间
    public $end_time = "2017-8-16 19:00:00";        //活动结束时间
    public $total = 5000;    //红包金额上限

    /**
     *获取奖券
     */
    public function gainCoupon($data = array())
    {
        $addData['member_id']      = $data['member_id'];
        $addData['valid_store_id'] = $data['store_id'];
        $tmp_rand                  = rand(0, 100);
        if ($tmp_rand < 75) {
            $tmp_price = rand(100, 300) * 0.01;
        } elseif ($tmp_rand < 95) {
            $tmp_price = rand(300, 450) * 0.01;
        } else {
            $tmp_price = rand(450, 500) * 0.01;
        }
        //判断红包剩余金额
        $total_money = $this->getTotalMoney();    //已领取红包总额
        $total_j     = $this->total;    //红包上限金额
        $s_total     = $total_j - $total_money;
        if ($s_total >= 3 && $s_total < 5) {
            $tmp_price = $s_total / 2;
        } elseif ($s_total < 3) {
            $tmp_price = $s_total;
        }

        $tmp_price                   = sprintf("%.1f", $tmp_price);
        $addData['title']            = '魅力中国' . $tmp_price . '元优惠券';
        $addData['reduce_price']     = $tmp_price;
        $addData['valid_price']      = '0';
        $addData['source_member_id'] = '0';
        $addData['start_time']       = time();
        $addData['end_time']         = strtotime('2017-8-30 23:59:59');
        $addData['type']             = '1';
        $coupon_id                   = $this->add($addData);
        $addData['coupon_id']        = empty($coupon_id) ? 0 : $coupon_id;
        if ($coupon_id) {
            $logData['coupon_id']   = $coupon_id;
            $logData['member_id']   = $data['member_id'];
            $logData['source']      = 1;
            $logData['create_time'] = time();
            $logData['store_id']    = $data['store_id'];
            M('coupon_get_log')->add($logData);
        }
        return $addData;//coupon_id为空的券，兼容接口

    }

    /**
     * [goodIfUseCoupon 根据商品id判断商品是否可以用优惠券]
     * @return [type] [description]
     */
    public function goodIfUseCoupon($ids = array())
    {
        return true;
    }

    /**
     * [获取用户的优惠券-要选取最优惠的]
     * status的值：-1已删除1未使用2已使用3已失效
     * @param  [type] $parm [包括用户ID，购买商品总价]
     * @return [type]           [description]
     */
    public function getBestCoupon($parm = array())
    {
        $no_info = array('title' => '', 'type' => 0, 'coupon_id' => 0, 'reduce_price' => 0, 'status' => 0);
        if (array_key_exists('goods_ids', $parm)) {
            if ($this->goodIfUseCoupon($parm['goods_ids']) == false) {
                return $no_info;
            }
        }
        if (array_key_exists('coupon_id', $parm)) {
            $info = $this->getCouponById($parm);
            if (empty($info)) {
                return $no_info;
            }
            return $info;
        }
        if (array_key_exists('valid_store_id', $parm)) {
            //根据超市id获取最优惠的红包
            $store_info = $this->getStoreCoupon($parm);
            if (empty($store_info)) {
                $store_info = $no_info;
            }
        } else {
            $store_info = $no_info;
        }
        $plat_info = $this->getPlatformCoupon($parm);
        if (empty($plat_info)) {
            $plat_info = $no_info;
        }
        if ($plat_info['reduce_price'] > $store_info['reduce_price']) {
            return $plat_info;
        } else {
            return $store_info;
        }
    }

    /**
     * [getBestCoupon1 获取平台最优惠的红包取一条]
     * @param  array $parm [description]
     * @return [type]       [description]
     */
    public function getPlatformCoupon($parm = array())
    {
        if ($this->goodIfUseCoupon($parm['goods_ids']) == false) {
            return array();
        }
        $where['member_id']      = array('eq', $parm['member_id']);
        $where['status']         = array('eq', 1);
        $where['valid_price']    = array('elt', $parm['goods_total']);    //商品总价要大于等于满减金额
        $where['reduce_price']   = array('lt', $parm['goods_total']);   //
        $where['start_time']     = array('elt', time());
        $where['end_time']       = array('gt', time());   //
        $where['valid_store_id'] = 0;    //表示平台红包
        $reg                     = $this->where($where)
            ->field('coupon_id,title,type,valid_price,valid_store_id,reduce_price,start_time,end_time,status')
            ->order('reduce_price desc')
            ->find();
        return $reg;
    }

    /**
     * [getBestCoupon1 获取平台最优惠的红包取全部]
     * @param  array $parm [description]
     * @return [type]       [description]
     */
    public function getPlatformAllCoupon($parm = array())
    {
        if ($this->goodIfUseCoupon($parm['goods_ids']) == false) {
            return array();
        }
        $where['member_id']      = array('eq', $parm['member_id']);
        $where['status']         = array('eq', 1);
        $where['valid_price']    = array('elt', $parm['goods_total']);    //商品总价要大于等于满减金额
        $where['reduce_price']   = array('lt', $parm['goods_total']);   //
        $where['start_time']     = array('elt', time());
        $where['end_time']       = array('gt', time());   //
        $where['valid_store_id'] = 0;    //表示平台红包
        $reg                     = $this->where($where)
            ->field('coupon_id,title,type,valid_price,valid_store_id,reduce_price,start_time,end_time,status')
            ->order('reduce_price desc')
            ->select();
        return $reg;
    }

    /**
     * [getBestCoupon1 根据超市id获取对应超市最优惠的红包]
     * @param  array $parm [description]
     * @return [type]       [description]
     */
    public function getStoreCoupon($parm = array())
    {
        $where['member_id']      = array('eq', $parm['member_id']);
        $where['status']         = array('eq', 1);
        $where['valid_price']    = array('elt', $parm['goods_total']);    //商品总价要大于等于满减金额
        $where['reduce_price']   = array('lt', $parm['goods_total']);   //
        $where['start_time']     = array('elt', time());
        $where['end_time']       = array('gt', time());   //
        $where['valid_store_id'] = $parm['valid_store_id'];
        $reg                     = $this->where($where)
            ->field('coupon_id,title,type,valid_price,valid_store_id,reduce_price,start_time,end_time,status')
            ->order('reduce_price desc')
            ->find();
        return $reg;
    }

    /**
     * [根据优惠券ID取出优惠券信息]
     * @param  [type] $member_id [用户id]
     * @param  [type] $coupon_id [优惠券id]
     * @param  [type] $goods_total [购买商品总价]
     * @return [type]            [优惠券信息]
     */
    public function getCouponById($parm = array())
    {
        $where['member_id'] = $parm['member_id'];
        $where['status']    = 1;
        $where['type']      = 1;
        $where['coupon_id'] = $parm['coupon_id'];
        if (!empty($parm['goods_total'])) {
            $where['valid_price']  = array('elt', $parm['goods_total']);    //商品总价要大于等于满减金额
            $where['reduce_price'] = array('lt', $parm['goods_total']);   //
            $where['start_time']   = array('elt', time());
            $where['end_time']     = array('gt', time());   //
        }
        if (!empty($parm['valid_store_id'])) {
            $where['valid_store_id'] = $parm['valid_store_id'];
        }
        $result = $this->where($where)->field('coupon_id,title,type,valid_price,valid_store_id,reduce_price,start_time,end_time,status')->find();
        if (!empty($result['valid_store_id'])) $result['valid_store_name'] = M('store')->where('store_id=' . $result['valid_store_id'])->getField('store_name');
        else $result['valid_store_name'] = '';
        return $result;
    }


    //现在一个用户只能领一张优惠券，这里是特定镇安超市
    public function getCouponQual($parm = array())
    {
        return 0;
    }

    /**
     * [getCouponQualAll 获取抽奖资格，以后都用这个]
     * @param  array $parm [description]
     * @return [type]       [description]
     */
    public function getCouponQualAll($parm = array())
    {
        $store_id = $parm['store_id'];
        //判断超市是否有参加红包活动
        if (!in_array($store_id, $this->store_list)) return 0;
        $start = strtotime($this->start_time);
        $end   = strtotime($this->end_time);
        if (time() < $start || $end < time()) return -2;
        $member_id             = $parm['member_id'];
        $addwhere['member_id'] = $member_id;
        $addwhere['store_id']  = $store_id;
        $getcount              = M('coupon_get_log')->where($addwhere)->count();
        if ($getcount > 0) return 0;
        //再判断红包金额总数是否已经达到上限
        $total_money = $this->getTotalMoney();    //已发金额
        $total_j     = $this->total;    //红包上限金额
        $s_total     = $total_j - $total_money;
        if ($total_money >= $total_j || $s_total < 1) return -1;
        return 1;
    }

    /**
     * [getTotalMoney 取出已经发放的红包总金额]
     * @return [type] [description]
     */
    public function getTotalMoney()
    {
        $where['valid_store_id'] = 0;    //为0表示我们平台
        $total                   = M('Coupon')->where($where)->sum('reduce_price');
        return $total;
    }

    /**
     * [getActivityIfEnd 获取活动是否已经结束]
     * @return [type] [description]
     */
    public function getActivityIfEnd()
    {
        $start = strtotime($this->start_time);
        $end   = strtotime($this->end_time);
        if ($start < time() && time() < $end) {
            return true;
        }
        return false;
    }

    public function temporary()
    {
        $end = strtotime($this->end_time);
        if (time() < $end) {
            return true;
        }
        return false;
    }
}
