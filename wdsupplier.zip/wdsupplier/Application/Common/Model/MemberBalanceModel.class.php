<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/3/7
 * Time: 15:38
 */

namespace Common\Model;

use Think\Exception;
use Think\Model;

/**
 * 用户余额表
 */
class MemberBalanceModel extends Model
{

    /**
     * 生成一条退款记录
     *
     * @param $order
     * @param $refund_ree
     * @param $refund_type
     *
     * @return array
     */
    public function preBalanceData($uid, $recharge = 0, $return = 0)
    {
        $data = [
            'uid'              => $uid,
            'recharge_balance' => $recharge,
            'return_balance'   => $return,
        ];
        return $data;
    }

    /**
     * 获取用户的余额账户，如果不存在就创建
     *
     * @param $userId
     *
     * @return array|mixed
     * @throws \Think\Exception
     */
    public function getBalanceInfoByUserId($userId)
    {
        $info = $this->where(['uid' => $userId])->find();
        if (!$info) {
            $info = $this->preBalanceData($userId);
            $rs = $this->add($info);
            if (!$rs) {
                throw new Exception('创建用户余额账户失败');
            }
            $info['id'] = $this->getLastInsID();
        } else {
            $info['recharge_balance'] = bcadd($info['recharge_balance'], 0, 2);
        }
        return $info;
    }

}