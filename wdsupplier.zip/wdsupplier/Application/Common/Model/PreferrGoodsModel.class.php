<?php
/**
 * 商品模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class PreferrGoodsModel extends GoodsModel {
	/**
	 * 获取企业采购商品列表
	 */
	
	public $sortList = array(
            'common_desc'   => 'gg.goods_sort asc,go.goods_id DESC',      // 人气排序
            'pop_desc'   => 'go.goods_click DESC,go.goods_sort ASC',      // 人气排序
            'sales_desc' => 'go.goods_salenum DESC,go.goods_sort ASC',    // 销量排序
            'price_desc' => 'gp.goods_price DESC,go.goods_id DESC',     // 价格排序 - 降序
            'price_asc'  => 'gp.goods_price ASC,go.goods_id DESC'       // 价格排序 - 升序
    );

    const FIELD_GOODS_LIST = 'go.goods_id,goods_name,goods_jingle,goods_state,goods_unit,goods_salenum,goods_img,goods_serial,goods_salenum,go.store_name,go.goods_marketprice,go.store_id,go.goods_spec_id,goods_sort';

	public function getList($where = array(), $limit = '0,10', $field = '*', $order = 'common_desc')
	{ 
		$member_id=$where['member_id'];
		unset($where['member_id']);
		$where['go.goods_state']=1;
		$where['gp.goods_price']=array('gt',0);
        $where['gg.is_show']=1;
		//sx_preferr_goods为主表 连商品表
		$orderby = empty($this->sortList[$order]) ? array_shift($this->sortList) : $this->sortList[$order];
		//$role=D('Member')->getMemberRole($member_id);
		//按排序获取商品列表
		$subQuery = $this->field("goods_id,goods_sort,goods_click,goods_salenum,goods_state,goods_spec_id,gc_id_1,gc_id_2")->table('__GOODS__')->buildSql(); 
		$subQuery2 = $this->field("goods_id,price as goods_price,goods_spec_id")->table('__GOODS_PRICE__')->where(array('type'=>0))->buildSql();
		$list=$this->alias('gg')
			->join("LEFT JOIN $subQuery as go ON gg.goods_id = go.goods_id")
			->join("LEFT JOIN $subQuery2 as gp on go.goods_id =gp.goods_id and go.goods_spec_id =gp.goods_spec_id")
			->where($where)->limit($limit)->field('go.goods_id,go.goods_spec_id')->order($orderby)->select();
		$goodsModel=D('Goods');
		foreach ($list as $key => &$value) {
			$value=$this->getListDetail(['goods_id'=>$value['goods_id'],'goods_spec_id'=>$value['goods_spec_id'],'role'=>0]);
			$value['goods_type']=3;
			$value['buy_store_id']=0;
			//商品合法性校验
			$checkState=$this->checkStateToBuyByInfo($value);
			if($checkState['code']!=$goodsModel::STATE_NORMAL&&$checkState['code']!= $goodsModel::STATE_CODE_NOT_STOCK) unset($list[$key]);
		}
		return array_values($list);
	}

}
