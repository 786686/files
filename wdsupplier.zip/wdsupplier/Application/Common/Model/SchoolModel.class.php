<?php
/**
 * 学校表
 * Created by PhpStorm.
 * Date: 2019/4/28
 * Time: 11:50
 */

namespace Common\Model;


use Think\Model;

class SchoolModel extends Model
{
    /**
     *  学校新增
     *  有对应学校就返回学校id，没对应的学校新增学校并返回学校id
     * @param $school
     */
    public function addSchool($school){

        if(empty($school)){
            return false;
        }
        $schoolData = $this->getSchoolInfoBySchool($school);

        if(!empty($schoolData)){
            return isset($schoolData['id']) ? $schoolData['id'] : false;
        }

        $result = M('school')->add(['school_name'=>$school,'created_time'=>date('Y-m-d H:i:s')]);
        return $result ? $result : false;
    }

    /**
     *  根据id查询学校
     * @param $id
     */
    public function getSchoolInfoById($id){
        if(empty($id) || int($id)){
            return false;
        }
        $where = [];
        $where['id'] = $id;
        $result = M('school')->field('id,school_name')->where($where)->find();

        return empty($result) ? [] : $result;
    }

    /**
     *  根据学校名称查询学校
     * @param $id
     */
    public function getSchoolInfoBySchool($school){

        if(empty($school)){
            return false;
        }
        $where = [];
        $where['school_name'] = $school;
        $result = M('school')->field('id,school_name')->where($where)->find();

        return empty($result) ? [] : $result;
    }

}