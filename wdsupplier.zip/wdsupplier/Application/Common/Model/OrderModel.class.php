<?php
/**
 * 订单模型
 * @author deason 2016-07
 */

namespace Common\Model;

use Api\Controller\CommonController;
use Api\Controller\NewCenterController;
use Common\Service\Sms as SmsService;
use Think\Model;
use Api\Model\CodeModel;
use Think\Template\Driver\Mobile;

class OrderModel extends Model
{

    // 订单状态	order_state
    // 订单状态：0(已取消)10(默认):未付款;20:已付款;30:已发货;40:已收货;
    const STATE_CANCEL = 0;    // 已取消
    const STATE_NORMAL = 10;    // 未付款 [默认]
    const STATE_PAY = 20;    // 已付款
    const STATE_SEND = 30;    // 已发货
    const STATE_FINISH = 40;    // 完成订单
    // 评价状态 FIELD : evaluation_state
    const EVAL_NOT = 0;        // 未评价
    const EVAL_DONE = 1;        // 已评价
    const EVAL_END = 2;        // 已过期
    const EVAL_VALID = 2592000;    // 有效时长 (30 * 24 * 60 * 60)
    // 订单送货类型
    const TYPE_SEND = 1;        // 送货上门
    const TYPE_PICK = 2;        // 网店自提
    const TYPE_RESERVATION = 3;    // 预定 -- 保留
    // 退款状态
    const REFUND_NOT = 0;    // 无退款
    const REFUND_PART = 1;        // 部分退款
    const REFUND_ALL = 2;        // 全部退款
    // 删除状态
    const DELETE_NOT = 0;        // 未删除
    const DELETE_PRE = 1;        // 放入回收站
    const DELETE_DONO = 2;        // 彻底删除
    // 每单最大商品量
    const ORDER_MAX_BUY_LIMIT = 50;
    // 订单过期时间
    const VALID_TIME = 900;        // 15分钟
    // 订单类别列表
    public $typeList = array(
        self::TYPE_SEND, self::TYPE_PICK, self::TYPE_RESERVATION
    );

    // 订单状态 {值:名称}
    public $stateNameList = array(
        self::STATE_CANCEL => '已取消',
        self::STATE_NORMAL => '未付款',
        self::STATE_PAY    => '已付款',
        self::STATE_SEND   => '已发货',
        self::STATE_FINISH => '已完成',
    );
    // 字段 - 列表使用
    const FIELD_LIST = 'order_id,order_sn,order_type,store_id,add_time,order_amount,goods_amount,shipping_fee,payment_code,evaluation_state,order_state,refund_state,order_message,reciver_name,reciver_mobile,reciver_address,is_batch,supplier_name';
    const FIELD_LISTS = 'o.order_id,o.order_sn,o.order_type,o.store_id,o.add_time,o.order_amount,o.goods_amount,o.shipping_fee,o.payment_code,o.evaluation_state,o.order_state,o.refund_state,o.order_message,o.reciver_name,o.reciver_mobile,o.reciver_address,o.is_batch,o.supplier_name,g.goods_name,o.voucher_status,o.voucher_reason,o.voucher_pay,o.is_welfare_zone';
    const FIELD_INFO = 'order_id,order_sn,order_type,buyer_id,pay_sn,store_id,add_time,order_amount,goods_amount,shipping_fee,payment_code,payment_time,refund_state,evaluation_state,order_state,reciver_name,reciver_mobile,reciver_address,order_message,reciver_info,reciver_province_id,reciver_city_id,reciver_area_id,reciver_zipcode,supplier_name,supplier_id,shipping_code,is_batch,shipping_type,finnshed_time,group_purchase_id,consum_account_cut,is_welfare_zone';
    public $needPageTotalRow = false;    // 开启获取分页总计条目数
    public $pageTotalRow = 0;        // 分页总计条目数

    /**
     * 生产订单
     */
    public function addOrder($data = array())
    {
        $colonel_discount_price = empty($data['colonel_discount_price']) ? 0 : $data['colonel_discount_price'];// 团长优惠价格（团购订单）
        $addressInfo            = D('MemberAddress')->getInfo(array('address_id' => $data['address_id']), 'address_id,member_id,true_name,area_id,city_id,area_info,address,tel_phone,mob_phone,lng,lat');
        $memberInfo             = D('Common/Member')->getInfo(array('member_id' => $data['member_id']), 'member_id,member_mobile,member_nickname');
        // 取出政企会员账户认证手机号
        $company_mobile = M('CompanyAuth')->where(['member_id' => $data['member_id'], 'status' => 1])->getField('apply_mobile');
        if ($data['order_type'] == self::TYPE_SEND) {
            $transport_data        = $data['transport_data'];//tmp
            $orderTransportFee     = $transport_data['data']['transport_fee'];
            $shipping_fee_platform = ($transport_data['data']['transport_fee_platform']) ? $transport_data['data']['transport_fee_platform'] : 0;
            $shipping_fee_store    = ($transport_data['data']['transport_fee_store']) ? $transport_data['data']['transport_fee_store'] : 0;
        }
        $adddata['company_id']             = $data['company_id'] ? $data['company_id'] : 0;
        $adddata['supplier_id']            = $data['supplier_id'];    // 订单编号
        $adddata['supplier_name']          = $data['supplier_name'];    // 订单编号
        $adddata['order_sn']               = $this->makeOrderSN($data['member_id']);    // 订单编号
        $adddata['pay_sn']                 = $this->makePaySN($data['member_id']);    // 支付单号
        $adddata['store_id']               = $data['store'];
        $adddata['store_name']             = '';
        $adddata['buyer_id']               = $data['member_id'];
        $adddata['buyer_name']             = $memberInfo['member_nickname'];
        $adddata['buyer_phone']            = $memberInfo['member_mobile'];
        $adddata['add_time']               = NOW_TIME;
        $adddata['payment_code']           = $data['payment_code'] ? $data['payment_code'] : '';
        $adddata['goods_amount']           = $data['orderGoodsAmount'];// 商品总价格
        $adddata['order_amount']           = $data['orderGoodsAmount'] + $orderTransportFee - $colonel_discount_price;// 商品总价格
        $adddata['shipping_fee']           = $orderTransportFee ? $orderTransportFee : 0;// 商品总价格
        $adddata['coupon_id']              = empty($data['coupon_id']) ? 0 : $data['coupon_id'];// 商品总价格
        $adddata['consum_account_cut']     = empty($data['consum_account']) ? 0 : $data['consum_account'];// 消费账户抵扣
        $adddata['is_welfare_zone']        = empty($data['is_welfare_zone']) ? 0 : $data['is_welfare_zone'];// 消费账户抵扣
        $adddata['colonel_discount_price'] = $colonel_discount_price;
        if (!empty($data['coupon_id'])) {
            $coupon_info = D('Coupon')->getCouponById(['member_id' => $data['member_id'], 'coupon_id' => $data['coupon_id'], 'goods_total' => $data['orderGoodsAmount']]);
            if ($coupon_info['reduce_price'] > 0) $adddata['order_amount'] = $adddata['order_amount'] - $coupon_info['reduce_price'];
            M('Coupon')->where(['coupon_id' => $coupon_info['coupon_id']])->save(['status' => 2]);
        }
        //消费账户抵扣
        if (!empty($data['consum_account'])) {
            $adddata['order_amount'] = $adddata['order_amount'] - $adddata['consum_account_cut'];
        }
        //判断是否有免邮ID
        if (!empty($data['free_id'])) {
            $regCoupon = M('Coupon')->where(array('coupon_id' => $data['free_id'], 'member_id' => $data['member_id'], 'type' => 2, 'status' => 1))->find();
            //如果存在免邮券，就要减去邮费
            if ($regCoupon)
                $adddata['order_amount'] = $adddata['order_amount'] - $orderTransportFee;
            M('Coupon')->where(array('coupon_id' => $data['free_id'], 'member_id' => $data['member_id'], 'type' => 2))->save(['status' => 2]);
        }
        $adddata['order_state']       = self::STATE_NORMAL;                    // 订单状态
        $adddata['order_from']        = $data['order_from'];                                // 来源设备
        $adddata['order_message']     = $data['order_message'];                                        // 订单留言
        $adddata['order_type']        = $data['order_type'];                                        // 订单类型
        $adddata['order_pointscount'] = 0;                                            // 订单赠送积分
        $adddata['chain_code']        = $data['order_type'] == self::TYPE_PICK ? $this->makeChainCode() : 0;    // 网店自提码 ,自提时生成
        // 收货信息
        $adddata['reciver_name']        = $addressInfo['true_name'] ?: $memberInfo['member_nickname'];            // 收货人姓名
        $adddata['reciver_info']        = $addressInfo['area_info'] ?: '';        // 收货人其它信息
        $adddata['reciver_province_id'] = $addressInfo['province_id'] ?: 0;            // 收货省份ID [暂无]
        $adddata['reciver_city_id']     = $addressInfo['city_id'] ?: 0;            // 收货城市ID
        $adddata['reciver_area_id']     = $addressInfo['area_id'] ?: 0;                // 收货地区ID
        $adddata['reciver_address']     = $addressInfo['address'] ?: '';            // 收货地址
        //$adddata['reciver_mobile']  =$data['order_type'] ==self::TYPE_PICK ? '0' : $addressInfo['mob_phone'];	// 收货人电话
        $reciver_mobile = $addressInfo['mob_phone'] ? $addressInfo['mob_phone'] : $memberInfo['member_mobile'];
        if ($data['order_type'] == self::TYPE_PICK && !empty($company_mobile)) {
            $reciver_mobile = $company_mobile;
        }
        $adddata['reciver_mobile']  = $reciver_mobile;
        $adddata['reciver_zipcode'] = $addressInfo['zipcode'] ?: '';        // 邮编	[暂无]
        // 与下单无关字段
        $adddata['delete_state']          = self::DELETE_NOT;    // 删除状态
        $adddata['refund_state']          = self::REFUND_NOT;    // 退款状态
        $adddata['evaluation_state']      = self::EVAL_NOT;        // 评价状态
        $adddata['delay_time']            = 0;        // 延迟时间,默认为0
        $adddata['trade_no']              = '';    // 外部交易订单号
        $adddata['api_pay_time']          = 0;    // 在线支付动作时间
        $adddata['payment_time']          = 0;    // 支付(付款)时间
        $adddata['pd_amount']             = 0;        // 余额支付金额（预留）
        $adddata['refund_amount']         = 0;        // 退款金额
        $adddata['evaluation_time']       = 0;    // 评价时间
        $adddata['evalseller_time']       = 0;        // 卖家评价买家的时间
        $adddata['daddress_id']           = 0;        // 发货地址ID
        $adddata['shipping_code']         = '';    // 物流单号
        $adddata['finnshed_time']         = 0;        // 订单完成时间
        $adddata['shipping_time']         = 0;        // 配送时间
        $adddata['shipping_express_id']   = 0;        // 配送公司ID
        $adddata['deliver_explain']       = 0;        // 发货备注
        $adddata['admin_remark']          = '';// 管理人员备注
        $adddata['shipping_fee_platform'] = ($shipping_fee_platform) ? $shipping_fee_platform : 0;//平台运费
        $adddata['shipping_fee_store']    = ($shipping_fee_store) ? $shipping_fee_store : 0; //网店运费
        $adddata['is_batch']              = $data['is_batch'];//是否企业采购（批量订单）
        $adddata['reserve_shipping_time'] = $data['reserve_shipping_time'];//预配送时间
        $adddata['store_id_type']         = 1;
        //是否为团购订单
        if (!empty($data['group_purchase_id'])) {
            $adddata['group_purchase_id'] = $data['group_purchase_id'];
        }
        $modelCart = D('Cart');
        //余额提现
        $tmp_option  = M('Option')
            ->where(array('option_name' => ['in', ['account_rate', 'choice_cash_type']]))
            ->select();
        $option_list = [];
        foreach ($tmp_option as $rows) {
            $option_list[$rows['option_name']] = $rows['option_value'];
        }
        unset($tmp_option);
        $rate               = 0;    // 费率
        $cash_time          = 0; // 提现时间
        $withdrawal_balance = 0;
        if (!empty($option_list)) {
            $rate               = !empty($option_list['account_rate']) ? $option_list['account_rate'] * 0.01 : 0;
            $withdrawal_balance = $adddata['order_amount'] * $rate;
            if ($withdrawal_balance <= 0.01) {
                $withdrawal_balance = 0.01;
            }
            $withdrawal_balance = ceil($withdrawal_balance * 100) / 100;
            if (!empty($option_list['choice_cash_type'])) {
                $cash_time = C('cash_time.' . $option_list['choice_cash_type']); // 提现时间
                if (empty($cash_time)) {  // config 文件没设置则为0
                    $cash_time = 0;
                }
            }
        }
        $adddata['withdrawal_balance']     = $adddata['order_amount'] - $withdrawal_balance;
        $adddata['freeze_withdrawal_rate'] = $rate;
        $adddata['can_withdrawal_time']    = $cash_time;

        // 数据库操作
        $orderId = $this->add($adddata);

        //判断是否测试订单（测试账号产生的订单都为测试订单）
        $check_test_member = M('member_test')->where(['member_id' => $data['member_id']])->getField('id');
        if ($orderId && $check_test_member) {
            M('order_test')->add(['order_id' => $orderId]);
        }
        return $orderId;
    }


    /**
     * 获取数据列表
     * @param  array $where [description]
     * @param  string $limit [description]
     * @param  string $field [description]
     * @param  string $order [description]
     * @return [type]        [description]
     */
    public function getList($where = array(), $limit = '', $field = '', $order = '', $ossClient)
    {
        if (empty($field)) $field = self::FIELD_LISTS;
        if (empty($order)) $order = 'o.order_id DESC';

        $orderList = $this->alias('o')->field($field)->join("left join __ORDER_GOODS__ as g on o.order_id =g.order_id")->where($where)->limit($limit)->order($order)->group('o.order_id')->select();

        $orderGoodsModel = D('OrderGoods');
        foreach ($orderList as $x => $order) {
            $store_data                   = D('Store')->getInfo(array('store_id' => $order['store_id']), '*', $ossClient);
            $orderList[$x]['voucher_pay'] = (!empty($order['voucher_pay'])) ? unserialize($order['voucher_pay']) : '';
            $orderList[$x]['goods_list']  = $orderGoodsModel->getListAndRefund(['order_id' => $order['order_id']], '', '', '', $ossClient);
            $orderList[$x]['goods_num']   = count($orderList[$x]['goods_list']);
            $orderList[$x]['store_phone'] = $store_data['store_phone'] ? $store_data['store_phone'] : '4009300277';
            $orderList[$x]['store_name']  = $store_data['store_name'] ? $store_data['store_name'] : '';
            if (!in_array($orderList[$x]['payment_code'], ['bankpay', 'checkpay'])) {
                unset($orderList[$x]['voucher_status']);
                unset($orderList[$x]['voucher_reason']);
                unset($orderList[$x]['voucher_pay']);
            }
        }
        return $orderList;
    }


    /**
     * 获取个人团购订单数据列表
     * @param  array $where []
     * @param  string $limit [description]
     * @param  string $field [description]
     * @param  string $order [description]
     * @return [type]        [description]
     */
    public function getGroupList($where = array(), $limit = '', $field = '', $order = 'a.order_id DESC', $ossClient)
    {
        $where['a.group_purchase_id'] = array('gt', 0);   //团购ID大于0表示团购订单
        $field                        = 'a.order_id,a.order_sn,a.order_type,a.store_id,a.add_time,a.order_amount,a.goods_amount';
        $field                        .= ',a.shipping_fee,a.payment_code,a.evaluation_state,a.order_state,a.refund_state';
        $field                        .= ',a.order_message,a.reciver_name,a.reciver_mobile,a.reciver_address,a.is_batch,a.supplier_name';
        $field                        .= ',b.spell_state,b.member_num,b.group_member_num,b.spell_state';
        $orderList                    = $this
            ->alias('a')
            ->join('left join __GROUP_PURCHASE__ b on a.group_purchase_id=b.id')
            ->join('left join __ORDER_GOODS__ as g on a.order_id=g.order_id')
            ->where($where)
            ->limit($limit)
            ->field($field)
            ->order($order)
            ->select();
        $orderGoodsModel              = D('OrderGoods');
        foreach ($orderList as $x => $order) {
            $store_data                   = D('Store')->getInfo(array('store_id' => $order['store_id']), '*', $ossClient);
            $orderList[$x]['goods_list']  = $orderGoodsModel->getGroupList(['order_id' => $order['order_id']], '', '', 'a.rec_id DESC', $ossClient);
            $orderList[$x]['goods_num']   = count($orderList[$x]['goods_list']);
            $orderList[$x]['store_phone'] = $store_data['store_phone'] ? $store_data['store_phone'] : '4009300277';
            $orderList[$x]['store_name']  = $store_data['store_name'] ? $store_data['store_name'] : '';
            //s_type:3表示团购专区类型
            $orderList[$x]['more_group_url'] = C('WEBSITE_URL') . U('Mobile/Index/hundred_roll');    //更多拼团跳转url
        }
        return $orderList;
    }

    //获取用户团购订单统计
    public function getGroupOrderNum($data = array())
    {
        $member_id                    = $data['member_id'];
        $where['a.buyer_id']          = $member_id;
        $where['a.delete_state']      = self::DELETE_NOT;
        $where['a.group_purchase_id'] = array('gt', 0);
        $result                       = $this
            ->alias('a')
            ->field('a.payment_code,b.spell_state')
            ->where($where)
            ->join('left join __GROUP_PURCHASE__ b on a.group_purchase_id=b.id')
            ->select();
        $orderState[1]                = array('num' => 0, 'spell_state' => '2');    //拼团中
        $orderState[2]                = array('num' => 0, 'spell_state' => '3');    //拼团成功
        $orderState[3]                = array('num' => 0, 'spell_state' => '4');    //拼团失败
        $orderState[9]                = array('num' => 0, 'spell_state' => '100');    //全部
        foreach ($result as $row) {
            if ($row['payment_code'] != '') {
                if ($row['spell_state'] == 2) {
                    $orderState[1]['num'] += 1;
                } else if ($row['spell_state'] == 3) {
                    $orderState[2]['num'] += 1;
                } else if ($row['spell_state'] == 4) {
                    $orderState[3]['num'] += 1;
                }
            }
            $orderState[9]['num'] += 1;    // 全部
        }
        $new['spell_state'] = array_values($orderState);
        unset($result);
        return $new;
    }


    /**
     * 获得详细信息
     * @param  array $where [description]
     * @param  string $field [description]
     * @return [type]        [description]
     */
    public function getInfo($where = array(), $field = '*')
    {
        return $this->where($where)->field($field)->find();
    }


    /**
     * 区分旧方法
     * 获得详细信息
     * @param  array $where [description]
     * @param  string $field [description]
     * @return [type]        [description]
     */
    public function getDetail($where = array(), $field = '', $ossClient)
    {

        if (empty($field)) $field = self::FIELD_INFO;
        $orderInfo = $this->where($where)->field($field)->find();
        $order_id  = $orderInfo['order_id'];
        //发票信息
        $invoiceInfo = M('order_invoice')->field('id as invoice_id,type as invoice_type ,title as invoice_title ,receive_phone as invoice_phone,receive_email as invoice_email,receive_content as invoice_content,tax_number,register_address,register_phone,bank,bank_account,is_company')->where(array('order_id' => $order_id))->find();
        if (!empty($invoiceInfo)) {
            $orderInfo               = array_merge($orderInfo, $invoiceInfo);
            $orderInfo['is_invoice'] = 1;
        } else {
            $orderInfo['is_invoice']       = 0;
            $orderInfo['invoice_id']       = 0;
            $orderInfo['invoice_type']     = 1;
            $orderInfo['is_company']       = 1;
            $orderInfo['invoice_title']    = '';
            $orderInfo['invoice_phone']    = '';
            $orderInfo['invoice_email']    = '';
            $orderInfo['invoice_content']  = '';
            $orderInfo['register_address'] = '';
            $orderInfo['register_phone']   = '';
            $orderInfo['bank']             = '';
            $orderInfo['bank_account']     = '';
        }
        $goods_list = D('OrderGoods')->getList(['order_id' => $order_id], $limit
            = '', $field = '', $order = 'rec_id asc', $ossClient);
        foreach ($goods_list as $key => $value) {
            $refund_info = M('refund_return')->field('refund_state')->where(array('order_id' => $order_id, 'goods_id' => $value['goods_id']))->find();
            $is_refund   = $refund_info ? 1 : 0;
            if ($refund_info['refund_state'] == 4) {
                $is_refund = 4;
            }
            $type                            = $is_refund == 0 ? 'add' : 'update';
            $base_url                        = $is_refund == 0 ? '/index.php/Mobile/Refund/refund_service' : '/index.php/Mobile/Refund/customer_service';
            $goods_list[$key]['refund_link'] = C('WEBSITE_URL') . $base_url . '/order_id/' . $orderInfo['order_id'] . '/goods_id/' . $value['goods_id'] . '/money/' . $value['goods_total'] . '/shipping_fee/' . $orderInfo['shipping_fee'] . '/type/' . $type . '/is_welfare/' . $value['is_welfare'];
            if (empty($refund_info)) {
                if (($orderInfo['order_state'] == 40 && (time() - $orderInfo['finnshed_time']) > 3600 * 24 * 7) || $value['is_refund'] == 0) {
                    $is_refund                       = -1;
                    $goods_list[$key]['refund_link'] = '';
                }
            }
            if (!empty($refund_info)) {
                if ($value['is_refund'] == 0) {
                    $is_refund = -1;
                }
                if ($orderInfo['finnshed_time'] > 0 && (time() - $orderInfo['finnshed_time']) > 3600 * 24 * 7 && $value['is_refund'] == 1) {
                    $is_refund = 5;
                }
            }
            $goods_list[$key]['is_refund'] = $is_refund;
        }
        //获取入口网店信息（用于自提）
        $store_data                 = D('Store')->getInfo(array('store_id' => $orderInfo['store_id']), $field = '*', $ossClient);
        $orderInfo['store_name']    = $store_data['store_name'];
        $orderInfo['store_address'] = $store_data['area_info'];
        $orderInfo['store_phone']   = $store_data['store_phone'] ? $store_data['store_phone'] : '4009300277';
        $orderInfo['goods_num']     = count($goods_list);
        $orderInfo['shipping_time']         = date("Y-m-d H:i:s", $orderInfo['shipping_time']);
        $orderInfo['goods_list']            = $goods_list;
        $orderInfo['payment_time']          = date("Y-m-d H:i:s", $orderInfo['payment_time']);
        $orderInfo['close_time']            = date("Y-m-d H:i:s ", $orderInfo['add_time'] + 1800);
        $orderInfo['add_time']              = date("Y-m-d H:i:s", $orderInfo['add_time']);
        $orderInfo['reserve_shipping_time'] = (!empty($orderInfo['reserve_shipping_time'])) ? date("Y-m-d ", $orderInfo['reserve_shipping_time']) : '';
        $orderInfo['finnshed_time']         = (!empty($orderInfo['finnshed_time'])) ? date("Y-m-d H:i:s", $orderInfo['finnshed_time']) : '';
        return $orderInfo;
    }

    /** 取出已拼团人信息
     * member_avatar头像，is_head是否为团长0不是，1是
     * @param $group_purchase_id
     * @return array
     */
    public function tuxedoPeople($group_purchase_id)
    {
        $list_water = [];
        //取出团长头像
        $info = M('GroupPurchase')
            ->alias('gp')
            ->field('gp.member_id,gp.virtual_member_num,m.member_avatar')
            ->join('left join __MEMBER__ m on gp.member_id=m.member_id')
            ->where(['id' => $group_purchase_id])
            ->find();
        if (empty($info)) {
            return [];
        }

        //表示后台帮助成团的，所以取出虚拟用户信息
        $list1 = M('GroupPurchaseWater')
            ->alias('gpw')
            ->field('wm.member_avatar')
            ->join('left join __WATER_MEMBER__ wm on gpw.water_member_id=wm.id')
            ->where(['gpw.group_purchase_id' => $group_purchase_id])
            ->select();

        $map['o.group_purchase_id'] = $group_purchase_id;
        $map['o.order_state']       = ['egt', 20];
        $map['o.buyer_id']          = ['neq', $info['member_id']];
        $list2                      = $this
            ->alias('o')
            ->field('m.member_avatar')
            ->join('left join __MEMBER__ m on o.buyer_id=m.member_id')
            ->where($map)
            ->select();
        $list                       = array_merge($list1, $list2);

        $default_avatar = C('WEBSITE_URL') . '/Public/Mobile/images/default_avatar_color.png';
        foreach ($list as $key => $value) {
            $list[$key]['member_avatar'] = $value['member_avatar'] ? C('WEBSITE_URL') . '/' . $value['member_avatar'] : $default_avatar;
            $list[$key]['is_head']       = 0;
        }
        $head_info = [
            0 => [
                'member_avatar' => $info['member_avatar'] ? C('WEBSITE_URL') . '/' . $info['member_avatar'] : $default_avatar,
                'is_head'       => 1
            ]
        ];
        $list      = array_merge($head_info, $list);
        return $list;
    }

    /**
     * 创建订单编号
     * @param  integer $memberId 会员ID
     * @return string(20)  订单编号
     */
    static public function makeOrderSN($memberId)
    {
        // 规则: 共20位
        // 1 ~12:为格式化当前时间 (ymdHis)
        // 13~15:(3位)毫秒
        // 16~18:(3位)会员ID取模1000 [与时间戳(7~9)混淆]
        // 示例: 160804 175525 717 209 47
        return date('ymdHis', NOW_TIME)
            . sprintf('%03d', floatval(microtime()) * 1000)
            . sprintf('%03d', ($memberId + substr(NOW_TIME, -4, 3)) % 1000)
            . sprintf('%02d', mt_rand(0, 99));
    }

    /**
     * 创建支付单编号
     * @param  integer $memberId 会员ID
     * @return string    支付单号
     */
    static public function makePaySN($memberId)
    {
        return mt_rand(10, 99)
            . sprintf('%010d', time() - 946656000)
            . sprintf('%03d', (float)microtime() * 1000)
            . sprintf('%03d', (int)$memberId % 1000);
    }

    /**
     * 创建订单自提码
     * @return string    订单自提码
     */
    static public function makeChainCode()
    {
        return mt_rand(100000, 999999);
    }

    /**
     * [updatePaySN description]
     * @author deason 2016-09-23
     * @param  integer $orderId [description]
     * @param  integer $memberId [description]
     * @return [type]            [description]
     */
    public function updatePaySN($orderId, $memberId)
    {
        $newPaySN = self::makePaySN($memberId);
        $result   = $this->where(array(
            'order_id' => $orderId
        ))->save(array(
            'pay_sn'       => $newPaySN,
            'api_pay_time' => NOW_TIME
        ));
        return $result ? $newPaySN : false;
    }

    /**
     * 设置为已评论状态
     * @param  integer $orderId 订单ID
     * @param  integer $star 评价星级,默认5星 (未启用)
     */
    public function setEval($orderId, $star = 5)
    {
        return $this->where(array('order_id' => $orderId))->sava(array(
            'evaluation_state' => self::EVAL_DONE,
            'evalseller_time'  => NOW_TIME,
            // 'evalseller_star' => $star
        ));
    }

    /**
     * 更新数据
     */
    public function update($where = array(), $save = array())
    {
        return $this->where($where)->save($save);
    }

    /**
     * order_pay表新增（支付）记录
     */
    public function insertOrderPay($array = array())
    {
        return M('order_pay')->add($array);
    }

    /**
     * order_pay表 更新支付状态
     * 更新字段（api_pay_state）
     */
    public function updateOrderPay($where = array(), $save = array())
    {
        return M('order_pay')->where($where)->save($save);
    }


    /**
     * 取消订单
     * @author deason 2016-08-05
     * @param  integer $orderId 订单ID
     * @param  integer $memberId 用户ID
     * @return mixed             操作结果
     */
    public function cancel($orderId, $memberId = 0, $cancel_state = '')
    {
        $where = array('order_id' => $orderId);
        if ($memberId) {
            $where['buyer_id'] = $memberId;
        }
        return $this->where($where)->save(array(
            'order_state'  => self::STATE_CANCEL,
            'cancel_state' => $cancel_state
        ));
    }

    /**
     * 完成订单
     * @author deason 2016-08-19
     * @param  integer $orderId 订单ID
     * @param  integer $memberId 用户ID
     * @return mixed             操作结果
     */
    public function finish($orderId, $memberId = 0)
    {
        $where = array('order_id' => $orderId);
        if ($memberId) {
            $where['buyer_id'] = $memberId;
        }
        return $this->where($where)->save(array(
            'order_state'   => self::STATE_FINISH,
            'finnshed_time' => NOW_TIME
        ));
    }

    /**
     * 删除订单
     * @ 重置了 parent::delete 的方法
     * @author deason 2016-08-16
     * @param  integer $orderId 订单ID
     * @param  integer $memberId 会员ID
     * @return [type]            [description]
     */
    public function delete($orderId, $memberId = 0)
    {
        $where = array('order_id' => $orderId);
        if ($memberId) {
            $where['buyer_id'] = $memberId;
        }
        return $this->where($where)->save(array('delete_state' => self::DELETE_PRE));
    }

    /**
     * 设置评论状态为完成
     * @author deason 2016-08-25
     * @param  integer $orderId 订单ID
     * @param  integer $memberId 会员ID
     * @return [type]           [description]
     */
    public function evalDone($orderId, $memberId)
    {
        $where = array('order_id' => $orderId);
        if ($memberId) {
            $where['buyer_id'] = $memberId;
        }
        return $this->where($where)
            ->save(array(
                'evaluation_state' => self::EVAL_DONE,
                'evaluation_time'  => NOW_TIME
            ));
    }

    // ------------------ 逻辑操作 ------------------ //

    /**
     * [逻辑]取消订单,包含状态设置及库存恢复
     * @author deason 2016-08-12
     * @param  integer $orderId 订单ID
     * @param  integer $memberId 用户ID
     * @return boolean             操作结果
     */
    public function logicCancelOrder($orderId, $memberId = 0, $cancel_state)
    {
        $this->startTrans();    // 开启事务
        // 先执行状态变更
        $cancelResult = $this->cancel($orderId, '', $cancel_state);
        if ($cancelResult) {
            // echo '[CENCEL ORDER] ID:',$orderId,"\n";
            $goodsData = D('OrderGoods')->where(array('order_id' => $orderId))->getField('goods_id,goods_num,goods_spec_id');
            $modelG    = D('Goods');
            foreach ($goodsData as $goodsId => $goodsVal) {
                // printf("\t[GOODS INC STOCK] ID:% 10s\t|\tNUM:% 10s\n",$goodsId, $goodsNum);
                $result = $modelG->incStock($goodsId, $goodsVal['goods_num'], $goodsVal['goods_spec_id']);
                if (!$result) {
                    $this->rollback();    // 事务回滚
                    return false;
                }
            }
            $this->commit();    // 提交事务
            return true;
        }
        $this->rollback();    // 事务回滚
        return false;
    }

    /**
     * 判断订单中还有商品未申请售后，或者售后还未完成
     * [checkOrderRights description]
     * @param  [type] $order_id [description]
     * @return [type]
     * [0表示订单中的商品售后状态已完成
     * 1表示还有商品未申请售后
     * 2表示还有商品的售后还未完成]
     * 4表示订单中有商品撤销申请]
     */
    public function checkOrderRights($orderId)
    {
        $status    = 0;
        $goodsData = D('OrderGoods')->field('goods_id')->where(array('order_id' => $orderId))->select();
        foreach ($goodsData as $key => $goodsVal) {
            $info = M('RefundReturn')
                ->field('seller_state,refund_state')
                ->where(['order_id' => $orderId, 'goods_id' => $goodsVal['goods_id']])
                ->find();
            if (empty($info)) {
                $status = 1;
            }
            if ($info && in_array($info['refund_state'], [1, 2])) {
                $status = 2;
            }
            if ($info && $info['refund_state'] == 4) {
                $status = 4;
            }
        }
        return $status;
    }

    /**
     * [用于后台售后订单处理完成，回滚对应商品库存
     * 订单中所有商品的售后都通过了，才把订单状态变为已取消]
     * @param  [type] $orderId    [订单ID]
     * @param  [type] $goods_info [订单商品信息]
     * @return [type]             [description]
     */
    public function cancelOrder($orderId, $goods_info)
    {
        $modelG = D('Goods');
        $result = $modelG
            ->incStock($goods_info['goods_id'], $goods_info['goods_num'], $goods_info['goods_spec_id']);
        if ($this->checkOrderRights($orderId) == 0) {
            $cancelResult = $this->cancel($orderId, '', '');
        }
    }

    public function balance($order_sn)
    {
        $list = M('balance_recharge')->where(array("order_sn" => $order_sn, "status" => 0))->field('*')->select();
        return $list[0];
    }

    public function balance_recharge($pay_sn, $order_sn)
    {
        $data['status'] = '1';
        $data['pay_sn'] = "$pay_sn";
        $list           = M('balance_recharge')->where(array("order_sn" => $order_sn, "status" => 0))->field('*')->select();
        $list           = $list[0];

        $sql = 'UPDATE sx_balance_recharge SET `status`=1,pay_sn="' . $pay_sn . '" WHERE order_sn="' . $order_sn . '"';
        M()->execute($sql);
        $sql = 'UPDATE sx_balance SET basic_balance=basic_balance+' . $list['money'] . ' WHERE member_id="' . $list['member_id'] . '"';
        M()->execute($sql);
        $sql = 'INSERT INTO sx_balance_log (member_id,money,type,order_sn,remark,createtime) VALUES ("' . $list['member_id'] . '","' . $list['money'] . '","2","' . $order_sn . '","微信充值余额","' . time() . '")';
        M()->execute($sql);

        //充值活动
        require_once('Application/Api/Controller/BalanceController.class.php');
        BalanceController::rechargeAct($order_sn);
    }

    //是否第一次购买商品
    public function add_first_goods($member_id)
    {
        $model = M('first_action');
        $sel   = $model->field('enter_goods')->where(array('member_id' => $member_id))->find();
        if ($sel) {
            if ($sel['enter_goods'] == '0') {
                $data['enter_goods'] = '1';
                $save                = $model->where(array('member_id' => $member_id))->save($data);
                if ($save !== false) {
                    return true;
                }
            }
        } else {
            $data['enter_goods'] = '1';
            $data['member_id']   = $member_id;
            $save                = $model->where(array('member_id' => $member_id))->add($data);
            if ($save !== false) {
                return true;
            }
        }
    }

    //添加发票信息
    public function addInvoice($param)
    {
        $data = M('member_invoice_info')->field('title,tax_number,receive_phone,receive_email,type,register_address,register_phone,bank,bank_account,is_company')->find($param['invoice_id']);
        if (empty($data)) return false;
        $data['order_id']   = $param['order_id'];
        $data['order_id']   = $param['order_id'];
        $data['apply_time'] = time();
        return M('order_invoice')->add($data);
    }

    //旧版添加发票
    public function oldAddInvoice($data)
    {
        if (empty($data['order_id'])) return false;
        if (empty($data['type'])) $data['type'] = 1;//默认纸质发票
        if (empty($data['title'])) $data['title'] = I('invoice_title');
        if (empty($data['receive_phone'])) $data['receive_phone'] = I('invoice_receive_phone');
        if (empty($data['receive_email'])) $data['receive_email'] = I('invoice_receive_email');
        if (empty($data['receive_content'])) $data['receive_content'] = I('invoice_receive_content');
        if (empty($data['tax_number'])) $data['tax_number'] = I('tax_number');
        if (!empty($data['tax_number'])) $data['is_company'] = 1;
        return M('order_invoice')->add($data);
    }

    //获取用户订单统计
    public function getOrderNum($data)
    {
        $member_id = $data['member_id'];
        if (!$data['order_type']) {
            $result     = $this->field('order_state,is_welfare_zone,evaluation_state,count(*) AS num')->where(['buyer_id' => $member_id, 'delete_state' => self::DELETE_NOT, 'group_purchase_id' => 0, 'payment_code' => ['not in', ['bankpay', 'checkpay']]])->group('order_state,evaluation_state,is_welfare_zone')->select();
            $result_num = $this->where("delete_state=0 AND (( buyer_id = '$member_id' AND group_purchase_id =0 AND is_welfare_zone = 0 AND payment_code NOT IN ('bankpay','checkpay')) OR (is_welfare_zone = 1 AND order_state IN (20,30,40) AND delete_state=0 AND buyer_id = '$member_id' AND group_purchase_id =0 ))")->count();
        } else {
            $result     = $this->field('order_state,is_welfare_zone,evaluation_state,count(*) AS num')->where(['buyer_id' => $member_id, 'delete_state' => self::DELETE_NOT, 'group_purchase_id' => 0, 'payment_code' => ['in', ['bankpay', 'checkpay']]])->group('order_state,evaluation_state,is_welfare_zone')->select();
            $result_num = $this->where("delete_state=0 AND ( (buyer_id = '$member_id' AND group_purchase_id =0 AND is_welfare_zone = 0 AND payment_code IN ('bankpay','checkpay')) OR (is_welfare_zone = 1  AND order_state IN (20,30,40) AND delete_state=0 AND buyer_id = '$member_id' AND group_purchase_id =0 ))")->count();
        }

        $orderState[0] = array('num' => 0, 'order_state' => '10');
        $orderState[1] = array('num' => 0, 'order_state' => '20');
        $orderState[2] = array('num' => 0, 'order_state' => '30');
        $orderState[3] = array('num' => 0, 'order_state' => '40');
        $orderState[9] = array('num' => $result_num, 'order_state' => '100');
        foreach ($result as $row) {
            if ($row['order_state'] == 10 && $row['is_welfare_zone'] == 0) {
                $orderState[0]['num'] += $row['num'];// 未付款
            } else if ($row['order_state'] == 20 || $row['order_state'] == 30) {
                $orderState[1]['num'] += $row['num'];// 未付款
            } else if ($row['order_state'] == 40) {
                if ($row['evaluation_state']) {
                    $orderState[3]['num'] += $row['num'];// 未付款

                } else {
                    $orderState[2]['num'] += $row['num'];// 未付款
                }
            }
        }
        $result['order_state'] = array_values($orderState);
        unset($result[0]);

        //:退款售后
        $result['refund_state'] = $this->alias('o')
            ->join('sx_refund_return r ON r.order_id=o.order_id')
            ->where(['o.delete_state' => 0, 'o.buyer_id' => $member_id, 'order_state' => array(30, 40, 'or'), 'r.refund_state' => array('GT', 0)])->count();
        return $result;
    }

    /**
     * 支付完成
     */
    public function after_pay($out_trade_no, $trade_no = '', $logtype = 1)
    {
        $sel   = M('merge_order')->where(array('m_pay_sn' => $out_trade_no))->getField('child_order_id_str');
        $field = 'order_state,buyer_id,buyer_phone,order_sn,goods_amount,order_amount,group_purchase_id,pay_sn,reciver_name';
        if ($sel) {
            $order_id_arr = explode('_', $sel);
        } else {
            $where     = array('pay_sn' => $out_trade_no);
            $orderInfo = $this->getInfo($where, $field);
        }

        if ($logtype == 1) $myfile = './Public/paylog/' . date('Ym') . '_alipay_log.txt';
        else  $myfile = './Public/paylog/' . date('Ym') . '_wechat_log.txt';
        $file_pointer = fopen($myfile, "a");
        fwrite($file_pointer, json_encode($orderInfo) . ';\r\n');
        if ($orderInfo['order_state'] == $this::STATE_NORMAL || $orderInfo['order_state'] == 0 || $sel) {
            $this->startTrans();
            //更新主订单表信息（order_state 20：支付状态改成已支付；trade_no=$postdata['transaction_id' 外部订单号（微信支付订单号））
            $newinfo = array(
                'order_state'  => $this::STATE_PAY,
                'trade_no'     => $trade_no,
                'payment_time' => NOW_TIME,
                'payment_code' => 'alipay'
            );
            if ($logtype != 1) $newinfo['payment_code'] = 'wxpay';

            if ($sel) {//合并订单
                foreach ($order_id_arr as $key => $value) {
                    $tmp1 = $this->update(array('order_id' => $value), $newinfo);
                }
            } else {//单笔订单
                $tmp1 = $this->update(array('pay_sn' => $out_trade_no), $newinfo);
            }
            //更新支付表信息
            $tmp2 = $this->updateOrderPay(array('pay_sn' => $out_trade_no), array('api_pay_state' => 1));
            //更新商品销量
            $tmp4 = $this->updateGoodsSalenum(array('pay_sn' => $out_trade_no));
            //更新团购订单记录状态
            $tmp3 = $this->updateGroupPurchase(array('group_purchase_id' => $orderInfo['group_purchase_id'], 'member_id' => $orderInfo['buyer_id']));
            if ($tmp1 && $tmp2 && $tmp3) {
                $this->commit();
                if ($sel) {
                    foreach ($order_id_arr as $key => $value) {
                        $newhere   = array('order_id' => $value);
                        $orderInfo = $this->getInfo($newhere, $field);
                        $this->add_first_goods($orderInfo['buyer_id']);
                        D('OrderDealLog')->addDealLog($orderInfo['pay_sn']);    //分配订单给客服处理
                        D('Member')->addPoints($orderInfo['buyer_id'], $orderInfo['goods_amount']);
                    }
                } else {
                    $this->add_first_goods($orderInfo['buyer_id']);
                    D('OrderDealLog')->addDealLog($out_trade_no);    //分配订单给客服处理
                    D('Member')->addPoints($orderInfo['buyer_id'], $orderInfo['goods_amount']);
                }

                fwrite($file_pointer, '--------------------------' . $out_trade_no . '-----success----------------------------------------;\r\n');
                fclose($file_pointer);
                return 1;
            } else {
                $this->rollback();
                fwrite($file_pointer, '--------------------------' . $out_trade_no . '-----rollback------------------------------------;\r\n');
                fclose($file_pointer);
                return 0;
            }
        }
        fclose($file_pointer);
        return 0;
    }

    /**
     * [updateGroupPurchase 根据团购主键更新团购订单状态]
     * @param  array $param [description]
     * @return [type]        [description]
     */
    public function updateGroupPurchase($param = array())
    {
        if ($param['group_purchase_id'] == 0) {
            return true;
        }
        //取出商品成团人数和商品ID
        $gpInfo     = M('GroupPurchase')
            ->field('goods_id,member_id,member_num,group_member_num')
            ->where(array('id' => $param['group_purchase_id']))
            ->find();
        $member_num = $gpInfo['member_num'] + 1;    //成团人数加1
        if ($gpInfo['member_id'] == $param['member_id']) {
            $data['spell_state'] = 2;    //如果是团长就把该团状态改为已付款
            $data['create_time'] = time();
        }
        if ($member_num == $gpInfo['group_member_num']) {
            $data['spell_state'] = 3;    //设置拼团记录状态为拼团成功
        }
        $data['member_num'] = $member_num;    //成团人数
        return M('GroupPurchase')->where(array('id' => $param['group_purchase_id']))->save($data);
    }

    /**
     * [updateGoodsSalenum 商品销量增加]
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function updateGoodsSalenum($where = array())
    {
        $order_id = M('order')->where($where)->getField('order_id');
        if (empty($order_id)) {
            return true;
        }
        $saleNum = M('order_goods')->field('goods_num,goods_id')->where(array('order_id' => $order_id))->select();
        foreach ($saleNum as $key => $value) {
            M('goods')->where(array('goods_id' => $value['goods_id']))->setInc('goods_salenum', $value['goods_num']);
        }
    }

    /**
     * [checkJoinGroup 检查是否参加过该团]
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function checkJoinGroup($params)
    {
        $where['order_state']       = 20;    //已付款
        $where['buyer_id']          = $params['member_id'];
        $where['group_purchase_id'] = $params['group_purchase_id'];
        $reg                        = M('Order')->where($where)->find();
        if ($reg) {
            return true;
        }
        return false;
    }

    /**
     * [getByStoreID 商家端取出订单数据]
     * @param  array $params [其中]
     * @param  [type] $limit  [description]
     * @return [type]         [description]
     */
    public function getByStoreID($params = array(), $limit)
    {
        $where = array();
        if ($params['store_id']) {
            $where['o.store_id'] = $params['store_id'];
        }
        if ($params['status'] != '') {
            if ($params['status'] == '70') {
                $where['r.refund_state'] = array('IN', array(\Common\Model\RefundReturnModel::STATE_APPLY_WAIT, \Common\Model\RefundReturnModel::STATE_APPLY_ADMIN));
            } else {
                $where['o.order_state'] = array('EQ', $params['status']);
            }
        }
        if ($params['buyer_phone'] != '') {
            $where['o.buyer_phone'] = $params['buyer_phone'];
        }

        $where['o.group_purchase_id'] = 0;    //普通订单
        $list                         = $this
            ->alias('o')
            ->join('LEFT JOIN __REFUND_RETURN__ AS r ON o.order_id = r.order_id')
            ->join('LEFT JOIN __STORE__ AS s ON s.store_id = o.store_id')
            ->join('LEFT JOIN __ORDER_GOODS__ AS od ON od.order_id = o.order_id')
            ->join('LEFT JOIN __GOODS__ AS g ON g.goods_id = od.goods_id')
            ->field('o.*, s.is_poor,s.store_name,r.refund_id, r.order_lock, r.refund_state')
            ->limit($limit)
            ->order('o.order_id desc')
            ->distinct(true)
            ->where($where)
            ->select();
        foreach ($list as $key => $value) {
            $hash              = $value['salt'];
            $order_code        = md5($hash . md5($value['order_id']) . $hash);
            $list[$key]['url'] = C('WEBSITE_URL') . U('StoreMobile/Order/orderDetail?order_id=' . $value['order_id'] . '&order_code=' . $order_code);

            $list[$key]['order_goods'] = M('OrderGoods')->where('order_id = ' . $value['order_id'])->select();
            foreach ($list[$key]['order_goods'] as $_key => $_value) {
                $list[$key]['order_goods'][$_key]['goods_img']  = C('WEBSITE_URL') . '/' . $_value['goods_img'];
                $list[$key]['order_goods'][$_key]['goods_spec'] = unserialize($_value['goods_spec']);
                $list[$key]['order_goods_count']                = count($list[$key]['order_goods']);
                $list[$key]['goods_nums']                       = $_value['goods_num'];
                $list[$key]['order_goods'][$_key]['goods_imgs'] = unserialize($_value['goods_imgs']);
            }
        }
        return $list;
    }

    /**
     * [getDetailByID 商家端取出订单详情]
     * @param  array $params [description]
     * @return [type]         [description]
     */
    public function getDetailByID($params = array())
    {
        $where['o.order_id'] = $params['order_id'];
        if ($params['store_id'] != '') {
            $where['o.store_id'] = $params['store_id'];
        }
        $list = $this
            ->alias('o')
            ->join('LEFT JOIN __REFUND_RETURN__ AS r ON o.order_id = r.order_id')
            ->join('LEFT JOIN __STORE__ AS s ON s.store_id = o.store_id')
            ->field('o.*, s.is_poor,s.store_name,s.store_phone,s.province_id, s.city_id, s.district_id, s.address, s.area_info, r.refund_id, r.order_lock, r.refund_state')
            ->order('o.order_id desc')
            ->where($where)
            ->find();
        if (empty($list)) {
            return array();
        }
        $list['add_time']      = date('Y-m-d H:i:s', $list['add_time']);
        $areaModel             = M('Area');
        $list['province_name'] = $areaModel->where(['area_id' => $list['province_id']])->getField('area_name');
        $list['city_name']     = $areaModel->where(['area_id' => $list['city_id']])->getField('area_name');
        $list['district_name'] = $areaModel->where(['area_id' => $list['district_id']])->getField('area_name');

        if ($list['coupon_id'] > 0) {
            $list['coupon_name'] = M('Coupon')->where(array('coupon_id' => $list['coupon_id']))->getField('title');
        } else {
            $list['coupon_name'] = '';
        }
        $list['store_phone'] = $list['store_phone'] ? $list['store_phone'] : '4009300277';

        $list['order_goods'] = M('OrderGoods')
            ->field('og.*,gs.supplier_id,s.name as supplier_name')
            ->alias('og')
            ->join('left join sx_goods_supplier gs on og.goods_id=gs.goods_id')
            ->join('left join sx_supplier s on s.id=gs.supplier_id')
            ->where('og.order_id = ' . $list['order_id'])
            ->order('gs.supplier_id')
            ->select();
        foreach ($list['order_goods'] as $_key => $_value) {
            $list['order_goods'][$_key]['goods_img']     = C('WEBSITE_URL') . '/' . $_value['goods_img'];
            $list['order_goods'][$_key]['sp_value_name'] = M('GoodsSpec')->where(['goods_spec_id' => $_value['goods_spec_id']])->getField('sp_value_name');
            $list['order_goods_count']                   = count($list['order_goods']);
            $list['goods_nums']                          = $_value['goods_num'];
        }
        $list['admin_remark'] = M('OrderRemarkLog')->field('message')->where(['order_id' => $list['order_id']])->select();

        return $list;
    }

    /**
     * [control_order 确认提货即把订单状态改为已发货]
     * @param  array $params [description]
     * @return [type]         [description]
     */
    public function controlOrder($params = array())
    {
        $where['order_id'] = $params['order_id'];
        if ($params['store_id']) {
            $where['store_id'] = $params['store_id'];
        }
        $where['order_type']  = 2;    //网店自提订单
        $where['order_state'] = 20;    //已付款的
        $reg                  = M('Order')->where($where)->save(['shipping_time' => NOW_TIME, 'finnshed_time' => NOW_TIME, 'order_state' => 40]);
        if ($reg) {
            $log_value = "商家端确认订单发货，order_id:" . $params['order_id'] . "，操作的商家管理员ID:" . $params['sa_id'];
            $this->add_log(['admin_id' => $params['sa_id'], 'log_value' => $log_value]);
            return true;
        } else {
            return false;
        }
    }

    public function add_log($params = array())
    {
        $data['admin_id']   = $params['admin_id'];
        $data['createtime'] = time();
        $data['log_value']  = $params['log_value'];
        $data['log_ip']     = get_client_ip();
        $data['log_type']   = 2;
        M('ShopAdminLog')->add($data);
    }

    //获取网店订单统计
    //订单状态：0(已取消)10(默认):未付款;20:已付款;30:已发货;40:已收货;
    public function getOrderNumAll($params = array())
    {
        if (!empty($params['store_id'])) {
            $where['store_id'] = $params['store_id'];
        }
        $where['group_purchase_id'] = 0;
        $result                     = $this->field('order_state,evaluation_state,count(*) AS num')->where($where)->group('order_state,evaluation_state')->select();
        $orderState[0]              = array('num' => 0, 'order_state' => '10');
        $orderState[1]              = array('num' => 0, 'order_state' => '20');
        $orderState[2]              = array('num' => 0, 'order_state' => '30');
        $orderState[3]              = array('num' => 0, 'order_state' => '40');
        $orderState[9]              = array('num' => 0, 'order_state' => '100');
        foreach ($result as $row) {
            if ($row['order_state'] == 10) {
                $orderState[0]['num'] += $row['num'];// 未付款
            } else if ($row['order_state'] == 20) {
                $orderState[1]['num'] += $row['num'];// 已付款
            } else if ($row['order_state'] == 30) {
                $orderState[2]['num'] += $row['num'];// 已发货
            } else if ($row['order_state'] == 40) {
                $orderState[3]['num'] += $row['num'];// 已完成
            }
            // 全部
            $orderState[9]['num'] += $row['num'];// 未付款
        }
        $result_n['order_state'] = array_values($orderState);
        return $result_n;
    }

    //发起售后时，设置订单售后状态，用于利润计算（作为条件查询）
    //$status:0可以计算利润，1不可计算利润
    public function setOrderSaleStatus($order_id, $status)
    {
        M('Order')->where(['order_id' => $order_id])->setField('all_sale_status', $status);
    }

    //有售后成功时要把订单exchange_status变为1，用于计算利润
    public function setOrderExchangeStatus($order_id)
    {
        M('Order')->where(['order_id' => $order_id])->setField('exchange_status', 1);
    }

    /** 消费发送给合伙人短信
     * @param $buyer_id -买家ID
     * @param $partner_id -合伙人ID
     */
    public function partnerConsumpSend($buyer_id, $partner_id)
    {
        return true;
    }

    /** 会员拍下订单付款关怀
     * @param $buyer_id -买家ID
     * @param $partner_id -合伙人ID
     */
    public function orderPaySuccess($pay_sn)
    {
        $username    = '';
        $buyer_phone = '';
        $orderModel  = M('order');
        $sel         = M('merge_order')->where(array('m_pay_sn' => $pay_sn))->getField('child_order_id_str');

        if (!empty($sel)) { //拆分订单
            $order_id_arr = explode('_', $sel);
            foreach ($order_id_arr as $kk => $vv) {
                $orderInfo   = $orderModel->where(array('order_id' => $vv))->field('buyer_phone,reciver_name')->find();
                $username    = $orderInfo['reciver_name'];
                $buyer_phone = $orderInfo['buyer_phone'];
            }

        } else { //单笔订单
            $orderInfo   = $orderModel->where(array('pay_sn' => $pay_sn))->field('buyer_phone,reciver_name')->find();
            $username    = $orderInfo['reciver_name'];
            $buyer_phone = $orderInfo['buyer_phone'];
        }

        $username  = $username ? $username : $buyer_phone;
        $sms_param = "{\"username\":\"{$username}\"}";
        SmsService::orderPaySuccess($buyer_phone, $sms_param);
    }

    public function orderGetUserInfo($member_id)
    {
        return M('Member')
            ->field('member_mobile,member_nickname')
            ->where(['member_id' => $member_id])
            ->find();
    }

    //团购商品支付时判断（开团限制）
    public function checkGroupOrderRestrictive($member_id, $group_purchase_id)
    {
        //如果是参团直接返回true
        $info = M('GroupPurchase')->where(['id' => $group_purchase_id])->find();
        if (empty($info)) {
            return [
                'code' => 0,
                'msg'  => '该团不存在'
            ];
        }
        $goods_info = M('GoodsGroupPurchase')->field('restrictive')->where(['goods_id' => $info['goods_id']])->find();
        if (empty($goods_info)) {
            return [
                'code' => 0,
                'msg'  => '团购商品不存在'
            ];
        }
        if ($goods_info['restrictive'] == 1 && $info['is_backstage'] == 0) {
            if ($member_id == $info['member_id']) {
                $count = M('GroupPurchase')->where([
                    'goods_id'     => $info['goods_id'],
                    'spell_state'  => 2,
                    'is_backstage' => 0
                ])->count();
                if ($count > 0) {
                    return [
                        'code' => 0,
                        'msg'  => '此商品已有人开团，去参团吧'
                    ];
                }
            }
        }

        return [
            'code' => 1,
            'msg'  => '成功'
        ];
    }
}
