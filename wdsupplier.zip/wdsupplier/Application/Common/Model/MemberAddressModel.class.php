<?php
/**
 * 会员收货地址模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class MemberAddressModel extends Model {

	/*
	`address_id` MEDIUMINT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '地址ID',
	`member_id` MEDIUMINT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '会员ID',
	`true_name` VARCHAR(50) NOT NULL COMMENT '会员姓名',
	`area_id` MEDIUMINT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '地区ID',
	`city_id` MEDIUMINT(9) NULL DEFAULT NULL COMMENT '市级ID',
	`area_info` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '地区内容',
	`address` VARCHAR(255) NOT NULL COMMENT '地址',
	`tel_phone` VARCHAR(20) NULL DEFAULT NULL COMMENT '座机电话',
	`mob_phone` VARCHAR(15) NULL DEFAULT NULL COMMENT '手机电话',
	`is_default` ENUM('0','1') NOT NULL DEFAULT '0' COMMENT '1默认收货地址',
	`dlyp_id` INT(11) NULL DEFAULT '0' COMMENT '自提点ID',
	`lng` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '经度',
	`lat` VARCHAR(50) NOT NULL DEFAULT '0' COMMENT '纬度',
	 */

	/**
	 * 获得详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($where = array(), $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

	/**
	 * 获取地址坐标
	 * @author deason 2016-08-05
	 * @param  integer $addressId 收货地址ID
	 * @param  integer $memberId  会员ID
	 * @return array  地理坐标数组
	 */
	public function getGeoPoint($addressId, $memberId = 0)
	{
		$where = array('address_id' => $addressId);
		if ($memberId) {
			$where['member_id'] = $memberId;
		}
		return $this->where($where)->field('lat,lng')->find();
	}

	/**
	 * 获取城市ID
	 * @author deason 2016-08-18
	 * @param  integer $addressId 收货地址ID
	 * @param  integer $memberId  会员ID
	 * @return integer            地址的城市ID
	 */
	public function getCityId($addressId, $memberId = 0)
	{
		$where = array( 'address_id' => $addressId );
		if ($memberId) {
			$where['member_id'] = $memberId;
		}
		return $this->where($where)->getField('city_id');
	}

	/**
	 * 获取用户默认地址
	 * @author deason 2016-09-19
	 * @param  integer $memberId 用户Id
	 * @return 默认地址信息
	 */
	public function getUserDefault($memberId)
	{
		return $this
			->where(array('member_id' => $memberId))
			->field('address_id,true_name,area_id,city_id,area_info,address,mob_phone,is_default')
			->order('is_default DESC,address_id DESC')
			->find();
	}

	/**
	 * [logic] 设置用户默认地址
	 * @author deason 2016-10-11
	 * @param  integer $addressId 地址ID
	 * @param  integer $memberId  用户ID
	 */
	public function setToDefault($addressId, $memberId)
	{
		$unsetOther = $this->where(array(
			'member_id'  => $memberId,
			'is_default' => '1'
		))->save(array('is_default' => 0));
		if ($unsetOther === false) {
			return false;
		}
		return $this->where(array('address_id' => $addressId))->save(array('is_default' => 1));
	}


	//wanxunpeisong
	public function youpei($parm=array()){
		
		$store_id=$parm['store_id'];
		$member_id=$parm['member_id'];
		$address_id=$parm['address_id'];
		if(empty($store_id)||empty($address_id)) return 0;
		$store_address ='aaaaa';//wrong  查出仓库位置对比
		$store_BL = $this->getlngAndlot($store_address['area_info']);
	
		$address_BL = $this->field('lng,lat,member_id')->where("address_id=$address_id")->find();
		if($address_BL['member_id']!=$member_id){
			return 0;
		}
		if ( $store_BL && $address_BL ) {
			$rateDistribution = getDistance($address_BL['lat'],$address_BL['lng'],$store_BL['lat'],$store_BL['lng']);
		}
		if ( $rateDistribution >5000 ) {
			return 0;
		}
		return 1;
	}

	public function getlngAndlot($address){
		$result=file_get_contents('http://api.map.baidu.com/geocoder/v2/?address='.$address.'&output=json&ak=zbQrD4cA5Yz7X7Pjmt3IpYcpovH2oqZs');
		$data=json_decode($result);
		$return=array('lng'=>(!empty($data->result->location->lng))?$data->result->location->lng:0,'lat'=>(!empty($data->result->location->lat)?$data->result->location->lat:0));
		return $return;
	}
}
