<?php
/**
 * 退款退货模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class RefundReturnModel extends Model {

	/*
	`refund_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '记录ID',
	`order_id` INT(10) UNSIGNED NOT NULL COMMENT '订单ID',
	`order_sn` VARCHAR(50) NOT NULL COMMENT '订单编号',
	`refund_sn` VARCHAR(50) NOT NULL COMMENT '申请编号',
	`store_id` INT(10) UNSIGNED NOT NULL COMMENT '网店ID',
	`store_name` VARCHAR(20) NOT NULL COMMENT '网店名称',
	`buyer_id` INT(10) UNSIGNED NOT NULL COMMENT '买家ID',
	`buyer_name` VARCHAR(50) NOT NULL COMMENT '买家会员名',
	`goods_id` INT(10) UNSIGNED NOT NULL COMMENT '商品ID,全部退款是0',
	`order_goods_id` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '订单商品ID,全部退款是0',
	`goods_name` VARCHAR(50) NOT NULL COMMENT '商品名称',
	`goods_num` INT(10) UNSIGNED NULL DEFAULT '1' COMMENT '商品数量',
	`refund_amount` DECIMAL(10,2) NULL DEFAULT '0.00' COMMENT '退款金额',
	`goods_img` VARCHAR(255) NULL DEFAULT NULL COMMENT '商品图片',
	`goods_imgs` TEXT NULL COMMENT '商品图片',
	`refund_type` TINYINT(1) UNSIGNED NULL DEFAULT '1' COMMENT '申请类型:1为退款,2为退货,默认为1',
	`seller_state` TINYINT(1) UNSIGNED NULL DEFAULT '1' COMMENT '卖家处理状态:1为待审核,2为同意,3为不同意,默认为1',
	`refund_state` TINYINT(1) UNSIGNED NULL DEFAULT '1' COMMENT '申请状态:1为处理中,2为待管理员处理,3为已完成,默认为1',
	`return_type` TINYINT(1) UNSIGNED NULL DEFAULT '1' COMMENT '退货类型:1为不用退货,2为需要退货,默认为1',
	`order_lock` TINYINT(1) UNSIGNED NULL DEFAULT '1' COMMENT '订单锁定类型:1为不用锁定,2为需要锁定,默认为1',
	`goods_state` TINYINT(1) UNSIGNED NULL DEFAULT '1' COMMENT '物流状态:1为待发货,2为待收货,3为未收到,4为已收货,默认为1',
	`add_time` INT(10) UNSIGNED NOT NULL COMMENT '添加时间',
	`seller_time` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '卖家处理时间',
	`admin_time` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '管理员处理时间,默认为0',
	`reason_id` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '原因ID:0为其它',
	`reason_info` VARCHAR(300) NULL DEFAULT '' COMMENT '原因内容',
	`pic_info` VARCHAR(300) NULL DEFAULT '' COMMENT '图片',
	`buyer_message` VARCHAR(300) NULL DEFAULT NULL COMMENT '申请原因',
	`seller_message` VARCHAR(300) NULL DEFAULT NULL COMMENT '卖家备注',
	`admin_message` VARCHAR(300) NULL DEFAULT NULL COMMENT '管理员备注',
	`express_id` TINYINT(1) UNSIGNED NULL DEFAULT '0' COMMENT '物流公司编号',
	`invoice_no` VARCHAR(50) NULL DEFAULT NULL COMMENT '物流单号',
	`ship_time` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '发货时间,默认为0',
	`delay_time` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '收货延迟时间,默认为0',
	`receive_time` INT(10) UNSIGNED NULL DEFAULT '0' COMMENT '收货时间,默认为0',
	`receive_message` VARCHAR(300) NULL DEFAULT NULL COMMENT '收货备注',
	 */

	// 申请类型 refund_type
	const TYPE_APPLY_MONEY = 1;		// 退款
	const TYPE_APPLY_GOODS = 2;		// 退货
	const TYPE_APPLY_SWAP  = 3;		// 换货

	// 退货类型 return_type
	const TYPE_GOODS_NOT = 1;		// 不用退货
	const TYPE_GOODS_YES = 2; 		// 需要退货

	// 申请状态 refund_state
	const STATE_APPLY_WAIT   = 1;	// 待(商家)处理中
	const STATE_APPLY_ADMIN  = 2;	// 待管理员处理
	const STATE_APPLY_DONE   = 3;	// 处理完成
	const STATE_APPLT_CANCEL = 4;	// 取消申请

	// 处理状态 seller_state
	const STATE_HANDLE_WAIT  = 1;	// 待审核
	const STATE_HANDLE_AGREE = 2;	// 同意退款
	const STATE_HANDLE_VETO  = 3;	// 不同意退款

	// 物流状态 goods_state
	const STATE_GOODS_WAIT = 1;		// 等待发货
	const STATE_GOODS_SEND = 2;		// 等待收货
	const STATE_GOODS_NOT  = 3;		// 未收到
	const STATE_GOODS_GET  = 4;		// 已收货

	// 订单锁定状态
	const LOCK_NOT = 1;		// 不需要锁定订单
	const LOCK_YES = 2;		// 需要锁定订单

	// 退款类型列表
	public $refundTypeList = array(
		self::TYPE_APPLY_MONEY => '仅退款',
		self::TYPE_APPLY_GOODS => '退货退款',
		self::TYPE_APPLY_SWAP  => '换货'
	);

	// 状态列表(说明)
	public $refundStateList = array(
		self::STATE_APPLY_WAIT		=> '待处理',
		self::STATE_APPLY_ADMIN		=> '处理中',
		self::STATE_APPLY_DONE		=> '处理完成',
		self::STATE_APPLT_CANCEL	=> '申请取消',
	);

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $limit [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $limit = '', $field = '*', $order = 'refund_id DESC')
	{
		return $this->where($where)->limit($limit)->field($field)->order($order)->select();
	}

	/**
	 * 获得详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($where = array(), $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

	/**
	 * 创建退货单编号
	 * @author deason 2016-08-09
	 * @param  integer $orderId 订单ID
	 * @return string           退货编号
	 */
	static public function makeRefundSN($orderId)
	{
		return sprintf('%09d', time() - 946656000)
			. sprintf('%03d', (float) microtime() * 1000)
			. sprintf('%04d', (int) $orderId % 10000)
			. sprintf('%02d', mt_rand(0,99));
	}

	/**
	 * 检查是否存在未完成申请退款的操作
	 * @author deason 2016-08-08
	 * @param  integer $orderId  订单ID
	 * @param  integer $memberId 会员ID
	 * @param  integer $goodsId  指定退货商品
	 * @return integer 存在的申请ID
	 */
	public function checkApplyAction($orderId, $memberId, $goodsId = 0)
	{
		$where = array(
			'order_id' => $orderId,
			'buyer_id' => $memberId,
			'refund_state' => array('NEQ', self::STATE_APPLT_CANCEL)
		);
		if ($goodsId) {
			$where['goods_id'] = array('IN', array(0, $goodsId));
		}
		return $this->where($where)->getField('refund_id');
	}

	public function getRefundTypeList()
	{
		$list = array();
		foreach ($this->refundTypeList as $key => $value) {
			$list[] = array('type_id' => $key, 'type_name' => $value);
		}
		return $list;
	}
    public function getRefundLogList($where=array(),$field='',$order=''){
        return M('refund_log')->field($field)->where($where)->order($order)->select();
    }
    public function addRefundLog($add=array()){
        return M('refund_log')->add($add);
    }

	/**
	 * * @param int $order_id 订单id
	 * @param array $goodIds  商品ids数组
	 * @param int $type  1：申请售后记录  2：是已经完成维权订单
	 * @return bool
	 */
	public function isRefundFee($order_id,$goodIds,$type=1){
		//查询已经售后商品
		if($type==1){
			$where['order_id'] = $order_id;
			$where['refund_state'] = array('NEQ',4);
			$refundData = M('refund_return')->where($where)->field('goods_id')->select();
		}elseif($type==2){
			$refundData = M('refund_return')->where(['order_id'=>$order_id,'refund_state'=>3])->field('goods_id')->select();
		}

		if($refundData){
			foreach ($refundData as $key=>$value){
				array_push($goodIds,$value['goods_id']);
			}

		}
		//查询订单商品ids
		$orderDoods = M('order_goods')->where(['order_id'=>$order_id])->field('goods_id')->select();
		$orderGoodIds = array_column($orderDoods,'goods_id');
		$diff = array_diff($orderGoodIds,$goodIds);
		if(empty($diff)){
			//是最后商品，可以给退运费
			return true;
		}else{
			return false;
		}

	}

}
