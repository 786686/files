<?php

namespace Common\Model;

use Think\Model;

/**
 * PrivilegeModel
 * @author Kun
 */
class PrivilegeModel extends Model
{
    const PRIVILEGE_LIST_FIELD    = 'p.priv_id,p.priv_title,p.priv_action,FROM_UNIXTIME(p.priv_createtime) as priv_createtime,p.priv_description,p.priv_status,p.priv_group,p.priv_sort,p.priv_update_user,a.admin_username,a.admin_mobile';
    const PRIVILEGE_ORDER      = 'p.priv_sort DESC , p.priv_id ASC';
    const PRIVILEGE_STRUCTURE  = 'p.priv_id,p.priv_title,p.priv_group';
    const PRIVILEGE_DETAILS    = 'priv_id,priv_title,priv_group,priv_status,priv_sort,priv_description';
    const PRIVILEGE_STATUS_DELETE = -1;
    const ROLE_PARENT             = 0;
    public function checkLogin( $data = [] ,$field = 'mark_name' )
    {
        return M("AdminToken")->where([
            'mark_name'       => "admin_".$data['admin_id'],
            'app_admin_token' => $data['admin_token']
        ])->field($field)->find();
    }

    private function getAdmin( $where = [] , $field= '' )
    {
        return M("Admin")->where($where)->field($field)->find();
    }


    public function getLists( $field = '', $where = [] ,$limit = '' )
    {
        $model = $this->alias('p')
            ->field($field)
            ->where($where)
            ->join("left join __ADMIN__ as a on a.admin_id = p.admin_id");

        if ( $limit ) {
            return $model->limit($limit)->order(self::PRIVILEGE_ORDER)->select();
        }

        return $model->order(self::PRIVILEGE_ORDER)->select();
    }

    public function countList( $where = [] )
    {
        return $this->alias('p')->where($where)->count();
    }


    private function getPram( $data = [] )
    {
        $return_arr = [];
        if ( $data['group'] ) {
            $return_arr['p.priv_group'] = ['like',"%{$data['group']}%"];
        }

        if ( $data['title'] ) {
            $return_arr['p.priv_title'] = ['like',"%{$data['title']}%"];
        }

        if ( is_numeric($data['status']) ) {
            $return_arr['p.priv_status'] = $data['status'];
        }

        if ( $data['start_time'] ) {
            $return_arr['p.priv_createtime']  = ['EGT',strtotime($data['start_time'])];
        }

        if ( $data['end_time'] ) {
            $end_time = $data['end_time'];
            $return_arr['p.priv_createtime']  = ['ELT',strtotime("$end_time 23:59:59")];
        }

        if ( $data['start_time'] && $data['end_time'] ) {
            $end_time = $data['end_time'];
            $return_arr['p.priv_createtime'] = [
                ['EGT',strtotime($data['start_time'])],
                ['ELT',strtotime("$end_time 23:59:59")],
            ];
        }

        return $return_arr;
    }

    /**
     * 角色列表
     * @param  $data['limit'] 分页
     * @param  $data['group'] 分组/模版类型
     * @param  $data['title'] 标题/模版内容
     * @param  $data['status'] 状态
     * @param  $data['start_time'] 创建时间
     * @param  $data['end_time']
     * @return array 返回类型
     */
    //todo
    public function lists( $data = [] )
    {
        $where = $this->getPram( $data );
        $count = count($where);
        $where = array_merge( [
            'p.priv_status' => ['NEQ',self::PRIVILEGE_STATUS_DELETE],
        ],$where );
        if ( $count >= 1 || $data['export'] == 1 ) {//如果是筛选的话，不缓存直接查询
            return $this->getListData( $where,$data,$count);

        }

        $list = S('privilege_lists');

        if ( empty($list[$data['limit']])  ) {
            return $this->getListData( $where,$data,$count );
        }

        return $list[$data['limit']];

    }


    private function getListData( $where = [],$data = [] ,$count_where = '' )
    {
        $list  = $this->getLists( self::PRIVILEGE_LIST_FIELD, $where, ($data['export']==1)?'':$data['limit'] );

            foreach ( $list as $key => $value ) {
                $list[$key]['sn'] = $key + 1 + ($data['page'] - 1) * $data['rows'];
                $list[$key]['admin_username'] = empty($value['admin_username'])?"":$value['admin_username'];
                $list[$key]['admin_mobile'] = empty($value['admin_mobile'])?"":$value['admin_mobile'];
            }

        $list = [
            'list'  => $list,
            'count' => $this->countList( $where )
        ];

        if ( $list['list'] && $count_where <= 0 ) {//有数据才缓存,且不是筛选
            if ( empty(S('privilege_lists')) ) {
                S('privilege_lists',[$data['limit']=>$list]);
            } else {
                $merge = array_merge([$data['limit']=>$list],S('privilege_lists'));
                S('privilege_lists',$merge);
            }
        }

        return $list;
    }


    public function structure( $keyword = '' )
    {
        $where = [
            'priv_status'    => ['NEQ',self::PRIVILEGE_STATUS_DELETE],
        ];
        if ( $keyword ) {
            $where['_string'] = "priv_group LIKE '%{$keyword}%' OR priv_title LIKE '%{$keyword}%'";
            return $this->getStructure( $where, $keyword );

        }

        $list = S('privilege_structure');

        if ( empty($list)  ) {//没有缓存，连接数据库
            $list = $this->getStructure( $where, $keyword );
        }

        return $list;
    }


    private function getStructure( $where = [] ,$keyword = '' )
    {
        $list = $this->getLists( self::PRIVILEGE_STRUCTURE,$where );
        static $right = [];
        foreach ($list as $key => $val ) {
            $right[$val['priv_group']][$val['priv_id']] = $val;
        }

        if ( empty($keyword) ) {
            S('privilege_structure',$right);
        }

        return $right;
    }


    public function modify( $data = [] )
    {
        if ( $data['type'] == 'add' || $data['type'] == 'update' ) {
            return $this->modifyAdd( $data );
        } elseif ( $data['type'] == 'del' || $data['type'] == 'state' ) {
            return $this->modifyStatus( $data );
        } elseif ( $data['type'] == 'details' ) {
            return $this->field(self::PRIVILEGE_DETAILS)->find();
        }
    }


    private function modifyStatus( $data = [] )
    {
        $save_data['priv_status'] = ($data['type']=='del')?'-1':$data['status'];

        $where = ['priv_id' => $data['id']];

        if ( $data['type'] == 'state' ) {
            $role_founder = $this->getAdmin( [
                'admin_id' => $data['admin_id']
            ] ,'admin_username');
            $role_createtime = time();
            $save_data['priv_update_user'] = $role_founder['admin_username'].' '.date('Y-m-d H:i:s',$role_createtime);
        }

        $bool = $this->where($where)->save($save_data);
        if ( $bool !== false ) {
            if ( $data['type'] == 'del' ) {
                $msg = '删除权限';
            } elseif ( $data['type'] == 'state' ) {
                $msg = '编辑权限';
            }
            admin_log("{$msg},ID:{$data['id']}",8,$data['admin_id']);
            return true;
        }
        return false;
    }

    private function modifyAdd( $data = [] )
    {
        $save_data['priv_title']          = $data['title'];
        $save_data['priv_action']         = $data['action'];
        $save_data['priv_status']         = $data['status'];
        $save_data['priv_group']          = $data['group'];
        $save_data['priv_sort']           = $data['sort'];
        $save_data['priv_description']    = $data['description'];
        $role_founder = $this->getAdmin( [
            'admin_id' => $data['admin_id']
        ] ,'admin_username');
        $role_createtime = time();
        $save_data['priv_update_user'] = $role_founder['admin_username'].' '.date('Y-m-d H:i:s',$role_createtime);
        if ( $data['type'] == 'add' ) {
            $save_data['priv_createtime']  = $role_createtime;
            $id = $this->add($save_data);
            if ( $id !== false ) {
                admin_log("新增权限,ID:{$id}",8,$data['admin_id']);
                return true;
            }

        }

        $bool = $this->where(['priv_id' => $data['id']])->save($save_data);
        if ( $bool !== false ) {
            admin_log("编辑权限,ID:{$data['id']}",8,$data['admin_id']);
            return true;
        }

    }


    /**
     * 导出权限列表
     * @param array $list
     */
    public static function exportPrivilegeListAndParams($list)
    {
        ini_set("max_execution_time", 0);//修改最大执行时间
        ini_set("memory_limit", -1); //修改此次的最大运行内存
        $fileName = '权限管理列表-'.date('Y-m-d H:i:s',time());
        $row = array();
        foreach ($list['list'] as $key => $value) {
            $row[$key]['sn']               = $key + 1;
            $row[$key]['admin_username']   = $value['admin_username'];
            $row[$key]['admin_mobile']     = $value['admin_mobile'] . "\t";
            $row[$key]['priv_createtime']  = $value['priv_createtime'] . "\t";
            $row[$key]['priv_update_user'] = $value['priv_update_user'] . "\t";
            $row[$key]['priv_action']      = $value['priv_action'] . "\t";
            $row[$key]['priv_group']       = $value['priv_group'] . "\t";
            $row[$key]['priv_title']       = $value['priv_title'] . "\t";
            if ( $value['priv_status'] == 0 ) {
                $role_status = '禁用';
            } elseif ( $value['priv_status'] == 1 ) {
                $role_status = '启用';
            }
            $row[$key]['role_status']      = $role_status . "\t";
            $row[$key]['priv_sort']        = $value['priv_sort'] . "\t";
            $row[$key]['priv_description'] = $value['priv_description'] . "\t";
        }
        $title = array('序号','创建人', '手机号码', '创建时间','上一次更新操作','操作动作','类型模版','模版内容','状态','排序','备注');
        $tableTitle = ['权限管理列表'];
        exportExcel($row,$fileName,$title,'Sheet1',$tableTitle);
    }
}
