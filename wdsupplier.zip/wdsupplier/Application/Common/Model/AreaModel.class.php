<?php

namespace Common\Model;

use Think\Model;

class AreaModel extends Model{

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $field = '*', $order = 'area_sort ASC')
	{	
		return $this->where($where)->field($field)->order($order)->select();
	}
	/**
	 * 格式化成树结构
	 * @param  array 	$list 	查询列表结果,必须包含 gc_id,gc_index 字段
	 * @return array 	格式化后的树形结构多维数组
	 */
	public function formatTree($list)
	{
		$newarray=array();
		foreach($list as $k1=>$v1){
			$mykey=$k1;
			foreach($list as $k2=>$v2){
				if($v2['area_parent_id']==$v1['area_id']){
					$list[$mykey]['child'][]=$v2;
					unset($list[$k2]);
					continue;
				}
			}
		}
		return array_values($list);
	}

	/**
	 * 获取父级地区ID
	 * @author deason 2017-04-24
	 * @param  int    $id 地区ID
	 * @return int        父级地区ID
	 */
	public function getParentIdById($id)
	{
		return $this->where(array('area_id' => $id))->getField('area_parent_id');
	}


	/**
	 * 多层级递归序列化
	 * @wuxiao
	 */
	public function serialize($list,$fvalue){
		$arr = array();
		foreach ($list as $key => $value) {
			if($value['area_parent_id']==$fvalue) {
				$value['children']=self::serialize($list,$value['value']);
				$arr[] = $value;
			}
		}
		return $arr;
	}



	public function getAllAreas( $area_deep ){

		$result = $this->field("area_id , area_name , area_parent_id , area_deep")
			 ->where(array('area_deep' => $area_deep))
			 ->select();
		return $result;

	}

	public function getStoresByAreaId( $area_id ){

	    // 初始化检索条件并搜索
		$where = [
			"area_id" => [
				"eq",
				$area_id
			],
			"is_cooperate"	=>	[
				"eq",
				1
			]
		];

		$stores = $this->field("area_id , area_name ,is_cooperate , group_concat(store_id) as store_id")
    		 ->join("left join sx_store as s on area_id = town_id")
    		 ->where($where)
    		 ->find();

    		return $stores['store_id'];
	}

	//根据名字和级别查询出数据库对应id
	public function getIDByName($name, $level){
	    $where['area_name'] = ['like', "%$name%"];
	    $where['area_deep'] = $level;
	    return $this->field('area_id,area_name')->where($where)->find();
    }

    /**
     * 获取子集区域数据
     */
    public function getClassArea($area_parent_id){
        return $this->where(['area_parent_id'=>$area_parent_id])->field('area_id,area_name,area_deep')->select();
    }

    /**
     * @param $area_id-地区ID
     * @param $parent_id-父级ID，如果是比较省地区时为0
     * @return array
     */
    public function checkIDrelation($area_id, $parent_id)
    {
        $array = [
            '省级ID',
            '市级ID和省级ID',
            '区级ID和市级ID',
            '镇级ID和区级ID',
            '村级ID和镇级ID'
        ];
        $info = M('Area')->field('area_name,area_parent_id,area_deep')->where(['area_id' => $area_id])->find();
        if(empty($info)){
            return [
                'ok' => 0,
                'msg' => 'ID为' . $area_id . '地区不存在',
                'data' => []
            ];
        }
        if ($info['area_parent_id'] != $parent_id) {
            return [
                'ok' => 0,
                'msg' => $array[$info['area_deep']] . '关系不对应',
                'data' => []
            ];
        }
        return [
            'ok' => 1,
            'msg' => '对应关系正确',
            'data' => $info
        ];
    }
}