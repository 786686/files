<?php
namespace Common\Model;

use Think\Model;

class StatMemberModel extends Model {
    
    public function updateStatmember($where,$update_arr)
    {
        return $this->where($where)->save($update_arr) !== false ? true : false;
    }

    public function delByStatmember($where)
    {
        if (empty($where)) {
            return false;
        }
        return $this->where($where)->delete();
    }

    public function insertAll($insert_arr)
    {
        if (empty($insert_arr) || !is_array($insert_arr)) {
            return false;
        }

        return $this->addAll($insert_arr);
    }

}