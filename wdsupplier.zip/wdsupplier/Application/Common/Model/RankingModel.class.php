<?php
/**
 * Created by PhpStorm.
 * User: fengfeiwu
 * Date: 2018/9/10
 * Time: 16:55
 */

namespace Common\Model;


use Think\Model;

class RankingModel extends Model
{
    public function exportRankingExcel($lists,$time){
        ini_set("max_execution_time", 0);//修改最大执行时间
        ini_set("memory_limit", -1); //修改此次的最大运行内存
        $fileName = '员工排行榜-' . date('Y-m-d H:i:s', time());
        $list = [];
        foreach ($lists as $key=>$value){
            $list[$key]['sn'] = $key+1;
            $list[$key]['id'] = $value['id'];
            $list[$key]['user_name'] = $value['user_name'];
            $list[$key]['department_name'] = $value['department_name'];
            $list[$key]['sex'] = $value['sex'];
            $list[$key]['position_name'] = $value['position_name'];
            $list[$key]['mobile'] = $value['mobile'];
            $list[$key]['total_order_amount'] = $value['total_order_amount'];
            $list[$key]['rank'] = $value['rank'];
        }

        $col = array('序号','员工id', '员工姓名', '部门', '性别', '职务', '手机号码', '扶贫业绩', '排名');
        $tableTitle1 = '员工排行榜';
        if($time){
            $tableTitle2 = date('Y年m月d日',$time[0]).'-'.date('Y年m月d日',$time[1]);
            exportExcel($list, $fileName, $col, 'Sheet1', [$tableTitle1,$tableTitle2],[]);
        }else{
            exportExcel($list, $fileName, $col, 'Sheet1', [$tableTitle1],[]);
        }

    }
    public function exportCompanyRankingExcel($lists){
        ini_set("max_execution_time", 0);//修改最大执行时间
        ini_set("memory_limit", -1); //修改此次的最大运行内存
        $fileName = '下级单位排行榜-' . date('Y-m-d H:i:s', time());
        $list = [];
        foreach ($lists as $key=>$value){
            $list[$key]['sn'] = $key+1;
            $list[$key]['id'] = $value['id'];
            $list[$key]['company_name'] = $value['company_name'];
            $list[$key]['total_order_amount'] = $value['total_order_amount'];
            $list[$key]['rank'] = $value['rank'];
        }

        $col = array('序号','单位id', '单位名称', '扶贫业绩', '排名');
        $tableTitle1 = '下级单位排行榜';
        exportExcel($list, $fileName, $col, 'Sheet1', [$tableTitle1],[]);
    }

}