<?php

namespace Common\Model;

use Think\Model;
use Api\Controller\CommonController;
/**
 * PrivilegeModel
 * @author Kun
 */
class StudentModel extends Model
{
    const PRIVILEGE_LIST_FIELD    = 'p.priv_id,p.priv_title,p.priv_action,FROM_UNIXTIME(p.priv_createtime) as priv_createtime,p.priv_description,p.priv_status,p.priv_group,p.priv_sort,p.priv_update_user,a.admin_username,a.admin_mobile';
    const PRIVILEGE_ORDER      = 'p.priv_sort DESC , p.priv_id ASC';
    const PRIVILEGE_STRUCTURE  = 'p.priv_id,p.priv_title,p.priv_group';
    const PRIVILEGE_DETAILS    = 'priv_id,priv_title,priv_group,priv_status,priv_sort,priv_description';
    const STUDENT_STATUS_DELETE = -1;
    const PASSWORD = 888888;
    const CENTER_URL = '/Mobile/Api/getPostData';
    const ROLE_PARENT             = 0;
    public function checkLogin( $data = [] ,$field = 'mark_name' )
    {
        return M("AdminToken")->where([
            'mark_name'       => "admin_".$data['admin_id'],
            'app_admin_token' => $data['admin_token']
        ])->field($field)->find();
    }



    public function getLists( $field = '', $where = [] ,$limit = '' )
    {
        $model = $this->alias('p')
            ->field($field)
            ->where($where)
            ->join("left join __ADMIN__ as a on a.admin_id = p.admin_id");

        if ( $limit ) {
            return $model->limit($limit)->order(self::PRIVILEGE_ORDER)->select();
        }

        return $model->order(self::PRIVILEGE_ORDER)->select();
    }

    public function countList( $where = [] )
    {
        return $this->alias('p')->where($where)->count();
    }



    public function checkStudent( $data = [] )
    {
        $err_msg = [];
        if ( !is_mobile(trim($data['student_mobile'])) ) {
            array_push($err_msg , '手机号码不正确');
        }

        if ( !preg_match('/^[A-Za-z0-9]+$/',$data['student_no']) ) {
            array_push( $err_msg , '学号不正确' );
        }

        $check_no = $this->where([
            'student_status' => ['NEQ',self::STUDENT_STATUS_DELETE],
            'student_no'     => $data['student_no']
        ])->getField('id');

        if ( $check_no ) {
            array_push( $err_msg , '学号已经存在' );
        }

        return $err_msg;
    }


    public function studentAdd( $data = [] ,$store_id = '' )
    {
        $student_sex = 0;
        if ( $data['student_sex']=='男' ) {
            $student_sex = 1;
        } elseif ( $data['student_sex'] == '女' ) {
            $student_sex = 2;
        }

        $save_data['student_realname'] = $data['student_realname'];
        $save_data['student_class']    = $data['student_class'];
        $save_data['student_no']       = $data['student_no'];
        $save_data['student_mobile']   = $data['student_mobile'];
        $save_data['student_sex']      = $student_sex;
        $save_data['store_id']         = $store_id;
        $save_data['create_time']      = time();
        return $this->add($save_data);
    }


    //将信息添加到会员表
    public function memberAdd( $student_mobile = '' ,$store_id = '' )
    {
        $checkCenter = $this->sendCenter( [
            'phone'    => $student_mobile,
            'method'   => 'NewCenter.checkPhoneReg',
        ] );
        if ( $checkCenter['code'] == '0' && $checkCenter['data']['isRgister'] != 1 ) {//尚未注册的
            $salt = createApiToken(6);
            $pass = create_password($salt, self::PASSWORD);
            $this->sendCenter( [
                'mobile' => $student_mobile,
                'passwd' => self::PASSWORD,
                'type'   => 0,
                'method'   => 'NewCenter.loginRegisterCheck',
            ] );
            $data = [
                'member_mobile'    => $student_mobile,
                'member_pass_salt' => $salt,
                'member_pass'      => $pass,
                'member_type'      => 3, //后台导入学生（学号类型）
                'member_reg_ip'    => get_client_ip(),
                'member_time'      => time(),
                'political_outlook'=> 0
            ];
            $member_id = M('member')->add($data);//添加会员信息
            if ( $member_id !== false ) {//绑定超市关系
                M('member_store')->add([
                    'member_id'   => $member_id,
                    'store_id'    => $store_id,
                    'create_time' => time()
                ]);
                return $this->where(['student_mobile'=>$student_mobile])->save([
                    'member_id'      => $member_id,
                    'student_status' => 1
                ]);
            }
        }


    }

    //对接会员中心
    public function sendCenter( $data = [] )
    {
        $url  = self::CENTER_URL;
        return json_decode((new CommonController)->postCurl($url, $data,2),true);

    }

    private function getPremWhere( $data = [] )
    {
        if ( $data['student_mobile'] ) {
            $where['student_mobile'] = ['like',$data['student_mobile'].'%'];
        }

        if ( $data['student_realname'] ) {
            $where['student_realname'] = ['like',$data['student_realname'].'%'];
        }

        if ( $data['student_no'] ) {
            $where['student_no'] = ['like',$data['student_no'].'%'];
        }

        if ( is_numeric($data['status']) ) {
            $where['student_status'] = $data['status'];
        }

        return $where;
    }

    public function studentArchivesLists( $data = [] )
    {
        $where = $this->getPremWhere( $data );
        $model = $this->where( $where );
        $list  = $model->limit($data['limit'])->select();
        $count = $model->count();
        return [
            'list'  => $list,
            'count' => $count
        ];
    }


    /**
     * 导出权限列表
     * @param array $list
     */
    public static function exportPrivilegeListAndParams($list)
    {
        ini_set("max_execution_time", 0);//修改最大执行时间
        ini_set("memory_limit", -1); //修改此次的最大运行内存
        $fileName = '权限管理列表-'.date('Y-m-d H:i:s',time());
        $row = array();
        foreach ($list['list'] as $key => $value) {
            $row[$key]['sn']               = $key + 1;
            $row[$key]['admin_username']   = $value['admin_username'];
            $row[$key]['admin_mobile']     = $value['admin_mobile'] . "\t";
            $row[$key]['priv_createtime']  = $value['priv_createtime'] . "\t";
            $row[$key]['priv_update_user'] = $value['priv_update_user'] . "\t";
            $row[$key]['priv_action']      = $value['priv_action'] . "\t";
            $row[$key]['priv_group']       = $value['priv_group'] . "\t";
            $row[$key]['priv_title']       = $value['priv_title'] . "\t";
            if ( $value['priv_status'] == 0 ) {
                $role_status = '禁用';
            } elseif ( $value['priv_status'] == 1 ) {
                $role_status = '启用';
            }
            $row[$key]['role_status']      = $role_status . "\t";
            $row[$key]['priv_sort']        = $value['priv_sort'] . "\t";
            $row[$key]['priv_description'] = $value['priv_description'] . "\t";
        }
        $title = array('序号','创建人', '手机号码', '创建时间','上一次更新操作','操作动作','类型模版','模版内容','状态','排序','备注');
        $tableTitle = ['权限管理列表'];
        exportExcel($row,$fileName,$title,'Sheet1',$tableTitle);
    }
}
