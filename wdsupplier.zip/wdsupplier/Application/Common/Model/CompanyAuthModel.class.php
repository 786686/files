<?php

namespace Common\Model;

use Think\Model;

/**
 * 企业认证模块
 */
class CompanyAuthModel extends Model
{
    //审核状态
    const STATUS_WATI_CHECK = 0;//0待审核
    const STATUS_YES_CHECK = 1;//1已通过
    const STATUS_NO_CHECK = 2;//2不通过
    const STATUS_REMOVE_BIND = 3;//3解绑状态

    //获取企业认证信息
    public function getInfoByMemberID($memberID)
    {
        $where['member_id'] = $memberID;
        $where['status'] = 1;   //审核状态为已通过
        return $this->field('id,company_name,member_id')->where($where)->find();
    }

    /** 取出关注的超市ID
     * @param $memberID
     * @return mixed
     */
    public function getMemberStore($memberID)
    {
        return M('MemberStore')->where(['member_id' => $memberID])->getField('store_id', true);
    }

    public function getMaxOrderStoreID($memberID)
    {
        $storeIDArr = $this->getMemberStore($memberID);
        if ($storeIDArr) {
            $where['o.store_id'] = ['in', $storeIDArr];
        }
        if ($memberID) {
            $where['o.buyer_id'] = $memberID;
        }
        $where['o.order_state'] = ['in', [20, 30, 40]];
        $where['s.store_state'] = 1;
        $field = 'o.store_id,s.store_name,count(o.order_id) as order_num';
        return M('Order')
            ->alias('o')
            ->field($field)
            ->join('left join __STORE__ s on o.store_id = s.store_id')
            ->where($where)
            ->group('o.store_id')
            ->order('order_num desc')
            ->limit(1)
            ->select();
    }

    //根据名字取出机构
    public function getInfoByName($companyName){
        $field = 'id,company_name,organization_code,apply_mobile,member_id';
        return $this->field($field)->where(['company_name' => $companyName])->find();
    }

    //根据企业ID取出企业
    public function getInfoByID($id){
        $where['id'] = $id;
        return $this->field('id,company_name')->where($where)->find();
    }

    //取出认证公司会员ID
    public function getCompanyID(){
        $where['status'] = 1;
        return $this->where($where)->getField('member_id', true);
    }

    //取出公司的下级单位用户集合
    public function getChildCompany($parent_id){
        $arr = $this->where(['parent_company_id' => $parent_id])->getField('member_id', true);
        return empty($arr) ? [] : $arr;
    }

    //取出扶贫超市数量包括自己绑定的
    public function getCompanyStore($member_id_arr){
        $where['member_id'] = ['in', $member_id_arr];
        $arr = M('MemberStore')->where($where)->getField('store_id', true);
        return empty($arr) ? [] : $arr;
    }

    /** 获取公司ID
     * @param $member_id -会员ID
     * @return array|mixed
     */
    public function getCompanyIDBuyMemberID($member_id)
    {
        $company = M('CompanyAuth')->where([
            'member_id' => $member_id,
            'status' => 1
        ])->getField('id');
        if (!empty($company)) {
            return $company;
        }
        $company = M('MemberAuth')->where([
            'member_id' => $member_id,
            'status' => 1
        ])->getField('company_id');
        if (!empty($company)) {
            return $company;
        }
        return 0;
    }

    /**
     * @param $companyId 企业id
     * @return bool true 存在  false 不存在
     */
    public function checkCompanyStatusByCompanyId($companyId = 0)
    {
        $result = $this->where(['id' => (int)$companyId, 'status' => self::STATUS_YES_CHECK])->find();
        if ($result){
            return true;
        }else{
            return false;
        }
    }

    /**
     * 获取下级企业的数据
     * @param $companyId
     * @param string $field
     * @return array
     */
    public function getChildCompanyDataByCompanyIdAndField($companyId,$field = "*")
    {
        return $this->where(['status' => self::STATUS_YES_CHECK, 'parent_company_id' => $companyId])->field($field)->select();
    }


    /**
     * 获取下级企业列表(花名单功能)
     * @param $companyIds
     * @return mixed
     */
    public function getLeftJoinRosterAndDepartmentPositionMemberMemberAuthModel()
    {
        $this->alias('ca')
            ->join('LEFT JOIN __COMPANY_ROSTER__ cr ON ca.id = cr.company_id')
            ->join('LEFT JOIN __COMPANY_ROSTER_DEPARTMENT__ crd ON crd.id = cr.department_id')
            ->join('LEFT JOIN __COMPANY_ROSTER_POSITION__ crp ON crp.id = cr.position_id')
            ->join('LEFT JOIN __MEMBER__ m ON m.member_mobile = cr.mobile')
            ->join('LEFT JOIN __MEMBER_AUTH__ ma ON ma.member_id = m.member_id');
        return $this;
    }
}