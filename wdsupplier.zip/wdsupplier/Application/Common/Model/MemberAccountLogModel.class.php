<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/1/7
 * Time: 11:22
 */

namespace Common\Model;


use Think\Model;

class MemberAccountLogModel extends Model
{
    const LOT_TYPE_NAME = [
        1 => '商品销售收入',
        2 => '消费支出',
        3 => '退款',
        4 => '余额提现',
        5 => '充值到余额',
        6 => '余额充值手续费', // 余额充值手续费
        7 => '余额转出手续费', // 余额充值手续费
        8 => '分佣金额', // 余额充值手续费
    ];

    const LOG_TYPE_COMMISSION = 8;

    /**
     * 通过提现申请的ID 获取 账户日志记录
     * @author: fanzhaogui
     * @param $wlID
     * @return array|mixed
     */
    public function getOneByWlId($wlID)
    {
        $data = $this->where('wl_id = ' . $wlID)->find();
        return $data ? $data : [];
    }


    /**
     * 新增一条分佣的记录
     *
     * @author: fanzhaogui
     */
    public function addCommissionLog($order_id, $order_sn, $uid, $changeMoney, $balance, $remark)
    {
        // order_sn  pay_sn  order_id
        $data = [
            'uid'          => $uid,
            'plat_order'   => 'plat_order',
            'order_id'     => $order_id,
            'order_sn'     => $order_sn,
            'account_type' => self::LOG_TYPE_COMMISSION,
            'change_money' => $changeMoney, // 变动金额
            'balance'      => $balance, // 当前余额
            'remark'       => $remark, // 交易详情
            'status'       => 1, // 状态 1 成功
            'createtime'   => NOW_TIME, // 创建时间
            'pay_type'     => 'balance', // 类型
        ];

        return $this->add($data);
    }
}