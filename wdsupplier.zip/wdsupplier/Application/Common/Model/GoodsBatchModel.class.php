<?php
/**
 * 商品模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class GoodsBatchModel extends GoodsModel {
    public $sortList = array(
			'sales_desc' => 'go.goods_salenum DESC,go.goods_sort ASC',    // 销量排序
            'common_desc'   => 'gb.goods_sort ASC,go.goods_id DESC',      // 人气排序
            'pop_desc'   => 'go.goods_sort ASC,go.goods_click DESC',      // 人气排序
            'price_desc' => 'gp.goods_price DESC',     // 价格排序 - 降序
            'price_asc'  => 'gp.goods_price ASC'       // 价格排序 - 升序
        );

	const FIELD_GOODS_LIST = 'go.goods_id,goods_name,goods_jingle,goods_unit,goods_salenum,go.goods_spec_id,go.goods_spec_id,goods_state,goods_img,goods_serial,goods_salenum';

	/**
	 * 获取企业采购商品列表
	 */
	public function getList($where = array(), $limit = '0,10', $field = '*', $order = 'sales_desc')
	{

		$member_id=$where['member_id'];
		unset($where['member_id']);
		$where['go.goods_state']=1;
		$where['gp.goods_price']=array('gt',0);
        $where['gb.is_show']=1;
		//goods_batch为主表 连商品表
		$orderby = empty($this->sortList[$order]) ? array_shift($this->sortList) : $this->sortList[$order];
		$role=D('Member')->getMemberRole($member_id);
		//按排序获取商品列表
		$subQuery = $this->field("goods_id,goods_name,goods_sort,goods_click,goods_salenum,goods_state,gc_id_1,gc_id_2")->table('__GOODS__')->buildSql();
		//企业采购列表查type=1的价格
		$subQuery2 = $this->field("goods_id,price as goods_price,goods_spec_id")->table('__GOODS_PRICE__')->where(array('type'=>1))->buildSql();
		if($where['ga.gc_id'] || $where['ga.attribute_category_id'] || $where['ga.attribute_id']){
            $list=$this->alias('gb')
                ->join("LEFT JOIN $subQuery as go ON gb.goods_id = go.goods_id")
                ->join("LEFT JOIN $subQuery2 as gp on gb.goods_id =gp.goods_id and gb.goods_spec_id =gp.goods_spec_id")
                ->join("LEFT JOIN __GOOD_ATTRIBUTE__ as ga on ga.goods_id =gb.goods_id")
                ->where($where)->limit($limit)->field('gb.goods_id,gb.goods_spec_id')->order($orderby)->group('gb.goods_id')->select();

        }else{
            $list=$this->alias('gb')
                ->join("LEFT JOIN $subQuery as go ON gb.goods_id = go.goods_id")
                ->join("LEFT JOIN $subQuery2 as gp on gb.goods_id =gp.goods_id and gb.goods_spec_id =gp.goods_spec_id")
                ->where($where)->limit($limit)->field('gb.goods_id,gb.goods_spec_id')->order($orderby)->group('gb.goods_id')->select();
        }


		$goodsModel=D('Goods');
		foreach ($list as $key => &$value) {
			$value=$this->getListDetail(['goods_id'=>$value['goods_id'],'goods_spec_id'=>$value['goods_spec_id'],'role'=>$role]);
			$value['goods_type']=1;
			$value['buy_store_id']=0;
			//商品合法性校验
			$checkState=$this->checkStateToBuyByInfo($value);
			if($checkState['code']!=$goodsModel::STATE_NORMAL&&$checkState['code']!= $goodsModel::STATE_CODE_NOT_STOCK) unset($list[$key]);
		}
		return array_values($list);
	}

	public function getBatchPrice($parm=array()){
		$batch_price = $this->where(array('goods_id'=>$parm['goods_id'],'goods_spec_id'=>$parm['goods_spec_id']))->getField('batch_price');
		if(empty($batch_price)){
			return 0;
		}else{
			return $batch_price;
		}
	}
}
