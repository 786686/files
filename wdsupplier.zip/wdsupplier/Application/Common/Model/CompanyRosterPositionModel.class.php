<?php
/**
 * 花名册部门Model
 * User: yangjiyang
 * Date: 2018/8/20
 * Time: 20:29
 */

namespace Common\Model;


use Think\Model;

class CompanyRosterPositionModel extends Model
{
    /**
     * 获取部门id，如果不存在则添加
     * @param $departmentName
     * @param $companyId
     * @return mixed
     */
    public function getPositionIdByPositionNameAndCompanyId($PositionName,$companyId)
    {
        $PositionId = $this->where(['position_name' => $PositionName, 'company_id' => $companyId])->getField('id');
        if (empty($PositionId)){
            $PositionId = $this->addPositionByPositionNameAndCompanyId($PositionName,$companyId);
        }
        return $PositionId;
    }

    /**
     * 添加部门
     * @param $departmentName
     * @param $companyId
     * @return mixed
     */
    public function addPositionByPositionNameAndCompanyId($PositionName,$companyId)
    {
        $data = [
            'company_id' => $companyId,
            'position_name' => $PositionName,
        ];
        return $this->add($data);
    }

}