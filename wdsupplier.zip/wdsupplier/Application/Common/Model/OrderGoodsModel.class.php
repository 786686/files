<?php
/**
 * 订单模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class OrderGoodsModel extends Model {

	/*
	`rec_id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '订单商品表索引id',
	`order_id` INT(11) NOT NULL COMMENT '订单id',
	`goods_id` INT(11) NOT NULL COMMENT '商品id',
	`product_id` BIGINT(20) NOT NULL COMMENT 'sku',
	`goods_name` VARCHAR(50) NOT NULL COMMENT '商品名称',
	`goods_price` DECIMAL(10,2) NOT NULL COMMENT '商品价格',
	`goods_num` SMALLINT(5) UNSIGNED NOT NULL DEFAULT '1' COMMENT '商品数量',
	`goods_img` VARCHAR(255) NULL DEFAULT NULL COMMENT '商品主图',
	`goods_imgs` TEXT NULL COMMENT '商品图片',
	`goods_pay_price` DECIMAL(10,2) UNSIGNED NOT NULL COMMENT '商品实际成交价',
	`goods_spec` TEXT NOT NULL COMMENT '商品规格序列化',
	`goods_body` TEXT NOT NULL COMMENT '商品描述',
	`mobile_body` TEXT NOT NULL COMMENT '手机端商品描述（预留）',
	`store_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '网店ID',
	`buyer_id` INT(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '买家ID',
	`gc_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT '0' COMMENT '商品最底级分类ID',
	`transport_id` MEDIUMINT(8) UNSIGNED NOT NULL COMMENT '运费模板id',
	`goods_unit` VARCHAR(10) NOT NULL COMMENT '计量单位',
	`goods_freight` DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT '0.00' COMMENT '运费 0为免运费',
	`is_own_shop` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '是否为平台自营 1是，0否',
	`create_time` INT(11) NOT NULL COMMENT '生成时间',
	`goods_sn` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '商品编号',
	`goods_weight` INT(11) NOT NULL DEFAULT '0' COMMENT '重量',
	`goods_cost_price` DECIMAL(10,2) NOT NULL COMMENT '成本价',
	`goods_marketprice` DECIMAL(10,2) NOT NULL COMMENT '市场价',
	`store_name` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '网店名称',
	`evaluation_state` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '评价状态( 0:待评论, 1:以评论, -1:过期或禁止评论 )',
	 */

	// 评价状态 FIELD : evaluation_state
	const EVAL_NOT		= 0;		// 未评价
	const EVAL_DONE		= 1;		// 已评价
	const EVAL_END		= 2;		// 已过期
	const EVAL_VALID	= 2592000;	// 有效时长 (30 * 24 * 60 * 60)
	const FIELD_LIST	= 'goods_id,goods_name,goods_unit,goods_img,goods_num,goods_pay_price,buy_store_id,store_id,store_name,goods_num * goods_pay_price AS goods_total,goods_spec_id';
	/**
	 * 生产订单
	 */
	public function addOrderGoods($data=array())
	{
		$data['goods_img']=str_replace('http://'.$_SERVER['SERVER_NAME'].'/', '', $data['goods_img_val']);
		$data['goods_img']=str_replace('http://www.wx7z.com/', '', $data['goods_img_val']);
		$data['goods_img']=str_replace('http://7zmall.wxw33.com/', '', $data['goods_img_val']);
		$data['mobile_body']='';
		$data['goods_body']='';
		$data['goods_spec']='';
		$data['transport_id']=0;
		$data['goods_cost_price']=0;
		$data['product_id']=0;
		$data['store_id']=0;
		$data['store_name']='';
		$data['buy_store_id']= $data['buy_store_id'] ?? 0;
		$data['evaluation_state']=self::EVAL_NOT;
		$data['create_time']=NOW_TIME;
		$data['goods_spec_value'] = M('goods_spec')->where(array('goods_spec_id'=>$data['goods_spec_id']))->getField('sp_value_name');
		return $this->add($data);
	}

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $limit [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $limit = '', $field = '',
                            $order = 'rec_id asc', $ossClient)
	{
		if($field=='') $field=self::FIELD_LIST;
		$goodslist=$this->where($where)->limit($limit)->field($field)->order($order)->select();
		foreach ($goodslist as $key => $value) {
            $goodslist[$key]['goods_img']=!empty($value['goods_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $value['goods_img'], 3600) : '';
			$goods = M('goods')->field('is_refund,is_welfare')->where(array('goods_id'=>$value['goods_id']))->find();
			$goodslist[$key]['is_refund'] = $goods['is_refund'];
			$goodslist[$key]['is_welfare'] = $goods['is_welfare'];
		}
		return $goodslist;
	}

    public function getListAndRefund($where = array(), $limit = '', $field = '', $order = 'rec_id asc',$ossClient)
    {
        if($field=='') $field=self::FIELD_LIST;
        $goodslist=$this->where($where)->limit($limit)->field($field)->order($order)->select();
        foreach ($goodslist as $key => $value) {
            $state = M('refund_return')->field('refund_state,seller_state')->where(array('order_id'=>$where['order_id'],'goods_id'=>$value['goods_id']))->find();
            /*if($state && $state['refund_state'] != 4){
                $refund_state = $state['seller_state'];
            }else {
                $refund_state = 0;
            }
            $goodslist[$key]['refund_state'] = $refund_state;
            */
            $reload = M('refund_reload')->field('refund_reload_status')->where(array('order_id'=>$where['order_id'],'goods_id'=>$value['goods_id']))->find();
	        $goodslist[$key]['refund_reload_status'] = $reload['refund_reload_status'];
            $goodslist[$key]['refund_state'] = $state['refund_state'];
            $goodslist[$key]['goods_img']=!empty($value['goods_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $value['goods_img'],
                3600) : '';
			$goodslist[$key]['goods_total'] =sprintf("%.2f",$goodslist[$key]['goods_total']);
        }
        return $goodslist;
    }

	/**
	 * 获得详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($where = array(), $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

	/**
	 * 设置为已评论状态
	 * @param  integer $id 		订单商品主键ID
	 */
	public function setEvalToDone($id)
	{
		return $this->where(array(
			'rec_id' => $id
		))->save(array(
			'evaluation_state' => self::EVAL_DONE
		));
	}

	/**
	 * 记录评论
	 * @author deason 2016-09-18
	 * @param  integer $goodsId      商品ID
	 * @param  integer $originId     订单商品主键
	 * @param  integer $memberId     评论人ID
	 * @param  string  $message      评论信息
	 * @param  integer $star         评级星级
	 * @return boolean		 	     操作状态
	 */
	public function logicEvalGoods($goodsId, $originId, $memberId, $message = '', $star = 5)
	{
		if (!$this->setEvalToDone($originId)) {
			return false;
		}
		$message = mb_strlen($message) > 140 ? substr($message, 0 , 140) : $message;
		$memberInfo = D('Member')->getInfo(
			array('member_id' => $memberId),
			'member_id,member_mobile,member_nickname,member_avatar'
		);
		$memberName = $memberInfo['member_nickname'] ? $memberInfo['member_nickname'] :  preg_replace ('/(?<=.{3})(.+)(?=.{2})/', '***', $memberInfo['member_mobile']);
		$modelC = D('GoodsComment');
		$commentData = array(
			'comment_type'          => $modelC::TYPE_GOODS,
			'comment_object_id'     => $goodsId,
			'comment_origin_id'     => $originId,
			'comment_message'       => $message ?: $modelC::DEFAULT_COMMIT,
			'comment_star'          => $modelC->starList[$star] ? $star : $modelC::DEFAULT_SART,
			'comment_member_id'     => $memberId,
			'comment_member_name'   => $memberName,
			'comment_member_avatar' => $memberInfo['member_avatar'],
			'comment_time'          => NOW_TIME
		);
		return $modelC->add($commentData);
	}

	/**
	 * [getPrivilegePrice 此方法用在提交订单时如果有使用优惠券时计算sx_order_goods的商品价格]
	 * @param  array  $data [订单ID,商品价格必传]
	 * @return [type]       [返回优惠后的价格]
	 */
	public function getPrivilegePrice($data=array()){
		$order_id = $data['order_id'];	//订单ID
		$price = $data['price'];	//商品价格
		$order_info = M('Order')->field('order_amount,coupon_id,shipping_fee,buyer_id')->where(array('order_id'=>$order_id))->find();
        $cupon_info = M('Coupon')->field('reduce_price')->where(array('coupon_id'=>$order_info['coupon_id'],'member_id'=>$order_info['buyer_id']))->find();
		//有使用优惠券才进行优惠价格
		if($order_info['coupon_id']>0 && !empty($cupon_info)){
			$formerPrice = $order_info['order_amount'] - $order_info['shipping_fee'] + $cupon_info['reduce_price'];	//未使用优惠券时的总价
			$ratio = $cupon_info['reduce_price']/$formerPrice;	//比例
			$privilegePrice = $price - $price*$ratio;	//优惠后的价格
			$privilegePrice = sprintf("%.2f", $privilegePrice);	//四舍五入，取两位小数点
		}else{
			$privilegePrice = $price;
		}
		return $privilegePrice;
	}

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $limit [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getGroupList($where = array(), $limit = '', $field = '', $order = 'a.rec_id DESC',$ossClient)
	{
		if($field == '') {
		    $field = 'a.order_id,a.goods_id,a.goods_name,a.goods_unit,a.goods_img,a.goods_num,a.goods_pay_price,a.goods_spec_id';
        }
		$goodslist = $this
            ->alias('a')
            ->where($where)
            ->limit($limit)
            ->field($field)
            ->order($order)
            ->select();
		foreach ($goodslist as $key => $value) {
            $state = M('refund_return')->field('refund_state,seller_state')->where(array('order_id'=>$where['order_id'],'goods_id'=>$value['goods_id']))->find();
            if($state && $state['refund_state'] != 4){
                $refund_state = $state['seller_state'];
            }else {
                $refund_state = 0;
            }
            $goodslist[$key]['refund_state'] = $refund_state;
			$goodslist[$key]['goods_img']=$ossClient->signUrl(C('aliyun.bucket'), $goodslist[$key]['goods_img'], 3600);
		}
		return $goodslist;
	}

    /**
     * 订单商品库存回滚
     */
    public function orderGoodsRollBack($order_id)
    {
        $order_goods_list=$this->where(['order_id'=>$order_id])->field('goods_id,goods_spec_id,goods_num')->select();
        foreach($order_goods_list as $key=>$value){
            $sql='UPDATE sx_goods_spec SET goods_stock=goods_stock+'.$value['goods_num'].' WHERE goods_id="'.$value['goods_id'].'" AND goods_spec_id="'.$value['goods_spec_id'].'"';
            M()->execute($sql);
        }
    }

}
