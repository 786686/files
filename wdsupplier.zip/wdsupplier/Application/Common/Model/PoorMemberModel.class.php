<?php
/**
 * 英雄榜模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class PoorMemberModel extends Model {
	/**
	 * [isMemberAuth 根据用户ID判断个人是否已经认证（包括认证企业和绑定企业）]
	 * @param  [type]  $member_id [用户ID]
	 * @return boolean            [如果有认证把认证的信息返回，没有认证就返回FALSE]
	 */
	public function isMemberAuth($member_id){
		$where['member_id'] = $member_id;
		$list = M('MemberAuth')->field('company_id,user_name as username')->where($where)->find();
		if(!empty($list))
			return $list;
		$list = M('CompanyAuth')->field('id as company_id,apply_username as username')->where($where)->find();
		if(!empty($list))
			return $list;
		return false;
	}
	public function initInfo(){
		$myInfo['poor_avatar'] = C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
		$myInfo['rank'] = 0;
		$myInfo['poor_score'] = 0;
		return $myInfo;
	}
	/**
	 * [getCompanyUserByCompanyId 根据公司ID获取绑定公司的用户信息]
	 * @return [type] [description]
	 */
	public function getCompanyUserByCompanyId($company_id, $limit='')
	{
		
		
		$where['b.company_id'] = $company_id;
		$poorModel = M('PoorMember');
		if(!empty($limit))
	        $poorModel->limit($limit);
		$list = $poorModel
				->field('a.poor_member_id,a.poor_score,a.member_id,b.user_name,c.member_avatar as poor_avatar')
				->alias('a')
				->join('left join __MEMBER_AUTH__ b on a.member_id=b.member_id')
				->join('left join __MEMBER__ c on c.member_id=b.member_id')
				->where($where)
				->order('a.poor_score desc')
				->select();
		foreach($list as $k =>$v){
			//用户头像如果不存在就给一个默认头像
			$list[$k]['poor_avatar'] = $v['poor_avatar']?C('WEBSITE_URL').'/'.$v['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
		}
		return $list;
	}
	/**
	 * [getCompanyMyInfo 获取个人在绑定企业中的信息，包括自己排名
	 * ，头像，扶贫积分，以及公司绑定的全部用户数量]
	 * @param  [type] $list      [绑定的公司用户列表]
	 * @param  [type] $member_id [要取出的个人信息的会员ID]
	 * @return [type]            [description]
	 */
	public function getCompanyMyInfo($list, $member_id){
		$myInfo = $this->initInfo();
		foreach($list as $k => $v){
			if($list[$k]['member_id'] == $member_id){
				$myInfo['poor_avatar'] = $v['poor_avatar']?C('WEBSITE_URL').'/'.$v['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
				$myInfo['rank'] = $k+1;
				$myInfo['poor_score'] = $v['poor_score'];
			}
		}
		$myInfo['member_count'] = count($list);
		return $myInfo;
	}
	/**
	 * [getListCompany 获取已经认证的公司信息]
	 * @return [type] [description]
	 */
	public function getListCompany($limit = ''){
		$caModel = M('CompanyAuth');
		if(!empty($limit))
	        $caModel->limit($limit);
		$list = M('CompanyAuth')
		->alias('ca')
		->join('sx_member m ON m.member_id=ca.member_id','LEFT')
		->join('sx_poor_member pm ON pm.company_id=ca.id','LEFT')
		->field('ca.company_name as poor_name,m.member_avatar as poor_avatar,pm.poor_score,ca.id as company_id,pm.member_id,pm.is_company')
		->where('pm.is_company = 1')
		->order('pm.poor_score desc')
		->select();
		foreach($list as $k=>$v){
			$list[$k]['poor_avatar'] = $v['poor_avatar']?C('WEBSITE_URL').'/'.$v['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
		}
		return $list;
	}
	/**
	 * [getCompanyRank 获取公司排名信息，包括头像、排名、扶贫积分
	 * 还有全部公司总数]
	 * @param  [type] $list       [全部认证公司列表]
	 * @param  [type] $company_id [要查询的公司ID]
	 * @return [type]             [description]
	 */
	public function getCompanyRank($list, $company_id){
		$companyInfo = $this->initInfo();
		foreach($list as $k => $v){
			if($list[$k]['company_id'] == $company_id && $list[$k]['is_company'] ==1){
				$companyInfo['poor_avatar'] = $v['poor_avatar']?C('WEBSITE_URL').'/'.$v['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
				$companyInfo['rank'] = $k+1;
				$companyInfo['poor_score'] = $v['poor_score'];
			}
		}
		$companyInfo['company_count'] = count($list);
		return $companyInfo;
	}
	/**
	 * [getIndexRank 扶贫英雄榜首页获取绑定的信息]
	 * @return [type] [description]
	 */
	public function getIndexRank($company, $member_id){
		$listUser = $this->getCompanyUserByCompanyId($company['company_id']);	//获取绑定的公司用户
		$myInfo = $this->getCompanyMyInfo($listUser, $member_id);	//获取自己在绑定的公司排名信息
		$listCompany = $this->getListCompany();	//认证的全部公司列表
		$companyInfo = $this->getCompanyRank($listCompany, $company['company_id']);	//获取要查询的公司排名信息
		return array('myInfo'=>$myInfo, 'companyInfo'=>$companyInfo);
	}

	/**
	 * [getPoorMemberList 获取全部英雄榜的信息（包括认证和没有认证的用户）]
	 * @return [type] [description]
	 */
	public function getPoorMemberList(){
		$list = M('member')
				->alias('m')
				->join('sx_poor_member pm ON pm.member_id=m.member_id','LEFT')
				->field('m.member_avatar as poor_avatar,m.member_nickname as poor_name,pm.poor_score,m.member_id')
				->limit($limit)
				->order('pm.poor_score desc')
				->select();
		foreach ($list as $key => $value) {
			if(!$value['poor_score']){
				$list[$key]['poor_score']=0;
			}
			$list[$key]['poor_avatar']=$value['poor_avatar']?C('WEBSITE_URL').'/'.$value['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
		}
		return $list;
	}
	/**
	 * [getNoBindMyRank 取出没有绑定企业的排名信息]
	 * @param  [type] $list      [全部用户列表]
	 * @param  [type] $member_id [要比较的用户ID]
	 * @return [type]            [description]
	 */
	public function getNoBindMyRank($list, $member_id){
		foreach ($list as $key => $value) {
			//取出自己在所有用户中排名和积分
			if($list[$key]['member_id'] == $member_id){
				$myInfo['poor_avatar'] = $value['poor_avatar']?C('WEBSITE_URL').'/'.$value['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
				$myInfo['rank'] = $key+1;
				$myInfo['poor_score'] = $value['poor_score'];
			}
		}
		$myInfo['member_count'] = count($list);
		return $myInfo;
	}
}
