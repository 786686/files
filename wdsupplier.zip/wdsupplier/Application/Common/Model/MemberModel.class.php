<?php
/**
 * 会员模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class MemberModel extends Model {

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $limit [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $limit = '', $field = '*', $order = 'order_id DESC')
	{
		return $this->where($where)->limit($limit)->field($field)->order($order)->select();
	}

	/**
	 * 获得详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($where = array(), $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

	/**
	 * 修改会员昵称
	 * @param  integer $memberId 修改的会员ID
	 * @param  string  $nickname 新的昵称
	 * @return [type]           [description]
	 */
	public function changeNickname($memberId, $nickname)
	{
		return $this->where(array('member_id' => $memberId))->save(array('member_nickname' =>$nickname));
	}

	/**
	 * 通过用户ID获取用户昵称
	 * @param  integer $memberId 会员ID
	 * @return [type]           [description]
	 */
	public function getNicknameById($memberId)
	{
		return $this->where(array('member_id' => $memberId))->getField('member_nickname');
	}

	//获取用户是否认证
	public function getMemberRole($memberId){
		if(empty($memberId)) return 0;
		$isauth=M('company_auth')->where(array('status=1 and member_id='.$memberId))->getField('id');
		return $isauth>0 ? 1 : 0;
	}
	/**
	 * [getMemberIsLock 根据用户主键ID来判断用户状态是否已激活]
	 * @return [bool] []
	 */
	public function getMemberIsLock($member_id){
		//用户状态为1(Admin/Model/MemberModel文件对应self::STATE_ACTIVE)时是已激活
		$status = $this->where(array('member_id'=>$member_id))->getField('member_state');
		if( $status == 1 )
			return true;
		else
			return false;
	}

	//添加会员积分
	public function addPoints($member_id,$addpoint){
		$addpoint=floor($addpoint);
		if($addpoint>0) $this->where(['member_id'=>$member_id])->setInc('member_points',$addpoint);
	}
	public function getWelcomeSpeech($member_id){
		$companyReg = M('CompanyAuth')->field('company_name')->where(array('member_id'=>$member_id))->find();
        if($companyReg && $member_id){
            $speech = "欢迎".$companyReg['company_name']."来扶贫购物！";
            return $speech;
        }
//        $memberReg = M('MemberAuth')->alias('a')->field('b.company_name')->join('left join __COMPANY_AUTH__ b on a.company_id=b.id')->where(array('a.member_id'=>$member_id))->find();
		$memberReg = M('Member')->field('member_nickname')->where(array('member_id'=>$member_id))->find();
        if($memberReg['member_nickname'] != ''){
            $speech = "欢迎".$memberReg['member_nickname']."来扶贫购物！";
            return $speech;
        }
        $speech = "欢迎您来扶贫购物！";
        return $speech;
	}
	//判断是否关注了镇安超市
	public function checkMemberByStoreID($member_id)
    {
        $list = M('MemberStore')->where(['member_id'=>$member_id, 'store_id'=>329])->find();
        if(empty($list)){
            return false;
        }
        return true;
    }

    public function getCompanyInfo($member_id)
    {
        $info = M('MemberAuth')
            ->alias('m')
            ->field('m.company_id,m.create_time,c.company_name')
            ->join('left join __COMPANY_AUTH__ c on m.company_id=c.id')
            ->where(['m.member_id'=>$member_id, 'm.status'=>1])
            ->find();
        if($info){
            return $info;
        }
        $info = M('CompanyAuth')
            ->field('id as company_id,create_time,company_name')
            ->where(['member_id'=>$member_id,'status'=>1])
            ->find();
        if($info){
            return $info;
        }
        return '';
    }

    //登录失败进行的操作
    public function loginErrorHandle($phone, $msg)
    {
        if ($msg == '账户名或密码错误') {
            //登录失败记录
            $date['ll_username'] = $phone;
            $date['ll_createtime'] = NOW_TIME;
            M('LoginLog')->add($date);
        }
        if ($msg == '该账户已被禁用') {
            M('Member')->where(['member_mobile' => $phone])->save([
                'member_state' => 0
            ]);
        }
        if ($msg == '该账户已被删除') {
            M('Member')->where(['member_mobile' => $phone])->save([
                'member_state' => -1
            ]);
        }
        return true;
    }

    //登录成功进行的操作
    public function loginSuccessHandle($phone)
    {
        //登录成功后清除登录失败记录
        M('LoginLog')->where(array('ll_username' => $phone))->delete();
        M('Member')->where(['member_mobile' => $phone])->save([
            'member_login_ip' => get_client_ip(),
            'member_login_time' => NOW_TIME,
            'member_state' => 1
        ]);
        cookie('auto_login_setting', '');    //把退出标识清空
        return true;
    }

	/**
	 * 根据手机号码获得用户详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getMemberInfoByMobile($mobile, $field = '*')
	{
		if(empty($mobile) || !is_mobile($mobile)){
			return false;
		}

		$where['member_mobile'] = $mobile;
		$res = M('Member')->where($where)->field($field)->find();
		
		return empty($res) ? [] : $res;
	}

	/**
	 *  商城账号更换手机号码
	 * @param $member_id
	 * @param $mobile
	 * @return bool
	 */
	public function changeMobile($member_id,$mobile){

		$where['member_id'] = $member_id;
		$updateData = ['member_mobile' => $mobile];

		$res = $this->where($where)->save($updateData);
		return $res ? true : false;

	}

}
