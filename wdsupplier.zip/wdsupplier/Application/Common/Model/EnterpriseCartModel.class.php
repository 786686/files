<?php
/**
 * 企业采购购物车
 * @author deason 2016-07
 */

namespace Common\Model;

use Think\Model;

class EnterpriseCartModel extends Model
{
    //查询出超市对应购物车中的商品种类数量，进行组装返回
    public function getNumList($list)
    {
        foreach ($list as $key => $val) {
            $count = $this->where(['store_id' => $val['store_id']])->count();
            $list[$key]['cart_num'] = empty($count) ? 0 : $count;
        }
        return $list;
    }

    public function getNumByUser($member_id, $store_id){
        $where['member_id'] = $member_id;
        $where['store_id'] = $store_id;
        $field = 'DATE_FORMAT(FROM_UNIXTIME(reservation_time), \'%Y-%m-%d\') as reservation_time,count(cart_id) as num';
        return $this->field($field)->where($where)->group('reservation_time')->select();
    }
}