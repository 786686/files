<?php

namespace Common\Model;
use Think\Model;
/**
 * 品牌模型
 */
class BrandModel extends Model{

	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $field = '*', $order = 'area_sort ASC')
	{	
		return $this->where($where)->field($field)->order($order)->select();
	}

	public function getInfo($where = array(), $field = '*')
	{
		
	}

	public function getBrandIdByName($name)
	{
		return $this->where(array('brand_name' => $name))->getField('brand_id');
	}

}