<?php
/**
 * Created by PhpStorm.
 * User: fengfeiwu
 * Date: 2018/7/4
 * Time: 16:53
 */

namespace Common\Model;


use Think\Model;

class GoodsClassAttributeModel extends Model
{
    /**
     * 获取商品第三分类的属性列表和商品属性的分类
     * @param $gc_id 商品分类id
     */
    public function getList($gc_id){
        $attribute_list = M('goods_class_attribute')->where(['gc_id'=>$gc_id])->field('attribute_id,gc_id,name')->select();
        foreach($attribute_list as $key=>$value){
            $attribute_list[$key]['attribute_category'] = M('attribute_category')->where(['attribute_id'=>$value['attribute_id']])->field('c_id,attribute_id,name')->select();
        }
        return $attribute_list;
    }


}