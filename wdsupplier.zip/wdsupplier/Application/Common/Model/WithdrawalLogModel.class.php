<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2020/1/6
 * Time: 16:39
 */

namespace Common\Model;


use Think\Model;

class WithdrawalLogModel extends Model
{
    protected $pk = 'log_id';

    protected $tableName = 'withdrawal_log';


    public function getOneByPk($logId)
    {
        return $this->field('')->where('log_id = ' . $logId)->find();
    }

    /**
     * 同步提现订单的状态值
     *
     * @author: fanzhaogui
     * @date xxx
     * @param $info
     */
    public function syncTransOrderSuccess($info)
    {
        try {
            if ($info['check_status'] != 1 && $info['withddraw_status'] != 1) {
                $data = [
                    'check_status' => 1,
                    'withddraw_status' => 1,
                ];
                $this->where($this->pk . '=' . $info[$this->pk])->save($data);
            }

            // sx_member_account_log 更新账户日志表
            $memberAccountLog = new MemberAccountLogModel();
            $log = $memberAccountLog->getOneByWlId($info[$this->pk]);
            if (empty($log)) {
                // todo 是否要新增一条记录
            }

            if ($log['status'] != 1) {
                // 更改日记的状态值？
                $memberAccountLog->where('wl_id='.$info[$this->pk])->save(['status' => 1]);
            }

            return true;
        } catch (\Throwable $e) {
            log2File('err: ' . $e->getMessage(), __FUNCTION__);
        }
        return false;
    }

}