<?php
/**
 * 商品规格
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class GoodsSpecModel extends Model {

	//传入goods_id获取 所有 商品规格和对应价格
	public function getSpecList($goods_id)
	{

		        $specList=$this->alias('a')
		        ->field('a.goods_spec_id,a.goods_id,a.sp_value_id,b.sp_value_name,a.sp_price,a.goods_stock,a.least_number,a.last_number,a.group_member_num,IFNULL(gb.number,0) as batch_number,gb.batch_price')
		        ->join('left join sx_goods_batch as gb on a.goods_spec_id=gb.goods_spec_id ')
		            ->join('left join __SPEC_VALUE__ as b on a.sp_value_id = b.sp_value_id')->where(['a.goods_id'=>$goods_id])->select();
		// foreach ($specList as $key => $value) {
		// 	$priceRes=D('GoodsPrice')->getAllPrice(['goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id]);
		// 	if($priceRes['code']==1){
		// 		$specList[$key]=array_merge($specList[$key],$priceRes['data']);
		// 	}
		// }
		return $specList;
	}

	//传入goods_id获取 默认 商品规格信息和对应价格
	public function getSpecInfo($goods_id,$goods_spec_id='')
	{
		//如果没有传入默认规格ID，取第一条
		$where['goods_id']=$goods_id;
		if(!empty($goods_spec_id)) $where['goods_spec_id']=$goods_spec_id;
		$specInfo=$this->alias('a')
            ->field('a.goods_spec_id,a.goods_id,a.sp_value_id,b.sp_value_name,a.goods_stock,a.least_number,a.last_number,a.group_member_num')
            ->join('left join __SPEC_VALUE__ as b on a.sp_value_id = b.sp_value_id')
            ->where($where)
            ->find();
		return $specInfo ?? [];
	}

	/**
	 * 获取商品默认规格 ID - 通过商品 ID
	 * @author deason 2017-05-08
	 * @param  integer $goodsId 商品 ID
	 * @return integer          商品规格 ID
	 */
	public function getSpecIdByGoodsId($goodsId)
	{
		$specInfo = $this->getSpecInfo($goodsId, true);
		return $specInfo['goods_spec_id'];
	}

	/**
	 * [getSpecleastNumberById 通过商品规格表主键ID获取对应的最小购买数量]
	 * @param  [type] $goods_spec_id [商品规格表主键ID]
	 * @return [type]                [description]
	 */
	public function getSpecleastNumberById($goods_spec_id){
		return $this->where(array('goods_spec_id'=>$goods_spec_id))->getField('least_number');
	}
}
