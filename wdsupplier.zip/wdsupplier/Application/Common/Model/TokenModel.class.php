<?php
/**
 * 令牌模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class TokenModel extends Model {

	/**
	 * 创建Token, 已存在则更新
	 * @author deason 2016-07-04
	 * @param  integer	$memberId	用户ID
	 * @return string/boolean		用户令牌
	 */
	public function BuildToken($memberId)
	{
		$token = hash('sha256', $memberId.NOW_TIME.rand(100000,999999));
		$where = array('member_id' => $memberId);
		$data = array(
			'member_id'		=> $memberId,
			'token'			=> $token,
			'updatetime'	=> NOW_TIME
			);
		$check = $this->where($where)->getField('token');
		if ($check) {
			$result = $this->where($where)->save(array());
		}
		$result = $this->add($data);
		if (!$result) {
			return false;
		}
		return $token;
	}

	/**
	 * 生成token，并写入数据库
	 * @param int $memberId		用户id
	 * @param int $device	登录设备类型
	 * @return bool|string
	 */
	public function newBuildToken($memberId,$device){
		if(empty($memberId)){
			return false;
		}

		$token = hash('sha256', $memberId.time().rand(100000,999999));
		$where = array('member_id' => $memberId,'type'=>$device);
		$data = [
			'token'			=> $token,
			'updatetime'	=> time()
		];

		$check = $this->where($where)->getField('token');
		if ($check) {	//更新
			$result = $this->where($where)->save($data);
		}else{	//新增
			$data['member_id'] = $memberId;
			$data['type'] = $device;
			$result = $this->add($data);
		}

		return !$result ? false : $token;
	}

    /**
     * 获取当前用户的token信息
     * @author: fanzhaogui
     * @date 2019-12-10
     * @param $member_id integer 用户的标识
     * @param $token string 当前登录用户的token
     */
    public function getTokenSer($member_id, $token, $device = 0)
    {
        $where = [
            'member_id'     => $member_id,
        ];

        if ($token) {
            $where['token'] = $token;
        }

        if ($device) {
            $where['type'] = $device;
        }
        $data = $this->where($where)->find();
        return $data;
    }
}