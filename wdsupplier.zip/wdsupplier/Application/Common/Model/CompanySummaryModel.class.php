<?php
/**
 * 商品价格模型
 * @author hubert 2017-04
 */
namespace Common\Model;
use Think\Model;

class CompanySummaryModel extends Model {

    protected $tableName = 'company_auth';
    public function getList(){
    }

    //取出有政企注册信息的省份
    public function getYearList($rows,$page,$where,$order_type,$order = 'create_time DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['province_id'] = array('neq','');
        if($where['create_time'] == '') {
            $where['create_time'] = array('neq', '');
            $where['time_type'] = 1;
        }
        $list = M('CompanyAuth')
//            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.province_id')
            ->field('FROM_UNIXTIME(create_time,"%Y") as year,create_time')
            ->order($order)
            ->group('year')
            ->where($where)
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['province_id'] = array('neq','');
            $start_time = strtotime(date($value['year'].'-01-01 00:00:00'));
            $end_time = strtotime(date($value['year'].'-12-31 23:59:59'));
            if($where['time_type'] == 1){
                $where_child['create_time'] = array('between',array($start_time,$end_time));
            }else{
                $where_child['create_time'] = $where['create_time'];
            }
            $child = M('CompanyAuth')
                ->where($where_child)
                ->field('id')
                ->order($order)
                ->group('province_id')
                ->select();
            $list[$key]['child_count'] = count($child);
            $list[$key]['start_time'] = $start_time;
            $list[$key]['end_time'] = $end_time;
            $list[$key]['id'] = $key+1;
            if($value['create_time'] != '') {
                $allList = $this->getSummaryAll($value,7,$where_child['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }
//        $list = $this->getSort($list,$order_type);

        return $list;
    }

    //取出有政企注册信息的省份
    public function getProvinceList($rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['province_id'] = array('neq','');
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.province_id')
            ->field('a.area_name,a.area_id,ca.id')
            ->order($order)
            ->group('ca.province_id')
            ->where($where)
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['province_id'] = $value['area_id'];
            $where['city_id'] = array('neq','');
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            $child = M('CompanyAuth')->alias('ca')
                ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.city_id')
                ->where($where_child)
                ->field('a.area_name,a.area_id')
                ->order($order)
                ->group('ca.city_id')
                ->select();
            $list[$key]['child_count'] = count($child);
            $list[$key]['id'] = $key;
            if($value['area_id'] != '') {
                $allList = $this->getSummaryAll($value, 1,$where_child['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }

        return $list;
    }

    //取出有政企注册信息的市份
    public function getCityList($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['province_id'] = $area_id;
        $where['city_id'] = array('neq','');
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.city_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.city_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['city_id'] = $value['area_id'];
            $where_child['ca.area_id'] = array('neq','');
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            $child = M('CompanyAuth')->alias('ca')
                ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.area_id')
                ->where($where_child)
                ->field('a.area_name,a.area_id')
                ->order($order)
                ->group('ca.area_id')
                ->select();
            $list[$key]['child_count'] = count($child);
            if($value['area_id'] != '') {
                $allList = $this->getSummaryAll($value, 2,$where_child['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }

        return $list;
    }

    //取出有政企注册信息的县份
    public function getCountyList($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['city_id'] = $area_id;
        $where['ca.area_id'] = array('neq','');
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.area_id')
            ->where($where)
            ->field('a.area_name,a.area_id,ca.id')
            ->order($order)
            ->group('ca.area_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['ca.area_id'] = $value['area_id'];
            $where_child['town_id'] = array('neq','');
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            $child = M('CompanyAuth')->alias('ca')
                ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.town_id')
                ->where($where_child)
                ->field('a.area_name,a.area_id')
                ->order($order)
                ->group('ca.town_id')
                ->select();
            $list[$key]['child_count'] = count($child);
            if($value['area_id'] != '') {
                $allList = $this->getSummaryAll($value, 3,$where_child['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }
        return $list;
    }

    //取出有政企注册信息的镇
    public function getTownList($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['ca.area_id'] = $area_id;
        $where['ca.town_id'] = array('neq','');
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.town_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.town_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['ca.town_id'] = $value['area_id'];
            $where_child['village_id'] = array('neq','');
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            $child = M('CompanyAuth')->alias('ca')
                ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.village_id')
                ->where(array('status'=>1,'ca.town_id'=>$value['area_id']))
                ->field('a.area_name,a.area_id')
                ->order($order)
                ->group('ca.village_id')
                ->select();
            $list[$key]['child_count'] = count($child);
            if($value['area_id'] != '') {
                $allList = $this->getSummaryAll($value, 4,$where_child['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }
        return $list;
    }

    //取出有政企注册信息的居委会
    public function getVillageList($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['ca.town_id'] = $area_id;
        $where['village_id'] = array('neq','');
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.village_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.village_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $child = M('member_family')
                ->where(array('is_householder'=>1,'area_id'=>$value['area_id']))
                ->count();
            $list[$key]['child_count'] = $child;
            if($value['area_id'] != '') {
                $allList = $this->getSummaryAll($value, 5,$where['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }
        return $list;
    }

    //取出有政企注册信息的村或者街道
    public function getVillageChildList($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['ca.village_id'] = $area_id;
        $where['village_child_id'] = array('neq','');
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.village_child_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.village_child_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $child = M('member_family')
                ->where(array('is_householder'=>1,'area_id'=>$value['area_id']))
                ->count();
            $list[$key]['child_count'] = $child;
            if($value['area_id'] != '') {
                $allList = $this->getSummaryAll($value, 6,$where['create_time']);
                $lists = $this->copyInfo($allList,1);
                $list[$key] = array_merge( $list[$key],$lists );
            }
        }
        return $list;
    }

    //取出有政企注册信息的户主
    public function getFamilyList($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['is_householder'] = 1;
        $where['area_id'] = $area_id;
        $list = M('member_family')
            ->where($where)
            ->order('id asc')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $child = M('member_family')
                ->where(array('is_householder'=>0,'parent_id'=>$value['id']))
                ->count();
            $list[$key]['child_count'] = $child+1;
            $list[$key]['member_count_register'] = M('member_family')->where(array('area_id'=>$value['area_id'],'member_id'=>array('neq',0)))->count();
            $list[$key]['member_register_scale'] = ($list[$key]['member_count_register']/$list[$key]['child_count']*100);
            $list[$key]['member_register_scale'] = sprintf("%.2f",$list[$key]['member_register_scale']);
            $list[$key]['member_count_unregister'] = $list[$key]['child_count'] - $list[$key]['member_count_register'];
            $list[$key]['member_unregister_scale'] = ($list[$key]['member_count_unregister']/$list[$key]['child_count']*100);
            $list[$key]['member_unregister_scale'] = sprintf("%.2f",$list[$key]['member_unregister_scale']);
        }
        return $list;
    }

    //取出有政企注册信息的户主家庭信息
    public function getFamilychildList($id,$rows,$page,$where){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['id'] = $id;
        $list = M('member_family')
            ->where($where)
            ->order('id asc')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $child = M('member_family')
                ->where(array('is_householder'=>0,'parent_id'=>$value['id']))
                ->count();
            $list[$key]['child_count'] = $child+1;
            $list[$key]['member_count_register'] = M('member_family')->where(array('area_id'=>$value['area_id'],'member_id'=>array('neq',0)))->count();
            $list[$key]['member_register_scale'] = ($list[$key]['member_count_register']/$list[$key]['child_count']*100);
            $list[$key]['member_register_scale'] = sprintf("%.2f",$list[$key]['member_register_scale']);
            $list[$key]['member_count_unregister'] = $list[$key]['child_count'] - $list[$key]['member_count_register'];
            $list[$key]['member_unregister_scale'] = ($list[$key]['member_count_unregister']/$list[$key]['child_count']*100);
            $list[$key]['member_unregister_scale'] = sprintf("%.2f",$list[$key]['member_unregister_scale']);
        }
        return $list;
    }

    //取出汇总表公共字段数据
    public function getSummaryAll($value,$level,$time){
        $where['status'] = array('in','1,4');
        if($time != ''){
            $where['create_time'] = $time;
        }

        if($level == 1) {
            $where['province_id'] = $value['area_id'];
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }elseif($level == 2){
            $where['city_id'] = $value['area_id'];
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }elseif($level == 3){
            $where['area_id'] = $value['area_id'];
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }elseif($level == 4){
            $where['town_id'] = $value['area_id'];
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }elseif($level == 5){
            $where['village_id'] = $value['area_id'];
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }elseif($level == 6){
            $where['village_child_id'] = $value['area_id'];
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }else{
            $list['company_exist'] = M('company_auth')->where($where)->field('id,company_name,company_person')->select();
            $list['member_count_exist'] = M('company_auth')->where($where)->sum('company_person');
        }
            //在册单位数
            $list['company_count_exist'] = count($list['company_exist']);
            //在册人数
            if($list['member_count_exist'] == ''){
                $list['member_count_exist'] = 0;
            }
            //已注册单位数
            $list['company_count_register'] = $list['company_count_exist'];
            //已注册人数
            $company_id = array_column($list['company_exist'],'id');
            $list['member_count_register'] = M('member_auth')->alias('ma')
                ->join('INNER JOIN __MEMBER__ AS m ON ma.member_id = m.member_id')
                ->where(array('company_id'=>array('in',$company_id),'status'=>1))
                ->count();
            //已注册单位占比
            $list['company_register_scale'] = ($list['company_count_register']/$list['company_count_exist']*100);
            $list['company_register_scale'] = sprintf("%.2f",$list['company_register_scale']);
            //已注册人数占比
            if($list['member_count_exist'] == 0 || $list['member_count_exist'] == ''){
                $list['member_register_scale'] = '0.00';
            }elseif ($list['member_count_exist'] < $list['member_count_register']){
                $list['member_register_scale'] = '100.00';
            }else{
                $list['member_register_scale'] = ($list['member_count_register']/$list['member_count_exist']*100);
                $list['member_register_scale'] = sprintf("%.2f",$list['member_register_scale']);
            }
            //未注册单位数
            $list['company_count_unregister'] = 0;
            //未注册单位数占比
            $list['company_unregister_scale'] = '0.00';
            //未注册人数
            $list['member_count_unregister'] = $list['member_count_exist'] - $list['member_count_register'];
            if($list['member_count_unregister'] < 0){
                $list['member_count_unregister'] = 0;
            }
            //未注册人数占比
        if($list['member_count_exist'] == 0 || $list['member_count_exist'] == ''){
            $list['member_unregister_scale'] = '0.00';
        }else {
            $list['member_unregister_scale'] = ($list['member_count_unregister'] / $list['member_count_exist'] * 100);
            $list['member_unregister_scale'] = sprintf("%.2f", $list['member_unregister_scale']);
        }
            return $list;
    }

    //汇总表赋值公共字段
    public function copyInfo($allList,$type){
        if($type == 1){
            $list['company_count_exist'] = $allList['company_count_exist'];
            $list['company_count_register'] = $allList['company_count_register'];
            $list['company_register_scale'] = $allList['company_register_scale'];
            $list['company_count_unregister'] = $allList['company_count_unregister'];
            $list['company_unregister_scale'] = $allList['company_unregister_scale'];
        }
        $list['member_count_exist'] = $allList['member_count_exist'];
        $list['member_count_register'] = $allList['member_count_register'];
        $list['member_register_scale'] = $allList['member_register_scale'];
        $list['member_count_unregister'] = $allList['member_count_unregister'];
        $list['member_unregister_scale'] = $allList['member_unregister_scale'];
        return $list;
    }

    //取出省份和对应的政企
    public function getProvinceDetail($rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['province_id'] = array('neq',0);
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.province_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.province_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['province_id'] = $value['area_id'];
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            if($where['company_name'] != '') {
                $where_child['company_name'] = $where['company_name'];
            }
            $list[$key]['companyList'] = M('CompanyAuth')
                ->where($where_child)
                ->field('id,company_name,create_time')
                ->order('create_time asc')
                ->select();
            $this->addSnByListAndPage($list[$key]['companyList'],$rows,$page);
            foreach($list[$key]['companyList'] as $kkk => $vvv){
                $list[$key]['companyList'][$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
                $allList = $this->getDetailAll($vvv);
                $lists = $this->copyInfo($allList,2);
                $list[$key]['companyList'][$kkk] = array_merge( $list[$key]['companyList'][$kkk],$lists );
            }
        }

        return $list;
    }

    //取出市份和对应的政企
    public function getCityDetail($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['province_id'] = $area_id;
        $where['city_id'] = array('neq',0);
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.city_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.city_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['city_id'] = $value['area_id'];
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            if($where['company_name'] != '') {
                $where_child['company_name'] = $where['company_name'];
            }
            $list[$key]['companyList'] = M('CompanyAuth')
                ->where($where_child)
                ->field('id,company_name,create_time')
                ->order('create_time asc')
                ->select();
            $this->addSnByListAndPage($list[$key]['companyList'],$rows,$page);
            foreach($list[$key]['companyList'] as $kkk => $vvv){
                $list[$key]['companyList'][$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
                $allList = $this->getDetailAll($vvv);
                $lists = $this->copyInfo($allList,2);
                $list[$key]['companyList'][$kkk] = array_merge( $list[$key]['companyList'][$kkk],$lists );
            }
        }

        return $list;
    }

    //取出县份和对应的政企
    public function getCountyDetail($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['city_id'] = $area_id;
        $where['ca.area_id'] = array('neq',0);
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.area_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.area_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['area_id'] = $value['area_id'];
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            if($where['company_name'] != '') {
                $where_child['company_name'] = $where['company_name'];
            }
            $list[$key]['companyList'] = M('CompanyAuth')
                ->where($where_child)
                ->field('id,company_name,create_time')
                ->order('create_time asc')
                ->select();
            $this->addSnByListAndPage($list[$key]['companyList'],$rows,$page);
            foreach($list[$key]['companyList'] as $kkk => $vvv){
                $list[$key]['companyList'][$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
                $allList = $this->getDetailAll($vvv);
                $lists = $this->copyInfo($allList,2);
                $list[$key]['companyList'][$kkk] = array_merge( $list[$key]['companyList'][$kkk],$lists );
            }
        }

        return $list;
    }

    //取出镇份和对应的政企
    public function getTownDetail($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['ca.area_id'] = $area_id;
        $where['town_id'] = array('neq',0);
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.town_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.town_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['town_id'] = $value['area_id'];
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            if($where['company_name'] != '') {
                $where_child['company_name'] = $where['company_name'];
            }
            $list[$key]['companyList'] = M('CompanyAuth')
                ->where($where_child)
                ->field('id,company_name,create_time')
                ->order('create_time asc')
                ->select();
            $this->addSnByListAndPage($list[$key]['companyList'],$rows,$page);
            foreach($list[$key]['companyList'] as $kkk => $vvv){
                $list[$key]['companyList'][$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
                $allList = $this->getDetailAll($vvv);
                $lists = $this->copyInfo($allList,2);
                $list[$key]['companyList'][$kkk] = array_merge( $list[$key]['companyList'][$kkk],$lists );
            }
        }

        return $list;
    }

    //取出居委会和对应的政企
    public function getVillageDetail($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['ca.town_id'] = $area_id;
        $where['village_id'] = array('neq',0);
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.village_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.village_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['village_id'] = $value['area_id'];
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            if($where['company_name'] != '') {
                $where_child['company_name'] = $where['company_name'];
            }
            $list[$key]['companyList'] = M('CompanyAuth')
                ->where($where_child)
                ->field('id,company_name,create_time')
                ->order('create_time asc')
                ->select();
            $this->addSnByListAndPage($list[$key]['companyList'],$rows,$page);
            foreach($list[$key]['companyList'] as $kkk => $vvv){
                $list[$key]['companyList'][$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
                $allList = $this->getDetailAll($vvv);
                $lists = $this->copyInfo($allList,2);
                $list[$key]['companyList'][$kkk] = array_merge( $list[$key]['companyList'][$kkk],$lists );
            }
        }

        return $list;
    }

    //取出村和对应的政企
    public function getVillageChildDetail($area_id,$rows,$page,$where,$order = 'a.area_id DESC'){
        $limit = sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $where['status'] = 1;
        $where['ca.village_id'] = $area_id;
        $where['village_child_id'] = array('neq',0);
        $list = M('CompanyAuth')->alias('ca')
            ->join('LEFT JOIN __AREA__ a ON a.area_id = ca.village_child_id')
            ->where($where)
            ->field('a.area_name,a.area_id')
            ->order($order)
            ->group('ca.village_child_id')
            ->limit($limit)
            ->select();
        foreach($list as $key =>$value){
            $where_child['status'] = 1;
            $where_child['village_child_id'] = $value['area_id'];
            if($where['create_time'] != '') {
                $where_child['create_time'] = $where['create_time'];
            }
            if($where['company_name'] != '') {
                $where_child['company_name'] = $where['company_name'];
            }
            $list[$key]['companyList'] = M('CompanyAuth')
                ->where($where_child)
                ->field('id,company_name,create_time')
                ->order('create_time asc')
                ->select();
            $this->addSnByListAndPage($list[$key]['companyList'],$rows,$page);
            foreach($list[$key]['companyList'] as $kkk => $vvv){
                $list[$key]['companyList'][$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
                $allList = $this->getDetailAll($vvv);
                $lists = $this->copyInfo($allList,2);
                $list[$key]['companyList'][$kkk] = array_merge( $list[$key]['companyList'][$kkk],$lists );
            }
        }

        return $list;
    }

    //明细表共同字段取值
    public function getDetailAll($value){
        //在册人数
        $list['member_count_exist'] = M('company_auth')->where(['id'=>$value['id']])->getField('company_person');
        if($list['member_count_exist'] == ''){
            $list['member_count_exist'] = 0;
        }
        //已注册人数
        $list['member_count_register'] = M('member_auth')->alias('ma')
            ->join('INNER JOIN __MEMBER__ AS m ON ma.member_id = m.member_id')
            ->where(array('company_id'=>$value['id'],'status'=>1))
            ->count();
        //已注册人数占比
        if($list['member_count_exist'] == 0 || $list['member_count_exist'] == ''){
            $list['member_register_scale'] = '0.00%';
        }elseif ($list['member_count_exist'] < $list['member_count_register']){
            $list['member_register_scale'] = '100.00%';
        }else {
            $list['member_register_scale'] = ($list['member_count_register'] / $list['member_count_exist'] * 100);
            $list['member_register_scale'] = sprintf("%.2f", $list['member_register_scale']);
            $list['member_register_scale'] = $list['member_register_scale'].'%';
        }
        //未注册人数和占比
        if($list['member_count_exist'] == 0 || $list['member_count_exist'] == ''){
            $list['member_count_unregister'] = 0;
            $list['member_unregister_scale'] = '0.00%';
        }else{
            $list['member_count_unregister'] = $list['member_count_exist'] - $list['member_count_register'];
            $list['member_unregister_scale'] = ($list['member_count_unregister']/$list['member_count_exist']*100);
            $list['member_unregister_scale'] = sprintf("%.2f",$list['member_unregister_scale']);
            $list['member_unregister_scale'] = $list['member_unregister_scale'].'%';
        }

        return $list;
    }

    //时间筛选类型
    public function getWhereTime($time_type){
        if($time_type == 1){
            $where['create_time'] = array('between',array(time()-259200,time()));
        }elseif($time_type == 2){
            $where['create_time'] = array('between',array(time()-604800,time()));
        }elseif($time_type == 3){
            $where['create_time'] = array('between',array(time()-2592000,time()));
        }elseif($time_type == 4){
            $where['create_time'] = array('between',array(time()-15552000,time()));
        }else{

        }
        return $where;
    }

    public function getCompany($rows,$page,$where,$export){
        $limit =($export)?'' : sprintf('%d,%d', ($page ? ($page - 1) : 0) * $rows, $rows);
        $field = 'id,company_name,apply_username,create_time,apply_mobile,company_person,company_address';
        $list = M('company_auth')->where($where)->field($field)->limit($limit)->select();
        foreach($list as $kkk => $vvv){
            $list[$kkk]['create_time'] = date("Y-m-d H:i:s",$vvv['create_time']);
            $allList = $this->getDetailAll($vvv);
            $lists = $this->copyInfo($allList,2);
            $list[$kkk] = array_merge( $list[$kkk],$lists );
        }

        return $list;
    }

    /**
     * 添加序号
     * @param $list
     * @param $Page
     */
    public function addSnByListAndPage(&$list,$rows,$Page)
    {
        foreach ($list as $key => $value){
            $list[$key]['sn'] = ($Page-1) * $rows + ($key +1);
        }
    }

    //合计
    public function sum($list,$type){
        $count = count($list);
        $sum['company_count_exist'] = 0;
        $sum['member_count_exist'] = 0;
        $sum['company_count_register'] = 0;
        $sum['member_count_register'] = 0;
        $sum['company_register_scale'] = 0;
        $sum['member_register_scale'] = 0;
        if($type == 1) {
            $sum['child_count'] = 0;
            $sum['company_count_unregister'] = 0;
            $sum['company_unregister_scale'] = 0;
            $sum['member_count_unregister'] = 0;
            $sum['member_unregister_scale'] = 0;
        }
        foreach($list as $item){
            $sum['company_count_exist'] += (int)$item['company_count_exist'];
            $sum['member_count_exist'] += (int)$item['member_count_exist'];
            $sum['company_count_register'] += (int)$item['company_count_register'];
            $sum['member_count_register'] += (int)$item['member_count_register'];
            $sum['company_register_scale'] += (int)$item['company_register_scale'];
            $sum['member_register_scale'] += (int)$item['member_register_scale'];
            if($type == 1) {
                $sum['child_count'] += (int)$item['child_count'];
                $sum['company_count_unregister'] += (int)$item['company_count_unregister'];
                $sum['company_unregister_scale'] += (int)$item['company_unregister_scale'];
                $sum['member_count_unregister'] += (int)$item['member_count_unregister'];
                $sum['member_unregister_scale'] += (int)$item['member_unregister_scale'];
            }
        }
        if($sum['company_count_exist'] == 0){
            $sum['company_register_scale'] = '0.00%';
        }else {
            $sum['company_register_scale'] = sprintf("%.2f", $sum['company_count_register'] / $sum['company_count_exist'] * 100) . '%';
        }
        if($sum['member_count_exist'] == 0){
            $sum['member_register_scale'] = '0.00%';
        }else {
            $sum['member_register_scale'] = sprintf("%.2f", $sum['member_count_register'] / $sum['member_count_exist'] * 100) . '%';
        }
        if($type == 1) {
            if($sum['company_count_exist'] == 0){
                $sum['company_unregister_scale'] = '0.00%';
            }else{
                $sum['company_unregister_scale'] = sprintf("%.2f", $sum['company_count_unregister'] / $sum['company_count_exist']*100) . '%';
            }
            if($sum['member_count_exist'] == 0){
                $sum['member_unregister_scale'] = '0.00%';
            }else {
                $sum['member_unregister_scale'] = sprintf("%.2f", $sum['member_count_unregister'] / $sum['member_count_exist'] * 100) . '%';
            }
        }
        return $sum;
    }
    public function getSort($list,$order_type,$sort_type){
        switch ($order_type){
            case 1:
                $last_names = array_column($list,'member_register_scale');
                break;
            case 2:
                $last_names = array_column($list,'child_count');
                break;
            case 3:
                $last_names = array_column($list,'company_count_exist');
                break;
            case 4:
                $last_names = array_column($list,'member_count_exist');
                break;
            case 5:
                $last_names = array_column($list,'company_count_register');
                break;
            case 6:
                $last_names = array_column($list,'member_count_register');
                break;
            case 7:
                $last_names = array_column($list,'company_register_scale');
                break;
        }
        if($sort_type == 'asc'){
            array_multisort($last_names, SORT_ASC, $list);
        }else {
            array_multisort($last_names, SORT_DESC, $list);
        }

        return $list;
    }

    public function addScale($list){
        foreach ($list as $key => $value){
            if($value['company_register_scale'] !== ''){
                $list[$key]['company_register_scale'] = $value['company_register_scale'].'%';
            }
            if($value['member_register_scale'] !== ''){
                $list[$key]['member_register_scale'] = $value['member_register_scale'].'%';
            }
            if($value['company_unregister_scale'] !== ''){
                $list[$key]['company_unregister_scale'] = $value['company_unregister_scale'].'%';
            }
            if($value['member_unregister_scale'] !== ''){
                $list[$key]['member_unregister_scale'] = $value['member_unregister_scale'].'%';
            }
        }
        return $list;
    }

    //重新分页
    function page_array($count,$page,$array,$order){
        global $countpage; #定全局变量
        $page=(empty($page))?'1':$page; #判断当前页面是否为空 如果为空就表示为第一页面
        $start=($page-1)*$count; #计算每次分页的开始位置
        if($order==1){
            $array=array_reverse($array);
        }
        $totals=count($array);
        $countpage=ceil($totals/$count); #计算总页面数
        $pagedata=array();
        $pagedata=array_slice($array,$start,$count);
        return $pagedata;  #返回查询数据
    }
}
