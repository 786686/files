<?php
/**
 * 致富超市商品模型
 * @author deason 2016-07
 */
namespace Common\Model;
use OSS\OssClient;
use Think\Model;

class GoodsModel extends Model {

    public $sortList = array(
            'common_desc'   => 'go.goods_sort asc,go.goods_id DESC',      // 综合排序
            'pop_desc'   => 'go.goods_click DESC,sgs.goods_sort ASC',      // 人气排序
            'sales_desc' => 'go.goods_salenum DESC,sgs.goods_sort ASC',    // 销量排序
            'price_desc' => 'gp.goods_price DESC',     // 价格排序 - 降序
            'price_asc'  => 'gp.goods_price ASC' ,     // 价格排序 - 升序
			'spread_asc'  => 'go.goods_sort DESC,go.goods_id DESC' ,      // 价格排序 - 升序
			'sort_asc'  => 'sgs.goods_sort asc,go.goods_id DESC',    // 推荐排序 - 升序
			'recommend_asc'  => 'go.is_recommend desc,go.goods_sort asc',    // 推荐排序
    );
	const FIELD_GOODS_LIST = 'go.goods_id,goods_name,goods_jingle,goods_state,goods_unit,go.evaluation_count,goods_img,goods_serial,goods_salenum,go.store_name,go.goods_marketprice,go.store_id,go.goods_spec_id,go.goods_sales_parameter,go.goods_type,go.is_welfare';
	const FIELD_GROUP_GOODS_LIST = 'go.goods_id,go.goods_name,go.goods_jingle,go.goods_state,go.goods_unit,go.evaluation_count,go.goods_img,go.goods_serial,go.goods_salenum,go.store_name,go.goods_marketprice,go.store_id,go.goods_sales_parameter';
	const FIELD_GOODS_INFO ='go.goods_id,go.goods_name,go.goods_jingle,go.point_id,go.parameter,go.point_name,go.store_id,go.gc_id,go.gc_id_1,go.gc_id_2,go.store_name,go.store_id,go.goods_cost_price,go.goods_marketprice,go.goods_serial,go.goods_click,go.goods_salenum,go.goods_unit,go.goods_img,go.goods_imgs,go.goods_body,go.goods_state,go.transport_id,go.goods_spec_id,go.goods_freight,go.evaluation_count,go.goods_weight,go.goods_origin,go.express_address,go.is_express,go.is_poor,go.is_spread,go.select_shipment,go.goods_type,go.is_limit' ;
	// 商品检查需要的字段
	//const FIELD_CHECK_INFO = 'goods_id,goods_name,goods_storage,store_id,store_name,goods_state,goods_img,goods_price';
	const STATE_NORMAL = 1;		// 状态 -- 正常
	const IS_EXPRESS_YES = 1;	// (超出网店配送范围)快递配送 - 允许
	const IS_EXPRESS_NOT = 0;	// (超出网店配送范围)快递配送 - 否决
	// 商品错误代码
	const STATE_CODE_NORMAL      = '1';	// 正常
	const STATE_CODE_INVALID     = '-2404';	// 无效商品
	const STATE_CODE_NOT_PRICE   = '-2405';		// 价格错误
	const STATE_CODE_NOT_STOCK   = '-2406';		// 没有库存
	const STATE_CODE_ERROR_STATE = '-2407';		// 商品下架

    const FIELD_SHOP_INFO = 'a.goods_id,a.goods_spec_id,goods_state,goods_name,goods_jingle,store_id,gc_id,goods_state,goods_price,goods_marketprice,goods_storage,goods_img,goods_unit,goods_spec,goods_imgs,goods_body,mobile_body,transport_id,goods_freight,is_own_shop,goods_serial,goods_cost_price,evaluation_count,goods_salenum,goods_weight,goods_origin,is_platform,is_express';

    /**
	 * 获取数据列表
	 * 当传入store_id时，则按store_goods_sort表排序
     *
     * @param \Oss\OssClient $ossClient
	 */
	public function getList($where = array(), $limit = '0,10', $field = '*', $order = 'common_desc',$ossClient)
	{
		$member_id = $where['member_id'] ?? 0;
		$store_id = $where['store_id'] ?? 0;
		if(empty($where['is_status'])){//用于未开启的网店展示商品，纯粹为了运营那边
			$where['s.store_state']=1;
		}
		if(empty($where['is_welfare'])){//区别是否展示福利商品
			$where['is_welfare']=0;
		}
		unset($where['is_status']);
		unset($where['store_id']);
		unset($where['member_id']);
		$where['goods_state']=1;
		$where['gp.goods_price']=array('gt',0);
		$where['go.goods_type'] = 0; // Default: 普通商品，区分团购商品
		$where['go.store_id'] = array('neq', C('company_store_id')); // Default: 普通商品，区分团购商品
		$orderby = empty($this->sortList[$order]) ? array_shift($this->sortList) : $this->sortList[$order];
		$role=D('Member')->getMemberRole($member_id);
		//按排序获取商品列表
		$sortwhere=array();
		if(!empty($store_id)) $sortwhere['store_id']=$store_id;
		$subQuery = $this->field("goods_id,goods_sort")->table('__STORE_GOODS_SORT__')->where($sortwhere)->group('goods_id')->buildSql();
		$subQuery2 = $this->field("goods_id,price as goods_price,goods_spec_id")->table('__GOODS_PRICE__')->where(array('type'=>$role))->buildSql(); 
		 $starttime = explode(' ',microtime());
        if((isset($where['ga.gc_id']) && $where['ga.gc_id'])
            || (isset($where['ga.attribute_category_id']) && $where['ga.attribute_category_id'])
            || (isset($where['ga.attribute_id']) && $where['ga.attribute_id']) ) {
            $list=$this->alias('go')
                ->join("join $subQuery as sgs on go.goods_id =sgs.goods_id")
                ->join("join $subQuery2 as gp on go.goods_id =gp.goods_id and go.goods_spec_id =gp.goods_spec_id")
                ->join("__STORE__ as s on go.store_id =s.store_id",'left')
                ->join("LEFT JOIN __GOOD_ATTRIBUTE__ as ga on ga.goods_id =go.goods_id")
                ->where($where)->limit($limit)->field('go.goods_id,go.goods_spec_id')->group('ga.goods_id')->order($orderby)->select();
            $endtime = explode(' ',microtime());
        }else{
            $list=$this->alias('go')
                ->join("join $subQuery as sgs on go.goods_id =sgs.goods_id")
                ->join("join $subQuery2 as gp on go.goods_id =gp.goods_id and go.goods_spec_id =gp.goods_spec_id")
                ->join("__STORE__ as s on go.store_id =s.store_id",'left')
                ->where($where)->limit($limit)->field('go.goods_id,go.goods_spec_id')->order($orderby)->select();
            $endtime = explode(' ',microtime());
        }

		$goodsModel=D('Goods');
        $goodsSpecModel = new GoodsSpecModel();
		foreach ($list as $key => &$value) {
			$value=$this->getListDetail(['goods_id'=>$value['goods_id'],'goods_spec_id'=>$value['goods_spec_id'],'role'=>$role],$ossClient);
			//商品合法性校验
			$value['goods_type']=2;
			$value['buy_store_id']=$store_id;
			$checkState=$this->checkStateToBuyByInfo($value);
			if($checkState['code']!=$goodsModel::STATE_NORMAL&&$checkState['code']!= $goodsModel::STATE_CODE_NOT_STOCK) unset($list[$key]);
			if($value['store_id'] == C('company_store_id')){
			    //屏蔽企业采购超市商品
			    unset($list[$key]);
            }
            $value['specList']= $goodsSpecModel->getSpecList($value['goods_id']);
		}
		return array_values($list);
	}

	//首页搜索兼容团购商品用
	public function getListAll($where = array(), $limit = '0,10', $field = '*', $order = 'common_desc')
	{
		$member_id=$where['member_id'];
		$store_id= $where['store_id']? $where['store_id'] :0 ;

		unset($where['is_status']);
		unset($where['store_id']);
		unset($where['member_id']);
		$where['goods_state']=1;
		$where['gp.goods_price']=array('gt',0);
        $where['go.goods_type'] = ['in', [0,1]];
		$orderby = 'go.goods_id desc';
		$role=D('Member')->getMemberRole($member_id);
		$subQuery2 = $this->field("goods_id,price as goods_price,goods_spec_id")->table('__GOODS_PRICE__')->where(array('type'=>$role))->buildSql();
		//我的关注
		if(isset($where['m.is_follow']) && $where['m.is_follow'] == 1){
			$where['m.member_id'] = $member_id;
			$list=$this->alias('go')
//			->join("join $subQuery as sgs on go.goods_id =sgs.goods_id")
                       ->join("join $subQuery2 as gp on go.goods_id =gp.goods_id and go.goods_spec_id =gp.goods_spec_id")
			           ->join("__STORE__ as s on go.store_id =s.store_id",'left')
			           ->join("left join __MEMBER_STORE__ m on m.store_id = go.store_id")
			           ->where($where)->limit($limit)->field('go.goods_id,go.goods_spec_id')->order($orderby)->select();
		}else{
			$list=$this->alias('go')
//			->join("join $subQuery as sgs on go.goods_id =sgs.goods_id")
                       ->join("join $subQuery2 as gp on go.goods_id =gp.goods_id and go.goods_spec_id =gp.goods_spec_id")
			           ->join("__STORE__ as s on go.store_id =s.store_id",'left')
			           ->where($where)->limit($limit)->field('go.goods_id,go.goods_spec_id')->order($orderby)->select();
		}


		$goodsModel=D('Goods');
		foreach ($list as $key => &$value) {
			$value=$this->getListDetail(['goods_id'=>$value['goods_id'],'goods_spec_id'=>$value['goods_spec_id'],'role'=>$role]);
			//商品合法性校验
//			$value['goods_type']=2;
			$value['buy_store_id']=$store_id;
			//取最新的网店名称
			$list[$key]['store_name'] = M('store')->where(array('store_id'=>$value['store_id']))->getField('store_name');
			if($list[$key]['store_name'] == ''){
				$list[$key]['store_name'] = $value['store_name'];
			}
			$checkState=$this->checkStateToBuyByInfo($value);
			if($checkState['code']!=$goodsModel::STATE_NORMAL&&$checkState['code']!= $goodsModel::STATE_CODE_NOT_STOCK) unset($list[$key]);
			if($value['store_id'] == C('company_store_id')){
				//屏蔽企业采购超市商品
				unset($list[$key]);
			}
			//屏蔽不在网店商品排序表内的商品
			if($value['goods_type'] == 0 && $value['is_welfare'] == 0){
				$right = M('store_goods_sort')->where(array('goods_id'=>$value['goods_id'],'store_id'=>$value['store_id']))->getField('id');
				$left = M('store')->where(array('store_id'=>$value['store_id']))->getField('store_state');
				if(empty($right) || $left != 1) {
					unset($list[$key]);
				}
			}
			//屏蔽团购商品未审核或者不在首页专区展示
			if($value['goods_type'] == 1){
				$show = M('goods_group_purchase')->where(array('goods_id'=>$value['goods_id']))->field('zone_show,audit_state,start_time,end_time')->find();
				if($show['audit_state'] != 1 && $show['zone_show'] != 1){
					unset($list[$key]);
				}
				//状态
				if($show['start_time'] > time()){
					$value['status'] = '活动未开始';
				}
				if($show['end_time'] < time()){
					$value['status'] = '活动已结束';
				}
				if($show['end_time'] >= time() && $show['start_time'] <= time()){
					$value['status'] = '去拼团';
				}
				$value['type'] = 2;
			}elseif($value['goods_type'] == 0 && $value['is_welfare'] == 1){
				$welfare_id = M('special')->where(array('s_type'=>6,'s_state'=>1))->getField('s_id');
				$welfare = M('special_goods')->where(array('s_id'=>$welfare_id,'goods_id'=>$value['goods_id']))->getField('sg_id');
				if($welfare == ''){
					unset($list[$key]);
				}
				$value['type'] = 3;
			}else{
				$value['type'] = 1;
			}
		}
		return array_values($list);
	}
    /**
     * 获取搜索模块商品数据列表
     *
     */
    public function getSearchList($params)
    {
        $limit = sprintf('%d,%d', ($params['page'] ? ($params['page'] - 1) : 0) * $params['rows'], $params['rows']);
        if($params['town_id']){
            $deep=M('Area')->where('area_id='.$params['town_id'])->getField('area_deep');
            if($deep == '3'){
                $where['s.district_id'] = $params['town_id'];
            }
            else{
                $where['s.town_id'] = $params['town_id'];
            }
        }
        if($params['store_id']){
            $where['g.store_id'] = $params['store_id'];
        }
        if($params['keyword']){
            $where['g.goods_name'] = ['like', '%'.$params['keyword'].'%'];
        }
        $where['g.goods_state'] = 1;    //商品状态正常
        $where['g.goods_type'] = ['in', [0,1]];
        $field = 'g.goods_id,g.store_id,g.goods_img,g.goods_name,g.goods_jingle,g.store_name,g.goods_spec_id';
        $field .= ',g.goods_state,g.goods_imgs,g.goods_type';
        $list = M('Goods')
            ->alias('g')
            ->field($field)
            ->join('left join __GOODS_GROUP_PURCHASE__ ggp on ggp.goods_id=g.goods_id')
            ->join('left join __STORE__ s on g.store_id=s.store_id')
            ->where($where)
            ->order('id desc')
            ->limit($limit)
            ->select();
        foreach($list as $k => &$v){
            $goods_spec = M('GoodsSpec')->alias('a')
                ->field('a.sp_price,a.goods_stock,a.least_number,a.last_number,a.group_member_num,b.sp_value_name')
                ->join('left join __SPEC_VALUE__ as b on a.sp_value_id = b.sp_value_id')
                ->where(['a.goods_spec_id'=>$v['goods_spec_id'],'a.goods_id'=>$v['goods_id']])
                ->find();
            $v['least_number'] = $goods_spec['least_number'];
            $v['last_number'] = $goods_spec['last_number'];
            $v['goods_price'] = $goods_spec['sp_price'];
            $v['goods_stock'] = $goods_spec['goods_stock'];
            $v['group_member_num'] = $goods_spec['group_member_num'];
            if($v['goods_type'] == 0){
                $v['url'] = $this->getDetailUrl($v['goods_id']);
                $v['goods_img'] = $this->getFullImg($v['goods_img']);
            }else{
                $v['url'] = $this->getGroupDetailUrl($v['goods_id']);
                $images_arr = unserialize($v['goods_imgs']);
                $v['goods_img'] = $images_arr[0] ? $this->getFullImg($images_arr[0]) : $this->getFullImg($v['goods_img']);
            }
            unset($v['goods_imgs']);
            $checkState = $this->checkStateToBuyByInfo($v);
            if($checkState['code'] != self::STATE_NORMAL) unset($list[$k]);
        }
        return $list;
    }

	/**
	 * 获取商品详情
	 */
	public function getDetail($parm = array(), $ossClient)
	{
		$member_id=$parm['member_id'];
		$goods_id=$parm['goods_id'];
		$buy_store_id=$parm['buy_store_id'];

		$cachekey  = 'goodsInfo_'.$goods_id;
		$goodsInfo = S($cachekey);
		if(empty($goodsInfo)){
			$where['go.goods_id']=$goods_id;
			$goodsInfo=$this->alias('go')->field(self::FIELD_GOODS_INFO)->where($where)->find();
			$store_data = D('Store')->getInfo(array('store_id'=>$goodsInfo['store_id']),$field = '*',$ossClient);
			$goodsInfo['store_phone'] = $store_data['store_phone'] ? $store_data['store_phone']: '4009300277';
			$goodsInfo['goods_img']=!empty($goodsInfo['goods_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $goodsInfo['goods_img'], 3600) : '';
			$goodsInfo['goods_imgs']=unserialize($goodsInfo['goods_imgs']);
			foreach($goodsInfo['goods_imgs'] as $key=>$goodsimg){
				$goodsInfo['goods_imgs'][$key]=!empty($goodsimg) ? $ossClient->signUrl(C('aliyun.bucket'), $goodsimg, 3600) : '';
			}
			$goodsInfo['goods_body'] = htmlspecialchars_decode($goodsInfo['goods_body']);
			$goodsInfo['goods_body']=str_replace("\"","'",$goodsInfo['goods_body']);
			preg_match_all('/<img[^>]*src\s*=\s*([\'"]?)([^\'" >]*)\1/isu',$goodsInfo['goods_body'],$app_img);
			foreach ($app_img[2] as $key => $value) {
				$app_img[2][$key]=C('WEBSITE_URL').$value;
			}
			$goodsInfo['app_goods_body']=$app_img[2];
			$goodsInfo['app_goods_content'] = strip_tags($goodsInfo['goods_body']);
			$goodsInfo['app_goods_content'] = str_replace("&nbsp;","",$goodsInfo['app_goods_content']);
//			$goodsInfo['app_goods_content'] = str_replace(chr(10),'\n\r',$goodsInfo['app_goods_content']);
			if(preg_match("[\u4e00-\u9fa5]",$goodsInfo['app_goods_content'])){
				$goodsInfo['app_goods_content'] = "";
			}
			//获取溯源信息
			$goodsInfo['sourceInfo']=M('goods_source')->field(['so_name','so_value','is_important'])->where(['goods_id'=>$goods_id])->order('so_sort')->select();
			//获取默认评论 仅显示好评
			$commentInfo = (new GoodsCommentModel())->getGoodsBetterComment($goods_id);

			$name = M('member')->where(array('member_id'=>$commentInfo['comment_member_id']))->getField('member_nickname');
			if($name != '') {
				$first = mb_substr($name,0,1,"utf-8");
				$last = mb_substr($name,-1,1,"utf-8");
				$name = $first . '***' . $last;
			}
			$m_avatar = M('member')->where(array('member_id'=>$commentInfo['comment_member_id']))->getField('member_avatar');
			$avatar=$m_avatar?C('WEBSITE_URL').'/'.$m_avatar:'';
			//评论等级数量
			$goods_num=M('goods_comment')->where(array('comment_star'=>array('in',array(5,4)),'comment_object_id'=>$goods_id, 'comment_parent_id' => 0))->count()+0;
			$zhong_num=M('goods_comment')->where(array('comment_star'=>array('eq',3),'comment_object_id'=>$goods_id, 'comment_parent_id' => 0))->count()+0;
			$bad_num=0;//作假
			$img_num=M('goods_comment')->where(array('comment_imgs'=>array('not in',array('a:1:{i:0;b:0;}','')), 'comment_parent_id' => 0,'comment_object_id'=>$goods_id,'comment_star'=>array('in',array(3,4,5))))->count()+0;
			$goodsInfo['comment_num'] = array(
				'0'=>array('title'=>'好评','num'=>$goods_num),
				'1'=>array('title'=>'中评','num'=>$zhong_num),
				'2'=>array('title'=>'差评','num'=>$bad_num),
				'3'=>array('title'=>'有图','num'=>$img_num),
			);
			$goodsInfo['evaluation_count'] = $goods_num + $zhong_num + $bad_num;
			if($commentInfo['is_anonymous'] == 1){
				$commentInfo['member_nickname'] = '匿名';
				$commentInfo['member_avatar'] = '';
			}else{
				if($commentInfo['comment_member_id'] == 0){
					$commentInfo['member_nickname'] = '匿名';
					$commentInfo['member_avatar'] = '';
				}elseif($name == ''){
					$commentInfo['member_nickname'] = '匿名';
					$commentInfo['member_avatar'] = $avatar;
				}else{
					$commentInfo['member_nickname'] = $name;
					$commentInfo['member_avatar'] = $avatar;
				}
			}
			$goodsInfo['commentInfo'] =  empty($commentInfo) ? (object)array() :$commentInfo;
			//相关商品
			$goodsInfo['relevantList']=$this->getRelevantList(['gc_id'=>$goodsInfo['gc_id'],'goods_id'=>$goods_id],$ossClient);
			//获取默认规格批量购买信息
			$goodsInfo['parameter'] = json_decode($goodsInfo['parameter'],1);
			//$goodsInfo['batchInfo']=  M('goods_batch')->field('goods_id,batch_price,number,goods_spec_id')->where(['goods_id'=>$goodsInfo['goods_id']])->select();
			$batchInfo=M('goods_batch')->field('goods_id,batch_price,number,goods_spec_id')->where(['goods_id'=>$goodsInfo['goods_id']])->select();
			foreach($batchInfo as $k=>$v){
				$batchInfo[$k]['goods_stock']=M('GoodsSpec')->where(array('goods_id'=>$v['goods_id'],'goods_spec_id'=>$v['goods_spec_id']))->getField('goods_stock');
			}
			$goodsInfo['batchInfo']=$batchInfo;
			$goodsInfo['share_title']=$goodsInfo['goods_name'].'--七子商城';
			$goodsInfo['share_img']=$goodsInfo['goods_img'];
			$goodsInfo['share_desc']='七子商城发现了好商品哦';
			$goodsInfo['share_link']=$this->getDetailShareUrl($goods_id,$buy_store_id);
			$goodsInfo['store_name']=M('store')->where(array('store_id'=>$goodsInfo['store_id']))->getField('store_name');
			S($cachekey,$goodsInfo,1);
		}
		//获取商品规格相关信息
		$goodsSpec=D('GoodsSpec')->getSpecInfo($goods_id,$goodsInfo['goods_spec_id']);
		$goodsInfo=array_merge($goodsInfo,$goodsSpec);
		$goodsInfo['specList']= D('GoodsSpec')->getSpecList($goodsInfo['goods_id']);
		$priceRes=D('GoodsPrice')->getAllPrice(['goods_id'=>$goods_id,'goods_spec_id'=>$goodsInfo['goods_spec_id']]);
		if($priceRes['code']!=1){
			return ;//异常处理
		}
		$role=D('Member')->getMemberRole($member_id);
		$goodsInfo['goods_price']= $role==1 ?  $priceRes['data']['company_price'] :$priceRes['data']['common_price'];
		$goodsInfo['batch_price']= $priceRes['data']['company_price'] ;
		$goodsInfo['batch_number']= 0;
		foreach ($goodsInfo['batchInfo'] as $key => $value) {
			if($value['goods_spec_id']==$goodsInfo['goods_spec_id']) $goodsInfo['batch_number']= $value['number'] ;
		}
		$goodsInfo['goods_module']= I('goods_module',2,'intval');//商品模块
        //弹窗类型内容
        if($goodsInfo['is_limit'] == 1){
            $special_title = M('store')->where(array('store_id'=>$goodsInfo['store_id']))->getField('store_special_title');
            $special_content = M('store')->where(array('store_id'=>$goodsInfo['store_id']))->getField('store_special_content');
            if($special_title != '' && $special_content != ''){
                $goodsInfo['limit_type'] = 1;
                $goodsInfo['special_title'] = $special_title;
                $goodsInfo['special_content'] = $special_content;
            }else{
                $goodsInfo['limit_type'] = 0;
            }
        }else{
            $goodsInfo['limit_type'] = 0;
        }
		return $goodsInfo;
	}

	/**
	 * [getGroupPurchaseDetail 获取团购商品详情]
	 * @param  array  $parm [description]
	 * @return [type]       [description]
	 */
	public function getGroupPurchaseDetail($parm = array()){
		$goods_id=$parm['goods_id'];

		$where['go.goods_id']=$goods_id;
		$goodsInfo = $this->alias('go')
            ->field(self::FIELD_GOODS_INFO.',ggp.start_time,ggp.end_time,ggp.restrictive,ggp.colonel_discount_price')
            ->join('left join __GOODS_GROUP_PURCHASE__ ggp on go.goods_id=ggp.goods_id')
            ->where($where)
            ->find();
		$store_data = D('Store')->getInfo(array('store_id'=>$goodsInfo['store_id']));
		$goodsInfo['store_phone'] = $store_data['store_phone'] ? $store_data['store_phone']: '4009300277';
        $goods_spec_id=(!empty($parm['goods_spec_id']))?$parm['goods_spec_id']:$goodsInfo['goods_spec_id'];
		$goodsSpec=D('GoodsSpec')->getSpecInfo($goods_id,$goods_spec_id);
		$goodsInfo=array_merge($goodsInfo,$goodsSpec);
		$goodsInfo['goods_img']=$this->getFullImg($goodsInfo['goods_img']);
		$goodsInfo['goods_imgs']=unserialize($goodsInfo['goods_imgs']);
		foreach($goodsInfo['goods_imgs'] as $key=>$goodsimg){
			$goodsInfo['goods_imgs'][$key]=$this->getFullImg($goodsimg);
		}
		$goodsInfo['goods_body'] = htmlspecialchars_decode($goodsInfo['goods_body']);
		$goodsInfo['goods_body']=str_replace("\"","'",$goodsInfo['goods_body']);
		preg_match_all('/<img[^>]*src\s*=\s*([\'"]?)([^\'" >]*)\1/isu',$goodsInfo['goods_body'],$app_img);
		foreach ($app_img[2] as $key => $value) {
			$app_img[2][$key]=C('WEBSITE_URL').$value;
		};
		$goodsInfo['app_goods_body']=$app_img[2];
		//获取溯源信息
		$goodsInfo['sourceInfo']=M('goods_source')->field(['so_name','so_value','is_important'])->where(['goods_id'=>$goods_id])->order('so_sort')->select();
		//获取商品规格相关信息
		$goodsInfo['specList']=D('GoodsSpec')->getSpecList($goodsInfo['goods_id']);
		//获取默认规格批量购买信息
		$goodsInfo['parameter'] = json_decode($goodsInfo['parameter'],1);
		$batchInfo=M('goods_batch')->field('goods_id,batch_price,number,goods_spec_id')->where(['goods_id'=>$goodsInfo['goods_id']])->select();
		foreach($batchInfo as $k=>$v){
			$batchInfo[$k]['goods_stock']=M('GoodsSpec')->where(array('goods_id'=>$v['goods_id'],'goods_spec_id'=>$v['goods_spec_id']))->getField('goods_stock');
		}
		$goodsInfo['batchInfo'] = $batchInfo;
		$goodsInfo['share_title'] = $goodsInfo['goods_name'].'--七子商城';
		$goodsInfo['share_img'] = $goodsInfo['goods_img'];
		$goodsInfo['share_desc'] = '七子商城发现了好商品哦';
		$goodsInfo['share_link'] = $this->getGroupDetailUrl($goods_id);
		$priceRes = D('GoodsPrice')->getAllPrice(['goods_id'=>$goods_id,'goods_spec_id'=>$goodsInfo['goods_spec_id']]);
		if($priceRes['code']!=1){
			return ;//异常处理
		}

        $goodsInfo['start_time'] = date('Y-m-d H:i:s', $goodsInfo['start_time']);    //活动截止时间
        $goodsInfo['end_time'] = date('Y-m-d H:i:s', $goodsInfo['end_time']);    //活动截止时间
		$goodsInfo['goods_price'] = $priceRes['data']['common_price'];
		$goodsInfo['batch_price'] = $priceRes['data']['company_price'] ;
		$goodsInfo['batch_number'] = 0;
		foreach ($goodsInfo['batchInfo'] as $key => $value) {
			if($value['goods_spec_id']==$goodsInfo['goods_spec_id']) $goodsInfo['batch_number']= $value['number'] ;
		}
		$goodsInfo['goods_module']= I('goods_module',2,'intval');//商品模块
		return $goodsInfo;
	}


	/**
	 * 获取商品列表详情
     *
     * @param \Oss\OssClient $ossClient
	 */
	public function getListDetail($parm,$ossClient=null)
	{
		if(empty($ossClient)){
			include_once(OssClient);
			$ossClient = new OssClient(C('aliyun.accessKeyId'), C('aliyun.accessKeySecret'), C('aliyun.oss_endpoint'));
		}

		$role = $parm['role'] ?? 0;
		$goods_id = $parm['goods_id'];
		$goods_spec_id = $parm['goods_spec_id'];
		$type = $parm['type'] ?? 1;
		$cachekey='goodsListInfo_'.$goods_id.'_'.$goods_spec_id;
		$goodsInfo=S($cachekey);
		if(empty($goodsInfo)){
			$where['go.goods_id']=$goods_id;
			$goodsInfo=M('goods')->alias('go')->field(self::FIELD_GOODS_LIST)->where($where)->find();
            $goodsInfo['goods_img_val'] = $goodsInfo['goods_img'];
			$goodsInfo['goods_img']=!empty($goodsInfo['goods_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $goodsInfo['goods_img'], 3600) : '';
			$batch_num=M('goods_batch')->where(['goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id])->getField('number');
			$goodsInfo['batch_num']= $goodsInfo['batch_number']=  $batch_num ? $batch_num : 0;
			$goodsInfo['moon_salenum']=$goodsInfo['goods_salenum'];
			//$goodsInfo['goods_sales']=$goodsInfo['goods_sales_parameter'];
			$goodsInfo['url']=$this->getDetailUrl($goods_id);
			S($cachekey,$goodsInfo,300);
		}
		$goodsSpec=D('GoodsSpec')->getSpecInfo($goods_id,$goods_spec_id);
		$goodsInfo=array_merge($goodsInfo,$goodsSpec);
		$priceRes=D('GoodsPrice')->getAllPrice(['goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id,'type'=>$type]);
		if($priceRes['code']!=1){
			return ;//异常处理
		}
		$goodsInfo['goods_price']= $role==1 ?  $priceRes['data']['company_price'] :$priceRes['data']['common_price'];
		$goodsInfo['batch_price']= $priceRes['data']['company_price'] ;
		return $goodsInfo;
	}

	/**
     * [getGoodsOnOrder 团购订单中取商品详情判断商品状态]
     * @param  [type] $goods_id [description]
     * @return [type]           [description]
     */
    public function getGoodsOnOrder($goods_id, $goods_spec_id=0){
        $field = 'go.goods_id,go.goods_name,go.goods_jingle,go.goods_state,go.goods_unit,go.evaluation_count';
        $field .= ',go.goods_img,go.goods_serial,go.goods_salenum,go.store_name,go.goods_marketprice';
        $field .= ',go.store_id,go.goods_sales_parameter,go.goods_type';
        $field .= ',gs.sp_price as goods_price,gs.goods_stock,gs.goods_spec_id';
    	$where['go.goods_id'] = $goods_id;
        if($goods_spec_id){
            $where['gs.goods_spec_id'] = $goods_spec_id;
        }
    	$goodsInfo=M('Goods')
    				->alias('go')
    				->field($field)
    				->join('left join __GOODS_SPEC__ gs on go.goods_id=gs.goods_id')
    				->where($where)
    				->find();
    	return $goodsInfo;
    }


	/**
	 * 获取相关推荐商品列表
	 */
	public function getRelevantList($parm=array(),$ossClient){
		if(empty($parm['gc_id'])) return array();
		$where['go.gc_id']=$parm['gc_id'];
		$where['go.goods_id']=array('NEQ',$parm['goods_id']);
		return $this->getList($where,'0,5',self::FIELD_GOODS_LIST,'common_desc',$ossClient);
	}

	//取出企业采购商品的相关推荐
    public function getCompanyList($param = []){
	    $field = 'go.goods_id,go.goods_name,go.goods_jingle,go.goods_state,go.goods_unit,go.evaluation_count';
	    $field .= ',go.goods_img,go.goods_serial,go.goods_salenum,go.store_name,go.goods_marketprice,go.store_id';
	    $field .= ',go.goods_spec_id,go.goods_sales_parameter,go.goods_type';
	    $list = $this->alias('go')->field($field)->where($param)->limit(0,5)->select();
	    $result = [];
	    foreach($list as $key => &$val){
	        $batch = M('GoodsBatch')->where([
	            'goods_id' => $val['goods_id'],
                'goods_spec_id' => $val['goods_spec_id']
            ])->getField('id');
	        if(empty($batch)){
	            unset($list[$key]);
	            continue;
            }
			$list[$key]['goods_img'] = $this->getFullImg($val['goods_img']);
            $priceRes = D('GoodsPrice')->getAllPrice(['goods_id'=>$val['goods_id'],'goods_spec_id'=>$val['goods_spec_id']]);
            if($priceRes['code'] != 1){
                unset($list[$key]);
                continue;
            }else{
                $company_price = $priceRes['data']['company_price'];
                $list[$key]['batch_price'] = $company_price;
                $list[$key]['goods_price'] = $company_price;
                $list[$key]['url'] = C('WEBSITE_URL').'/Mobile/Procure/procure_detail/goods_id/'.$val['goods_id'];
            }
            $checkState=$this->checkStateToBuyByInfo($val);
            if($checkState['code']!=self::STATE_NORMAL&&$checkState['code']!= self::STATE_CODE_NOT_STOCK){
                unset($list[$key]);
                continue;
            }
            $result[] = $list[$key];
        }
	    return $result;
    }

    /**
     * 获取相关推荐福利商品列表
     */
    public function getWelfareList($params=[]){
        if($params['gc_id']){
            $where['go.gc_id'] = $params['gc_id'];
        }
        if($params['goods_id']){
            $where['go.goods_id']=['neq', $params['goods_id']];
        }
        $where['is_welfare'] = 1;
        $list = $this->getList($where,'0,5',self::FIELD_GOODS_LIST);
        return $list ? $list : [];
    }


	/**
	 * 获取购物车推荐商品列表
	 */
	public function getRecommendList($parm=array(), $ossClient){
	    $where['gb.member_id'] = $parm['member_id'];
	    $where['sg.goods_type'] = 0;
	    $where['is_welfare'] = 0;
	    $where['sg.store_id'] = ['neq', C('company_store_id')]; //屏蔽企业采购超市商品
		$list=M('goods_browse')
            ->field('sg.goods_id,sg.goods_spec_id,sg.goods_type,gb.buy_store_id')
            ->alias('gb')->join('left join sx_goods as sg on gb.goods_id =sg.goods_id')
            ->where($where)
            ->group('sg.goods_id')
            ->order('browsetime desc')
            ->limit(6)
            ->select();
		if(!empty($list)){
			foreach ($list as $key => &$value) {
				$buy_store_id=$value['buy_store_id'];
				$value=$this->getListDetail(['goods_id'=>$value['goods_id'],'goods_spec_id'=>$value['goods_spec_id']],$ossClient);
				//商品合法性校验
//				$value['goods_type']=2;
				$value['buy_store_id']=$buy_store_id;
				$checkState=$this->checkStateToBuyByInfo($value);
				if($checkState['code']!=self::STATE_NORMAL&&$checkState['code']!= self::STATE_CODE_NOT_STOCK) unset($list[$key]);
			}
		}else{
			$where['go.is_spread']=1;
			$where['go.goods_state']=1;
			unset($where['gb.member_id']);
			unset($where['sg.goods_type']);
			unset($where['sg.store_id']);
			$list=$this->getList($where,'0,5',self::FIELD_GOODS_LIST,'',$ossClient);
		}
		
		return array_merge($list);
	}


	//获取默认规格信息
	public function getSpecInfo($list){
		$goodsSpecModel=D('GoodsSpec');
		foreach($list as $key=> $goods){
			$specInfo=$goodsSpecModel->getSpecInfo($goods['goods_id'],$goods['goods_spec_id']);
			$list[$key]['goods_stock']= empty($specInfo['goods_stock']) ? 0 : $specInfo['goods_stock']; 
			$list[$key]['sp_value_id']= empty($specInfo['sp_value_id']) ? 0 : $specInfo['sp_value_id']; 
			$list[$key]['sp_value_name']= empty($specInfo['sp_value_name']) ? 0 : $specInfo['sp_value_name']; 
		}
		return $list;
	}

    public function getFullImg($img){
        return C('WEBSITE_URL').'/'.$img;
    }  


    public function getDetailUrl($goods_id){
        return C('WEBSITE_URL').'/index.php/Mobile/Store/storeGoodDetail/s/1/goods_id/'.$goods_id;
    }

    public function getDetailShareUrl($goods_id,$buy_store_id){
        return C('WEBSITE_URL').'/index.php/Mobile/Store/storeGoodDetail/s/1/goods_id/'.$goods_id.'/buy_store_id/'.$buy_store_id;
    }

    //团购商品详情
    public function getGroupDetailUrl($goods_id){
        return C('WEBSITE_URL').'/Mobile/Store/group_goodsDetail/goods_id/'.$goods_id;
    }

    //返回价格
    public function getPrice($goods_id,$goods_spec_id,$type='0'){
		$priceRes=D('GoodsPrice')->getPrice(['goods_id'=>$goods_id,'goods_spec_id'=>$goods_spec_id,'type'=>$type]);
		return $priceRes['code']==1? $priceRes['data']:NULL;
    }



	 /**
	  * 商品是否允许购买 -- 通过商品信息
	  * @author deason 2016-10-18
	  * @param  array  $goodsInfo   商品信息数组
	  * @param  integer $compareNum 购买数量
	  * @return [type]              [description]
	  */
	 public function checkStateToBuyByInfo($goodsInfo, $compareNum = 1)
	 {
	 	// 该商品不存在
	 	if (!$goodsInfo || !is_array($goodsInfo)) {
	 		return array(
	 			'code'  => self::STATE_CODE_INVALID,
	 			'msg'   => '商品不存在',
	 			'data'  => array()
	 		);
	 	}
	 	// 状态不正常
	 	if ($goodsInfo['goods_state'] != self::STATE_NORMAL) {
	 		return array(
	 			'code'  => self::STATE_CODE_ERROR_STATE,
	 			'msg'   => '已下架',
	 			'data'  => $goodsInfo
	 		);
	 	}
	 	// 库存不足
	 	if ($goodsInfo['goods_stock'] < $compareNum) {
            return array(
	 			'code'  => self::STATE_CODE_NOT_STOCK,
	 			'msg'   => '该商品暂无库存',
	 			'data'  => $goodsInfo
	 		);
	 	}

	 	//不正确价格
	 	if ($goodsInfo['goods_price'] <= 0) {
	 		return array(
	 			'code'  => self::STATE_CODE_NOT_PRICE,
	 			'msg'   => '价格错误',
	 			'data'  => $goodsInfo
	 		);
	 	}
	 	return array(
	 		'code'  => self::STATE_CODE_NORMAL,
	 		'msg'   => '状态正常',
	 		'data'  => $goodsInfo
	 	);
	 }

	/**
	 * 减少商品库存
	 */
	 public function decStock($goodsId, $num = 1 ,$goods_spec)
	 {
	 	if(!empty($goods_spec)){
	 		$where['goods_spec_id'] = $goods_spec;
	 	}
	 	$where['goods_id'] = $goodsId;
	 	$where['goods_stock'] = array('EGT', abs($num));
        return M('goods_spec')->where($where)->setDec('goods_stock', abs($num));
	 }

	/**
	 * 商品点击量+1
	 * @param  integer $id 商品ID
	 */
	public function incClick($goods_id)
	{
		return $this->where(array('goods_id' => $goods_id))->setInc('goods_click');
	}
    /**
     * 写入浏览日志
     */
    public function addGoodsBrowse($memberId,$goods_id,$buy_store_id=0){
        $check=M('goods_browse')->where(array('goods_id'=>$goods_id,'member_id'=>$memberId))->field('goods_id')->find();
        if(empty($check)){
            M('goods_browse')->add(array('goods_id'=>$goods_id,'member_id'=>$memberId,'browsetime'=>time(),'buy_store_id'=>$buy_store_id));
        }else{
            M('goods_browse')->where(array('member_id'=>$memberId,'goods_id'=>$goods_id))->data(array('browsetime'=>time(),'buy_store_id'=>$buy_store_id))->save();
        }
    }
    /**
     * [getGoodsSpecDefaultStock 根据商品商品默认规格关联id从商品规格表
     * 取出商品默认规格库存数量-后台页面中使用到]
     * @param  [type] $arr [规格数组]
     * @return [type]      [description]
     */
    public function getGoodsSpecDefaultStock($goods_spec_id){
    	return M('GoodsSpec')->where(array('goods_spec_id'=>$goods_spec_id))->getField('goods_stock');
    }

    /**
     * [getAllStockIsNot 根据商品规格列表判断所有规格是否库存不足]
     * @return [bool] [返回true就表示库存不足，false就表示库存大于0]
     */
    public function getAllStockIsNot($listSpec){
    	$result = true;
    	foreach($listSpec as $k=>$v){
    		if($v['goods_stock'] > 0)
    		{
    			$result = false;	//商品存在一个规格库存大于0就可以返回为false，商品详情就可以购买
    			break;
    		}
    	}
    	return $result;
    }
    /**
     * [checkGroupPurchase 检查商品团购信息]
     * @return [type] [description]
     */
    public function checkGroupPurchase($parm=array()){
    	$where['goods_id'] = $parm['goods_id'];
		//判断商品团购活动是否已经结束
		$info = M('GoodsGroupPurchase')->field('restrictive,colonel_discount_price,start_time,end_time')->where($where)->find();
		if(empty($info)){
            return array(
                'code'  => self::STATE_CODE_INVALID,
                'msg'   => '团购商品不存在',
                'data'  => []
            );
        }
        if($info['start_time'] > time()){
            return array(
                'code'  => -3000,
                'msg'   => '活动还未开始',
                'data'  => []
            );
        }
        if($info['end_time'] < time()){
            return array(
                'code'  => -3001,
                'msg'   => '活动已经结束',
                'data'  => []
            );
        }
        return array(
            'code'  => self::STATE_CODE_NORMAL,
            'msg'   => '状态正常',
            'data'  => $info
        );
    }
    /**拼团支付判断
     * [checkGroupStateById 支付订单时通过拼团主键id判断该团是否可以进行支付]
     * @param  [type] $id [description]
     * @return [type]     [description]
     */
    public function checkGroupStateById($id){
    	$where['id'] = $id;
    	$where['spell_state'] = array('not in','3,4');	//开团状态：1未付款，2已付款，3拼团成功，4拼团失败
    	$spell_state = M('GroupPurchase')->where($where)->find();
    	if(empty($spell_state)){
    		return false;
    	}
    	//再判断商品是否已经过期
    	$info = M('GoodsGroupPurchase')->where(['goods_id'=>$spell_state['goods_id']])->find();
    	if(empty($info) || $info['end_time'] < time()){
    	    return false;
        }
    	return true;
    }
    /**
     * [getGroupPurchaseGoods 根据商品ID取出当前商品已经发起的团购信息
     * spell_state=2表示当前团已经付款]
     * @return [type] [description]
     */
    public function getGroupPurchaseGoods($goods_id){
        $default_avatar = C('WEBSITE_URL').'/Public/Mobile/images/default_avatar_color.png';
        $map['gp.goods_id'] = $goods_id;
        $map['gp.spell_state'] = 2;
        $map['ggp.end_time'] = ['gt', time()];
    	$list = M('GroupPurchase')
		    	->alias('gp')
		    	->field('gp.id,gp.goods_id,gp.create_time,gp.member_num,gp.group_member_num,m.member_id,m.member_avatar,insert(m.member_mobile,4,4,\'****\') as member_mobile')
		    	->join('left join __MEMBER__ m on gp.member_id=m.member_id')
                ->join('left join __GOODS_GROUP_PURCHASE__ ggp on ggp.goods_id=gp.goods_id')
		    	->where($map)
		    	->select();
		foreach($list as $k => $v){
			$list[$k]['create_time'] = date('Y-m-d H:i:s', $v['create_time']);
			$list[$k]['member_avatar'] = $v['member_avatar'] ? $this->getFullImg($v['member_avatar']) : $default_avatar;
            $company_name = D('Member')->getCompanyInfo($v['member_id'])['company_name'];
			$list[$k]['company_name'] = $company_name ? $company_name : '会员';
			$url = $this->getGroupDetailUrl($v['goods_id']);
            $list[$k]['group_detail_url'] = $url.'/group_purchase_id/'.$v['id'];
		}
		return $list;
    }

    /**
     * [getGroupInfoById 根据拼团记录主键ID取出团购商品信息(分享出去的页面也是请求该方法)
     * spell_state=2表示当前团已经付款]
     * @return [type] [description]
     */
    public function getGroupInfoById($id){
        $field = 'gp.id,gp.goods_id,gp.spell_state,gp.member_num,gp.group_member_num,gp.goods_spec_id';
        $field .= ',ggp.end_time,g.store_id,g.goods_name,g.goods_img,gs.sp_value_name';
    	$list = M('GroupPurchase')
		    	->alias('gp')
		    	->field($field)
		    	->join('left join __GOODS_GROUP_PURCHASE__ ggp on ggp.goods_id=gp.goods_id')
		    	->join('left join __GOODS__ g on g.goods_id=gp.goods_id')
                ->join('left join __GOODS_SPEC__ gs on gs.goods_id=gp.goods_id AND gs.goods_spec_id=gp.goods_spec_id')
		    	->where(array('gp.id'=>$id))
		    	->find();
    	if(empty($list)){
    	    return [];
        }
		$list['goods_img'] = $this->getFullImg($list['goods_img']);
        $list['end_time'] = date('Y-m-d H:i:s',$list['end_time']);
		return $list;
    }

    /**
     * [getStoreGroupPurchase 取出当前商店的其它团购商品]
     * @param  [type] $goods_id [description]
     * @return [type]           [description]
     */
    public function getStoreGroupPurchase($parm=array()){
        $limit = 10;
        $where['g.goods_state'] = 1;    //商品状态正常
        $where['g.goods_type'] = 1; //团购商品
        $where['g.goods_id'] = ['neq', $parm['goods_id']];
        //取出本商品的条件
        $group_info = M('GoodsGroupPurchase')
            ->field('zone_show,audit_state')
            ->where(['goods_id'=>$parm['goods_id']])
            ->find();
        if($group_info['zone_show'] == 1 && $group_info['audit_state'] == 1){
            $where['ggp.zone_show'] = 1;
            $where['ggp.audit_state'] = 1;
            $list = $this->getOrtherGroupGoods($where, $limit);
        }else{
            $other_list = [];
            $where['g.store_id'] = $parm['store_id'];
            $list = $this->getOrtherGroupGoods($where, $limit);
            $count = count($list);
            if($count < $limit){    //不够10个取出其它网店的团购商品
                unset($where['g.store_id']);
                if($count > 0){
                    $goods_ids = array_column($list, 'goods_id');
                    $where['g.goods_id'] = ['not in', $goods_ids];
                }
                $o_limit = $limit - $count;
                $other_list = $this->getOrtherGroupGoods($where, $o_limit);
            }
            $list = array_merge($list, $other_list);
        }
        foreach($list as $k => &$v){
            $goods_spec = M('GoodsSpec')->alias('a')
                ->field('a.sp_price,a.goods_stock,a.group_member_num,b.sp_value_name')
                ->join('left join __SPEC_VALUE__ as b on a.sp_value_id = b.sp_value_id')
                ->where(['a.goods_spec_id'=>$v['goods_spec_id'],'a.goods_id'=>$v['goods_id']])
                ->find();
            if(empty($goods_spec) || $goods_spec['goods_stock'] <= 0){
                unset($list[$k]);
                continue;
            }
            $v['sp_price'] = $goods_spec['sp_price'];
            $v['sp_value_name'] = $goods_spec['sp_value_name'];
            $v['group_member_num'] = $goods_spec['group_member_num'];
            $v['goods_img'] = $this->getFullImg($v['goods_img']);
            $v['group_detail_url'] = $this->getGroupDetailUrl($v['goods_id']);
        }
        return $list;
    }

    public function getOrtherGroupGoods($params = [], $limit = 10){
        $list = M('Goods')
            ->alias('g')
            ->field('g.goods_id,g.goods_img,g.goods_name,g.goods_spec_id')
            ->join('left join __GOODS_GROUP_PURCHASE__ ggp on ggp.goods_id=g.goods_id')
            ->where($params)
            ->order('ggp.end_time desc')
            ->limit($limit)
            ->select();
        return $list;
    }

    /**
     * [getAllGroupGoods 取出首页专区展示的团购商品]
     * @param  [type] $goods_id [description]
     * @return [type]           [description]
     */
    public function getAllGroupGoods($params = []){
        $limit = sprintf('%d,%d', ($params['page'] ? ($params['page'] - 1) : 0) * $params['rows'], $params['rows']);
        if($params['town_id']){
            $deep=M('Area')->where('area_id='.$params['town_id'])->getField('area_deep');
            if($deep == '3'){
                $where['s.district_id'] = $params['town_id'];
            }
            else{
                $where['s.town_id'] = $params['town_id'];
            }
        }
        $where['g.goods_state'] = 1;    //商品状态正常
        $where['g.goods_type'] = 1; //团购商品
        $where['ggp.zone_show'] = 1;  //首页专区展示
        $where['ggp.audit_state'] = 1;    //通过审核
//        $where['ggp.end_time'] = ['gt',time()];
        //关键字搜索（商品名或网店名）
        if(!empty($params['keyword'])){
            $where_name_ary=[
                'g.goods_name' => ['like','%'.$params['keyword'].'%'],
                's.store_name' => ['like','%'.$params['keyword'].'%'],
                '_logic' => 'OR'
            ];
            array_push($where,$where_name_ary);
        }
        $list = M('Goods')
            ->alias('g')
            ->field('g.goods_id,g.goods_img,g.goods_name,g.goods_jingle,s.store_name,g.goods_spec_id,ggp.start_time,ggp.end_time')
            ->join('left join __GOODS_GROUP_PURCHASE__ ggp on ggp.goods_id=g.goods_id')
            ->join('left join __STORE__ s on g.store_id=s.store_id')
            ->where($where)
//            ->order('ggp.end_time<now(),g.goods_sort asc')
            ->order('g.goods_sort asc,ggp.end_time<unix_timestamp(now()),if(ggp.end_time<unix_timestamp(now()),0,ggp.end_time),ggp.end_time desc')
            ->limit($limit)
            ->select();
        foreach($list as $k => &$v){
            $goods_spec = M('GoodsSpec')->alias('a')
                ->field('a.sp_price,a.goods_stock,a.group_member_num,b.sp_value_name')
                ->join('left join __SPEC_VALUE__ as b on a.sp_value_id = b.sp_value_id')
                ->where(['a.goods_spec_id'=>$v['goods_spec_id'],'a.goods_id'=>$v['goods_id']])
                ->find();
            $v['sp_price'] = $goods_spec['sp_price'];
            $v['sp_value_name'] = $goods_spec['sp_value_name'];
            $v['group_member_num'] = $goods_spec['group_member_num'];
            $v['goods_img'] = $this->getFullImg($v['goods_img']);
            $v['group_detail_url'] = $this->getGroupDetailUrl($v['goods_id']);
			//状态
			if($v['start_time'] > time()){
				$v['status'] = '活动未开始';
			}
			if($v['end_time'] < time()){
				$v['status'] = '活动已结束';
			}
			if($v['end_time'] >= time() && $v['start_time'] <= time()){
				$v['status'] = '马上抢';
			}
            $v['start_time'] = date('Y-m-d H:i:s', $v['start_time']);
            $v['end_time'] = date('Y-m-d H:i:s', $v['end_time']);
        }

        return $list;
    }

	/**
	 * 回滚商品库存
	 */
	public function incStock($goodsId, $num = 1 ,$goods_spec)
	{
		if(!empty($goods_spec)){
			$where['goods_spec_id'] = $goods_spec;
		}
		$where['goods_id'] = $goodsId;
		$where['goods_stock'] = array('EGT', abs($num));
		return M('goods_spec')->where($where)->setInc('goods_stock', abs($num));
	}
    /**
     * 商品购买最大限购
     */
    public function checkGoodsLimit($goodsId, $goodsLimit,$goodsSpecId,$memberId, $goodsNum = 1)
    {
        $time1 = strtotime(date('Y-m-d', time()));
        $time2 = $time1 + 86400;
        $num = 0;
        $order = M('order')->field('order_id')->where(array('buyer_id' => $memberId, 'order_state' => array('neq', 0), 'add_time' => array('BETWEEN', "{$time1},{$time2}")))->select();
        foreach ($order as $key => $value) {
            $num += M('order_goods')->where(array('goods_id' => $goodsId, 'goods_spec_id'=>$goodsSpecId,'buyer_id' => $memberId, 'order_id' => $value['order_id'], 'create_time' => array('BETWEEN', "{$time1},{$time2}")))->getField('goods_num');
        }

        $num1 = $goodsLimit - $num;

        if ($goodsNum > $num1) {
            $name = M('goods')->where(array('goods_id'=>$goodsId))->getField('goods_name');
            return array(
                'msg'=>$name.'每天每人限购'.$goodsLimit.'件',
                'code' => 2
            );
        }

        return true;

    }

    /** 判断商品状态
     * @param $goods_list-商品二维数组
     * @return array
     */
    public function checkGoodsStatus($goods_list){
        foreach($goods_list as $k => $v){
            $goods_state = M('Goods')->where(['goods_id'=>$v['goods_id']])->getField('goods_state');
            if (empty($goods_state) || $goods_state != 1) {
                return [
                    'code'  => -2407,
                    'msg'   => $v['goods_name'].'已下架'
                ];
            }
//            $goods_stock = M('GoodsSpec')->where(['goods_spec_id'=>$v['goods_spec_id']])->getField('goods_stock');
//            if (empty($goods_stock) || $goods_stock < $v['goods_num']) {
//                return [
//                    'code'  => -2406,
//                    'msg'   => '库存不足'
//                ];
//            }
        }
        return [
            'code'  => 1,
            'msg'   => '商品状态正常'
        ];
    }

}
