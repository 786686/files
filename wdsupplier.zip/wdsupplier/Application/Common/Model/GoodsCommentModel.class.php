<?php
/**
 * 商品评论模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class GoodsCommentModel extends Model {

	// 评论类别-商品
	const TYPE_GOODS = 1;

	const STAR_ONE   = 1;
	const STAR_TWO   = 2;
	const STAR_THREE = 3;
	const STAR_FOUR  = 4;
	const STAR_FIVE  = 5;

	public $starList = array(
		self::STAR_ONE   => '一星',
		self::STAR_TWO   => '二星',
		self::STAR_THREE => '三星',
		self::STAR_FOUR  => '四星',
		self::STAR_FIVE  => '五星',
	);

	// 默认评论
	const DEFAULT_COMMIT = '收到商品，默认好评！';

	const DEFAULT_SART = 5;


	const FIELD_COMMENT_LIST = 'comment_id,comment_type,comment_object_id,comment_message,comment_member_id,comment_member_name,comment_time,comment_star,comment_imgs,is_anonymous,comment_parent_id';



	/**
	 * 获取数据列表
	 * @param  array  $where 查询条件
	 * @param  integer $memberId 点赞的用户
	 * @param  string $limit 数据条目
	 * @return array  返回查询结果
	 */
	public function getList($where = array(),$field="", $limit = '0,10')
	{
		if(empty($field)) $field=self::FIELD_COMMENT_LIST;
		return $this->field($field)->where($where)->limit($limit)->order('comment_id DESC')->select();
	}

	/**
	 * 增加点赞数
	 * @param  integer $commentId 评论ID
	 * @param  integer $memberId  用户ID
	 */
	public function incLike($commentId, $memberId)
	{
		return $this->where(array('comment_id' => $commentId))->setInc('comment_like');
	}

	/**
	 * 获取列表数量
	 * @param  array  $where [description]
	 * @return [type]        [description]
	 */
	public function getCount($where = array())
	{
		return $this->where($where)->count();
	}

	/**
	 * 获得详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($where = array(), $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

    /**
     * 商品好评信息
     *
     * @author: fanzhaogui
     * @param $goods_id
     * @return mixed
     */
	public function getGoodsBetterComment($goods_id)
    {
        //获取默认评论 仅显示好评
        $commentInfo= $this->field(['comment_message','comment_member_name','comment_star','is_anonymous','comment_star','comment_time','comment_member_id'])
            ->where([
                'comment_object_id' => $goods_id,
                'comment_star'      => array('in','5,4')
            ])
            ->order('comment_star desc')
            ->find();
        if(!empty($commentInfo['comment_time'])) {
            $commentInfo['comment_time'] = date('Y-m-d',$commentInfo['comment_time']);
        }
        $commentInfo['comment_message'] = self::replaceCommentMessage($commentInfo['comment_message']);
        return $commentInfo;
    }

    /**
     * 更加评价内容
     *
     * @author: fanzhaogui
     * @param string $comment_message
     * @return mixed
     */
    public static function replaceCommentMessage($comment_message)
    {
        if (empty($comment_message)) return '';
        return str_replace('此用户没有填写任何评价，系统自动默认好评。', '物美价廉，支持！', $comment_message);
    }
}
