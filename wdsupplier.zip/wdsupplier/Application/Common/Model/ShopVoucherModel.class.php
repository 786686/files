<?php
/**
 * 购物券模型
 * @author wuxiao 2017-3-30
 */
namespace Common\Model;
use Think\Model;

class ShopVoucherModel extends Model
{
    public function is_type($shop_id)
    {
        if($shop_id){
            $list = M('ShopVoucher')->where(array('sv_shop_id'=>$shop_id))->field('sv_type,sv_amount')->find();
        }
        return $list;
    }
    public function save($shop_id){
        if($shop_id){
            $list = M('ShopVoucher')->where(array('sv_shop_id'=>$shop_id))->save(array('sv_type'=>1));
        }
        return true;
    }
}