<?php
/**
 * 退款退货模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class RefundReasonModel extends Model {

	/*
	`reason_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '原因ID',
	`reason_info` VARCHAR(50) NOT NULL COMMENT '原因内容',
	`sort` TINYINT(1) UNSIGNED NULL DEFAULT '255' COMMENT '排序',
	`update_time` INT(10) UNSIGNED NOT NULL COMMENT '更新时间',
	 */

	/** 获取数据列表 */
	public function getList()
	{
		return $this->order('update_time DESC,reason_id DESC')
			->field('reason_id,reason_info')
			->order('sort DESC,reason_id ASC')->select();
	}

}
