<?php
/**
 * 商品分类模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class PointModel extends Model {
	/**
	 * 获取数据列表
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @param  string $order [description]
	 * @return [type]        [description]
	 */
	public function getList($where = array(), $field = '*', $order = 'point_id DESC')
	{
		return $this->where($where)->field($field)->order($order)->select();
	}
	/**
	 * 格式化成树结构
	 * @param  array 	$list 	查询列表结果,必须包含 gc_id,gc_index 字段
	 * @return array 	格式化后的树形结构多维数组
	 */
	public function formatTree($list)
	{

		foreach($list as $k1=>$v1){
			foreach($list as $k2=>$v2){
				if($v2['point_parent_id']==$v1['point_id']){
					$list[$k1]['child'][]=$v2;
					unset($list[$k2]);
					continue;
				}
			}
		}
		return $list;
	}
	/**
	 * [getIsPoint 判断是否是村委或村官]
	 * @return [type] [description]
	 */
	public function getIsPoint($member_id){
		$reg = M('point')->where(array('member_id'=>$member_id))->find();
		if($reg)
			return true;
		else
			return false;
	}
	/**
	 * [getPointList 获取全部村委信息]
	 * @return [type] [description]
	 */
	public function getPointList($limit = ''){
		$pointModel = M('point');
		if(!empty($limit))
	        $pointModel->limit($limit);
		$res = $pointModel
				->alias('p')
				->join('sx_poor_point pp ON pp.point_id=p.point_id','LEFT')
				->join('sx_store s ON s.point_id=p.point_id','LEFT')
				->field('p.member_id,pp.poor_score,p.point_name,s.store_img as member_avatar')
				->order('pp.poor_score desc')
				->select();
		foreach ($res as $key => $value) {
			if(!is_numeric($value['poor_score'])){
				$res[$key]['poor_score']=0;
			}
			$res[$key]['member_avatar']=$value['poor_avatar']?C('WEBSITE_URL').'/'.$value['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
		}
		return $res;
	}
	/**
	 * [getPointList 获取全部村官信息]
	 * @return [type] [description]
	 */
	public function getPointMemberList($limit = ''){
		$pointModel = M('point');
		if(!empty($limit))
	        $pointModel->limit($limit);
		$res = $pointModel
				->alias('p')
				->join('sx_poor_point pp ON pp.point_id=p.point_id','LEFT')
				->join('sx_member m ON m.member_id=p.member_id','LEFT')
				->field('p.member_id,pp.poor_score,p.point_name,m.member_avatar,m.member_nickname')
				->limit($limit)
				->order('pp.poor_score desc')
				->select();
		foreach ($res as $key => $value) {
			if(!is_numeric($value['poor_score'])){
				$res[$key]['poor_score']=0;
			}
			$res[$key]['member_avatar']=$value['poor_avatar']?C('WEBSITE_URL').'/'.$value['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
			$res[$key]['member_nickname'] = $value['member_nickname']?$value['member_nickname']:"七子村官";
		}
		return $res;
	}
	/**
	 * [getMyPointInfo 根据用户ID获取要查询的村委或村官的排名]
	 * @param  [type] $list      [村委或村官列表]
	 * @param  [type] $member_id [要查询的用户ID]
	 * @return [type]            [description]
	 */
	public function getMyPointInfo($list, $member_id){
		foreach ($list as $key => $value) {
			if($list[$key]['member_id'] == $member_id){
				$myInfo['poor_avatar'] = $value['poor_avatar']?C('WEBSITE_URL').'/'.$value['poor_avatar']:C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
				$myInfo['rank'] = $key+1;
				$myInfo['poor_score'] = $value['poor_score'];
				$myInfo['point_name'] = $value['point_name'];
			}
		}
		return $myInfo;
	}
}
