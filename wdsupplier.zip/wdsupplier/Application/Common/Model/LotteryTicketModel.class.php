<?php
/**
 * 首次充值活动送奖券模型
 */
namespace Common\Model;
use Think\Model;

class LotteryTicketModel extends Model {
	public $min_blance = 0;	//满足最低的充值余额才能送中奖券
	public function addLottery($data=array()){
		if($data['money'] < $this->min_blance){
			return;
		}
		$result = $this->where(array('member_id'=>$data['member_id']))->find();
		if($result){
			return;
		}
		$this->add(array( 'member_id'=>$data['member_id'], 'denomination'=>$data['money'], 'create_time'=>time() ));
	}

	public function getGoods(){
        $modelGoods     = D('Goods');
        $subgoods_list = M('SpecialGoods')->alias('sp')->join('__GOODS__ as go on sp.goods_id=go.goods_id')->field('go.goods_id,go.goods_spec_id')->where(array('sp.s_id'=>8))->order('sp.sg_sort asc,sp.sg_id asc')->select();
        foreach ($subgoods_list as $kk => &$vv) {
            $vv=$modelGoods->getListDetail(['goods_id'=>$vv['goods_id'],'goods_spec_id'=>$vv['goods_spec_id']]);
            //商品合法性校验
            $checkState=$modelGoods->checkStateToBuyByInfo($vv);
            if($checkState['code']!=1) unset($subgoods_list[$kk]);
        }
        return $subgoods_list;
	}
}
