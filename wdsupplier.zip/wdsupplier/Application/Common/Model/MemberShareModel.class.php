<?php
/**
 * 分销模型
 * 
 */
namespace Common\Model;
use Think\Model;

class MemberShareModel extends Model {
	public function getListByLevel($share_member_id, $limit, $level = 1)
	{
		if($level == 1){
			$where['ms.father_id'] = $share_member_id;
		}else if($level == 2){
			$where['ms.grandad_id'] = $share_member_id;
		}
		$list = $this
				->alias('ms')
				->field('ms.*,INSERT(m.member_mobile,4,5,\'*****\') as member_mobile,m.member_avatar,m.member_nickname')
				->join('left join __MEMBER__ m on m.member_id = ms.invite_member_id')
				->where($where)
				->limit($limit)
				->select();
		foreach($list as $k => &$v){
			$list[$k]['member_avatar'] = $v['member_avatar'] ? C('WEBSITE_URL').'/'.$v['member_avatar'] : C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
			$list[$k]['createtime'] = date('Y-m-d H:i:s', $v['createtime']);
			$list[$k]['share_member_total'] = $this->getShareNumByUid($v['invite_member_id']);	//取出TA的合伙人数量
			$list[$k]['father_member_nickname'] = $this->getMemberInfo($v['father_id'])['member_nickname'];
			if($level == 1){
				$list[$k]['share_money'] = $v['father_rewards_money'];
			}else if($level == 2){
				$list[$k]['share_money'] = $v['grandad_rewards_money'];
			}
			unset($v['father_rewards_money']);
			unset($v['grandad_rewards_money']);
		}
		return $list;
	}
	public function getCountByLevel($share_member_id, $level = 1){
		if($level == 1){
			$where['father_id'] = $share_member_id;
		}else if($level == 2){
			$where['grandad_id'] = $share_member_id;
		}
		return $this->where($where)->count();
	}
	//取出所有商家用户ID
	public function getStoreMemberIds(){
		$where['member_id'] = array('neq', 0);
		$where['store_state'] = array('eq', 1);
		return M('Store')->where($where)->getField('member_id', true);
	}
	public function getAll($share_member_id, $limit)
	{
		$list1 = $this->getListByLevel($share_member_id, $limit, 1);
		$list2 = $this->getListByLevel($share_member_id, $limit, 2);
		$list = array_merge($list1, $list2);
		return $list;
	}
	/**
	 * [getAllByType description]
	 * @param  [type] $share_member_id [description]
	 * @param  [type] $limit           [description]
	 * @return [type]                  [返回商家合伙人列表和普通合伙人列表]
	 */
	public function getAllByType($share_member_id, $limit)
	{
		$array = [
			'store_member_list' => [],
			'general_member_list' => []
		];
		//$list = $this->getAll($share_member_id, $limit);
		$list1 = $this->getListByLevel($share_member_id, $limit, 1);
		$list2 = $this->getListByLevel($share_member_id, $limit, 2);
		$storeMemberIds = $this->getStoreMemberIds();
		foreach($list1 as $k => &$v){
			//合伙人奖励（除了自己的还包括二级的）
			foreach($list2 as $k2 => $v2){
				if($v['invite_member_id'] == $v2['father_id']){
					$v['share_money'] += $v2['share_money'];
				}
			}
			if(in_array($v['invite_member_id'], $storeMemberIds)){
				$array['store_member_list'][] = $v;
			}else{
				$array['general_member_list'][] = $v;
			}
		}
		return $array;
	}
	//取出合伙人数量，包括一级和二级合伙人
	private function getShareNumByUid($share_member_id)
	{
		return count($this->getOneShareIds($share_member_id)) + count($this->getTwoShareIds($share_member_id));
	}
	//根据分享人ID获取对应其分享的一级用户ID集合
	public function getOneShareIds($share_member_id, $start_time = '', $end_time = '')
	{
		if($start_time && $end_time){
			$where['createtime'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
		}else if($start_time){
			$where['createtime'] = array('egt', strtotime("$start_time"));
		}else if($end_time){
			$where['end_time'] = array('elt', strtotime("$end_time 23:59:59"));
		}
		$where['father_id'] = $share_member_id;
		$ids = $this->where($where)->getField('invite_member_id', true);
		return $ids ? $ids : [];
	}
	//根据分享人ID获取对应其分享的一级用户ID集合
	private function getTwoShareIds($share_member_id, $start_time = '', $end_time = '')
	{
		if($start_time && $end_time){
			$where['createtime'] = array('between', [strtotime("$start_time"), strtotime("$end_time 23:59:59")]);
		}else if($start_time){
			$where['createtime'] = array('egt', strtotime("$start_time"));
		}else if($end_time){
			$where['end_time'] = array('elt', strtotime("$end_time 23:59:59"));
		}
		$where['grandad_id'] = $share_member_id;
		$ids = $this->where($where)->getField('invite_member_id', true);
		return $ids ? $ids : [];
	}
	//昨日新增合伙人数量
	public function yesterDayNum($share_member_id){
		$time = date('Y-m-d', strtotime("-1 day"));
		$father_num = $this->getOneShareIds($share_member_id, $time, $time);
		$grandad_num = $this->getTwoShareIds($share_member_id, $time, $time);
		return count($father_num) + count($grandad_num);
	}
	public function getInfoByUid($share_member_id)
	{
		$father_info = $this->getFatherInfo($share_member_id);
		$father_num = $this->getOneShareIds($share_member_id);
		$grandad_num = $this->getTwoShareIds($share_member_id);
		$total = $this->getMoneyTotal($share_member_id);
		return [
			'father_num' => count($father_num),
			'grandad_num' => count($grandad_num),
			'father_member_mobile' => $father_info['member_mobile']?$father_info['member_mobile']:'',
			'father_member_nickname' => $father_info['member_nickname']?$father_info['member_nickname']:'',
			'yesterday_share_member_num' => $this->yesterDayNum($share_member_id),
			'store_total' => $total['store_total'],
			'general_total' => $total['general_total'],
			'all_total' => $total['all_total'],
		];
	}
	//取出合伙人上级信息
	public function getFatherInfo($share_member_id)
	{
		$where['ms.invite_member_id'] = $share_member_id;
		$list = $this
				->alias('ms')
				->field('m.member_nickname,INSERT(m.member_mobile,4,5,\'*****\') as member_mobile')
				->join('left join __MEMBER__ m on m.member_id = ms.father_id')
				->where($where)
				->find();
		$list['member_nickname'] = $list['member_nickname'] ? $list['member_nickname'] : $list['member_mobile'];
		return $list;
	}
	public function getMemberInfo($member_id)
	{
		$info = M('Member')
				->field('member_nickname,member_avatar,INSERT(member_mobile,4,5,\'*****\') as member_mobile')
				->where(['member_id'=>$member_id])
				->find();
		$info['member_nickname'] = $info['member_nickname'] ? $info['member_nickname'] : $info['member_mobile'];
		return $info;
	}
	public function getInfoById($id)
	{
		$info = $this->getMemberInfo($id);
		$info['member_nickname'] = $info['member_nickname'] ? $info['member_nickname'] : $info['member_mobile'];
		$total = $this->getMoneyTotal($id);
		$oneList = $this->getOneList($id);
		$info['member_avatar'] = $info['member_avatar'] ? C('WEBSITE_URL').'/'.$info['member_avatar'] : C('WEBSITE_URL')."/Public/Mobile/images/default_avatar.png";
		$info['father_money_total'] = $oneList['father_rewards_money'];	//我对上级的奖励积分
		$info['my_consume_total'] = $this->getMyConsumeTotal($id);	//我消费的总金额
		$info['consume_money_total'] = $this->getConsumeMoneyTotal($id);
		$info['share_member_total'] = $this->getShareNumByUid($id);
		$info['store_total'] = $total['store_total'];
		$info['general_total'] = $total['general_total'];
		$info['all_total'] = $total['all_total'];
		return $info;
	}
	public function getOneList($invite_member_id)
	{
		return $this->where(['invite_member_id'=>$invite_member_id])->find();
	}
	//根据用户ID取出我的消费总额
	public function getMyConsumeTotal($id)
	{
		$where['consume_member_id'] = $id;
		$total = M('ShareRewardsLog')->where($where)->sum('consume_money');
		return $total ? $total : 0;
	}
	//根据用户ID取出我的合伙人消费总额
	public function getConsumeMoneyTotal($id)
	{
		$where['rewards_member_id'] = $id;
		$total = M('ShareRewardsLog')->where($where)->sum('consume_money');
		return $total ? $total : 0;
	}
	//取出所有合伙人奖励积分信息
	public function getAllList($share_member_id, $level = 1)
	{
		if($level == 1){
			$where['father_id'] = $share_member_id;
		}else if($level == 2){
			$where['grandad_id'] = $share_member_id;
		}
		$list = $this->field('invite_member_id,father_rewards_money,grandad_rewards_money')->where($where)->select();
		foreach($list as $k => &$v){
			if($level == 1){
				$list[$k]['share_money'] = $v['father_rewards_money'];
			}else if($level == 2){
				$list[$k]['share_money'] = $v['grandad_rewards_money'];
			}
			unset($v['father_rewards_money']);
			unset($v['grandad_rewards_money']);
		}
		return $list;
	}
	//所有合伙人人积分统计
	public function getMoneyTotal($share_member_id)
	{
		$array = [
			'store_total' => 0,	//商家合伙人总积分
			'general_total' => 0,	//普通合伙人总积分
			'all_total' => 0	//总计
		];
		$list1 = $this->getAllList($share_member_id, 1);
		$list2 = $this->getAllList($share_member_id, 2);
		$list = array_merge($list1, $list2);
		$storeMemberIds = $this->getStoreMemberIds();
		foreach($list as $k => $v){
			if(in_array($v['invite_member_id'], $storeMemberIds)){
				$array['store_total'] += $v['share_money'];
			}else{
				$array['general_total'] += $v['share_money'];
			}
		}
		$array['all_total'] = $array['store_total'] + $array['general_total'];
		return $array;
	}
}
