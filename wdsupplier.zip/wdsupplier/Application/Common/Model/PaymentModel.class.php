<?php
/**
 * 支付模型模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class PaymentModel extends Model {

	// `payment_id` TINYINT(1) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '支付索引id',
	// `payment_code` VARCHAR(12) NOT NULL COMMENT '支付代码名称',
	// `payment_name` CHAR(10) NOT NULL COMMENT '支付名称',
	// `payment_config` VARCHAR(2000) NULL DEFAULT NULL COMMENT '支付接口配置信息',
	// `payment_state` ENUM('0','1') NOT NULL DEFAULT '0' COMMENT '接口状态0禁用1启用',
	// `payment_sort` MEDIUMINT(9) NOT NULL DEFAULT '0' COMMENT '排序',
	// `payment_port` VARCHAR(10) NULL DEFAULT '0' COMMENT '支付端口开放配置(0:全部,其他组合{PC:1,WAP:2,ANDROID:3,IOS:4,WECHAT:5}, 例子:支付宝:1,2,3,4,5)',

	// 字符串类型,状态
	const STATE_OPEN    = '1';
	const STATE_DISABLE = '0';

	/**
	 * 获取支付代码列表
	 * @author deason 2016-08-06
	 * @param  integer $device 根据设备可用获取
	 * @return array
	 */
	public function getPayCodeList($device = 0)
	{
		// 增加未开启支付状态过滤
		$this->where(array('payment_state' => self::STATE_OPEN));
		/* TODO:逻辑不一致,暂时关闭设备过滤设置[2016-11-18]
		if ($device) {
			$this->where(array(
				'payment_port' => array(
					array('EQ', '0'),
					array('LIKE', '%'.$device.'%'),
					'OR'
					)
			));
		}*/
		return $this->field('payment_id,payment_code,payment_name,payment_state')->select();
	}

	public function getInfo($where, $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

	public function checkCode($code)
	{
		return $this->where(array(
			'payment_code' => $code,
			'payment_state' => self::STATE_OPEN
		))->getField('payment_id');
	}

}
