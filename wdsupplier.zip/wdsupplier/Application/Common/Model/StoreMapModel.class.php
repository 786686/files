<?php
/**
 * 网店百度地图模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class StoreMapModel extends Model {

	/**
	 * 获得详细信息
	 * @param  array  $where [description]
	 * @param  string $field [description]
	 * @return [type]        [description]
	 */
	public function getInfo($where = array(), $field = '*')
	{
		return $this->where($where)->field($field)->find();
	}

	/**
	 * 通过商店ID获取坐标
	 * @author deason 2016-07-22
	 * @param  integer $id 商店ID
	 * @return array     百度坐标
	 */
	public function getCoordinateById($id)
	{
		return $this->where(array('store_id' => $id))->field('baidu_lng,baidu_lat')->find();
	}
}
