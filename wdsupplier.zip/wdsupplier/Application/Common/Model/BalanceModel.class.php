<?php

namespace Common\Model;
use Think\Model;
use Common\Service\Sms as SmsService;
use Common\Service\Push as PushService;
/**
 * 余额模型
 */
class BalanceModel extends Model{
	//检查是否有充值下单记录
	public function checkRecharge($where = array()){
		return M('MemberAccountLog')->where($where)->find();
		// return M('BalanceRecharge')->where($where)->find();
	}
	//充值后处理逻辑
	public function afterPay($out_trade_no,$logtype=1){
		if($logtype==1){
			$myfile='./Public/paylog/'.date('Ym').'_alipay_log.txt';
			$remark='支付宝充值余额';
			$payment_type = 1;
		}else{
			$myfile='./Public/paylog/'.date('Ym').'_wechat_log.txt';
			$remark='微信充值余额';
			$payment_type = 2;
		}
		$file_pointer = fopen($myfile,"a");
		$RechargeInfo=M('MemberAccountLog')->where(array('pay_sn'=>$out_trade_no,'status'=>0))->field('change_money,uid,order_sn,pay_sn')->find();
		// $RechargeInfo=M('BalanceRecharge')->where(array('pay_sn'=>$out_trade_no,'status'=>0))->find();
		if(empty($RechargeInfo)) return 0;
		$payment_type_str = '';
		switch ($payment_type) {
			case 1:
				$payment_type_str = 'alipay';
				break;
			case 2:
				$payment_type_str = 'wxpay';
				break;
			default:
				# code...
				break;
		}
		$this->startTrans();
		$data['status'] = 1;
		$data['pay_type'] = $payment_type_str;
		$getMB = M('MemberBalance')->where( array('uid'=>$RechargeInfo['uid']) )->field('recharge_balance')->find();
		//扣除余额
		$rechargeData = M('option')->where(['option_name'=>'recharge_rate'])->field('option_value')->find();
		$rechargeRate = $rechargeData['option_value'];
		if($rechargeRate>0){
			$rechargeFee = round($RechargeInfo['change_money']*$rechargeRate*0.01,2)>=0.01 ? round($RechargeInfo['change_money']*$rechargeRate*0.01,2) : 0.01;
		}else{
			$rechargeFee = 0;
		}

		$RechargeInfo['change_money'] = $RechargeInfo['change_money'] - $rechargeFee;

		$data['balance'] = $getMB['recharge_balance'] + $RechargeInfo['change_money'];  // 余额充值成功之后用户剩余的余额
		$tmp1=M('MemberAccountLog')->where(array('pay_sn'=>$out_trade_no))->save($data);
		$time = time();
		// $tmp1=M('BalanceRecharge')->where(array('pay_sn'=>$out_trade_no))->save($data);
		// $this->sendPovertySection($RechargeInfo['member_id'], $RechargeInfo['money'], $RechargeInfo['type']);
//		$tmp2=$this->where(array('member_id'=>$RechargeInfo['member_id']))->setInc('basic_balance', $RechargeInfo['money']);
		if($tmp1){
			// require_once( 'Application/Api/Common/mysql.php' );
			$sql    = 'UPDATE __MEMBER_BALANCE__ SET recharge_balance=recharge_balance+' . $RechargeInfo['change_money'] . ' WHERE uid="' . $RechargeInfo['uid'] . '" AND recharge_balance>=0';
			M()->execute( $sql );
			// $koukuan = mysql::db_query( $sql );
			//写入扣款日志
			
			// $present_balance_sql =  '余额充值:(uid:'.$RechargeInfo['uid'] .'元;剩余余额:'.($getMB['recharge_balance']+$RechargeInfo['change_money']).'元;时间戳:'. $time .';时间:'.date('Y-m-d H:i:s',$time);
			// $sql1 = 'INSERT INTO __MEMBER_ACCOUNT_LOG__ (uid,account_type,change_money,balance,type_name,remark,createtime,pay_type) VALUES ("'.$member_id.'","4","'.$RechargeInfo['change_money'].'","'.($getMB['recharge_balance']+$RechargeInfo['change_money']).'","余额充值","'.$present_balance_sql.'","'.$time.'","balance")';
			// M()->execute( $sql1 );

			$this->addBalanceLog([
				'member_id' => $RechargeInfo['uid'],
				'money' => $RechargeInfo['change_money'],
				'out_trade_no' => $out_trade_no,
				'remark' => $remark,
				'payment_type' => $payment_type
			]);

			//添加余额充值手续费流水
			if($rechargeFee>0){
				$feeData['uid'] = $RechargeInfo['uid'];
				$feeData['status'] = 0;
				$feeData['account_type'] = 6; 	// 余额充值手续费
				$feeData['change_money'] = sprintf("%.2f", $rechargeFee);
				$feeData['type_name'] = '余额充值手续费';  //交易类目
				$feeData['remark'] = '线上充值';
				$feeData['order_sn'] = $RechargeInfo['order_sn'];
				$feeData['pay_sn'] = $RechargeInfo['pay_sn'];
				$feeData['fee_rate'] = $rechargeRate;
				$feeData['pay_type'] = 1;
				$feeData['createtime'] = time();
				M('MemberAccountLog')->add($feeData);
			}

            $this->commit();
			fwrite($file_pointer,'-----------------'.$out_trade_no.'------------------success----------------------------------------;\r\n');
			fclose($file_pointer);
			return 1;
		}else{
			$this->rollback();
			fwrite($file_pointer,'-----------------'.$out_trade_no.'------------------rollback------------------------------------;\r\n');
			fclose($file_pointer);
			return 0;
		}
		
	}
	private function addBalanceLog($params){
		$logData['member_id'] = $params['member_id'];
		$logData['money'] = $params['money'];
		$logData['type'] = 0;   
		$logData['order_sn'] = $params['out_trade_no'];   
		$logData['remark'] = $params['remark'];
		$logData['payment_type'] = $params['payment_type'];
		$logData['createtime'] = time();
		M('BalanceLog')->add($logData);
	}
	//镇安活动进行充500送50扶贫款
    public function sendPovertySection($member_id, $money, $type)
    {
        $bool = D('Member')->checkMemberByStoreID($member_id);
        if(!$bool){
            return;
        }
        if($money != 500){
            return;
        }
        if($type != 2){
            return;
        }
        $this->addPovertySectionLog($member_id);
    }
    private function addPovertySectionLog($member_id)
    {
        M('PovertySectionLog')->add([
            'member_id' => $member_id,
            'store_id' => 329,
            'money' => 50,
            'createtime' => time()
        ]);
    }
    //充值成功发送短信
    public function sendSms($member_id, $money, $type)
    {
	    $info = M('Member')->field('member_mobile,registration_id')->where(['member_id'=>$member_id])->find();
	    if($type == 0){
	        //普通充值
            $point1 = $money * 100;
            $lilv = "0.05";
            $sms_param = "{\"money\":\"{$money}\",\"point\":\"{$point1}\",\"lilv\":\"{$lilv}\"}";
            SmsService::commonRecharge($info['member_mobile'], $sms_param);
            if($info['registration_id']){
            	PushService::commonRecharge($info['registration_id'], $money, $point1, $lilv);
            }
        }else if($type == 1){
	        //活动充值
            $point1 = $money * 100;
            $sms_param = "{\"money1\":\"{$money}\",\"money2\":\"{$money}\",\"point1\":\"{$point1}\"}";
            SmsService::activityRecharge($info['member_mobile'], $sms_param);
            if($info['registration_id']){
            	PushService::activityRecharge($info['registration_id'], $money, $money, $point1);
            }
        }
        return;
    }
}