<?php
/**
 * 商品评论点击记录模型
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class GoodsCommentLikeModel extends Model {

	/**
	 * 检查评论是否已点赞
	 * @param  integer $commentId 点赞评论ID
	 * @param  integer $memberId  点赞用户ID
	 * @return inieger	点赞记录ID
	 */
	public function checkClick($commentId, $memberId)
	{
		return $this->where(array(
			'comment_id' => $commentId,
			'gclike_member_id' => $memberId
		))->getField('gclike_id');
	}

	/**
	 * 增加点赞记录
	 * @param  integer $commentId 点赞评论ID
	 * @param  integer $memberId  点赞用户ID
	 * @return inieger	点赞记录ID
	 */
	public function addClick($commentId, $memberId)
	{
		$data = array(
			'comment_id' => $commentId,
			'gclike_member_id' => $memberId,
			'gclike_time' => NOW_TIME
		);
		return $this->add($data);
	}

}
