<?php
namespace Common\Model;

use Think\Model;

class StatOrderModel extends Model {

    public function insertAll($insert_arr)
    {
        if (empty($insert_arr) || empty($insert_arr[0]) || !is_array($insert_arr)) {
            return false;
        }

        return $this->addAll($insert_arr);
    }

    /**
     * 利润分配
     * 1）村民联社（村委）、村民合作社（自然村）
     * 2）按入口网店来换算订单，暂不理会用户绑定的对象
     * 3）商品售价-毛利成本（配置）=纯利润
     * 4）利润按纯利润固定比例分配（村委：20%；自然村：50%；万讯扶贫基金：5%；金淘：25%；）村委能拿50%+20%，自然村50%
     * （页面展示逻辑）
     * 日期（固定）：天、月、年 （周再考虑）
     * 村委（固定）：名称/金额
     * 自然村（全部/一项）：名称/金额
     * 扶贫对象（扶贫基金）（全部/一项）：名称/金额
     * 金淘（全部/一项）：名称/金额
     */
    public function profit($where=array()){
        if($where['point_name']) {
            $point_name = $where['point_name'];
        }

        if($where['state'] == 1) {
            $state = '%Y';
        }elseif($where['state'] == 2) {
            $state = '%m';
        }elseif($where['state'] == 3) {
            $state = '%d';
        }else{
            $state = '%Y-%m-%d';
        }
        $sql=  "SELECT o.order_id,o.store_id,o.order_amount,o.add_time,s.store_name,s.point_id,p.point_name,p.level,
                (SELECT point_parent_id FROM sx_point WHERE point_id=s.point_id) parent_point_id,
                (SELECT point_name FROM sx_point WHERE point_id=((SELECT point_parent_id FROM sx_point WHERE point_id=s.point_id))) parent_point_name,
                FROM_UNIXTIME(o.add_time,'$state') date
                FROM sx_order o
                LEFT JOIN sx_store s ON o.store_id=s.store_id
                LEFT JOIN sx_point p ON s.point_id=p.point_id
                WHERE o.order_state IN(20,30,40) AND o.order_amount>=1 AND p.point_name LIKE '%$point_name%' ORDER BY o.add_time DESC ";
        $list= M()->query($sql);
        //数据组装
        $return=$array_level_1=array();
        foreach($list as $key=>$value){
            switch($value['level']){
                case 1:
                    $array_level_1[$value['point_id'].'_'.$value['date']][]=$list[$key];
                    break;
                case 2:
                    $array_level_1[$value['parent_point_id'].'_'.$value['date']][]=$list[$key];
            }
        }
        foreach($array_level_1 as $key=>$value){
            $main_data_ary=explode('_',$key);
            $money_level_1=0;
            foreach($value as $key2=>$value2){
                //换算每一笔订单的纯利润
                $cost_money=$goods_pay_price=0;
                $order_goods_list=M('order_goods')->where(array('order_id'=>$value2['order_id']))->field('goods_id,goods_spec_id,goods_pay_price')->select();
                foreach($order_goods_list as $key3=>$value3){
                    $goods_pay_price+=$value3['goods_pay_price'];
                    $cost_money+=D('GoodsCost')->getGoodsCostData($value3['goods_id'],$value3['goods_spec_id'],$value2['add_time']);
                }
                $value[$key2]['lirun']=$lirun=($goods_pay_price-$cost_money)?$goods_pay_price-$cost_money:0;
                $money_level_1+=($value2['level']==1)?0.5*$lirun:0.2*$lirun;
                //换算完成后，删除一级村委订单数据，只保留二级的
                if($value2['level']==1) unset($value[$key2]);
            }

            $return[]=array(
                'point_id'=>$main_data_ary[0],
                'point_name'=>M('point')->where(array('point_id'=>$main_data_ary[0]))->getField('point_name'),
                'date'=>$main_data_ary[1],
                'money'=>(string)sprintf('%0.2f',$money_level_1),
                'order_list'=>array_values($value)
            );

        }
        //重新构造二级数据(分point_id统计)
        foreach($return as $key=>$value){
            $array_level_2=array();
            foreach($value['order_list'] as $key2=>$value2){
                $array_level_2[$value2['point_id']][]=$value2;
            }
            $child_ary=array();
            foreach($array_level_2 as $key3=>$value3){
                $money=0;
                foreach($value3 as $key4=>$value4){
                    $money+=0.5*$value4['lirun'];
                }
                $child_ary[]=array(
                    'point_id'=>$value3[0]['point_id'],
                    'point_name'=>$value3[0]['point_name'],
                    'money'=>(string)sprintf('%0.2f',$money),
                );

            }
            $return[$key]['child']=$child_ary;
            unset($return[$key]['order_list']);
        }

        return $return;
    }
}