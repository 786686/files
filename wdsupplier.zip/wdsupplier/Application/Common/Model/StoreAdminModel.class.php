<?php
/**
 * 学校表
 * Created by PhpStorm.
 * Date: 2019/4/28
 * Time: 11:50
 */

namespace Common\Model;


use Think\Model;

class StoreAdminModel extends Model
{
    protected $TableName = 'store_admin';

    /**
     *  根据条件查询商家后台账号信息
     * @param $id
     */
    public function getStoreAdminInfoByWhere($where,$field = 'sa_id,sa_store_id,sa_store_name'){

        if(empty($where)){
            return false;
        }

        $result = $this->field($field)->where($where)->find();

        return empty($result) ? [] : $result;
    }


    /**
     * 根据手机号码获得用户详细信息
     * @param  array  $where [description]
     * @param  string $field [description]
     * @return [type]        [description]
     */
    public function getStoreAdminInfoByMobile($mobile, $field = '*')
    {
        if(empty($mobile) || !is_mobile($mobile)){
            return false;
        }

        $where['sa_username'] = $mobile;
        $res = $this->where($where)->field($field)->find();

        return empty($res) ? [] : $res;
    }


    /**
     *  商城账号更换手机号码
     * @param $member_id
     * @param $mobile
     * @return bool
     */
    public function changeMobile($id,$mobile){

        $where['sa_id'] = $id;
        $updateData = [
            'sa_username' => $mobile,
            'sa_mobile' => $mobile,
        ];

        $res = $this->where($where)->save($updateData);
        return $res ? true : false;

    }

    public function getStoreAdmin($store_id)
    {
        return $this->getStoreAdminInfoByWhere([], '*');
    }
}