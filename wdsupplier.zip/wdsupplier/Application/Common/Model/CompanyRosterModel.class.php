<?php
/**
 * Created by PhpStorm.
 * User: yangjiyang
 * Date: 2018/8/20
 * Time: 16:00
 */

namespace Common\Model;


use Think\Model;

class CompanyRosterModel extends Model
{

    /**
     * 获取企业花名单人数数据
     * @param int array $companyId  企业id 整型 获取 数组
     * @return mixed  total_member 单位总人数， total_reg 注册人数, total_auth 认证人数
     */
    public function getCompanyMemberNumberByCompanyIds($companyIds)
    {
        $field = 'COUNT(cr.id) AS total_member,
        SUM(CASE WHEN  m.member_id is NOT NULL THEN 1 ELSE 0 END) AS total_reg,
        SUM(CASE WHEN (m.is_company_user = 1 OR ma.status = 1 AND cr.company_id = ma.company_id) THEN 1 ELSE 0 END) AS total_auth';

        $data = (new static())->alias('cr')
            ->join('LEFT JOIN __MEMBER__ m ON cr.mobile = m.member_mobile')
            ->join('LEFT JOIN __MEMBER_AUTH__ ma ON ma.member_id = m.member_id')
            ->where(['cr.company_id' => ['IN',$companyIds]])
            ->field($field)
            ->select();
        return $data;
    }

    /**
     * 通过企业id获取花名单
     * @param $companyIds
     * @return mixed
     */
    public function getLeftJoinDepartmentPositionMemberMemberAuthModel()
    {
         $this->alias('cr')
            ->join('LEFT JOIN __COMPANY_ROSTER_DEPARTMENT__ crd ON crd.id = cr.department_id')
            ->join('LEFT JOIN __COMPANY_ROSTER_POSITION__ crp ON crp.id = cr.position_id')
            ->join('LEFT JOIN __MEMBER__ m ON m.member_mobile = cr.mobile')
            ->join('LEFT JOIN __MEMBER_AUTH__ ma ON (ma.member_id = m.member_id AND cr.company_id = ma.company_id)');
         return $this;
    }

    /**
     * 个人认证添加到花名单
     * @param $data
     */
    public function userAuthAddRosterByData($data)
    {
        $memberData = M('Member')->where(['member_id' => $data['member_id']])->find();
        $oldData = M('CompanyRoster')->where(['mobile' => $memberData['member_mobile'],'company_id' => $data['company_id']])->find();
        if (empty($oldData)){
            $newData = [];
            $newData['company_id'] = $data['company_id'];
            $newData['employee_id'] = $data['number'];
            $newData['user_name'] = $data['user_name'];
            $newData['mobile'] = $memberData['member_mobile'];
            $newData['sex'] = $memberData['member_sex'];
            $newData['add_time'] = time();
            M('CompanyRoster')->add($newData);
        }
    }


}