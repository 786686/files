<?php
/**
 * 学校表
 * Created by PhpStorm.
 * Date: 2019/4/28
 * Time: 11:50
 */

namespace Common\Model;


use Think\Model;

class OrderWithdrawalModel extends Model
{
    protected $TableName = 'order_withdrawal';

    /**
     *  检查记录在 order_withdrawal 表是否存在
     * @param $id
     */
    public function checkOW($id,$field='*'){

        if(empty($id)){
            return false;
        }
        $result = $this->field('id')->where(array('id'=>$id))->field($field)->find();
        if( !empty($result) )
            return $result;
        else
            return false;
    }
}