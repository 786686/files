<?php
/**
 * 用户绑定超市表
 * @author deason 2016-07
 */
namespace Common\Model;
use Think\Model;

class MemberStoreModel extends Model {
		//已关注
		const IS_FOLLOW = 1;
		//取消关注
		const IS_NOT_FOLLOW = 2;

        /*
        用户绑定超市
        wuxiao
        */
       public function bind($parm=array())
       {
        if(empty($parm['member_id'])||empty($parm['store_id'])) return false;
        $addData['member_id']=$parm['member_id'];
        $addData['store_id']=$parm['store_id'];
        $addData['create_time']= $parm['create_time'];
        $addData['sort']=100;
        return $this->add($addData);
    }
        /*
        获取用户绑定超市列表
        wuxiao
        */
       public function getList($parm=array())
       {
          if(empty($parm['member_id'])&&empty($parm['company_id'])) return array();
          $where['mp.member_id']=$parm['member_id'];
          $where['store_state']=1;
        //若传入company_id，则返回改company_id所绑定的超市
          if(!empty($parm['company_id'])){
            $where['mp.member_id']=$parm['company_id'];
        }
        if(!empty($parm['town_id'])) $where['town_id']=$parm['town_id'];
        $sort= empty($parm['sort']) ? 'sort asc'  : $parm['sort'].' desc';
        $field= empty($parm['field']) ? 'mp.store_id,s.store_name,s.province_id,s.city_id,s.district_id,s.town_id,s.point_id,s.address,s.store_img,s.createtime,s.store_state,s.store_sort,s.is_own_shop,s.store_member_id,s.store_member_name,s.store_story'  : $parm['field'];
        $limit = sprintf('%d,%d', ($parm['page'] ? ($parm['page'] - 1) : 0) * $parm['rows'], $parm['rows']);
        $storeList=$this->alias('mp')->join('__STORE__ AS s ON mp.store_id = s.store_id', 'LEFT')->where($where)->limit($limit)->field($field)->order($sort)->select();
        //如果传入附带商品个数
           $result = [];
        foreach ($storeList as $key => $store) {
            if($store['store_id'] == C('company_store_id')){
                //屏蔽企业超市
                unset($storeList[$key]);
                continue;
            }
            $storeList[$key]['url']=C('WEBSITE_URL').U('Mobile/Store/StoreDetail',array('store_id'=>$store['store_id']));
            $storeList[$key]['bind_num']=M('member_store')->where(array('store_id'=>$store['store_id']))->count();
            $storeList[$key]['store_img']=$this->getFullImg($store['store_img']);
            $storeList[$key]['goodsList']=array();
            if(!empty($parm['goods_num'])){
                $goodsModel=D('Goods');
                $storeList[$key]['goodsList']=$goodsModel->getList(['store_id'=>$store['store_id']],'0,'.$parm['goods_num'],$goodsModel::FIELD_GOODS_LIST);
            }
            $result[] = $storeList[$key];
        }
        return $result;
    }
    
    public function getFullImg($img){
        return 'http://'.$_SERVER['SERVER_NAME'].'/'.$img;
    }
    /**
     * [getSpreadStore 取出推广的超市]
     * @param  integer $limit [默认取出三个推广的超市]
     * @param \Oss\OssClient $ossClient
     * @return [type]         [description]
     */
    public function getSpreadStore($parm = array(), $ossClient)
    {
        if(isset($parm['id']) && $parm['id']) {
            $where['store_id'] = array('not in', $parm['id']);
        }
        $where['store_state'] = 1;
        $list = M('Store')->field('store_id,store_name,store_img,is_spread')->where($where)->order('store_sort')->limit($parm['limit'])->select();
        foreach($list as $k=>$v){
            $list[$k]['store_img'] = !empty($v['store_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $v['store_img'], 3600) : '';
            $list[$k]['url'] = C('WEBSITE_URL').U('Mobile/Store/StoreDetail',array('store_id'=>$v['store_id']));
	        $list[$k]['is_follow'] = 0;
        }
        return $list;
    }
    /**
     * [getStore 取出我关注的超市]
     * @param \Oss\OssClient $ossClient
     * @return [type] [description]
     */
    public function getMyAttentionStore($parm=array(),$ossClient){
        $list = $this
                    ->alias('a')
                    ->field('s.store_id,s.store_name,s.store_img')
                    ->join('__STORE__ AS s ON a.store_id = s.store_id', 'LEFT')
                    ->where(array('a.member_id'=>$parm['member_id'],'s.store_state'=>1,'is_follow'=>1))
                    ->limit($parm['limit'])
                    ->order('a.sort')
                    ->select();
        foreach($list as $k=>$v){
            $list[$k]['url'] = C('WEBSITE_URL').U('Mobile/Store/StoreDetail',array('store_id'=>$v['store_id']));
            $list[$k]['store_img'] = !empty($v['store_img']) ? $ossClient->signUrl(C('aliyun.bucket'), $v['store_img'], 3600) : '';
            $list[$k]['is_spread'] = 0; //表示不是平台推广的
	        $list[$k]['is_follow'] = 1; //关注，0是不关注
        }
        return $list;
    }
    /**
     * [getStoreByMemberId 取出三个超市，如果用户没有登录，那就取出我们平台推荐的三个超市，
     * 如果用户登录了那就取出用户绑定的超市，不足三个的就补足三个]
     * @return [type] [description]
     */
    public function getStoreByMemberId($member_id,$ossClient){
        if(empty($member_id)){
            $data = $this->getSpreadStore(array('limit'=>3),$ossClient);
            return $data;
        }
        $my_list = $this->getMyAttentionStore(array('member_id'=>$member_id,'limit'=>3),$ossClient);

        $my_list_num = count($my_list);
        if($my_list_num<3){
            $array = array_map('array_shift', $my_list);
            $ids = implode(',', $array);    //取出我关注的超市ID
            $limit = 3-$my_list_num;
            $spread_list = $this->getSpreadStore(array('limit'=>$limit,'id'=>$ids),$ossClient);
            $my_list = array_merge($my_list,$spread_list);
        }
        return $my_list;
    }
    /**
     * ]
     * @param  [type] $member_id [根据用户ID取出我关注的第一级商店ID]
     * @return [type]            [返回ID数组]
     */
    public function getParentStoreByMemberId($member_id){
        $where['s.store_state'] = 1;      // Default: 正常状态
        $where['s.store_parent_id'] = 0;  //取出一级商店
        $where['ms.member_id'] = $member_id;
        $list = M('MemberStore')
                ->field('ms.member_id,s.store_id')
                ->alias('ms')
                ->join('left join __STORE__ s on ms.store_id=s.store_id')
                ->where($where)
                ->select();
        foreach ($list as $key => $value) {
            $hasIds[]=$value['store_id'];
        }
        return $hasIds;
    }

    public function getBindStoreID($member_id){
        return M('MemberStore')->where(['member_id' => $member_id])->getField('store_id', true);
    }

    //获取用户关注超市的简要信息
    public function getBriefInfo($member_id){
        return $this
            ->alias('ms')
            ->field('s.store_id,s.store_name')
            ->join('left join __STORE__ s on ms.store_id = s.store_id')
            ->where(['ms.member_id' => $member_id])
            ->order('ms.sort asc')
            ->select();
    }

    //获取用户没有绑定的超市简要信息
    public function getNoBindBriefInfo($member_id, $limit){
        $store_id_arr = $this->getBindStoreID($member_id);
        if($store_id_arr){
            $where['store_id'] = ['not in', $store_id_arr];
        }
        return M('Store')->field('store_id,store_name')->where($where)->limit($limit)->select();
    }

	//取消关注
	public function cancelFollow($member_id, $store_id){
		$data['is_follow'] = self::IS_NOT_FOLLOW;
		return $result = $this->where(['member_id'=>$member_id, 'store_id'=>$store_id])->save($data);
	}


}