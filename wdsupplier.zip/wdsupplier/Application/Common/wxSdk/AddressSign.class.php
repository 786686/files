<?php
namespace Common\wxSdk;

class AddressSign extends Common_util_pub
{
	/**
	 * 	作用：生成签名 address
	 */
	public function getSign_address($Obj)
	{
		foreach ($Obj as $k => $v)
		{
			$Parameters[strtolower($k)] = $v;
		}
		//签名步骤一：按字典序排序参数
		ksort($Parameters);
		$String = $this->formatBizQueryParaMap($Parameters, false);
		$result_ = sha1($String);
		return $result_;
	}
	

	/*
	*	作用：设置地址签名
	*
	*/
	public function get_address_sign($infolist)
	{   
		$jsApiObj["accesstoken"] = $infolist['accesstoken'];
		$jsApiObj["appId"] = $infolist['appid'];
		$jsApiObj["nonceStr"] = $infolist['nonceStr'];
	    $jsApiObj["timeStamp"] = $infolist['timeStamp'];;
		$jsApiObj["url"] = $infolist['url'];
	    $addresssign = $this->getSign_address($jsApiObj);
		return $addresssign;
	}
}
?>
