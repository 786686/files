<?php
namespace Common\wxpay;
/**
 * 通用通知接口
 */
class Notify_pub extends Wxpay_server_pub 
{

}

?>