<?php

namespace Common\wxSdk;

class WeixinInfo {
	private $app_id;
	private $app_secret;
	
	public function __construct() {
		$this->app_id = \Common\wxSdk\WxPayConf_pub::APPID;
		$this->app_secret = \Common\wxSdk\WxPayConf_pub::APPSECRET;
	}
	
	function backinfo() {
		return $this->app_id;
	}
	/**
	 * 获取微信code
	 *
	 * @param string $redirect_uri
	 *        	跳转地址
	 * @param mixed $state
	 *        	参数
	 */
	public function get_authorize_url($redirect_uri = '', $state = '') {
		$redirect_uri = urlencode ( $redirect_uri );
		return "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->app_id}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_base&state={$state}#wechat_redirect";
	}
	
	/**
	 * 获取微信授权链接
	 *
	 * @param string $redirect_uri
	 *        	跳转地址
	 * @param mixed $state
	 *        	参数
	 */
	public function get_authorize_url_userinfo($redirect_uri = '', $state = '') {
		$redirect_uri = urlencode ( $redirect_uri );
		return "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->app_id}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_userinfo&state={$state}#wechat_redirect";
	}
	
	/**
	 * 获取授权token
	 *
	 * @param string $code
	 *        	通过get_authorize_url获取到的code
	 */
	public function get_access_token($code = '') {
		$token_url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$this->app_id}&secret={$this->app_secret}&code={$code}&grant_type=authorization_code";
		$token_data = $this->http ( $token_url );
		
		if ($token_data [0] == 200) {
			return json_decode ( $token_data [1], TRUE );
		}
		
		return FALSE;
	}
	
	/**
	 * 获取消息发送token授权token
	 *
	 * @param
	 *        	string
	 */
	public function getAccessToken() // 获取access_token
    {
        $data = json_decode(file_get_contents("./access_token.json"));
        if ($data->expire_time < time()) {
            $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" . $this->app_id . "&secret=" . $this->app_secret . "";
            $data = $this->getCurl ( $url );
            $res = json_decode ( $data, true );
            $access_token = $res->access_token;
            if ($access_token) {
                $data->expire_time = time() + 7000;
                $data->access_token = $access_token;
                $fp = fopen("./access_token.json", "w");
                fwrite($fp, json_encode($data));
                fclose($fp);
            }
        } else {
            $access_token = $data->access_token;
        }
        return $access_token;
	}

    //获取用户基本信息(UnionID机制)（包括返回是否关注公众号）
    public function getWxDetailUserInfo($access_token, $openid)
    {
        $url_2 = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" . $access_token . "&openid=" . $openid . "&lang=zh_CN";
        $user_info = json_decode(file_get_contents($url_2));
        return $user_info;
    }
	
	/**
	 * 消息发送
	 *
	 * @param
	 *        	string
	 */
	public function sendmsg($openid, $msg) {
		$accessToken = $this->getAccessToken (); // 获取access_token
		                                        // 内容部分
		$menuPostString = '{
						  "touser":"' . $openid . '",
						  "msgtype": "text",
						  "text":{"content": "' . $msg . '"}
	 }';
		$openidPostUrl = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" . $accessToken;
		$result = $this->dataPost ( $menuPostString, $openidPostUrl );
		return $result;
	}
	
	/**
	 * 远程消息发送
	 *
	 * @param
	 *        	string
	 */
	function dataPost($post_string, $url) { // POST方式提交数据
		$context = array (
				'http' => array (
						'method' => "POST",
						'header' => "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US) \r\n Accept: */*",
						'content' => $post_string 
				) 
		);
		$stream_context = stream_context_create ( $context );
		$data = file_get_contents ( $url, FALSE, $stream_context );
		return $data;
	}
	/**
	 * 获取授权后的微信用户信息
	 *
	 * @param string $access_token        	
	 * @param string $open_id        	
	 */
	public function get_user_info($access_token = '', $open_id = '') {
		if ($access_token && $open_id) {
			$info_url = "https://api.weixin.qq.com/sns/userinfo?access_token={$access_token}&openid={$open_id}&lang=zh_CN";
			$info_data = $this->http ( $info_url );
			
			if ($info_data [0] == 200) {
				return json_decode ( $info_data [1], TRUE );
			}
		}
		
		return FALSE;
	}
	
	/**
	 * 发送微信客服信息接口
	 *
	 * @param string $access_token        	
	 * @param string $open_id        	
	 */
	function getCurl($url) { // get https的内容
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 ); // 不输出内容
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, false );
		$result = curl_exec ( $ch );
		curl_close ( $ch );
		return $result;
	}
	public function http($url, $method, $postfields = null, $headers = array(), $debug = false) {
		$ci = curl_init ();
		curl_setopt ( $ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1 );
		curl_setopt ( $ci, CURLOPT_CONNECTTIMEOUT, 30 );
		curl_setopt ( $ci, CURLOPT_TIMEOUT, 30 );
		curl_setopt ( $ci, CURLOPT_RETURNTRANSFER, true );
		
		switch ($method) {
			case 'POST' :
				curl_setopt ( $ci, CURLOPT_POST, true );
				if (! empty ( $postfields )) {
					curl_setopt ( $ci, CURLOPT_POSTFIELDS, $postfields );
					$this->postdata = $postfields;
				}
				break;
		}
		curl_setopt ( $ci, CURLOPT_URL, $url );
		curl_setopt ( $ci, CURLOPT_HTTPHEADER, $headers );
		curl_setopt ( $ci, CURLINFO_HEADER_OUT, true );
		
		$response = curl_exec ( $ci );
		$http_code = curl_getinfo ( $ci, CURLINFO_HTTP_CODE );
		
		if ($debug) {
			echo "=====post data======\r\n";
			var_dump ( $postfields );
			
			echo '=====info=====' . "\r\n";
			print_r ( curl_getinfo ( $ci ) );
			
			echo '=====$response=====' . "\r\n";
			print_r ( $response );
		}
		curl_close ( $ci );
		return array (
				$http_code,
				$response 
		);
	}
}
?>