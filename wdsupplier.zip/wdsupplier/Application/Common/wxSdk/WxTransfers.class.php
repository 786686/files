<?php
/**
 * Created by PhpStorm.
 * User: fanzhaogui
 * Date: 2019/12/9
 * Time: 17:58
 */

namespace Common\wxSdk;


class WxTransfers
{
    /**
     * 商户ID
     */
    protected $mchid;

    protected $appid;

    protected $appKey;

    protected $apiKey;

    public $data = null;


    private $sslkey_path = '';
    private $sslcert_path = '';

    /**
     * @var 支付结果
     */
    public $responseNode;

    public function __construct(array $config = [])
    {
        if (!empty($config)) {
            $this->mchid        = $config['mchid'];
            $this->appid        = $config['appid'];
            $this->appKey       = $config['appsecret'];
            $this->apiKey       = $config['partnerkey'];
            $this->sslkey_path  = $config['sslkey_path'];
            $this->sslcert_path = $config['sslcert_path'];
        } else {
            $config             = C('wxpay_app');
            $this->mchid        = $config['mchid'];          //微信支付商户号 PartnerID 通过微信支付商户资料审核后邮件发送
            $this->appid        = $config['appid'];          //微信支付申请对应的公众号的APPID
            $this->appKey       = $config['appsecret'];          //微信支付申请对应的公众号的APP Key
            $this->apiKey       = $config['partnerkey'];          //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
            $this->sslkey_path  = $config['sslkey_path'];          //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
            $this->sslcert_path = $config['sslcert_path'];          //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
        }
    }

    /**
     * 通过跳转获取用户的openid，跳转流程如下：
     * 1、设置自己需要调回的url及其其他参数，跳转到微信服务器https://open.weixin.qq.com/connect/oauth2/authorize
     * 2、微信服务处理完成之后会跳转回用户redirect_uri地址，此时会带上一些参数，如：code
     * @return string 用户的openid
     */
    public function GetOpenid()
    {
        //通过code获得openid
        if (!isset($_GET['code'])) {
            //触发微信返回code码
            $scheme  = $_SERVER['HTTPS'] == 'on' ? 'https://' : 'http://';
            $baseUrl = urlencode($scheme . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . $_SERVER['QUERY_STRING']);
            $url     = $this->__CreateOauthUrlForCode($baseUrl);
            Header("Location: $url");
            exit();
        } else {
            //获取code码，以获取openid
            $code   = $_GET['code'];
            $openid = $this->getOpenidFromMp($code);
            return $openid;
        }
    }

    /**
     * 通过code从工作平台获取openid机器access_token
     * @param string $code 微信跳转回来带上的code
     * @return openid
     */
    public function GetOpenidFromMp($code)
    {
        $url = $this->__CreateOauthUrlForOpenid($code);
        $res = self::curlGet($url);
        //取出openid
        $data       = json_decode($res, true);
        $this->data = $data;
        $openid     = $data['openid'];
        return $openid;
    }

    /**
     * 构造获取open和access_toke的url地址
     * @param string $code，微信跳转带回的code
     * @return string 请求的url
     */
    private function __CreateOauthUrlForOpenid($code)
    {
        $urlObj["appid"]      = $this->appid;
        $urlObj["secret"]     = $this->appKey;
        $urlObj["code"]       = $code;
        $urlObj["grant_type"] = "authorization_code";
        $bizString            = $this->ToUrlParams($urlObj);
        return "https://api.weixin.qq.com/sns/oauth2/access_token?" . $bizString;
    }

    /**
     * 构造获取code的url连接
     * @param string $redirectUrl 微信服务器回跳的url，需要url编码
     * @return string 返回构造好的url
     */
    private function __CreateOauthUrlForCode($redirectUrl)
    {
        $urlObj["appid"]         = $this->appid;
        $urlObj["redirect_uri"]  = "$redirectUrl";
        $urlObj["response_type"] = "code";
        $urlObj["scope"]         = "snsapi_base";
        $urlObj["state"]         = "STATE" . "#wechat_redirect";
        $bizString               = $this->ToUrlParams($urlObj);
        return "https://open.weixin.qq.com/connect/oauth2/authorize?" . $bizString;
    }

    /**
     * 拼接签名字符串
     * @param array $urlObj
     * @return string 返回已经拼接好的字符串
     */
    private function ToUrlParams($urlObj)
    {
        $buff = "";
        foreach ($urlObj as $k => $v) {
            if ($k != "sign") $buff .= $k . "=" . $v . "&";
        }
        $buff = trim($buff, "&");
        return $buff;
    }

    /**
     * 企业付款
     * @param string $openid 调用【网页授权获取用户信息】接口获取到用户在该公众号下的Openid
     * @param float $totalFee 收款总费用 单位元
     * @param string $outTradeNo 唯一的订单号
     * @param string $orderName 订单名称
     * @param string $notifyUrl 支付结果通知url 不要有问号
     * @param string $timestamp 支付时间
     * @return string
     */
    public function createJsBizPackage($openid, $totalFee, $outTradeNo, $trueName)
    {
        // success
//        $res              = [];
//        $res['return_code'] = 'SUCCESS';
//        $res['return_msg']  = [
//            'mch_appid'        => 'wxe58848faf19617eb',
//            'mchid'            => '1388613902',
//            'nonce_str'        => 'Y3CpuYS8wlRkJKtO',
//            'result_code'      => 'SUCCESS',
//            'partner_trade_no' => 'wxorder5def1455a65c5',
//            'payment_no'       => '10100144718411912100028916562730',
//            'payment_time'     => '2019-12-10 11:44:20',
//        ];
//
//        // error
//        $res = [
//            'return_code' => 'SUCCESS',
//            'return_msg' => '支付失败',
//            'mch_appid' => 'wxe58848faf19617eb',
//            'mchid' => '1388613902',
//            'result_code' => 'FAIL',
//            'err_code' => 'AMOUNT_LIMIT',
//            'err_code_des' => '付款金额超出限制。低于最小金额1.00元或累计超过5000.00元。',
//        ];
//
//        return $res;


        $config          = array(
            'mch_id' => $this->mchid,
            'appid'  => $this->appid,
            'key'    => $this->apiKey,
        );

        // uat 环境
        $amount = intval(1 * 100);

        if (C('wechat_transfer_env') == 2) {
            $amount = intval($totalFee * 100);
        }

        $unified         = array(
            'mch_appid'        => $config['appid'],
            'mchid'            => $config['mch_id'],
            'nonce_str'        => self::createNonceStr(),
            'openid'           => $openid,
            'check_name'       => 'NO_CHECK',        //校验用户姓名选项。NO_CHECK：不校验真实姓名，FORCE_CHECK：强校验真实姓名
            're_user_name'     => $trueName,         //收款用户真实姓名（不支持给非实名用户打款）
            'partner_trade_no' => $outTradeNo,
            'spbill_create_ip' => '127.0.0.1',
            'amount'           => $amount,       //单位 转为分
            'desc'             => '创课网店转出',            //企业付款操作说明信息
        );
        $unified['sign'] = self::getSign($unified, $config['key']);
        $responseXml     = $this->curl_post_ssl('https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers', self::arrayToXml($unified));
        $unifiedOrder    = simplexml_load_string($responseXml, 'SimpleXMLElement', LIBXML_NOCDATA);

        // 结果
        if ($unifiedOrder === false) {
            log2File($unified, 'wechat_transfer_failed_');
            // die('parse xml error');
            return false;
        }
        if ($unifiedOrder->return_code != 'SUCCESS') {
            log2File($unified, 'wechat_transfer_failed_');
            log2File($unifiedOrder, 'wechat_transfer_failed_');
            // die($unifiedOrder->return_msg);
            return false;
        }
        if ($unifiedOrder->result_code != 'SUCCESS') {
            log2File($unified, 'wechat_transfer_failed_');
            log2File($unifiedOrder, 'wechat_transfer_failed_');
            // die($unifiedOrder->err_code);
            return false;
        }
        log2File($unified, 'wechat_transfer_successed_');
        log2File($unifiedOrder, 'wechat_transfer_successed_');
        $this->responseNode = $unifiedOrder;
        return true;
    }


    public static function curlGet($url = '', $options = array())
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        if (!empty($options)) {
            curl_setopt_array($ch, $options);
        }
        //https请求 不验证证书和host
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }


    /***
     * 生成订单编号
     * @return <string>
     */
    private function order_sn()
    {
        return date('Ymd') .
            sprintf('%06d',
                (float)microtime() * 1000000) . mt_rand(100, 999)

            . sprintf('%03d', (int)$this->logininfo['id'] % 1000
            );
    }

    public function curl_post_ssl($url, $vars, $second = 30, $aHeader = array())
    {
        $ch = curl_init();
        //超时时间
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        //这里设置代理，如果有的话
        //curl_setopt($ch,CURLOPT_PROXY, '10.206.30.98');
        //curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        //以下两种方式需选择一种

        //第一种方法，cert 与 key 分别属于两个.pem文件
        //默认格式为PEM，可以注释
        curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
        curl_setopt($ch, CURLOPT_SSLCERT, getcwd() . '/Application/Common/Conf/cert/cert_wanxun/apiclient_cert.pem');//本地用
//        curl_setopt($ch, CURLOPT_SSLCERT, './public/apiclient_cert.pem');//服务器用

        //默认格式为PEM，可以注释
        curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
        curl_setopt($ch, CURLOPT_SSLKEY, getcwd() . '/Application/Common/Conf/cert/cert_wanxun/apiclient_key.pem');//本地用
//        curl_setopt($ch, CURLOPT_SSLKEY, './public/apiclient_key.pem');//服务器用

        //第二种方式，两个文件合成一个.pem文件
//        curl_setopt($ch,CURLOPT_SSLCERT,getcwd().'/all.pem');

        if (count($aHeader) >= 1) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $aHeader);
        }

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30); //设置cURL允许执行的最长秒数

        $data = curl_exec($ch);
        if ($data === false) {
            $err = 'Curl error: ' . curl_error($ch);
            curl_close($ch);
            log2File($err, 'wechat_transfer_curl_err');
            return false;
        }
        curl_close($ch);
        return $data;
    }

    // 生成随机字符串
    public static function createNonceStr($length = 16)
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $str   = '';
        for ($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }


    public static function arrayToXml($arr)
    {
        $xml = "<xml>";
        foreach ($arr as $key => $val) {
            if (is_numeric($val)) {
                $xml .= "<" . $key . ">" . $val . "</" . $key . ">";
            } else
                $xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
        }
        $xml .= "</xml>";
        return $xml;
    }

    public static function getSign($params, $key)
    {
        ksort($params, SORT_STRING);
        $unSignParaString = self::formatQueryParaMap($params, false);
        $signStr          = strtoupper(md5($unSignParaString . "&key=" . $key));
        return $signStr;
    }


    protected static function formatQueryParaMap($paraMap, $urlEncode = false)
    {
        $buff = "";
        ksort($paraMap);
        foreach ($paraMap as $k => $v) {
            if (null != $v && "null" != $v) {
                if ($urlEncode) {
                    $v = urlencode($v);
                }
                $buff .= $k . "=" . $v . "&";
            }
        }
        $reqPar = '';
        if (strlen($buff) > 0) {
            $reqPar = substr($buff, 0, strlen($buff) - 1);
        }
        return $reqPar;
    }

    /**
     * 订单号状态
     * @author: fanzhaogui
     * @date xxx
     * @param $openid
     * @param $info
     * @return \SimpleXMLElement
     */
    public function gettransferinfo($info)
    {
        $unified         = array(
            'nonce_str'        => self::createNonceStr(),
            'partner_trade_no' => $info['log_number'],// 可用于测试 ： 已支付成功 '201912111858315688185827'  支付失败过 202001050716467165568103
            'appid'            => $this->appid,
            'mch_id'           => $this->mchid,
        );
        $unified['sign'] = self::getSign($unified, $this->apiKey);
        $responseXml     = $this->curl_post_ssl('https://api.mch.weixin.qq.com/mmpaymkttransfers/gettransferinfo', self::arrayToXml($unified));
        $unifiedOrder    = simplexml_load_string($responseXml, 'SimpleXMLElement', LIBXML_NOCDATA);
        /*successs 返回的结果*/
        /*
        appid: "wxe58848faf19617eb"
        desc: "创课网店转出"
        detail_id: "10100144718411912110062000523730"
        mch_id: "1388613902"
        openid: "oc6J055l9sEC4U5H8HR5eGia4E6U"
        partner_trade_no: "201912111858315688185827"
        payment_amount: "100"
        payment_time: "2019-12-11 18:58:58"
        reason: {}
        result_code: "SUCCESS"
        return_code: "SUCCESS"
        status: "SUCCESS"
        transfer_name: {}
        transfer_time: "2019-12-11 18:58:58"
        */

        /*fail*/
        /*
        appid: "wxe58848faf19617eb"
        err_code: "NOT_FOUND"
        err_code_des: "指定单号数据不存在"
        mch_id: "1388613902"
        partner_trade_no: "202001031631478300027905"
        result_code: "FAIL"
        return_code: "SUCCESS"
        return_msg: "指定单号数据不存在"
        */
        return $unifiedOrder;
    }


    public function orderquery($info)
    {
        $unified         = array(
            'appid'            => $this->appid,
            'mch_id'           => $this->mchid,
            'nonce_str'        => self::createNonceStr(),
            'out_trade_no'   => $info['pay_sn'],// 可用于测试 ： 已支付成功 '201912111858315688185827'  支付失败过 202001050716467165568103
        );
        $unified['sign'] = self::getSign($unified, $this->apiKey);
        $responseXml     = $this->curl_post_ssl('https://api.mch.weixin.qq.com/pay/orderquery', self::arrayToXml($unified));
        $unifiedOrder    = simplexml_load_string($responseXml, 'SimpleXMLElement', LIBXML_NOCDATA);
        /*successs 返回的结果*/
        /*
        appid: "wxe58848faf19617eb"
        desc: "创课网店转出"
        detail_id: "10100144718411912110062000523730"
        mch_id: "1388613902"
        openid: "oc6J055l9sEC4U5H8HR5eGia4E6U"
        partner_trade_no: "201912111858315688185827"
        payment_amount: "100"
        payment_time: "2019-12-11 18:58:58"
        reason: {}
        result_code: "SUCCESS"
        return_code: "SUCCESS"
        status: "SUCCESS"
        transfer_name: {}
        transfer_time: "2019-12-11 18:58:58"
        */

        /*fail*/
        /*
        appid: "wxe58848faf19617eb"
        err_code: "NOT_FOUND"
        err_code_des: "指定单号数据不存在"
        mch_id: "1388613902"
        partner_trade_no: "202001031631478300027905"
        result_code: "FAIL"
        return_code: "SUCCESS"
        return_msg: "指定单号数据不存在"
        */
        return $unifiedOrder;
    }
}