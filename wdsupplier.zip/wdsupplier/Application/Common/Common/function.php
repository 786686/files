<?php
/**
 * 生成随机字符串
 * @param int $length  生成长度
 * @param int $numeric  0 有英文 、 1 纯数字
 * @return string
 */
function random($length, $numeric = 0) {
	$seed = base_convert(md5(microtime().$_SERVER['DOCUMENT_ROOT']), 16, $numeric ? 10 : 35);
	$seed = $numeric ? (str_replace('0', '', $seed).'012340567890') : ($seed.'zZ'.strtoupper($seed));
	if ($numeric) {
		$hash = '';
	} else {
		$hash = chr(rand(1, 26) + rand(0, 1) * 32 + 64);
		$length--;
	}
	$max = strlen($seed) - 1;
	for ($i = 0; $i < $length; $i++) {
		$hash .= $seed{mt_rand(0, $max)};
	}
	return $hash;
}

/**
 * 递归创建目录
 * @param string $dir
 * @return bool
 */
function mkDirs($dir){
    if(!is_dir($dir)){
        if(!mkDirs(dirname($dir))){
            return false;
        }
        if(!mkdir($dir,0777)){
            return false;
        }
    }
    return true;
}

/**
 * 检查密码长度是否符合规定，密码长度6-16位
 *
 * @param STRING $password
 * @return 	TRUE or FALSE
 */
function is_password($password) {
	if (preg_match("/^[a-zA-Z0-9]{6,20}$/",$password)) {
		return true;
	}else{
		return false;
	}
	
}

/**
 * 检测输入中是否含有不允许的特殊字符
 *
 * @param char $string 要检查的字符串名称
 * @return TRUE or FALSE
 */
function is_badword($string) {
	$badwords = array("\\",'&',' ',"'",'"','/','*',',','<','>',"\r","\t","\n","#");
	foreach ($badwords as $value) {
		if (strpos($string, $value) !== FALSE) {
			return TRUE;
		}
	}
	return FALSE;
}

/**
 * 检查用户名是否符合规定（ 3-20位英文数字组成）
 *
 * @param STRING $username 要检查的用户名
 * @return 	TRUE or FALSE
 */
function is_username($username) {
	$strlen = strlen($username);
	if (is_badword($username) || !preg_match("/^[a-zA-Z0-9_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]+$/", $username)) {
		return false;
	} elseif ( 20 < $strlen || $strlen < 3 ) {
		return false;
	}
	return true;
}

/**
 * 邮箱合法校验
 * @param string $email 待验证邮箱
 * @return boolean 合法返回True,否则返回false
 */
function is_email($email){
	if (!$email || !is_string($email)) {
		return false;
	}
	$preg = '/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([_a-z0-9]+\.)+[a-z]{2,5}$/';
	return preg_match($preg,$email)?true:false;
}

/**
 * 手机号码校验
 * @param string $mobile 待验证手机号码
 * @return boolean 合法返回True,否则返回false
 */
function is_mobile($mobile){
	if(!$mobile || !is_numeric($mobile)){
		return false;
	}
    $preg = '/^((\(\d{2,3}\))|(\d{3}\-))?1\d{10}$/';
	return preg_match($preg,$mobile)?true:false;
}


/**
 * URL合法校验(常见域名)
 * @param string $url 待验证URL
 * @return boolean 合法返回True,否则返回false
 */
function is_url($url){
	if(!$url || !is_string($url)){
		return false;
	}
	$preg = '/^(http[s]?:)?(\/{2})?([a-z0-9]+\.)?([a-z0-9]+\.)?([a-z0-9]+\.)?([a-z0-9]+\.)?[a-z0-9]+(\.(com|cn|me|info|co|so|net\.cn|org\.cn|biz|name|tv|asia|tel|mobi|cc|hk|xin|io|org|net|com\.cn))+(.*)$/i'; // 可允许4级
	return preg_match($preg,$url)?true:false;
}

/**
 * kineditor内部排序(该函数非外部调用)
 * @param unknown $a
 * @param unknown $b
 * @return number
 */
function kineditor_cmp_func($a, $b) {
	// name or size or type
	$order = $GLOBALS['kindeditor_order']?$GLOBALS['kindeditor_order']:'name';

	if ($a['is_dir'] && !$b['is_dir']) {
		return -1;
	} else if (!$a['is_dir'] && $b['is_dir']) {
		return 1;
	} else {
		if ($order == 'size') {
			if ($a['filesize'] > $b['filesize']) {
				return 1;
			} else if ($a['filesize'] < $b['filesize']) {
				return -1;
			} else {
				return 0;
			}
		} else if ($order == 'type') {
			return strcmp($a['filetype'], $b['filetype']);
		} else {
			return strcmp($a['filename'], $b['filename']);
		}
	}
}

/**
 * 遍历获取目录下的指定类型的文件（ueditor内部调用）
 * @param $path
 * @param array $files
 * @return array
 */
function ueditor_getfiles($path, $allowFiles, &$files = array()) {
	if (!is_dir($path)) return null;
	if(substr($path, strlen($path) - 1) != '/') $path .= '/';
	$handle = opendir($path);
	while (false !== ($file = readdir($handle))) {
		if ($file != '.' && $file != '..') {
			$path2 = $path . $file;
			if (is_dir($path2)) {
				ueditor_getfiles($path2, $allowFiles, $files);
			} else {
				if (preg_match("/\.(".$allowFiles.")$/i", $file)) {
					$files[] = array(
						'url'=> substr($path2, strlen($_SERVER['DOCUMENT_ROOT'])),
						'mtime'=> filemtime($path2)
					);
				}
			}
		}
	}
	return $files;
}

/**
 * 获取省份
 */
function get_province(){
	$province = S('province');
	if (empty($province)) {
		$province = M('Area')->cache(true)->where(array('area_parent_id'=>0))->order('area_sort asc,area_id asc')->select();
		S('province',$province);
	}
	return $province;
}

/**
 * 获取市
 */
function get_city($province = 0){
	if (!$province) {
		return false;
	}
	$city = S('city_'.$province);
	if (empty($city)) {
		$city = M('Area')->cache(true)->where(array('area_parent_id'=>$province))->order('area_sort asc,area_id asc')->select();
		S('city_'.$province,$city);
	}
	return $city;
}

/**
 * 获取县/区
 */
function get_county($city = 0){
	if (!$city) {
		return false;
	}
	$county = S('county_'.$city);
	if (empty($county)) {
		$county = M('Area')->cache(true)->where(array('area_parent_id'=>$city))->order('area_sort asc,area_id asc')->select();
		S('county_'.$city,$county);
	}
	return $county;
}

/**
 * 获取乡/镇
 */
function get_town($district = 0){
	if (!$district) {
		return false;
	}
	$town = S('town_'.$district);
	if (empty($town)) {
		$town = M('Area')->cache(true)->where(array('area_parent_id'=>$district))->order('area_id asc')->select();
		S('town_'.$district,$town);
	}
	return $town;
}
/**
 * 获取乡/镇
 */
function get_village($town_id = 0){
    if (!$town_id) {
        return false;
    }
    $village = S('village_'.$town_id);
    if (empty($village)) {
        $village = M('Area')->cache(true)->where(array('area_parent_id'=>$town_id))->order('area_id asc')->select();
        S('village_'.$town_id,$village);
    }
    return $village;
}

/**
 * 获取乡/镇
 */
function get_village_child($village_id = 0){
    if (!$village_id) {
        return false;
    }
    $village_child = S('village_child_'.$village_id);
    if (empty($village_child)) {
        $village_child = M('Area')->cache(true)->where(array('area_parent_id'=>$village_id))->order('area_id asc')->select();
        S('village_'.$village_id,$village_child);
    }
    return $village_child;
}

/**
 * 获取村委
 */
function get_point($town = 0){
	if (!$town) {
		return false;
	}
	$point = S('point_'.$town);
	if (empty($point)) {
		$point = M('Point')->cache(true)->where(array('area_id'=>$town))->order('point_id asc')->select();
		S('point_'.$town,$point);
	}
	return $point;
}

/**
 * 获取村委
 */
function get_point2($point = 0){
	if (!$point) {
		return false;
	}
	$point2 = S('point2_'.$point);
	if (empty($point)) {
		$point2 = M('Point')->cache(true)->where(array('point_parent_id'=>$point2))->order('point_id asc')->select();
		S('point2_'.$point,$point2);
	}
	return $point2;
}

/**
 * 判断字符串中是否含有中文
 * @param string $str 待检测字符串
 * @return bool
 */
function check_chinese($str) {
	if (preg_match('/^[A-Za-z0-9]+$/', $str)) {
		return true;
	} else {
		return false;
	}
}

/**
 * 判断字符串中是否只是英文数字
 * @param string $str 待检测字符串
 * @return bool
 */
function is_english($str) {
	if (preg_match('/^[A-Za-z0-9]+$/', $str)) {
		return true;
	}else{
		return false;
	}
}


/**
 * 调试性输出字符或数组
 * @param mix $data 打印输出的内容
 * @param int  $type 0-echo输出字符串，print_r输出数组，否则使用var_dump打印字符串/数组
 * @param bool $pre true格式化输出
 * @param bool $break true输出内容后exit中断程序
 */
function p($data,$type=0,$pre=true,$break=true){

	if(is_string($data) || is_int($data)){

		if($type == 0){
			echo $data;
		}else{
			var_dump($data);
		}

	}else if(is_array($data)){

		if($pre){
			echo '<pre>';
			if($type == 0){
				print_r($data);
			}else{
				var_dump($data);
			}
			echo '</pre>';
		}else{
			if($type == 0){
				print_r($data);
			}else{
				var_dump($data);
			}
		}

	}else{
		if($pre){
			echo '<pre>';
			if($type == 0){
				print_r($data);
			}else{
				var_dump($data);
			}
			echo '</pre>';
		}else{
			if($type == 0){
				print_r($data);
			}else{
				var_dump($data);
			}
		}
	}

	if($break){
		exit();
	}
}

/**
 * 读取xml格式. XML转数组
 * @param string $xml XML文档
 * @return array
 */
function xml_to_array($xml) {
	$reg = "/<(\w+)[^>]*>([\\x00-\\xFF]*)<\\/\\1>/";
	if(preg_match_all($reg, $xml, $matches)){
		$count = count($matches[0]);
		for($i = 0; $i < $count; $i++){
		$subxml= $matches[2][$i];
		$key = $matches[1][$i];
			if(preg_match( $reg, $subxml )){
				$arr[$key] = xml_to_array( $subxml );
			}else{
				$arr[$key] = $subxml;
			}
		}
	}
	return $arr;
}


/**
 * 判断是否微信浏览器
 * @return boolean
 */
function is_weixin() {
	if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ) {
		return true;
	}
	return false;
}

/**
 * 将全角字符转换为相应半角字符
 * @param   string $str 待转换字串
 * @return  string $str 处理后字串
 */
function make_semiangle($str) {
	$arr = array('０' => '0', '１' => '1', '２' => '2', '３' => '3', '４' => '4',
			'５' => '5', '６' => '6', '７' => '7', '８' => '8', '９' => '9',
			'Ａ' => 'A', 'Ｂ' => 'B', 'Ｃ' => 'C', 'Ｄ' => 'D', 'Ｅ' => 'E',
			'Ｆ' => 'F', 'Ｇ' => 'G', 'Ｈ' => 'H', 'Ｉ' => 'I', 'Ｊ' => 'J',
			'Ｋ' => 'K', 'Ｌ' => 'L', 'Ｍ' => 'M', 'Ｎ' => 'N', 'Ｏ' => 'O',
			'Ｐ' => 'P', 'Ｑ' => 'Q', 'Ｒ' => 'R', 'Ｓ' => 'S', 'Ｔ' => 'T',
			'Ｕ' => 'U', 'Ｖ' => 'V', 'Ｗ' => 'W', 'Ｘ' => 'X', 'Ｙ' => 'Y',
			'Ｚ' => 'Z', 'ａ' => 'a', 'ｂ' => 'b', 'ｃ' => 'c', 'ｄ' => 'd',
			'ｅ' => 'e', 'ｆ' => 'f', 'ｇ' => 'g', 'ｈ' => 'h', 'ｉ' => 'i',
			'ｊ' => 'j', 'ｋ' => 'k', 'ｌ' => 'l', 'ｍ' => 'm', 'ｎ' => 'n',
			'ｏ' => 'o', 'ｐ' => 'p', 'ｑ' => 'q', 'ｒ' => 'r', 'ｓ' => 's',
			'ｔ' => 't', 'ｕ' => 'u', 'ｖ' => 'v', 'ｗ' => 'w', 'ｘ' => 'x',
			'ｙ' => 'y', 'ｚ' => 'z',
			'（' => '(', '）' => ')', '〔' => '[', '〕' => ']', '【' => '[',
			'】' => ']', '〖' => '[', '〗' => ']', '“' => '[', '”' => ']',
			'‘' => '[', '’' => ']', '｛' => '{', '｝' => '}', '《' => '<',
			'》' => '>',
			'％' => '%', '＋' => '+', '—' => '-', '－' => '-', '～' => '-',
			'：' => ':', '。' => '.', '、' => ',', '，' => '.', '、' => '.',
			'；' => ',', '？' => '?', '！' => '!', '…' => '-', '‖' => '|',
			'”' => '"', '’' => '`', '‘' => '`', '｜' => '|', '〃' => '"',
			'　' => ' ');

	return strtr($str, $arr);
}


/**
 * 获取供应商导航菜单
 */
function get_menu() {
    $key = 'supplier:menu';
    $menu = \Common\Lib\Redis\Redis::getInstance()->get($key);
    if (empty($menu)) {
        $menuModel = M('SupplierMenu');
        $menu = $menuModel->where(array('parent_menu_id'=>0))->order('sort ASC, menu_id asc')->select();
        if (!empty($menu)) {
            foreach ($menu as $k=>$v) {
                $menu[$k]['_child'] = $menuModel->where(array('parent_menu_id'=>$v['menu_id']))->order('sort ASC,menu_id asc')->select();
            }

            // 存在数据，缓存 7200s 两个小时
            \Common\Lib\Redis\Redis::getInstance()->set($key, $menu, 7200);
        } else {
            // 查不出数据，缓存60s
            \Common\Lib\Redis\Redis::getInstance()->set($key, $menu, 60);
        }

    } else {
        $menu = json_decode($menu, true);
    }

    return $menu;
}


/**
 * 字符串加密、解密函数
 *
 * @param	string	$string		字符串
 * @param	string	$operation	ENCODE为加密，DECODE为解密，可选参数，默认为ENCODE，
 * @param	string	$key		密钥：数字、字母、下划线
 * @param	int	$expiry		过期时间
 * @return	string
 */
function sys_auth($string, $operation = 'ENCODE', $key = '', $expiry = 0) {
	$ckey_length = 4;
	$key = md5($key != '' ? $key : 'i7z1kjOffx4fr$LoxOw*WfCcwX3&c*jk');
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);

	$string = $operation == 'DECODE' ? base64_decode(strtr(substr($string, $ckey_length), '-_', '+/')) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
	$string_length = strlen($string);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if($operation == 'DECODE') {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc.rtrim(strtr(base64_encode($result), '+/', '-_'), '=');
	}
}

/**
 * 价格格式化
 *
 * @param int	$price
 * @return string	$price_format
 */
function price_format($price) {
	$price_format	= number_format($price,2,'.','');
	return $price_format;
}

/**
 * 时间转化函数
 *
 * @param $now
 * @param $datetemp
 * @param $dstr
 * @return string
 */
function smart_date($datetemp, $dstr = 'Y-m-d H:i') {
	$timezone = C('timezone');
	$op = '';
	$sec = time() - $datetemp;
	$hover = floor($sec / 3600);
	if ($hover == 0) {
		$min = floor($sec / 60);
		if ($min == 0) {
			$op = $sec . ' 秒前';
		} else {
			$op = "$min 分钟前";
		}
	} elseif ($hover < 24) {
		$op = "约 {$hover} 小时前";
	} else {
		$op = gmdate($dstr, $datetemp + $timezone * 3600);
	}
	return $op;
}



/**
 * 手机电话号码隐藏
 *
 * @param $phone
 * @return mixed
 */
function hidtel($phone){
	$IsWhat = preg_match('/(0[0-9]{2,3}[\-]?[2-9][0-9]{6,7}[\-]?[0-9]?)/i',$phone); //固定电话
	if($IsWhat == 1){
		return preg_replace('/(0[0-9]{2,3}[\-]?[2-9])[0-9]{3,4}([0-9]{3}[\-]?[0-9]?)/i','$1****$2',$phone);
	}else{
		return  preg_replace('/(1[358]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$phone);
	}
}


/**
 * 检查并获取 来源设备
 * @return init	设备ID
 */
function checkDevice()
{
	/*
	DEVICE
		PC		: 1
		WAP		: 2
		ANDROID	: 3
		IOS		: 4
		WECHAT	: 5
	 */
	$device = 1;	// PC - Default
	if (strpos($_SERVER["HTTP_USER_AGENT"],"MicroMessenger")) {
		$device = 5;
	} elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')) {
		$device = 4;
	} elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Android')||$_SERVER['HTTP_USER_AGENT']=='Android') {
		$device = 3;
	}
	return $device;
}

/**
 * 计算两个经纬度坐标的距离
 * @param  float $lat1 坐标一.经度
 * @param  float $lng1 坐标一.纬度
 * @param  float $lat2 坐标二.经度
 * @param  float $lng2 坐标二.纬度
 * @return float	距离(米)
 */
function getDistance($lat1, $lng1, $lat2, $lng2){

	$r_lat1 = M_PI * $lat1 / 180;
	$r_lng1 = M_PI * $lng1 / 180;

	$r_lat2 = M_PI * $lat2 / 180;
	$r_lng2 = M_PI * $lng2 / 180;

	return 6370996.81 * acos(sin($r_lat1) * sin($r_lat2) + cos($r_lat1) * cos($r_lat2) * cos($r_lng2 - $r_lng1));
}

/**
 * 电话打码
 * @author deason 2016-09-19
 * @return 返回打码后的号码
 */
function phoneMask($phone)
{
	return is_string($phone) && $phone ? preg_replace('/(?<=.{3})(.+)(?=.{2})/', '***', $phone) : $phone;
}

/**
 * 文件大小单位转换
 * @param $size
 * @param string $space
 * @return string
 */
function format_bytes($size,$space=' ') {
	$units = array('B', 'KB', 'MB', 'GB', 'TB');
	for ($i = 0; $size >= 1024 && $i < 4; $i++) {
		$size /= 1024;
	}
	return round($size, 2).$space.$units[$i];
}

/**
 * 身份证校验
 * @author deason 2017-01-22
 * @param  string  $idcard 身份证号码
 * @return boolean         是否正确
 */
function is_idcard($idcard)
{
	// 长度
	$lenth = strlen($idcard);
	if ($lenth != 15 && $lenth != 18) {
		return false;
	}

	// 正则校验
	$regex = '/^((\d{8})(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|30|31)(\d{3})|(\d{6})(18|19|20)(\d{2})(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|30|31)(\d{3})([\d|X|x]))$/';
	if (preg_match($regex, $idcard)) {
		if ($lenth == 18) {
			// 18位 末位校验
			$factor = array(7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2);
			$amass = 0;
			for ($i = 0; $i < 17; $i++) { 
				$amass += $idcard[$i] * $factor[$i];
			}
			$check = (12 - ($amass % 11)) % 11;
			// printf("idcard %s[%s] check is [%s]\n", substr($idcard, 0, 17), substr($idcard, 17, 1),($check == 10 ? 'X' : $check));
			if ($check == $idcard[17] || ($check == 10 && strcasecmp('X', $idcard[17]) == 0)) {
				return true;
			}
			return false;
		}
		return true;
	}
	return false;
}

/**
 * 阿里大鱼短信发送
 *
 * @param $rec_num 发送手机号
 * @param $sms_template_code  短信模板id
 * @param $sms_free_sign_name 短信签名
 * @param string $sms_param   短信模板变量（json）
 * @param string $extend      公共参数返回值
 * @param string $sms_type    短信类型
 */
function alidayu_sms_num_send_old($rec_num,$sms_template_code,$sms_free_sign_name,$sms_param='',$extend='',$sms_type='normal')
{
    /*fanzhaogui 20200324 替换为下面的函数发送 */
    return alidayu_sms_num_send($rec_num, $sms_template_code, $sms_free_sign_name, $sms_param, $extend, $sms_type);
}


/**
 * 阿里大鱼短信发送
 *
 * @param $rec_num 发送手机号
 * @param $sms_template_code  短信模板id
 * @param $sms_free_sign_name 短信签名
 * @param string $sms_param   短信模板变量（json）
 * @param string $extend      公共参数返回值
 * @param string $sms_type    短信类型
 */
function alidayu_sms_num_send($rec_num,$sms_template_code,$sms_free_sign_name,$sms_param='',$extend='',$sms_type='normal')
{
//print_r($sms_template_code);exit();
	if (empty($rec_num) || !is_mobile($rec_num)) {
		return false;
	}
	if (!C('alidayu.switch')) {
		return true;
	}
    $sms_free_sign_name = C('alidayu.App_Sign');
	require_once dirname(__DIR__) . '/Service/SendMsg.php';

	return (new Common\Service\SendMsg)->sendSms( $rec_num,$sms_template_code,$sms_free_sign_name ,$sms_param );
}

/**
 * 创建前端用户密码
 * @param $username 用户名
 * @param $password 用户密码
 * @return string
 */
function create_password($salt,$password)
{
    return (!empty($salt))?md5($salt. md5($password)):md5($password);
}




/**
 * 取汉字的第一个字的首字母
 * @param type $str
 * @return string|null
 */
function _getFirstCharter($str){
    if(empty($str)){return '';}
    $fchar=ord($str{0});
    if($fchar>=ord('A')&&$fchar<=ord('z')) return strtoupper($str{0});
    $s1=iconv('UTF-8','gb2312',$str);
    $s2=iconv('gb2312','UTF-8',$s1);
    $s=$s2==$str?$s1:$str;
    $asc=ord($s{0})*256+ord($s{1})-65536;
    if($asc>=-20319&&$asc<=-20284) return 'A';
    if($asc>=-20283&&$asc<=-19776) return 'B';
    if($asc>=-19775&&$asc<=-19219) return 'C';
    if($asc>=-19218&&$asc<=-18711) return 'D';
    if($asc>=-18710&&$asc<=-18527) return 'E';
    if($asc>=-18526&&$asc<=-18240) return 'F';
    if($asc>=-18239&&$asc<=-17923) return 'G';
    if($asc>=-17922&&$asc<=-17418) return 'H';
    if($asc>=-17417&&$asc<=-16475) return 'J';
    if($asc>=-16474&&$asc<=-16213) return 'K';
    if($asc>=-16212&&$asc<=-15641) return 'L';
    if($asc>=-15640&&$asc<=-15166) return 'M';
    if($asc>=-15165&&$asc<=-14923) return 'N';
    if($asc>=-14922&&$asc<=-14915) return 'O';
    if($asc>=-14914&&$asc<=-14631) return 'P';
    if($asc>=-14630&&$asc<=-14150) return 'Q';
    if($asc>=-14149&&$asc<=-14091) return 'R';
    if($asc>=-14090&&$asc<=-13319) return 'S';
    if($asc>=-13318&&$asc<=-12839) return 'T';
    if($asc>=-12838&&$asc<=-12557) return 'W';
    if($asc>=-12556&&$asc<=-11848) return 'X';
    if($asc>=-11847&&$asc<=-11056) return 'Y';
    if($asc>=-11055&&$asc<=-10247) return 'Z';
    return null;
}

/**
 * 写入文件
 * @param $fp
 * @param $string
 * @return int
 */
function fwrite_stream($fp, $string)
{
    $strlen = strlen($string);
    for ($written = 0; $written < $strlen; $written += $fwrite) {
        $fwrite = fwrite($fp, substr($string, $written));
        if ($fwrite === false) {
            return $written;
        }
    }
    return $written;
}


/**
 * 系统校验签名响应码说明
 * @param $code
 * @return mixed
 */
function get_response_msg($code)
{
    $response_msg = array(
        '0'=>'系统错误',
        '1'=>'请求成功',
        '40001'=>'未指定appKey',
        '40002'=>'无效appKey',
        '40003'=>'无效的时间参数',
        '40004'=>'请求没有签名参数',
        '40005'=>'签名校验失败',
        '40006'=>'未指定请求的Api方法',
        '40007'=>'请求非法的Api方法',
        '40008'=>'没有指定api协议版本',
        '40009'=>'api协议版本不合法',
        '40010'=>'api协议版本已弃用',
        '40011'=>'请求的Api方法不在访问范围内',
        '40012'=>'HTTP请求的类型错误',
        '40100'=>'请求的Api方法应用级输入参数错误',
        '50000'=>'请求方法时业务逻辑发生错误',
        '50001'=>'未指定api_token',
        '50002'=>'无效的api_token',
        '50005'=>'api_token超过有效期,重新获取',
    );

    return $response_msg[$code];
}

/**
 * 判断是否合法的时间格式
 * @param $dateString
 * @return bool
 */
function is_date($dateString) {
    return strtotime(date('Y-m-d H:i:s', strtotime($dateString))) === strtotime( $dateString );
}

function log_erro($msg)
{
    $content = date("Y-m-d H:i:s",time()).PHP_EOL."文件".__FILE__ . "行：".__LINE__ . PHP_EOL;
    $fp = fopen("log_erro.txt","a");
    flock($fp, LOCK_EX) ;
    fwrite($fp,"执行日期：".strftime("%Y%m%d%H%M%S",time())."\r\n".$content.$msg."\r\n"."\r\n"." ");
    flock($fp, LOCK_UN);
    fclose($fp);
    $len = filesize("log_erro.txt");
    if($len > 10240)
    {
        @unlink("log_erro.txt");
    }
}

/*
 * 生成apitoken
 * param $length长度
 */
function createApiToken($length = 32)
{

    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $ApiToken= '';
    for ($i = 0; $i < $length; $i++) {

        $ApiToken .= $chars[mt_rand(0, strlen($chars) - 1)];
    }
    return $ApiToken;
}

//获取微信Openid
function getOpenID() {
    $jsApi = new \Common\wxSdk\JsApi_pub();
    if (! isset ( $_GET ['code'] )) {
        // 触发微信返回code码
        //$url = $jsApi->createOauthUrlForCode (\Common\wxSdk\WxPayConf_pub::JS_API_CALL_URL.$_SERVER['REQUEST_URI']);
        $url = $jsApi->createOauthUrlForCode (C('WEBSITE_URL').$_SERVER['REQUEST_URI']);
        Header ( "Location: $url" );
    } else {
        // 获取code码，以获取openid
        $code = $_GET ['code'];
        $_SESSION ['code'] = $code;

        $jsApi->setCode ( $code );
        $data = $jsApi->getOpenId ();
    }
    return $data;
}


/**
 * 按指定宽度或高度等比缩放图片
 * \Think\Image::IMAGE_THUMB_SCALE
 * @author deason 2017-05-11
 * @param  mixed   $images    图片保存(相对)路径 (单张或多张)
 * @param  integer $width     剪裁缩略宽度
 * @param  integer $height    剪裁缩略高度
 * @return [type]             [description]
 */
function thumbImage($images, $width = 350, $height = 0)
{
    if (empty(intval($width)) && empty(intval($height))) {
        return $images;
    }
    // {原图片名}@{宽}x{高}.{原后缀} : '%s@%dx%d.%s'
    // 如果是数组则遍历递归一次
    if (is_array($images)) {
        $imageList = array();
        foreach ($images as $image) {
            $imageList[] = thumbImage($image, $width, $height);
        }
        return  $imageList;
    }

    $imagePath = WEB_ROOT . $images;
    // 不存在则不理会
    if (!file_exists($imagePath) && getimagesize($imagePath) === false) {
        return $images;
    }
    $imageInfo = pathinfo($images);
    $imageObj = new \Think\Image();
    $imageObj->open($imagePath);
    // 无指定"宽或高"则默认为[原]"宽或高"
    $thumbImage = sprintf(
        '%s/%s@%sx%s.%s',
        $imageInfo['dirname'],
        $imageInfo['filename'],
        $width ?: 'AUTO',
        $height ?: 'AUTO',
        $imageInfo['extension']
        );
    $thumbPath = WEB_ROOT . $thumbImage;
    if (file_exists($thumbPath)) {
        return $thumbImage;
    }
    $widthOri = $imageObj->width();
    $heightOri = $imageObj->width();
    if ($width && $width >= $widthOri) {
    	return $images;
    }
    if ($height && $height >= $heightOri) {
    	return $images;
    }
    $width = $width ?: $widthOri;
    $height = $height ?: $heightOri;
    // 裁剪缩略图并保存
    $imageObj->thumb($width, $height, \Think\Image::IMAGE_THUMB_SCALE)->save($thumbPath);
    // 成功返回结果
    if (file_exists($thumbPath)) {
        return $thumbImage;
    }
    return $images;
}

//获取图片全链接
function getFullImg($img){
        return C('WEBSITE_URL').'/'.$img;
}

//获取图片全链接
function getFullUrl($Url){
        return C('WEBSITE_URL').$Url;
}

/**
 * 推送
 * @param int $pust_type （推送类型：0：单播推送；1：广播推送；）
 * @param Array $data (传入参数)
 * $data['title']（标题）
 * $data['content']（内容）
 * $data['content_type'](内容类型 1、商品详情；2、网店主页；3、公告详情；4活动专区页；)
 * $data['content_id'](内容id)
 * $data['content_url'](wap网页url，兼容app内非原生页面)
 */
function push($pust_type=0,$registration_id='',$data=array()){
    include_once VENDOR_PATH . '/Push/autoload.php';
    $client = new JPush\Client(C('PUSH.AppKey'),C('PUSH.Master_Secret'));
    $title=$data['title'];
    $content=$data['content'];
    $extras=array(
        'content_type'=>$data['content_type'],
        'content_id'=>$data['content_id'],
        'content_url'=>$data['content_url'],
        'jiguang'
    );
    //单推
    if(!$pust_type){
        $client->push()
            ->setPlatform(array('ios', 'android'))
            // 一般情况下，关于 audience 的设置只需要调用 addAlias、addTag、addTagAnd  或 addRegistrationId
            // 这四个方法中的某一个即可，这里仅作为示例，当然全部调用也可以，多项 audience 调用表示其结果的交集
            // 即是说一般情况下，下面三个方法和没有列出的 addTagAnd 一共四个，只适用一个便可满足大多数的场景需求

            // ->addAlias('alias')
            //->addTag(array('tag1', 'tag2'))
            ->addRegistrationId($registration_id)

            ->setNotificationAlert($content)
            ->iosNotification($content, array(
                'sound' => 'sound.caf',
                // 'badge' => '+1',
                // 'content-available' => true,
                // 'mutable-content' => true,
                'category' => 'jiguang',
                'extras' => $extras,
            ))
            ->androidNotification($content, array(
                'title' => $title,
                // 'build_id' => 2,
                'extras' => $extras,
            ))
            ->message($content, array(
                'title' => $title,
                // 'content_type' => 'text',
                'extras' => $extras,
            ))
            ->options(array(
                // sendno: 表示推送序号，纯粹用来作为 API 调用标识，
                // API 返回时被原样返回，以方便 API 调用方匹配请求与返回
                // 这里设置为 100 仅作为示例

                // 'sendno' => 100,

                // time_to_live: 表示离线消息保留时长(秒)，
                // 推送当前用户不在线时，为该用户保留多长时间的离线消息，以便其上线时再次推送。
                // 默认 86400 （1 天），最长 10 天。设置为 0 表示不保留离线消息，只有推送当前在线的用户可以收到
                // 这里设置为 1 仅作为示例

                // 'time_to_live' => 1,

                // apns_production: 表示APNs是否生产环境，
                // True 表示推送生产环境，False 表示要推送开发环境；如果不指定则默认为推送生产环境

                'apns_production' => false,

                // big_push_duration: 表示定速推送时长(分钟)，又名缓慢推送，把原本尽可能快的推送速度，降低下来，
                // 给定的 n 分钟内，均匀地向这次推送的目标用户推送。最大值为1400.未设置则不是定速推送
                // 这里设置为 1 仅作为示例

                // 'big_push_duration' => 1
            ))
            ->send();
    }
    //群推
    else{
        $client->push()
            ->setPlatform(array('ios', 'android'))
            ->addAllAudience()
            ->setNotificationAlert($content)
            ->iosNotification($content, array(
                'sound' => 'sound.caf',
                // 'badge' => '+1',
                // 'content-available' => true,
                // 'mutable-content' => true,
                'category' => 'jiguang',
                'extras' => $extras,
            ))
            ->androidNotification($content, array(
                'title' => $title,
                // 'build_id' => 2,
                'extras' => $extras,
            ))
            ->message($content, array(
                'title' => $title,
                // 'content_type' => 'text',
                'extras' => $extras,
            ))
            ->options(array(
                // sendno: 表示推送序号，纯粹用来作为 API 调用标识，
                // API 返回时被原样返回，以方便 API 调用方匹配请求与返回
                // 这里设置为 100 仅作为示例

                // 'sendno' => 100,

                // time_to_live: 表示离线消息保留时长(秒)，
                // 推送当前用户不在线时，为该用户保留多长时间的离线消息，以便其上线时再次推送。
                // 默认 86400 （1 天），最长 10 天。设置为 0 表示不保留离线消息，只有推送当前在线的用户可以收到
                // 这里设置为 1 仅作为示例

                // 'time_to_live' => 1,

                // apns_production: 表示APNs是否生产环境，
                // True 表示推送生产环境，False 表示要推送开发环境；如果不指定则默认为推送生产环境

                'apns_production' => false,

                // big_push_duration: 表示定速推送时长(分钟)，又名缓慢推送，把原本尽可能快的推送速度，降低下来，
                // 给定的 n 分钟内，均匀地向这次推送的目标用户推送。最大值为1400.未设置则不是定速推送
                // 这里设置为 1 仅作为示例

                // 'big_push_duration' => 1
            ))
            ->send();
    }

    /**
     * 产生随机字串，可用来自动生成密码 默认长度6位 字母和数字混合
     * @param string $len 长度
     * @param string $type 字串类型
     * 0 字母 1 数字 其它 混合
     * @param string $addChars 额外字符
     * @return string
     */
    function rand_string($len=6,$type='',$addChars='') {
        $str ='';
        switch($type) {
            case 0:
                $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.$addChars;
                break;
            case 1:
                $chars= str_repeat('0123456789',3);
                break;
            case 2:
                $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.$addChars;
                break;
            case 3:
                $chars='abcdefghijklmnopqrstuvwxyz'.$addChars;
                break;
            case 4:
                $chars = "们以我到他会作时要动国产的一是工就年阶义发成部民可出能方进在了不和有大这主中人上为来分生对于学下级地个用同行面说种过命度革而多子后自社加小机也经力线本电高量长党得实家定深法表着水理化争现所二起政三好十战无农使性前等反体合斗路图把结第里正新开论之物从当两些还天资事队批点育重其思与间内去因件日利相由压员气业代全组数果期导平各基或月毛然如应形想制心样干都向变关问比展那它最及外没看治提五解系林者米群头意只明四道马认次文通但条较克又公孔领军流入接席位情运器并飞原油放立题质指建区验活众很教决特此常石强极土少已根共直团统式转别造切九你取西持总料连任志观调七么山程百报更见必真保热委手改管处己将修支识病象几先老光专什六型具示复安带每东增则完风回南广劳轮科北打积车计给节做务被整联步类集号列温装即毫知轴研单色坚据速防史拉世设达尔场织历花受求传口断况采精金界品判参层止边清至万确究书术状厂须离再目海交权且儿青才证低越际八试规斯近注办布门铁需走议县兵固除般引齿千胜细影济白格效置推空配刀叶率述今选养德话查差半敌始片施响收华觉备名红续均药标记难存测士身紧液派准斤角降维板许破述技消底床田势端感往神便贺村构照容非搞亚磨族火段算适讲按值美态黄易彪服早班麦削信排台声该击素张密害侯草何树肥继右属市严径螺检左页抗苏显苦英快称坏移约巴材省黑武培著河帝仅针怎植京助升王眼她抓含苗副杂普谈围食射源例致酸旧却充足短划剂宣环落首尺波承粉践府鱼随考刻靠够满夫失包住促枝局菌杆周护岩师举曲春元超负砂封换太模贫减阳扬江析亩木言球朝医校古呢稻宋听唯输滑站另卫字鼓刚写刘微略范供阿块某功套友限项余倒卷创律雨让骨远帮初皮播优占死毒圈伟季训控激找叫云互跟裂粮粒母练塞钢顶策双留误础吸阻故寸盾晚丝女散焊功株亲院冷彻弹错散商视艺灭版烈零室轻血倍缺厘泵察绝富城冲喷壤简否柱李望盘磁雄似困巩益洲脱投送奴侧润盖挥距触星松送获兴独官混纪依未突架宽冬章湿偏纹吃执阀矿寨责熟稳夺硬价努翻奇甲预职评读背协损棉侵灰虽矛厚罗泥辟告卵箱掌氧恩爱停曾溶营终纲孟钱待尽俄缩沙退陈讨奋械载胞幼哪剥迫旋征槽倒握担仍呀鲜吧卡粗介钻逐弱脚怕盐末阴丰雾冠丙街莱贝辐肠付吉渗瑞惊顿挤秒悬姆烂森糖圣凹陶词迟蚕亿矩康遵牧遭幅园腔订香肉弟屋敏恢忘编印蜂急拿扩伤飞露核缘游振操央伍域甚迅辉异序免纸夜乡久隶缸夹念兰映沟乙吗儒杀汽磷艰晶插埃燃欢铁补咱芽永瓦倾阵碳演威附牙芽永瓦斜灌欧献顺猪洋腐请透司危括脉宜笑若尾束壮暴企菜穗楚汉愈绿拖牛份染既秋遍锻玉夏疗尖殖井费州访吹荣铜沿替滚客召旱悟刺脑措贯藏敢令隙炉壳硫煤迎铸粘探临薄旬善福纵择礼愿伏残雷延烟句纯渐耕跑泽慢栽鲁赤繁境潮横掉锥希池败船假亮谓托伙哲怀割摆贡呈劲财仪沉炼麻罪祖息车穿货销齐鼠抽画饲龙库守筑房歌寒喜哥洗蚀废纳腹乎录镜妇恶脂庄擦险赞钟摇典柄辩竹谷卖乱虚桥奥伯赶垂途额壁网截野遗静谋弄挂课镇妄盛耐援扎虑键归符庆聚绕摩忙舞遇索顾胶羊湖钉仁音迹碎伸灯避泛亡答勇频皇柳哈揭甘诺概宪浓岛袭谁洪谢炮浇斑讯懂灵蛋闭孩释乳巨徒私银伊景坦累匀霉杜乐勒隔弯绩招绍胡呼痛峰零柴簧午跳居尚丁秦稍追梁折耗碱殊岗挖氏刃剧堆赫荷胸衡勤膜篇登驻案刊秧缓凸役剪川雪链渔啦脸户洛孢勃盟买杨宗焦赛旗滤硅炭股坐蒸凝竟陷枪黎救冒暗洞犯筒您宋弧爆谬涂味津臂障褐陆啊健尊豆拔莫抵桑坡缝警挑污冰柬嘴啥饭塑寄赵喊垫丹渡耳刨虎笔稀昆浪萨茶滴浅拥穴覆伦娘吨浸袖珠雌妈紫戏塔锤震岁貌洁剖牢锋疑霸闪埔猛诉刷狠忽灾闹乔唐漏闻沈熔氯荒茎男凡抢像浆旁玻亦忠唱蒙予纷捕锁尤乘乌智淡允叛畜俘摸锈扫毕璃宝芯爷鉴秘净蒋钙肩腾枯抛轨堂拌爸循诱祝励肯酒绳穷塘燥泡袋朗喂铝软渠颗惯贸粪综墙趋彼届墨碍启逆卸航衣孙龄岭骗休借".$addChars;
                break;
            default :
                // 默认去掉了容易混淆的字符oOLl和数字01，要添加请使用addChars参数
                $chars='ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'.$addChars;
                break;
        }
        if($len>10 ) {//位数过长重复字符串一定次数
            $chars= $type==1? str_repeat($chars,$len) : str_repeat($chars,5);
        }
        if($type!=4) {
            $chars   =   str_shuffle($chars);
            $str     =   substr($chars,0,$len);
        }else{
            // 中文随机字
            for($i=0;$i<$len;$i++){
                $str.= msubstr($chars, floor(mt_rand(0,mb_strlen($chars,'utf-8')-1)),1);
            }
        }
        return $str;
    }

}


/*
     * 输出json数据
     * 传入参数：$code 状态编码 $data 输出数据
     */
function _apiReturn($code,$data=array(),$msg=''){
	$CodeModel=new \CodeModel();
	$_data['code']=(is_numeric($code))?$code:$CodeModel->$code;
	empty($msg)?$_data['msg']=$CodeModel->codeMessage[$code]:$_data['msg']=$msg;
	$_data['data']=$data;
	$device=$this->checkDevice();
	if((count($_data['data'])==0||$_data['data']=='') && $_data['code']!=1){
		unset($_data['data']);
	}
	$_data['param']=I();
	exit(json_encode($_data));
}


/**
 * @param $url 请求网址
 * @param bool $params 请求参数
 * @param int $ispost 请求方式
 * @param int $https https协议
 * @return bool|mixed
 */
function curlRequest($url, $params = false, $ispost = 1, $https = 0)
{
	$httpInfo = array();
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
	if ($https) {
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // 对认证证书来源的检查
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // 从证书中检查SSL加密算法是否存在
	}
	if ($ispost) {
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
		curl_setopt($ch, CURLOPT_URL, $url);
	} else {
		if ($params) {
			if (is_array($params)) {
				$params = http_build_query($params);
			}
			curl_setopt($ch, CURLOPT_URL, $url . '?' . $params);
		} else {
			curl_setopt($ch, CURLOPT_URL, $url);
		}
	}

	$response = curl_exec($ch);

	if ($response === FALSE) {
		//echo "cURL Error: " . curl_error($ch);
		return false;
	}
	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$httpInfo = array_merge($httpInfo, curl_getinfo($ch));
	curl_close($ch);
	return $response;
}


/**
 * 获取当前用户是登录设备
 * device(1-pc，wap；3-android;4-ios；5-微信端)
 * @return string
 */
function NewCheckDevice(){
	$device = '1';//默认为PC、WAP端
	if(strpos($_SERVER["HTTP_USER_AGENT"],"MicroMessenger")){
		$device = '5';//微信
	}elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPhoneWeb')){
		$device = '4';//IOS
	}elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'Android')||$_SERVER['HTTP_USER_AGENT']=='Android'||strpos($_SERVER['HTTP_USER_AGENT'], 'AndroidWeb')||$_SERVER['HTTP_USER_AGENT']=='AndroidWeb'){
		$device = '3';//Android
	}

	return $device;

}


/**
 *  校验用户状态
 * @return array
 */
function checkUserStatus(){
	// 接受数据
	$member_id = I( 'param.member_id', '', 'intval' );
	$token     = I( 'param.token', '', 'trim' );

	if(empty($member_id)||empty($token)){
		return false;
	}

	$where = [
		't.member_id'=>$member_id,
		't.token'=>$token,
		'm.member_state'=>1		//状态 0：待激活 1：已激活 -1：标记删除',
	];
	// 校验用户状态
	$check = M('token')
		->alias('t')
		->field('t.member_id,t.token,m.member_mobile')
		->join('__MEMBER__ as m ON m.member_id = t.member_id')
		->where($where)
		->find();

	if (empty($check)) {
		cookie('member_id', 0);
		cookie('token', null);
		return false;
	}
	return $check;

}


/**
 *  接口请求日记
 * @param $url
 * @param $ip
 * @param $data
 * @return array|bool|mixed
 */
function port_log($url,$ip,$data){

	if(empty($url)){
		exit('url is empty!');
	}
	if(empty($ip)){
		exit('ip is empty!');
	}
	if(empty($data)){
		exit('data is empty!');
	}
	if(is_array($data)){
		$data = json_encode($data);
	}

	$addData = [
		'url' => $url,
		'ip' => $ip,
		'data' => $data,
	];
	$res = M('port_log')->add($addData);
	return $res ? $res : false;

}

/**
 * 循环创建目录
 * @param $dir
 * @param int $mode
 * @return bool
 */
function mk_dir($dir, $mode = 0755)
{
	if (is_dir($dir) || @mkdir($dir,$mode)) return true;
	if (!mk_dir(dirname($dir),$mode)) return false;
	return @mkdir($dir,$mode);
}

/*
 * 对问答信息进行签名
 * @param $info
 */
function signQuestion($info) {
    $key = signKey();
//    $key_size =  strlen($key);
//    echo "Key size: " . $key_size . "\n";

    $plaintext = json_encode($info);

    # 为 CBC 模式创建随机的初始向量
    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);


    # 创建和 AES 兼容的密文（Rijndael 分组大小 = 128）
    # 仅适用于编码后的输入不是以 00h 结尾的
    # （因为默认是使用 0 来补齐数据）
    $ciphertext = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key,
        $plaintext, MCRYPT_MODE_CBC, $iv);

    # 将初始向量附加在密文之后，以供解密时使用
    $ciphertext = $iv . $ciphertext;
    # 对密文进行 base64 编码
    $ciphertext_base64 = base64_encode($ciphertext);
    return $ciphertext_base64;
}

/**
 * 加解密的密钥
 * @return string
 */
function signKey() {
    return pack('H*', "bcb04b7e103a0cd8b54763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3");
}

/**
 * 将字符串解开，得到问答信息
 * @param $ciphertext
 */
function unsignQuestion($ciphertext_base64) {
    $key = signKey();


    # === 警告 ===
    # 密文并未进行完整性和可信度保护，
    # 所以可能遭受 Padding Oracle 攻击。
    # --- 解密 ---

    $ciphertext_dec = base64_decode($ciphertext_base64);

    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
    # 初始向量大小，可以通过 mcrypt_get_iv_size() 来获得
    $iv_dec = substr($ciphertext_dec, 0, $iv_size);

    # 获取除初始向量外的密文
    $ciphertext_dec = substr($ciphertext_dec, $iv_size);

    # 可能需要从明文末尾移除 0
    $plaintext_dec = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key,
        $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);

    return $plaintext_dec;
}

//发送curl请求
function postCurl ($url, $post_data, $type = 0)
{
	if ($type == 2) {//2：请求本地接口
		$url = 'http://' . $_SERVER['SERVER_NAME'] . $url;
	}
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}


/** 获取物流时间
 * @param $code -快递公司代码
 * @param $nu -物流单号
 * @return mixed
 */
function getLogistics($code, $nu)
{
	$url = 'https://www.kuaidi100.com/query?type=' . $code . '&postid=' . $nu;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
	$file_contents = curl_exec($ch);
	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	return json_decode($file_contents, true);
}

/**
 * @param int $type
 * @return bool
 */
function combing($type = 0, $form_time) {
    $adminModel = D('StoreAdmin');
    $res = $adminModel->getUserInfoById(session('sa_id'));
    if (empty($res)) {
        return false;
    }
    $data = array(
        'store_id' => $res['sa_store_id'],
        'store_admin_id' => session('sa_id'),
        'type' => $type,
        'lastmodified_time' => $form_time,
        'created_time' => $form_time
    );
    $storeCombRecord = D('StoreCombRecord');
    return $storeCombRecord->storeCombing($data);
}

/**
 * redis
 * author: zhou
 * @param  integer $select [description]
 * @return [type]          [description]
 */
function redis($select = 0)
{
    $redis = new \Redis();
    $host       = C('SESSION_REDIS_HOST') ? C('SESSION_REDIS_HOST') : '127.0.0.1';
    $port       = C('SESSION_REDIS_PORT') ? C('SESSION_REDIS_PORT') : 6379;
    $password   = C('SESSION_REDIS_AUTH') ? C('SESSION_REDIS_AUTH') : false;
    $timeOut    = C('SESSION_CACHE_TIME') ? C('SESSION_CACHE_TIME') : false;
    $persistent = C('SESSION_PERSISTENT') ? C('SESSION_PERSISTENT') : false;

    if($persistent == 1){
        $redis->pconnect($host, $port, $timeOut);
        $redis->popen($host, $port, $timeOut);
    } else {
        $redis->connect($host, $port, $timeOut);
        $redis->open($host, $port, $timeOut);
    }

    if( !empty($password)) $redis->auth($password);
    $redis->select((int)$select);
    return $redis;
}

function filterEmojiZ($str)
{
  $str = preg_replace_callback( '/./u',
      function (array $match) {
        return strlen($match[0]) >= 4 ? '' : $match[0];
      },
      $str);
   return $str;
}

/**
 * curl 发送 post 请求
 * @author fanzhaogui
 * @date 2019.10.23
 * @param $url
 * @param array $postData
 * @param array $header
 * @return mixed
 */
function curl_post($url, $postData = array(), $header = 'Content-type:application/x-www-form-urlencoded')
{
    $ch = curl_init($url);
    curl_setopt($ch,CURLOPT_HEADER,0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //返回数据不直接输出
    curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //指定gzip压缩

    //add header
    if(!empty($header) && is_array($header)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    }

    //add ssl support
    if(substr($url, 0, 5) == 'https') {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);    //SSL 报错时使用
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);    //SSL 报错时使用
    }
    //add 302 support
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    //curl_setopt($ch,CURLOPT_COOKIEFILE, $this->lastCookieFile); //使用提交后得到的cookie数据

    // 连接超时，数据加载超时
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    //add post data support
    if(!empty($postData)) {
        curl_setopt($ch,CURLOPT_POST, 1);
        if (is_array($postData)) {
            $sets = array();
            foreach ($postData AS $key => $val) {
                $sets[] = $key . '=' . urlencode($val);
            }
            $postData = implode('&', $sets);
        }
        curl_setopt($ch,CURLOPT_POSTFIELDS, $postData);
    }
    try {
        $content = curl_exec($ch); //执行并存储结果
    } catch (\Exception $e) {
        log2File($e->getMessage(), 'curl_post_err');
    }
    $curlError = curl_error($ch);
    if(!empty($curlError)) {
        log2File($curlError, 'curl_post_err');
    }
    curl_close($ch);
    return $content;
}

/**
 * 写入文件 ，日志
 * @param $content
 * @param string $filename
 * @author fanzhaogui
 * @date 2019.10.23
 */
function log2File($content, $filename='_empty_file_name_')
{
    try {
        if (!is_string($content)) {
            $content = var_export($content, true);
        }
        $content = date("Y-m-d H:i:s") . PHP_EOL . $content. PHP_EOL;

        $dir = './logs/'. date("Ymd", time()) . '/';
        $filename = $dir . $filename . '.log';
        if ( !is_dir($dir) ) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents($filename, $content, FILE_APPEND);
    }
    catch (\Exception $e) {

    }
}


function breadTitleDesc($title)
{
    $ext = '列表';
    if (strpos($title, $ext) === false) {
        return $title . $ext;
    }
    return $title;
}