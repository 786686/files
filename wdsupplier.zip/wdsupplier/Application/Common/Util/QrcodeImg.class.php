<?php
namespace Common\Util;

use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\QrCode;


/**
 * @desc   生成二维码
 * @author 建强  2020年3月13日 11:12:38
 *
 */
class QrcodeImg  
{
	const DIR_PATH = 'qr_img';
	/**
	 * @method 建强  2020年3月13日 
	 * @return string 二维码生成 
	 */
    public function create_qrcode($param,$display = 0){
    	
    	$param = http_build_query($param);
    	
    	$url    = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/Mobile/PreOrder/detail?'.$param;
    	
    	
    	//配置参数 
    	$qrsize   =  250;
    	$margin   =  5;
    	$img_type = 'png';
    	$encode   = 'UTF-8';
    	$logoPath = './Public/qr_img/logo.png';
    	$logoSize = 50; 
    	
    	
    	$qrCode   = new QrCode($url);
    	$qrCode->setSize($qrsize,$qrsize);
    	$qrCode->setWriterByName($img_type); 
    	$qrCode->setMargin($margin);           
    	$qrCode->setEncoding($encode);
    	
    	//二维码容错级别
    	$qrCode->setErrorCorrectionLevel(ErrorCorrectionLevel::HIGH());
    	
    	$qrCode->setForegroundColor(['r' => 0, 'g' => 0, 'b' => 0, 'a' => 0]);
    	$qrCode->setBackgroundColor(['r' => 255, 'g' => 255, 'b' => 255, 'a' => 0]);
    	$qrCode->setLogoPath($logoPath);
    	$qrCode->setLogoWidth($logoSize);
    	//$qrCode->setRoundBlockSize(true);
    	//$qrCode->setValidateResult(false);
    	//$qrCode->setWriterOptions(['exclude_xml_declaration' => true]);
    	
    	
    	if($display ==1){
    		header('Content-Type: '.$qrCode->getContentType());
    		ob_clean();
    		echo $qrCode->writeString();
    		die();
    	}
    	
    	$this->checkDir(self::DIR_PATH);
    	
    	$file ='./'.self::DIR_PATH.'/'.date('ymd').'_'.microtime(true).'.png'; 
    	$qrCode->writeFile($file);
    	
    	
    	$url_file = ltrim($file,'.');
    	$http_url = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/'.$url_file;
    	
    	return ['qr_url'=>$http_url,'file'=>$file];
    }
    /**
     * @method 生成文件图片
     * @author 建强  2020年3月13日 11:48:26
     * 
     * @return void
     */
    public function checkDir($dir = ''){
    	$file = APP_PATH.'../'.$dir;
    	
    	if(file_exists($file)) return true;
    	mkdir($file,0777,true);
    }

    /**
     * @method  合成二维码图片 填充背景图片 
     * @param string $store_name
     * @param number $display
     */
    public function imagecpoy($text = '',$qr_png = '',$display = 0){
    	
    	$bg_img =  './Public/qr_img/bg.png';
    	$font   =  ROOT_PATH.'/Public/qr_img/msyh.ttc';
    	$text   =  mb_convert_encoding($text,'utf-8');
    	$tip    =  mb_convert_encoding('请长按二维码识别内容','utf-8');
    	 
    	 
    	$bg_image = imagecreatefrompng($bg_img);
    	
    	$qr       = imagecreatefrompng($qr_png);
    	
    	//合成 背景图+二维码  坐标位置 x y  + 图像开始 xy+ 图片结束 xy
    	imagecopy($bg_image, $qr, 230, 500, 0, 0, 260,260);
    	 
    	//蓝色图片 
    	$color = imagecolorallocate($bg_image, 30, 144, 255); 
    	$gray = imagecolorallocate($bg_image, 0, 0, 0);
    	 
    	//字体颜色 
    	imagettftext($bg_image, 30, 0, 180, 100, $color, $font, $text);
    	imagettftext($bg_image, 20, 0, 230, 850, $gray, $font, $tip);
    	
    	//直接显示
        if($display == 1){
        	header('Content-type: image/png');
        	ob_clean();
        	imagepng($bg_image);
        	die;
        }
        
        //保存  
        $this->checkDir(self::DIR_PATH);
        
        $file = self::DIR_PATH.'/'.date('ymd').'_ad_'.time().rand(11111,99999).'.png';
        imagepng($bg_image,$file);
        
        //销毁内存
        imagedestroy($bg_image);
    	imagedestroy($qr);
    	
    	//返回图片地址
    	return  $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/'.$file;
    }
    
}