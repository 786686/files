<?php
namespace Common\Util;

use Common\Lib\Redis\Redis;

/**
 * @desc   阿里付费接口地址
 * @author 建强 2020年3月3日 
 * 
 */
class AliExpressApi
{
	 const EXPIRE_TIME       =  7200;   //2小时 
	 const EXPRESS_ADDR_INFO = 'EXPRESS_ADDR_INFO';

	 const  APPCODE          = '6e8a1e3ee8fc4ddda7d6cc5bf999d53e';  //公司编号


    /**
     * @method 获取物流完整信息
     * @return array
     */
    public static  function getExpressDetailBySn($sn = ''){
        try {
            if(empty($sn)) {
                return ['code'=>30001,'msg'=>'单号不能为空'];
            }

            //缓存结果
            $key = self::EXPRESS_ADDR_INFO.$sn;
            $res = Redis::getInstance()->get($key);

            if($res){
                return ['code'=>200,'msg'=>'success','data'=>json_decode($res,true)];
            }

            $res = self::search($sn);
            if(empty($res)){
                return ['code'=>'30004' , 'msg'=>'您的物流信息不存在'];
            }

            if($res['status']!=200){
                return ['code'=>'30005' , 'msg'=>'您的物流信息暂时没有更新'];
            }

            return ['code'=>200,'msg'=>'success','data'=>$res];

        }catch(\Exception $e){
            log2File($e->getMessage());
            return ['code'=>'30002' , 'msg'=>'系统繁忙请稍后'];
        }
    }


	 /**
	  * @method 获取快递地址
	  * @author 建强  2020年3月3日 13:47:39 
	  * @return array
	  */
     public static  function getExpressStatusBySn($sn = ''){
     	 try {
     	 	if(empty($sn)) {
     	 		return ['code'=>30001,'msg'=>'单号不能为空'];
     	 	}
     	 	 

     	 	$res  = self::getExpressApi($sn);

     	 	return $res;
     	 	
     	 }catch(\Exception $e){
     	 	log2File($e->getMessage());
     	 	return ['code'=>'30002' , 'msg'=>'系统繁忙请稍后'];
     	 }
     }

     /**
      * @method 获取快递100的接口
      * @param  $sn 
     */
     public static function getExpressApi($sn= ''){
         //缓存结果
         $key = self::EXPRESS_ADDR_INFO.$sn;
         $res = Redis::getInstance()->get($key);

         if($res){
             return ['code'=>200,'msg'=>'success','data'=>json_decode($res,true)['list']];
         }

         $res = self::search($sn);
     	 if(empty($res)){
     	 	 return ['code'=>'30004' , 'msg'=>'您的物流信息不存在'];
     	 }
     	 
     	 if($res['status']!=200){
     	 	 return ['code'=>'30005' , 'msg'=>'您的物流信息暂时没有更新'];
     	 }

         Redis::getInstance()->set($key, json_encode($res),self::EXPIRE_TIME);

     	 return ['code'=>'200' , 'msg'=>'操作成功','data'=>$res['list']];
     }

    /**
     * 查询物流
     *
     * @author: fanzhaogui
     * @param $sn
     * @return mixed
     */
     protected static function search($sn)
     {
         $host   = "https://kuaidi101.market.alicloudapi.com/getExpress";
         $method = "GET";

         $param  = [
             'NO'=>$sn,
             'TYPE'=>'AUTO',
         ];
         $headers = ["Authorization:APPCODE " . self::APPCODE];
         $querys  = http_build_query($param);
         $url     = $host.'?'.$querys;
         $res     = self::CurlHttp($url,$method,[],$headers);

         return json_decode($res,true);
     }

     /**
      * @method curl HTTP请求
      * @author 建强 2020年3月3日 14:24:21
      * 
      * @return array
      */
     public static function CurlHttp($url,$method ='GET',$data= [],$headers=[]){
     	 $method  = strtoupper($method);
     	 $curl   = curl_init();
     	 
      	 curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
     	 curl_setopt($curl, CURLOPT_URL, $url);
     	 
     	 if(!empty($headers)){
     	 	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
     	 }
     	 
     	 if($method == 'POST'){
     	 	curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
     	 }
     	 
     	 curl_setopt($curl, CURLOPT_FAILONERROR, false);
     	 curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
     	 curl_setopt($curl, CURLOPT_HEADER, false);
     	
     	 curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
     	 curl_setopt($curl, CURLOPT_TIMEOUT, 15);
     	 
     	 if (1 == strpos("$" . $url, "https://")) {
     		 curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
     		 curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
     	 }
     	 $result = curl_exec($curl);
     	 
     	 $info             = curl_getinfo($curl);
     	 $info['error_no'] = curl_errno($curl);
     	 
     	 if($info['error_no']>0){
     	 	log2File($info,'aliexpress'.date('ymd'));
     	 }
     	 curl_close($curl);
     	 return $result;
     }
}