<?php

namespace Common\Util;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;

/**
 *
 * @desc    优化导出需求 所有导出格式通过工具类
 * @author  宋建强   2020年1月10日 10:05:08
 */
class Exc
{
    private $_A1Desc;
    private $_A2Time;
    private $_field;
    private $_filename;
    private $_colomArr = [];
    private $_rgb = 'FFFFFF00';

    /**
     * @var \Common\Util\Exc
     */
    private static $_instance;

    private function __construct()
    {
    }

    private function __clone()
    {
    }

    /**
     * @method 单例模式  Spreadsheet 对象
     * @return \Common\Util\Exc
     */
    public static function getInstance()
    {
        if (!self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * @method 设置A1 行合并的标题
     * @param  string $a1
     */
    public function setA1Desc($A1 = '创客网店')
    {
        $this->_A1Desc = $A1;
        return $this;
    }

    /**
     * @method 设置第二行导出excel
     * @param string $a2
     */
    public function setA2Time($A2 = '')
    {

        if (empty($A2)) {
            $A2 = '导出数据时间 ：' . date('Y-m-d H:i:s');
        }

        $this->_A2Time = $A2;
        return $this;
    }

    /**
     * @method 设置导出的文件名称
     * @param string filename
     */
    public function setFileName($fileName = '')
    {

        if (empty($fileName)) {
            $fileName = '文件导出 ：' . date('Y-m-d H:i:s') . '.xls';
        }
        $this->_filename = $fileName . '.xls';

        return $this;
    }


    /**
     * 设置尾部数据
     *
     * @author: fanzhaogui
     * @param string $footer
     * @return $this
     */
    public function setFooter($footer = '')
    {
        if (empty($footer)) {
            $footer = '';
        }
        $this->_footer = is_array($footer) ? implode($footer,  '   ') : $footer;

        return $this;
    }

    /**
     * @method
     * @param  array $field
     */
    public function setField(array $field)
    {
        $this->_field = $field;
        return $this;
    }

    /**
     * @method 获取row 行高
     * @author 建强 2020年1月10日 10:17:08
     *
     * @return int 单位 pt
     */
    public function getRowHeight($row = 1)
    {

        switch ($row) {
            case 1:
                return 25.5;
                break;
            case 2 :
            case 3 :
                return 20;
                break;
            default:
                return 18;
                break;
        }

    }

    /**
     * @method 部分列宽设置宽带
     * @author 建强 2020年2月18日 14:00:41
     * @param  $colomArr .. ['E'=>28, ]
     * @return $this
     */
    public function setWidthArr($colomArr = [])
    {
        $this->_colomArr = $colomArr;
        return $this;
    }

    /**
     * @method 获取colom 列宽
     * @author 建强 2020年1月10日 10:17:08
     * @param  int $width
     *
     * @return int 单位 pt
     */
    public function getColomWidth($width = 0)
    {
        return $width > 0 ? $width : 15;
    }

    /**
     * @author  建强 2020年1月10日 10:26:55
     * @method  根据每行获取适当的行对应的字体大小
     *
     * @param   int $row
     * @return  int
     */
    public function getFontSizeByRow($row = 1)
    {
        switch ($row) {
            case 1:
                return 20;
                break;
            case 2 :
                return 11;
                break;
            default:
                return 10;
                break;
        }
    }

    /**
     * @method  设置字体
     * @author 建强 2020年1月10日 10:43:04
     *
     * @return string
     */
    public function getFontName()
    {
        return '宋体';
    }

    /**
     * @author  建强 2020年1月10日 10:43:59
     * @method  获取样式 应用数组
     *
     * @return array
     */
    public function getStyleArrayByRow($row = 1)
    {

        $style = [
            'font'      => [
                'name' => self::getFontName(),
                'size' => self::getFontSizeByRow($row)
            ],
            //内容水平居中  自动换行
            'alignment' => [
                'horizontal' => Alignment::HORIZONTAL_CENTER,
                'vertical'   => Alignment::HORIZONTAL_CENTER,
                'wrapText'   => true,
            ],
            //通用配置所有边框细线
            'borders'   => [
                'allBorders' => [
                    'borderStyle' => Border::BORDER_THIN,
                ],
            ],
        ];
        return $style;
    }
    
    /**
     * @author 建强  2020年4月13日 14:29:08
     * @method 导出excle 数据
     *
     * @return void
     */
    public function dumpExcelNoHeader(array $data,$save = false)
    {
        
        if (!is_array($data)) {
            E('数据格式错误');
        }
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        
        //渲染你标题数据
        $cel = 'A';
        //固定第三行
        foreach ($this->_field as $val) {
            if ($this->_colomArr && isset($this->_colomArr[$cel])) {
                $width =  $this->_colomArr[$cel] ?? 0;
                $sheet->getColumnDimension($cel)->setWidth($this->getColomWidth($width));
            } else {
                $sheet->getColumnDimension($cel)->setWidth($this->getColomWidth());
            }
            // 单元格内容写入
            $sheet->getRowDimension(1)->setRowHeight($this->getRowHeight(3));
            $sheet->setCellValue($cel . '1', $val);
            $sheet->getStyle($cel . '1')->applyFromArray($this->getStyleArrayByRow(3));
            
            $cel++;
        }
        
       
        
        //渲染主体数据data
        $row = 2;
        if (!empty($data)) {
            foreach ($data as $item) {
                $dataCol = 'A';
                $sheet->getRowDimension($row)->setRowHeight($this->getRowHeight($row));
                foreach ($item as $value) {
                    
                    $style = $this->getStyleArrayByRow($row);
                    
                    $sheet->getStyle($dataCol . $row)->applyFromArray($style);
                    $pType = DataType::TYPE_STRING;
                    $sheet->setCellValueExplicit($dataCol . $row, $value, $pType);
                    
                    if(isset($item['match']) && $item['match']=='匹配失败') {
                        $spreadsheet->getActiveSheet()->getStyle($dataCol . $row)
                        ->getFont()->getColor()->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_RED);
                    }
                    $dataCol++;
                }
                $row++;
            }
        }
        
        
        
        if($save == false){
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="' . $this->_filename . '"');
            header('Cache-Control: max-age=0');
            
            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
            ob_end_clean();
            $writer->save('php://output');
            die ;
        }
        
        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        ob_end_clean();
        $writer->save('./Uploads/'.$this->_filename);
    }
    
    /**
     * @author 建强 2020年1月10日 11:03:49
     * @method 导出excle 数据
     *
     * @return void
     */
    public function dumpExcel(array $data)
    {

        if (!is_array($data)) {
            E('数据格式错误');
        }
        $len         = count($this->_field);
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();

        //渲染你标题数据
        $this->renderHeaderAndTitle($sheet, $len);

        //渲染主体数据data
        $row = 4;
        if (!empty($data)) {
            foreach ($data as $item) {
                $dataCol = 'A';
                $sheet->getRowDimension($row)->setRowHeight($this->getRowHeight($row));
                foreach ($item as $value) {
                    $sheet->getStyle($dataCol . $row)->applyFromArray($this->getStyleArrayByRow($row));
                    $pType = DataType::TYPE_STRING;
                    $sheet->setCellValueExplicit($dataCol . $row, $value, $pType);
                    $dataCol++;
                }
                $row++;
            }
        }

        $this->renterFooter($sheet, $row);

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $this->_filename . '"');
        header('Cache-Control: max-age=0');

        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        ob_end_clean();
        $writer->save('php://output');

        die;
    }

    /**
     * @author 建强 2020年1月10日 11:36:04
     * @param  object $sheet
     *
     * @return  void
     */
    public function renderHeaderAndTitle($sheet, $len = 3)
    {

        $colomn = $this->getRowIndexKey();;

        //渲染主体 第一 第二行
        for ($i = 1; $i <= 2; $i++) {
            $cel = 'A' . $i . ':' . $colomn[$len - 1] . $i;

            $sheet->mergeCells($cel);
            $sheet->getStyle($cel)->applyFromArray($this->getStyleArrayByRow($i));
            $sheet->getRowDimension($i)->setRowHeight($this->getRowHeight($i));

            $title = ($i == 1) ? $this->_A1Desc : $this->_A2Time;
            $sheet->setCellValue('A' . $i, $title);
        }


        //渲染第三行标题
        $cel = 'A';
        //固定第三行
        foreach ($this->_field as $val) {
            if ($this->_colomArr && isset($this->_colomArr[$cel])) {
                $width =  $this->_colomArr[$cel] ?? 0;
                $sheet->getColumnDimension($cel)->setWidth($this->getColomWidth($width));
            } else {
                $sheet->getColumnDimension($cel)->setWidth($this->getColomWidth());
            }
            // 单元格内容写入
            $sheet->getRowDimension(3)->setRowHeight($this->getRowHeight(3));
            $sheet->setCellValue($cel . '3', $val);
            $sheet->getStyle($cel . '3')->applyFromArray($this->getStyleArrayByRow(3));

            $cel++;
            $i++;
        }
        //标题行添加背景
        $col = 'A3' . ':' . $colomn[$len - 1] . '3';
        $sheet->getStyle($col)->getFill()->setFillType(Fill::FILL_SOLID)
            ->getStartColor()->setARGB($this->_rgb);

    }


    /**
     * 尾部处理
     *
     * @author: fanzhaogui
     * @param object $sheet
     * @param $dataCol
     * @param $len
     */
    public function renterFooter($sheet, $len)
    {
        if (empty($this->footer)) return ;
        $cells = $this->getRowIndexKey();
        $dataCol = array_pop($cells);
        $cel = 'A' . $len . ':' . $dataCol . $len;

        $sheet->mergeCells($cel);
        $sheet->getStyle($cel)->applyFromArray($this->getStyleArrayByRow($len));
        $sheet->getRowDimension($len)->setRowHeight($this->getRowHeight($len));

        $sheet->setCellValue('A' . 1, $this->footer);
    }


    /**
     * 获取横向坐标
     *
     * @param array $headerTitle
     * @param int $rowNum
     *
     * @return array
     */
    public function getRowIndexKey()
    {
        $headerTitle = $this->_field;
        $key         = $startKey = ord("A");  //A--65
        $key2        = ord("@"); //@--64
        $Z_key       = ord("Z");
        $columArrKey = [];

        // 头部标题 -- 从第三行开始

        foreach ($headerTitle as $kh => $vh) {
            if ($key > $Z_key) {
                $key2  += 1;
                $key   = $startKey;
                $colum = chr($key2) . chr($key);//超过26个字母时才会启用
            }
            else {
                if ($key2 >= $startKey) {
                    $colum = chr($key2) . chr($key);//超过26个字母时才会启用
                }
                else {
                    $colum = chr($key);
                }
            }
            $columArrKey[] = $colum;
            $key++;
        }

        return $columArrKey;
    }
}