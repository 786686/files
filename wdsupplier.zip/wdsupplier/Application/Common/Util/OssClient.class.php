<?php

/**
 * OSS操作工具
 *
 */

namespace Common\Util;

use OSS\Core\OssException;
use OSS\OssClient as AliOssClient;

class OssClient
{


    /**
     * 阿里云oss实例
     * @var AliOssClient
     */
    private $_ossClient;

    /**
     *
     * @param string $accessKeyId 从OSS获得的AccessKeyId
     * @param string $accessKeySecret 从OSS获得的AccessKeySecret
     * @param string $endpoint 您选定的OSS数据中心访问域名，例如oss-cn-hangzhou.aliyuncs.com
     * @param boolean $isCName 是否对Bucket做了域名绑定，并且Endpoint参数填写的是自己的域名
     * @param array $config
     */
    public function __construct($accesskeyid = "", $accesskeysecret = "", $endpoint = "", $isCName = "")
    {
        if ($accesskeyid === "") $accesskeyid = C('aliyun.accessKeyId');
        if ($accesskeysecret === "") $accesskeysecret = C('aliyun.accessKeySecret');
        if ($endpoint === "") $endpoint = C('aliyun.oss_endpoint');
        if ($isCName === "") $isCName = C('aliyun.oss_iscname');
        $ossClient = new AliOssClient($accesskeyid, $accesskeysecret, $endpoint, $isCName);
        $this->setOssClient($ossClient);
    }

    /**
     *
     */
    public function getOssClient()
    {
        return $this->_ossClient;
    }

    /**
     *
     * @param object $ossClient
     */
    public function setOssClient($ossClient)
    {
        $this->_ossClient = $ossClient;
    }

    /**
     * 创建一个存储空间
     * acl 指的是bucket的访问控制权限，有三种，私有读写，公共读私有写，公共读写。
     * 私有读写就是只有bucket的拥有者或授权用户才有权限操作
     * 三种权限分别对应 (OssClient::OSS_ACL_TYPE_PRIVATE，OssClient::OSS_ACL_TYPE_PUBLIC_READ, OssClient::OSS_ACL_TYPE_PUBLIC_READ_WRITE)
     *
     * @param type $bucket 要创建的存储空间名称
     * @param type $ossAcl 权限
     * @return type
     */
    public function createBucket($bucket, $ossAcl = AliOssClient::OSS_ACL_TYPE_PUBLIC_READ_WRITE)
    {
        return $this->_ossClient->createBucket($bucket, $ossAcl);
    }

    /**
     * 创建虚拟目录
     */
    public function createObjectDir($bucket, $object)
    {
        $result = $this->_ossClient->createObjectDir($bucket, $object);
        if (is_null($result)) {
            return true;
        }
        return false;
    }

    /**
     * 删除object
     * @param class $ossClient OssClient实例
     * @param string $bucket 存储空间名称
     * @return null
     */
    public function deleteObject($bucket, $object)
    {
        $result = $this->_ossClient->deleteObject($bucket, $object);
        if (is_null($result)) {
            return true;
        }
        return false;
    }

    /**
     * 批量删除object
     * @param class $ossClient OssClient实例
     * @param string $bucket 存储空间名称
     * @return null
     */
    public function deleteObjects($bucket, $objects)
    {
        if (is_array($objects)) {
            $result = $this->_ossClient->deleteObjects($bucket, $objects);
            if (is_null($result)) {
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * 列出Bucket内所有目录和文件, 注意如果符合条件的文件数目超过设置的max-keys， 用户需要使用返回的nextMarker作为入参，通过
     * 循环调用ListObjects得到所有的文件，具体操作见下面的 listAllObjects 示例
     *
     * @param class $ossClient OssClient实例
     * @param string $bucket 存储空间名称
     * @return null
     */
    public function listObjects($bucket, $prefix, $delimiter = '/', $maxkeys = 1000, $nextMarker = '')
    {
        $options = array(
            'delimiter' => $delimiter,
            'prefix' => $prefix,
            'max-keys' => $maxkeys,
            'marker' => $nextMarker,
        );
        static $objects = [];
        static $prefixs = [];
        static $allsize = 0;
        $listObjectInfo = $this->_ossClient->listObjects($bucket, $options);
        $objectLists = $listObjectInfo->getObjectList(); // 文件列表
        $prefixLists = $listObjectInfo->getPrefixList(); // 目录列表
        if (!empty($objectLists)) {
            foreach ($objectLists as $objectrow) {
                $allsize += $objectrow->getSize();
                $objects[] = $objectrow->getKey();
            }
        }
        if (!empty($prefixLists)) {
            foreach ($prefixLists as $prefixrow) {
                $prefixs[] = $prefixrow->getPrefix();
            }
        }
        /**
         * 判断是否所有的结果都已经返回；
         * SDK返回结果是字符串,兼容布尔值
         * 'true'表示本次没有返回全部结果；'false'表示本次已经返回了全部结果。
         */
        $isTruncated = $listObjectInfo->getIsTruncated();
        if (is_string($isTruncated)) {
            $isTruncated = strtolower($isTruncated);
        }
        if ($isTruncated == 'true' || $isTruncated === true) {
            /**
             * 递归获取所有结果
             */
            $nextMarker = $listObjectInfo->getNextMarker();
            //如果文件过多，多次请求OSS可能会拒绝，最好能够迟缓执行递归
            $this->listObjects($bucket, $prefix, $delimiter, $maxkeys, $nextMarker);
        }
        return ['objectlist' => $objects, 'prefixlist' => $prefixs, 'size' => $allsize];
    }

    /**
     * 获取object meta, 也就是getObjectMeta接口
     * @param string $bucket 存储空间名称
     * @param string $object 对象路径
     * @return array
     */
    public function getObjectMeta($bucket, $object)
    {
        try {
            $objectMeta = $this->_ossClient->getObjectMeta($bucket, $object);
        } catch (OssException $e) {
            return [];
        }
        return $objectMeta;
    }

    /**
     * 拷贝object
     * 当目的object和源object完全相同时，表示修改object的meta信息
     * @param type $fromBucket
     * @param type $fromObject
     * @param type $toBucket
     * @param type $toObject
     * @param type $options
     * @return boolean
     */
    public function copyObject($fromBucket, $fromObject, $toBucket, $toObject, $options = array())
    {
        try {
            $this->_ossClient->copyObject($fromBucket, $fromObject, $toBucket, $toObject, $options);
        } catch (OssException $e) {
            $e->getErrorMessage();
            return false;
        }
        return true;
    }

    /**
     * 把本地变量的内容到文件
     *
     * 简单上传,上传指定变量的内存值作为object的内容
     * @param string $bucket 存储空间名称
     * @param string $object 对象路径
     * @param type $content
     * @param type $options
     * @return boolean
     */
    public function putObject($bucket, $object, $content, $options = array())
    {
        try {
            $this->_ossClient->putObject($bucket, $object, $content, $options);
        } catch (OssException $e) {
            $e->getErrorMessage();
            return false;
        }
        return true;
    }

    /**
     * 上传指定的本地文件内容
     *
     * @param string $bucket 存储空间名称
     * @param string $object 对象路径
     * @param type $filePath
     * @param type $options
     * @return boolean
     */
    public function uploadFile($bucket, $object, $filePath, $options = array())
    {
        try {
            $this->_ossClient->uploadFile($bucket, $object, $filePath, $options);
        } catch (OssException $e) {
            $e->getErrorMessage();
            return false;
        }
        return true;
    }

    /**
     *
     * @param type $bucket
     * @param type $object
     * @param type $timeout
     * @param type $method
     * @param type $options
     * @return boolean
     */
    public function signUrl($bucket, $object, $timeout = 3600, $method = 'GET', $options = NULL)
    {
        try {
            $signurl = $this->_ossClient->signUrl($bucket, $object, $timeout, $method, $options);
        } catch (OssException $e) {
            $e->getErrorMessage();
            return '';
        }
        return $signurl;
    }

}
