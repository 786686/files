<?php
return [
    //'配置项'=>'配置值'
    'URL_CASE_INSENSITIVE' => false,    // 区分URL大小写
    // 自定义配置
    'editor' => 'kindeditor', // 可选在线编辑器kindeditor,ueditor
    'upload_path' => 'Uploads', //上传根目录
    'upload_max_size' => 5242880, //最大上传文件大小（字节）
//	'upload_allow_exts' => array('jpg', 'gif', 'png', 'jpeg', 'rar', '7z', 'doc', 'docx', 'xlsx', 'avi', 'rm', 'rmvb', 'mkv', 'swf', 'flv', 'mp3', 'zip', 'mp4', 'xls', 'ppt', 'pptx', 'txt', 'pdf','m4a'), // 允许上传的文件类型
    'upload_allow_exts' => ['jpg', 'gif', 'png', 'jpeg'],
    'upload_autosub' => true, //自动创建子目录保存
    'upload_subname' => ['date', 'Y/m/d'], // 子目录URL_MODEL创建形式

    'ADMIN_ID' => 2,//超级管理员ID
    'DEVELOPER' => [1],//开发者
    'ALLOW_VIEWS_URL' => [],//允许访问的地址，模块/控制器/方法
    'WEBSITE_URL' => 'http://www.chuangkewd.com:8081', //在百度编辑器上有用到
    'timezone' => 8,//时区

    // 短信配置
    'smsconf' => [
        'validitytime' => 1800,//验证码有效时长（秒）
        'hour_num' => 6,//1小时限制次数
    ],
    //极光推送
    'PUSH' => [
        'AppKey' => '786b2ae29b3660bda5269a58',
        'Master_Secret' => 'be188242a72ab15cb1e741c9',
    ],

    //单位分
    'randommoney' => [
        'min' => 1,
        'max' => 100,
    ],

    //alioss
    'aliyun' => [
        'accessKeyId' => 'LTAIloWbsCa4ZpH7',
        'accessKeySecret' => 'VpZXKK7L871Sbe2c5efKHfbg5YgcrQ',
        'oss_endpoint' => 'http://oss-cn-shenzhen.aliyuncs.com',
        'oss_iscname' => true, // OSS是否使用自定义域名 只允许子用户使用角色（这是重点，此策略只能使用子用户角色）
        'bucket' => 'test-ckwd',
        'object' => 'ckwd',
    ],

    'allow_withdraw' => 1,//允许提现金额，单位元

    'alipay' => [
        'account' => 'wanxunnongye@126.com',
        'partner' => '2088231502450477',
        'secret' => 'gsfg9dj0yz8azam0kcrkfvznua06uye3',
        'account_name' => '茂名金陶电子商务有限公司',
        'url' => 'http://uatckwd.wxeepp.com/',//授权域名
        'notify_url' => 'http://uatckwd.wxeepp.com/index.php/Api/PayCallBack/alipayCallback',//支付回调url
        'appid' => '2019042364251523',
        'private_key' => 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCcPIhzbSULr+0zgvrh9WpGZpXQLG56ucnvdGlFY7AR3vEmy548/txl0PHCwduZxa3CmHqGgKa+YPhdvla/jaWqcyp3dBhejIa6UmeXrZ/M5oovCtnoWxr9563lmSCWLmenaXMjCC5uo/4OgjyQrc+mm4ZztsT6Zm0YMZ7YwzUnMQGqbecNifYyOamnIK7bLAvER8dipfPNN+YFQw2Dv4vyD7DdvBe/rZbrTwOI4Ew2yLK25DiyvT7eirsVyu9rU7FAKDYkAGgmYOEE6jdXv70rB2sNwtLBriqUuxbsRLn5AY3IeJChEtry4bzTt6Igqyd3/SiaN+a/+M44edJF9LSbAgMBAAECggEAJRsnWSqp6r2su1g3V6UeyXuhxyBWWOV5NVrTibxkW8o0Qf+IJHpvQ+s9EAFUs4/Edfwa1YkGkR6cvj7vgW0V1Ianplk3VHVRpjzeB6Mf2d1DImsUV+ATaAw3O9mDaMe6rIMZ6k8OIA7ozu9VjRMKx0oWw7K707Cx5lYaoOaz4Aufl0g6LYAFzn0gFGyFcAgbRxxU35iBi/6ieTqyYi45bGxnrBO//ILdoGtC7I9hLp36LmYB0FQGBS2KUkQF33Rz+HIgi7VL4NgeP3bm65HFmHVI1lqzcooUGC+GTpW3pMhObJWzBtUNuTPauirrkHc71nNvYejsw3ZeJeymhv9IiQKBgQDImvAUFJXcN5UEoLEQ/6RGGdrgLYqn7W8aDSd7YDoE59xMsuUxrj67vqNnooil1SAtJTaX7mWxs+0If55bEiIRmUnl6D6spMYawK04sj8m6cBeH2Zef4NcFOjl8XsOcL971gxY9KJmw0pJ9IOXm5hqGCmM8CwKtt6FsEMt7+wPtwKBgQDHYRrz40GlEHQEebRJKXsegntPpelT2/cz80kvaJK9t0sfeeCmnFTqrfJkU+iJhEsa75rXg5ebfRbbCIrA7cWoUjaaFXhq9lSCvcv2qXAvuDmwyJsnadRAU2MZYEyaI68+MQ0s/ZrLz+iy5nqN8VTrCWzZVd1eZ+KukMC5jwa6PQKBgQDGg7zMwkpCsKZA/Bv9LF4OGQvmCGtMHsRxTU8i4mjH7gKty+LPNRVTiSX/KnJ7WNsMkeTimMH+BoWsgU3d5aXdMIpWf2t2QWDhnIZOsuWXxn3dJsmQ/jKp7u9CjaMu+Rgknf9+ECid9OgRI20NnKZJZzvHAu0ydSDjvzfbv68lJQKBgH9YW4G4/l2yk5ekMG2ma/gBuUcXHl+smEj7NBxuu4MnRnk1PDLOmUJHlhFUsqra76mlro3GhBgRHn8KBq3RcLTgxfVGj2IqMbJMDbFfacNg9KAgkVDsPGBVom873dF5x11+sP6ygKN7CRLzOQXeRbHVlEuAl2LMEbITzLT4UIC1AoGAEetmFcB0GdlSyMOE85AB72LcypK4EHNaug6yNU+LWa8F5nNVuWDXttzMEUU9uKysSGK969/sbIQojGpdiiojeY92VC1pZgOEqq+w/XbUIuDVdNiV1U8dbEblVlywz7ZlgIGOWpqyX1mQxhcWcI8o6qChGmyLSrS/QMJmcuS6LFc=',
        'alipay_public_key' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAobdAilqr91ATK0oeKMwvPKOnW7Jwv1GvrPBJBZ9Pr7Bf3RZkwBCtaYsbdQ/xT0G7PazAj/uMJVHekMKStaoKYOEAsTSl1H4NxX3Cx0F0hgeaaWd04TyGsInJnOAx9dRAbMV6KGdegP4nA8c0Fhfn7QRsOwtcgDA9J4G/LXDUt1H1n6iAIedUNQ07H1q8BzRuoN3AztefqjjTqyYb2Q4V4nECLkI102LJ3wfq4FGMjln+QCOvqGKbI2qoxNe8zjHZ8bwEhm3CZ415EAnrL+qBxkl4uNeqPLHTWf9RgaSsJlCjvWsQQ1d0roDPa2Lwlpj2typQz2UiEGxwNu4veFX9MwIDAQAB',
    ],

    /* 微信号 */
    'wxpay' => [
        'appid' => 'wxe58848faf19617eb',//公众号appid
        'appsecret' => 'b4f6e38237f3534a513ed7cff6deb3c9',//公众号appsecret
        'mchid' => '1388613902',//商户ID
        'partnerkey' => 'Wxwnygfgs13886139021388613902wxw',//支付密钥
        'url' => 'http://uatckwd.wxeepp.com',//授权域名
        'notify_url' => 'http://uatckwd.wxeepp.com/index.php/Api/PayCallBack/wxpay_notify',//
        'sslkey_path' => getcwd() . realpath(ROOT_PATH) . '/Application/Common/Conf/cert/cert_jintao/apiclient_key.pem',//授权域名
        'sslcert_path' => getcwd() . realpath(ROOT_PATH) . '/Application/Common/Conf/cert/cert_jintao/apiclient_cert.pem',//授权域名
    ],

    /*App 微信支付配置 */
    'wxpay_app' => [
        'appid' => 'wxe58848faf19617eb',//appid
        'appsecret' => '72df9d80f0e982d997c2d0045f0cfd08',//appsecret
        'mchid' => '1388613902',//商户ID
        'partnerkey' => 'Wanxunnongyeabc12345678912345678',//支付密钥
        'url' => 'http://uatckwd.wxeepp.com',//授权域名
        'notify_url' => 'http://uatckwd.wxeepp.com/index.php/Api/PayCallBack/wxpay_notify',//支付回调url
        'sslkey_path' => getcwd() . realpath(ROOT_PATH) . '/Application/Common/Conf/cert/cert_wt/apiclient_key.pem',//证书
        'sslcert_path' => getcwd() . realpath(ROOT_PATH) . '/Application/Common/Conf/cert/cert_wt/apiclient_cert.pem',//证书
    ],


    'INSTALL_TIME' => 1475251200,//系统安装时间

    /*
    * API校验权限密串
    */
    'QzApi' => [
        'appKey' => 'w1ozJ12P5XcCseR5',
        'appSecret' => 'IcksMeb8C2BDJ50fbxlohToEF6scxOdD',
    ],

    /*
     * API版本权限
     */
    'debug_tips' => true, //调试信息
    'allow_version' => ['1.0'], //允许的api版本
    'aband_version' => [], //弃用的api版本
    'apiVersion' => '1.0',

    'api_token_time' => 7200,//单位秒，两小时

    //合作单位性质
    'property' => [
        1 => ['property_id' => 1, 'property_name' => '政府机构'],
        2 => ['property_id' => 2, 'property_name' => '行政机关'],
        3 => ['property_id' => 3, 'property_name' => '事业单位'],
        4 => ['property_id' => 4, 'property_name' => '企业单位'],
        5 => ['property_id' => 5, 'property_name' => '社会团体'],
        6 => ['property_id' => 6, 'property_name' => '民办非企业'],
        7 => ['property_id' => 7, 'property_name' => '其他依法成立机构'],
    ],
    //合作单位列表
    'property_list' => [
        1 => [//政府机构
            'company_list' => [
                ['content' => '合作机构名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                ['content' => '所属部门与职位'],
                ['content' => '真实姓名'],
                ['content' => '工号'],
                ['content' => '直属上级'],
            ],

        ],
        2 => [//行政机关
            'company_list' => [
                ['content' => '合作机构名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                ['content' => '所属部门与职位'],
                ['content' => '真实姓名'],
                ['content' => '工号'],
                ['content' => '直属上级'],
            ],

        ],

        3 => [//事业单位
            'company_list' => [
                ['content' => '合作单位分类', 'classification' => [
                    ['personal_id' => 1, 'content' => '学校'],
                    ['personal_id' => 2, 'content' => '其他事业单位'],
                ]],
                ['content' => '合作机构名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                1 => [//学校
                    ['content' => '所属学院'],
                    ['content' => '所在专业'],
                    ['content' => '职业身份', 'classification' => [
                        ['personal_id' => 2, 'content' => '老师'],
                        ['personal_id' => 1, 'content' => '学生'],
                    ]],
                    ['content' => '真实姓名'],
                    ['content' => '学号工号'],
                    ['content' => '直属上级'],
                ],
                2 => [//其他事业单位
                    ['content' => '所属部门与职位'],
                    ['content' => '真实姓名'],
                    ['content' => '工号'],
                    ['content' => '直属上级'],

                ],
            ],

        ],

        4 => [//企业单位
            'company_list' => [
                ['content' => '合作机构名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                ['content' => '真实姓名'],
                ['content' => '工号'],
                ['content' => '直属上级'],
            ],

        ],
        5 => [//社会团体
            'company_list' => [
                ['content' => '合作团体分类', 'classification' => [
                    ['personal_id' => 1, 'content' => '工会'],
                    ['personal_id' => 2, 'content' => '社会团体'],
                ]],
                ['content' => '合作团体名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                1 => [//工会
                    ['content' => '公会名称'],
                    ['content' => '担任职位'],
                    ['content' => '直属上级'],
                ],
                2 => [//社会团体
                    ['content' => '团体名称'],
                    ['content' => '担任职位'],
                    ['content' => '直属上级'],
                ],
            ],

        ],
        6 => [//民办非企业
            'company_list' => [
                ['content' => '合作团体分类', 'classification' => [
                    ['personal_id' => 1, 'content' => '工会'],
                    ['personal_id' => 2, 'content' => '社会团体'],
                ]],
                ['content' => '合作团体名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                1 => [//民办认证
                    ['content' => '所属部门与职位'],
                    ['content' => '真实姓名'],
                    ['content' => '工号'],
                    ['content' => '直属上级'],
                ],
                2 => [//个体商户
                    ['content' => '所属部门与职位'],
                    ['content' => '真实姓名'],
                    ['content' => '工号'],
                    ['content' => '直属上级'],
                ],
            ],

        ],
        7 => [//其他依法成立机构
            'company_list' => [
                ['content' => '合作机构名称'],
                ['content' => '法定代表名称'],
                ['content' => '组织机构代码'],
                ['content' => '直属上级'],
            ],
            'personal_list' => [
                ['content' => '所属部门与职位'],
                ['content' => '真实姓名'],
                ['content' => '工号'],
                ['content' => '直属上级'],
            ],
        ],
    ],

    //阿里大鱼(创客移植)
    'alidayu' => [
        'switch' => 1,
        'App_Key' => 'LTAI4FhJj2rUHYsgeB5b9FaE', //23343802
        'App_Secret' => '8a7pzR7WSiz5qiyVJOZS4EvC45avaj' //41db88199a6016ed3a59b93c953feb7b
    ],

    /**
     * 万讯平台基础服务
     * API
     */
    'wxservice' => [
        'appKey' => 'UoCXC6c7FHBcOMFcjH7o',
        'appSecret' => 'Lr1P5IZ8RSR7f8Ke944s7iIK8RP7n7I77ZsUS181Fsf',
        'url' => 'http://test.service.wx7z.com/index/index/entry',
    ],

    'wxkj' => [
        'url' => 'http://wxrelease.wxeepp.com/',
    ],

    'admin_api_code' => '88888888',
    //企业采购超市
    'company_store_id' => 0,

    // app分享下载配置
    'app_share_title' => '创课网店',    //分享标题
    'app_share_content' => '点击下载创课网店APP',    //分享标题
    'app_share_image' => 'Public/Mobile/images/wanxunlogo.jpg',    //分享图片
    'app_share_link' => '/Mobile/App/appDownload',     //分享链接
    'ios_download_link' => 'https://itunes.apple.com/cn/app/%E4%B8%87%E8%AE%AF%E4%B8%83%E5%AD%90/id1142925058?mt=8',     //ios下载链接
    'android_download_link' => 'https://sj.qq.com/myapp/detail.htm?apkName=com.wanxun.seven.kid.mall',     //android下载链接

    'ck_conf' => [
//        'url'                => 'http://flat.wxeepp.cc/Mobile/Api/getPostData', // 本地配置的虚拟域名
        'url' => 'http://www.chuangkewd.com:8081/Mobile/Api/getPostData', // 本地配置的虚拟域名
        'v' => '3.0', //版本
        // 请求创客相应的接口
        'user_status_method' => 'StudentCurriculum.checkStudent', //用户状态同步请求
        'school_data_method' => 'StudentCurriculum.schoolInfo', //学校院系班级请求
        'store_data_method' => 'StudentCurriculum.getShopList', //学校院系班级请求

        // 2019-11-06
        'App_Secret' => 'LSK3kzm5sA2vUSWSFUpokBjNgQ1I0sy4gFRR1Qelbap',
        'App_Key' => '1W2PuwAHrfge6k2q',
//        'base_api_url'       => 'http://flat.wxeepp.cc/api.php/Index/entry',
        'base_api_url' => 'http://www.chuangkewd.com:8081/api.php/Index/entry',
    ],

    'OSS_URL' => 'http://test-ckwd.oss-cn-shenzhen.aliyuncs.com/',

    'SHARECODE' => 'WANXUNCHUANGKE',

    /* 提现余额时间 */
    'cash_time' => [
        '10' => 0,            // T+0
        '20' => 86400,        //T+1
        '30' => 86400 * 2,    //T+2
        '40' => 86400 * 3,    //T+3
        '50' => 86400 * 4,    //T+4
        '60' => 86400 * 5,    //T+5
        '70' => 86400 * 6,    //T+6
        '80' => 86400 * 7,    //T+7
        '90' => 86400 * 8,    //T+8
        '100' => 86400 * 9,    //T+9
        '110' => 86400 * 10,    //T+10
    ],

    // 余额提现申请限制
    'cash_set' => [
        'top_count' => 2,       //每天提现限制次数
        'min_cash' => 0.1,
        'max_cash' => 10000,
    ],

    'wechat_transfer_env' => 0, // 0 = 本地，测试 ; 1 =uat ; 2 = 正式

    /**
     * 扩展配置
     *
     * @see https://www.kancloud.cn/manual/thinkphp/1693
     */
    'LOAD_EXT_CONFIG' => 'db, redis, session',

];
