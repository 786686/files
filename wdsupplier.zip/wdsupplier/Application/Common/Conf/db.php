<?php

return [
    /* 数据库设置 */
    'DB_TYPE' => 'mysql',     // 数据库类型
    'DB_HOST' => '192.168.123.231', // 测试服务器地址
    'DB_NAME' => 'wkwd_supplier_dev',   // 测试环境数据库名
    'DB_USER' => 'root',            // 用户名
    'DB_PWD' => 'test_wxeepp_com', // 测试密码
];