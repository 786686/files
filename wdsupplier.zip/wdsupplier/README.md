## 分支管理

常用命令

`git clone [remote_url]`

`git pull origin [branch_name]`

`git rebase [branch_name]`  `git merge`

`git push origin [origin_branch_name]`

`git checkout branch_name `  切换分支

`git checkout -b branch_name `  基于当前分支，创建新分支，并跳转到新分支



## 代码分支

* master
* uat
* dev 
* release
* feature
* bug_fix



## 代码发布流程

>  1 开发新的功能

确保在`mater`分支下 `git checkout -b feature/[功能描述]` 

如 : 需要做一个客服功能`git checkout -b feature/service`

> 2 修复紧急bug

确保在`master`分支下，执行 `git c heckout -b bug_fix/[修复bug的描述]`

如： 登入问题  `git checkout -b bug_fix/login_error`

> 3 开发人员自己测试

本地测试没有问题

线上测试

使用  `dev` 分支， `git checkout dev` `git merge [开发分支]`

> 4 测试人员测试

切换到uat分支 `git checkout uat` 然后合并 `git merge [功能分支|bug分支]`

> 5 发布代码-并测试

切换到 `master`，创建一个新的 release分支，名称以 release/日期，如 `git checkout -b release/20191109`

发布到线上，并测试

> 6 测试如果出现问题，快速切换到最近的一个 `relese`分支，进行版本回退

> 7 没有任何问题，将release分支合并到master分支

在release分支执行`git rebase master` 保证master分支的干净

如有冲突，就解决冲突

切换到 `git checkout master `

合并最新的代码`git merge release/20191109`

