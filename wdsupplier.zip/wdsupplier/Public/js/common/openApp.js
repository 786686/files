 var is_share = getQueryString('is_share');
 var member_id = getCookie('member_id');
 var shareCode = getQueryString('shareCode');
 var timeout = 3000,
     timer = null;

 function GetMobelType() {
     var browser = {
         versions: function() {
             var u = window.navigator.userAgent;
             return {
                 trident: u.indexOf('Trident') > -1, //IE内核
                 presto: u.indexOf('Presto') > -1, //opera内核
                 Alipay: u.indexOf('Alipay') > -1, //支付宝
                 webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                 gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
                 mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                 ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                 android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
                 iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //
                 iPad: u.indexOf('iPad') > -1,
                 webApp: u.indexOf('Safari') == -1,
                 weixin: u.indexOf('MicroMessenger') > -1,
                 qq: u.match(/\sQQ/i) !== null,
                 Safari: u.indexOf('Safari') > -1,
                 ///Safari浏览器,
             };
         }()
     };
     return browser.versions;
 }

 function testApp() {
     var location = window.location.href;
     var start = location.indexOf('store_id/');
     var end = location.indexOf('?');
     store_id = location.substring(start, end);
     var split_store_id = store_id.split('/');
     var shareCode = getQueryString('shareCode');
     var myurl = "wxmaker://StoreDetail?" + split_store_id[0] + "=" + split_store_id[1] + '&shareCode=' + shareCode;
     if(location.indexOf("registersuccess")>-1){//注册成功跳进来app的
         myurl = "wxmaker://StoreDetail";
     }
     if (GetMobelType().weixin || GetMobelType().qq) {
         $("#bgCoverOPen").show();
     } else {
         var startTime = Date.now();
         if (GetMobelType().android) { // android
             var btnArray = ['下载APP', '打开APP']; //注意这里的顺序是先否再是
             mui.confirm("请用APP打开", '提示', btnArray, function(e) {
                 if (e.index == 1) {
                     window.location.href = myurl;
                 } else {
                     window.open("https://sj.qq.com/myapp/detail.htm?apkName=com.wanxun.maker");
                 }
             })
         }
         if (GetMobelType().ios || GetMobelType().iPhone || GetMobelType().iPad) { // ios
             var btnArray = ['下载APP', '打开APP']; //注意这里的顺序是先否再是
             mui.confirm("请用APP打开", '提示', btnArray, function(e) {
                 if (e.index == 1) {
                     window.location.href = myurl;
                 } else {
                     window.location.href = "https://itunes.apple.com/cn/app/id1111450338?mt=8";
                 }
             });

         }
     }
 }
 $(document).on('visibilitychange webkitvisibilitychange', function() {
     var tag = document.hidden || document.webkitHidden;
     if (tag) {
         clearTimeout(timer);
     }
 })
 $(window).on('pagehide', function() {
     clearTimeout(timer);
 });
 //如果是分享页过来就打开创课App
 if (GetMobelType().weixin || GetMobelType().qq) {
     $("#share-box").show();
 }
 //分享出来的就检测有没有APP打开
 if (is_share == 1) {
     if (GetMobelType().android || GetMobelType().iPhone) {
         testApp();
     }
 }

 $("#share-box").on('click', function() {
    //  $("#share-box").hide();
 });