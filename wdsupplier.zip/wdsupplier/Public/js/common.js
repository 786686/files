//获取cookie
function getCookie(c_name)
{
    return $.cookie(c_name);
}
//设置cookie
function setCookie(c_name,c_value){
    $.cookie(c_name,c_value,{expires:1,path:'/'});
}

/**
 * 拼接 GET.URL 参数
 * @author deason 2017-03-17
 * @param  {string} url    URL连接
 * @param  {mixed}  params 需要拼接的参数
 *                         ex. object(JSON): {param_a: value_a, param_b: value_b}
 *                         ex. string: 'param_a=value_a&param_b=value_b'
 * @return {string}        拼接后的连接
 */
function spliceUrl(url, params) {
	if (!params) {
		return url;
	}
	if (typeof params == 'object') {
		var a = [];
		for( key in params ) {
			a.push(key + '=' + params[key]);
		}
		// return url + getUrlSpliceSymbol(url) + a.join('&');
		// 将锚点移动至最后
		return url.replace(/(#.*)|$/, getUrlSpliceSymbol(url) + a.join('&') + '$1');
	}
	return url.replace(/(#.*)|$/, getUrlSpliceSymbol(url) + params + '$1');
}

/**
 * [getQueryString 获取url地址参数]
 * @author zwl
 * @DateTime 2019-02-21T10:06:21+0800
 * @param    {[type]}                 name [参数名]
 * @return   {[type]}                      [参数]
 */
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var reg_rewrite = new RegExp("(^|/)" + name + "/([^/]*)(/|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    var q = window.location.pathname.substr(1).match(reg_rewrite);
    if (r != null) {
        return unescape(r[2]);
    } else if (q != null) {
        return unescape(q[2]);
    } else {
        return null;
    }
}

/**
 * 获取 GET.URL 拼接符号
 * @author deason 2017-03-17
 * @param  {string} url URL连接
 * @return {string}     后续连接符号
 */
function getUrlSpliceSymbol(url) {
	return (url.search(/\?/) != '-1') ? '&' : '?';
}

/**
 * [postAjax 公共ajax]
 * @author zwl
 * @DateTime 2019-02-21T10:09:18+0800
 * @param    {[type]}                 data [请求参数]
 * @param    {[type]}                 func [回调函数]
 * @return   {[type]}                      [description]
 */
function postAjax(data, func) {
    var timer = setTimeout(function() {
        layer.load(2);
    }, 500);

    $.ajax({
        url: data.url,
        type: data.type,
        dataType: 'json',
        data: data.params,
        success: function(result) {
            clearTimeout(timer);
            layer.closeAll();
            if (result.status == 1) {
                func(result);
            } else {
                layer.closeAll();
                if (result.info) {
                    layer.msg(result.info, { time: 1500, icon: 5 });
                } else {
                    layer.msg(result.data.info, { time: 1500, icon: 5 });
                }

            }
        },
        error: function(error) {
            layer.closeAll();
            layer.msg('服务器异常，请联系管理员！', { time: 1500, icon: 5 });
        }
    })
}

Array.prototype._forEach = function(func) {
    for (var i = 0, j = this.length; i < j; i++) {
        var item = this[i];
        func(item, i);
    }
}
