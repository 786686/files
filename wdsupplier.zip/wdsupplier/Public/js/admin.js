//全局图片上传配置
var swf = "__PUBLIC__/js/webuploader/Uploader.swf";
var server = "<{:U('Admin/Gallery/uploadImg')}>";

$(function(){
	//二级菜单展开效果
	$('#header_menu').find('.menu_li').click(function(){

		if(!$(this).is('.is_only')) {

			if(!$(this).next('.next_menu_ul').is(":animated")) {


				if($(this).is('.on')){
					$(this).removeClass('on');
					$(this).next('.next_menu_ul').slideToggle();

					return false;

				}else {
					$(this).parent().siblings().find('.menu_li').removeClass('on');
					$(this).parent().siblings().find('.next_menu_ul').slideUp();

					$(this).addClass('on');
					$(this).next('.next_menu_ul').slideToggle();

					return false;
				}

			}

		}
	});

});